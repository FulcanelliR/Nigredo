#!/usr/bin/env python3
"""nigredo launcher.

Run this directly instead of `python -m prima_materia`:

    python run.py engagement-init
    python run.py engagement
    python run.py engagement --dry-run

This avoids the nested-package / venv name-collision issues entirely:
the code lives in the ./prima_materia/ package, and this script just calls its
entry point.
"""
import sys
import os
from pathlib import Path

# make sure this folder is importable no matter where it's launched from
sys.path.insert(0, str(Path(__file__).resolve().parent))


def _relaunch_under_script():
    """Capture the ENTIRE terminal session — user keystrokes and all subprocess
    output (ffuf/nuclei/ferox that write straight to the terminal) — by re-exec'ing
    this run under the Unix `script` utility, which records a faithful transcript.

    A pure-Python stdout tee would MISS subprocess output that writes directly to
    the terminal fd and would miss the echo of typed input; `script` captures all
    of it. We only relaunch once (guarded by NIGREDO_TRANSCRIPT) and only if
    `script` exists and we're on a TTY (interactive). Non-interactive/automated
    runs and environments without `script` fall through and run normally.
    """
    import shutil

    if os.environ.get("NIGREDO_TRANSCRIPT"):
        return  # already inside our script session — don't relaunch
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        return  # non-interactive (piped/automated) — don't wrap
    if shutil.which("script") is None:
        return  # no `script` available — run normally (Python-side logs still exist)
    if os.environ.get("NIGREDO_NO_TRANSCRIPT") == "1":
        return  # explicit opt-out

    import time
    ts = time.strftime("%Y%m%d_%H%M%S")
    # transcript lands in ./transcripts/ next to the launcher; created up front.
    tdir = Path(__file__).resolve().parent / "transcripts"
    try:
        tdir.mkdir(exist_ok=True)
    except OSError:
        return  # can't make the dir — just run normally
    transcript = tdir / f"nigredo_session_{ts}.txt"

    # Rebuild the command we were invoked with, for `script -c` to re-run.
    #
    # CRITICAL: we must relaunch through the SAME interpreter/venv we're running
    # in now. Using a bare `sys.executable` here silently drops the uv venv (uv
    # runs the venv's python, but re-invoking that python path directly under
    # `script` loses uv's environment resolution) — the relaunched process then
    # can't import venv-only deps (openpyxl, etc.) and blows up mid-pipeline.
    #
    # So: if we were launched under uv (or uv is resolvable), re-enter via
    # `uv run python …`, which guarantees the venv interpreter + deps. Only fall
    # back to the raw interpreter if uv genuinely isn't available.
    launcher = str(Path(__file__).resolve())
    inner_argv = None
    running_under_uv = bool(
        os.environ.get("UV")
        or os.environ.get("VIRTUAL_ENV")
        or os.environ.get("UV_INTERNAL__PARENT_INTERPRETER")
    )
    try:
        from prima_materia.toolsetup import _uv_bin
        uv_bin = _uv_bin()
    except Exception:
        uv_bin = ""

    # Prefer uv whenever we can resolve it — it keeps the venv intact across the
    # re-exec. `uv_bin == "uv"` is the last-resort "assume on PATH" value; only
    # trust it if we have other evidence we're in a uv/venv context.
    import shutil as _sh
    uv_usable = bool(uv_bin) and (
        uv_bin != "uv" or _sh.which("uv") is not None or running_under_uv
    )
    if uv_usable:
        inner_argv = [uv_bin, "run", "python", launcher, *sys.argv[1:]]
    else:
        # No uv available: re-run with the current interpreter. If we're inside
        # an activated venv this still preserves it; otherwise it's the best we
        # can do and matches the original behavior.
        inner_argv = [sys.executable, launcher, *sys.argv[1:]]

    import shlex
    inner = " ".join(shlex.quote(a) for a in inner_argv)
    env = dict(os.environ)
    env["NIGREDO_TRANSCRIPT"] = str(transcript)

    print(f"[transcript] Recording this session to: {transcript}")
    print("[transcript] (full terminal capture incl. your input + all tool output; "
          "set NIGREDO_NO_TRANSCRIPT=1 to disable)\n")

    # `script -q -c "<cmd>" <file>`: -q quiet, -c runs the command, file gets the
    # full typescript. Linux util-linux script syntax.
    os.execvpe("script", ["script", "-q", "-c", inner, str(transcript)], env)


if __name__ == "__main__":
    _relaunch_under_script()
    from prima_materia.__main__ import main
    raise SystemExit(main())
