# nigredo — data flow

How data moves through the tool: the two engines, the scope firewall between them,
the on-disk artifacts that hand state from stage to stage, and how it all lands in
the final workbook. Grounded in the current code (post recon/targets firewall +
redirect-confirmation work).

---

## 1. The two engines and the firewall

nigredo has **two independent engines** with a hard scope boundary between them:

- **Recon engine** — `ReconOrchestrator` (`recon_orchestrator.py`). Loops over the
  **operator-entered domains** (the "Client domain(s)" preflight prompt →
  `domains.txt`). Runs passive/OSINT recon. **Never fuzzes.**
- **Scan engine** — `Pipeline` (`pipeline.py`). Driven **exclusively by
  `targets.txt`** (the IPs/hostnames the operator put in scope during `init`).
  Runs port scan, web probing, fuzzing, TLS/SSH checks, and vuln enrichment.

**The firewall (the rule):** domains typed at preflight are **recon input only**.
They are never resolved to an IP or handed to the scan/fuzz side. The scan engine is
constructed with `correlate_domains=[]` — it does not receive the recon domains as
scan input. Division is by **source** (typed-at-preflight vs. targets.txt), *not* by
IP-vs-hostname: a hostname deliberately placed in `targets.txt` is scanned normally.

**The one deliberate crossing:** if a **target IP** (from targets.txt) is probed and
it **301/302-redirects to one of the operator-entered recon domains**, that FQDN is
the same target's declared front door — so it *is* scanned and promoted into the
fair-game set. The recon-domain list is passed to the scan engine only as a
**read-only confirmation key** (`recon_domains_ref`) for exactly this test; it is
never fed to any tool. Off-site redirects (SSO/IdP/CDN) are still excluded.

```mermaid
flowchart TD
    subgraph INPUT
      A["init: targets.txt + scope.txt"]
      B["preflight: Client domain(s) → domains.txt"]
    end

    B -->|recon input only| REC
    A -->|scan scope| SCAN

    subgraph REC["RECON ENGINE (ReconOrchestrator)"]
      R1["subdomains / dnsrecon / dnstwist / dkim"]
      R2["fileenum / funnelweb (+harvesters)"]
      R3["snov / emailenum / github_enum"]
      R4["buckets / cloud_enum / partyon(DeHashed)"]
    end

    subgraph SCAN["SCAN ENGINE (Pipeline) — targets.txt only"]
      S1["nmap → classify → probe"]
      S2["emit_target_files → web_urls.txt"]
      S3["httpx / katana / gau  (gau = targets.txt hostnames)"]
      S4["fair-game pool (fairgame_pool.txt)"]
      S5["nuclei / ffuf / feroxbuster / nomore403"]
      S6["testssl / sshaudit / iis(sns)"]
      S7["enrichment: shodan / cvemap / cache / snyk\n(against target tech/CVEs)"]
    end

    B -. read-only confirmation key .-> S2
    S1 --> S2 --> S3 --> S4 --> S5
    S4 --> S6
    S1 --> S7

    REC --> RPT["report.build_report → final_report.xlsx"]
    SCAN --> SS["scan_summary.xlsx (+ folded into final report)"]
    SS --> RPT
```

---

## 2. Recon engine flow (per typed domain)

`domains.txt` → `load_domains()` (splits comma/space, dedupes) → for each domain,
`_run_phase1` / `_run_phase2` dispatch the recon tools via `_dispatch()` (which adds
audit logging + per-(domain,tool) completion markers for resume):

| Tool | Reads | Writes (per domain) |
|---|---|---|
| subdomains (subfinder\|shuffledns\|dnsx) | domain | `subdomains_<d>.raw.csv` / `.clean.csv` |
| dnsrecon | domain | `dnsrecon_<d>.json` |
| dnstwist | domain | `dnstwist_<d>.csv` |
| dkim | domain | `dkim_<d>.*` |
| takeover | subdomain list | `takeover_*.json/.jsonl` |
| submutate | domain + resolvers | appends to `subdomains_<d>.clean.csv` |
| fileenum | domain | `fileenum_<d>.raw.csv` / `.clean.csv` |
| funnelweb (+ js/php harvest, login_detect, jsluice/retirejs/secret/semgrep) | domain | `<d>/report.csv`, `<d>/<d>_report.xlsx` |
| snov | domain | `snov_<d>.emails.txt` |
| emailenum (LinkThief) | domain | `linkthief_<d>.csv` |
| github_enum | org | `trufflehog_<org>.jsonl`, `gitleaks_<org>/*.json`, `*_forks.txt` |
| buckets (GrayHatWarfare) | domain/keywords | bucket listings |
| cloud_enum | keywords | cloud_enum log |
| partyon (DeHashed) | domain (per-domain, `cwd=outdir`) | `DeHashed_Engagements/<d>_dehashed_report.xlsx`, `_raw_api_dump.json`, `_valid_usernames.txt`, `_locked_accounts.txt` |

These artifacts are consumed later by `report.build_report` to build the workbook
tabs (Subdomains, Files, Emails, FunnelWeb, PartyOn (DeHashed), etc.).

---

## 3. Scan engine flow (targets.txt only)

`targets.txt` → `Pipeline.run()`:

1. **nmap** → `results.json` → **classifier** groups ports into web / tls /
   auth_surface / other.
2. **probe** each web endpoint (curl, no redirect-follow) → `ProbeResult`s.
3. **`emit_target_files`** turns probes into `web_urls.txt` (the scan pool):
   - non-redirecting endpoints → included
   - redirecting **origins** → included (scan the origin, never the destination)
   - **redirect destination that is a declared recon domain** → included +
     recorded in `confirmed_redirect_hosts.txt` (the deliberate crossing)
   - http→https self-upgrades → dropped (dup)
4. **httpx / katana / gau** expand/​fingerprint the pool. `gau` runs only on
   **targets.txt hostnames**.
5. **fair-game filter** → `fairgame_pool.txt`: `web_urls.txt` filtered down to the
   **allow-set** = `targets.txt` entries + CONFIRMED `fqdn_pairs.json` pairs +
   `confirmed_redirect_hosts.txt`. This is the single chokepoint that keeps the
   fuzzers in scope.
6. **fuzzers** consume the fair-game pool: `nuclei` (`nuclei.jsonl`), `ffuf`
   (`ffuf_hits.txt`), `feroxbuster`, `nomore403` (`nomore403.jsonl`).
7. **TLS/host checks** against the fair-game TLS endpoints: `testssl`
   (`testssl_<host>_<port>.json`), `sshaudit`, `iis`/`sns`.
8. **enrichment against the targets**: shodan (`shodan_enrichment.csv/json`),
   cvemap (`cvemap_findings.csv`), cache/PoC (`cache_pocs.json`), snyk
   (retire.js enrichment). These look up vulns/info for the target hosts/tech.
9. **nessus** (if provided) is parsed and reconciled against nmap
   (`nessus_exploitable.txt`, host/port merge).

---

## 4. Key state-passing artifacts (the "wires")

| Artifact | Written by | Read by |
|---|---|---|
| `targets.txt` | operator (`init`) | scan engine (scope), gau, fair-game allow-set |
| `domains.txt` | preflight | recon engine; scan engine only as read-only redirect key |
| `results.json` | nmap | classifier, Targets/Hosts-by-Port tabs |
| `web_urls.txt` | `emit_target_files` | httpx, fair-game filter |
| `confirmed_redirect_hosts.txt` | `emit_target_files` | fair-game allow-set (promotion) |
| `fqdn_pairs.json` | fqdn_resolve | fair-game allow-set |
| `fairgame_pool.txt` | fair-game filter | nuclei / ffuf / feroxbuster |
| `nuclei.jsonl` | nuclei | Findings tab, nuclei tab |
| `testssl_<h>_<p>.json` | testssl | testssl tab |
| `*_dehashed_report.xlsx` (+ sidecars) | PartyOn | PartyOn (DeHashed) tab, Spray tab |
| `<d>/report.csv`, `<d>_report.xlsx` | FunnelWeb | Files/Emails/FunnelWeb/At-a-Glance tabs |
| `recon_state.json` / `state.json` | both engines | resume |
| `*_targets.txt` / `*_errors.txt` | `audit` | Master Targets / Master Errors tabs |

---

## 5. Report assembly → workbook

`report.build_report(outdir)` reads the artifacts above and assembles
`final_report.xlsx`. Highlights:

- **Findings** (front-pinned): CVSS-scored findings (nessus/cvemap/nuclei), ranked
  Critical→Low, then a divider, then non-CVSS "other quick wins" (confirmed
  takeovers, login portals, 403 bypasses).
- **Targets** grid + **Hosts by Port**: nmap + Nessus (ports from the rich parse);
  Certificate column fed by Nessus cert/TLS findings (SWEET32, TLS 1.0/1.1, …);
  host id shown as `FQDN [IP]` (bare IP when no FQDN).
- **PartyOn (DeHashed)** per domain (Valid Accounts → Locked Accounts → Combo Lists
  → Unique Emails → Omitted Backups → Breach Records) + **DeHashed Raw Results**.
- **testssl**, **Burp Target URLs** (= the scan target list), plus the FunnelWeb /
  subdomains / emails / cloud / squatting tabs.
- Tab ordering: front-pinned set first, then alphabetical; PartyOn sorts under
  "DeHashed"; `scan_summary.xlsx` phase-0 tabs are folded in (its own workbook is
  skipped by the external-workbook merge).

---

## 6. The scope guarantee, in one line

**Fuzzers/scanners only ever touch hosts whose provenance is `targets.txt`** (plus
CONFIRMED fqdn pairs and the narrow redirect-to-own-recon-domain crossing). A domain
typed at preflight never becomes a scanned IP on its own — it drives recon, and the
report, and nothing on the fuzz side unless a legitimately-scanned target points at
it.
