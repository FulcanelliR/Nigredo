# Nigredo — every external command it runs (for manual testing)

Example values used below:
  DOMAIN      = client.com
  URL         = https://client.com/admin/
  WEB_FILE    = results/client.com/web_urls.txt   (list of live URLs)
  OUTDIR      = results/client.com
  ORG         = ClientOrg
  IP:PORT     = 203.0.113.10:443
  HOST        = host.client.com

Flags in <angle brackets> are conditional (added only when that option/config is set).
Everything is run from the engagement working dir.

--------------------------------------------------------------------------
## PHASE 0 — active scan (web discovery + vuln)
--------------------------------------------------------------------------

# ffuf  (directory discovery; feeds feroxbuster)        [ffuf_tool.py:236]
ffuf -u https://client.com/FUZZ -w <wordlist> -mc 200,204,301,302,307,308,401,403,405,500 \
     -ac -k -t 40 -rate 0 -o results/client.com/ffuf_client.com.json -of json \
     <-x PROXY> <-e .php,.html,.txt,.asp,.aspx,.jsp,.json>
# wordlist size s/m/l chosen from config -> raft-small/medium/large-directories.txt
# -k already present (insecure). -ac = auto-calibrate.

# feroxbuster  (recursive content discovery)            [tools.py:903]
feroxbuster -u https://client.com/admin/ -w <wordlist> -t 10 -d 3 \
     <--auto-tune --rate-limit 50 | --rate-limit 50 | --auto-tune>  \
     --scan-limit 3 --insecure --json -o results/client.com/feroxbuster_<hp>_<label>.json \
     <-s 200,204,301,302,307,308,401,403,405,500> <-x .php,html,txt,asp,aspx,jsp,json> \
     <--proxy PROXY>
# --insecure IS present. rate flags depend on feroxbuster_rate_mode (default auto_tune_capped).
# NOTE: auto_tune_capped needs feroxbuster >= 2.13.1 (older rejects --auto-tune + --rate-limit).

# nuclei  (vuln templates over live URLs)               [tools.py:536]
nuclei -l results/client.com/web_urls.txt -rl <rate> -o results/client.com/nuclei.txt \
     -jsonl-export results/client.com/nuclei.jsonl \
     <-tags takeover>  <-ss <strategy>>  <-stats -stats-interval 60>  <-proxy PROXY>

# nomore403  (403 bypass over ferox/ffuf 403 URLs)      [nomore403_tool.py]
cat results/client.com/nomore403_targets.txt | nomore403 --jsonl -o results/client.com/nomore403.jsonl \
     <-k verbs,verbs-case,headers,endpaths,midpaths,double-encoding,http-versions,path-case,header-confusion,host-override,forwarded-trust,proto-confusion,ip-encoding,hop-by-hop,unicode,path-normalization,suffix-tricks,http-parser,absolute-uri> \
     <-x PROXY> <-f results/client.com/nomore403_safe_payloads>
# Input is a URL LIST via STDIN (valid per nomore403 v2 docs).
# -k list is the SAFE set (state-changing methods stripped from payloads/httpmethods).
# Output now also tee'd to results/client.com/nomore403.log
# MANUAL TEST A SINGLE URL:  nomore403 -u https://client.com/admin/ -v

# testssl  (TLS audit, per host)                         [tools.py:1008]
testssl.sh --quiet --warnings batch --logfile results/client.com/testssl_<safe>.log \
     <--jsonfile-pretty results/client.com/testssl_<safe>.json> <host:port>

# sns  (IIS short-name scanner)                          [tools.py:1066]
sns --check -u https://client.com/admin/ -t <threads> <extra>

# ssh-audit                                              [tools.py:1127]
ssh-audit -j -p 22 <extra> host.client.com

# IIS recon probe                                        [iis_recon.py:90]
curl -s -k -I --http1.0 --max-time <t> <-x PROXY> https://client.com/admin/

# nmap reconcile (directed re-probe of Nessus ports)     [reconcile.py:124,141]
nmap -sT -Pn -sV <ports> <host>
nmap -sT -Pn --script banner <ports> <host>

--------------------------------------------------------------------------
## PHASE 1 — recon / OSINT   (driven by domains.txt, NOT targets.txt)
--------------------------------------------------------------------------

# subfinder  (passive subdomain enum)                    [subdomains.py:120]
subfinder -d client.com -all -recursive -silent

# dnsrecon                                               [dnsrecon_tool.py:54]
dnsrecon -d client.com -t std,axfr <...>

# dnstwist  (typosquat)                                  [dnstwist_tool.py:79]
dnstwist --registered --format json <--whois> <--nameservers NS> \
     --output results/client.com/dnstwist.json client.com

# httpx liveness (host validation)                       [host_validation.py:414]
httpx -l <list> -json -silent -nc <-rate-limit N> <...>

# cvemap  (CVE lookup per product)                       [cvemap_tool.py:186]
cvemap -product <product> -json -silent

# cloud_enum  (bucket/blob enum)                          [cloud_enum.py:126]
python <cloud_enum.py> -k <keyword> -l <logfile> <-qs> <-m MUTATIONS -b MUTATIONS> <extra>

# DKIM selector brute (uses bundled 837-selector list)   [dkim.py]
# (internal python resolver over dkim_selectors.txt — no external binary)

# exiftool  (metadata from downloaded docs)              [fileenum.py:678]
exiftool -json -r <fields> results/client.com/files/

--------------------------------------------------------------------------
## PHASE 1 — GitHub (org secret scanning)
--------------------------------------------------------------------------

# trufflehog  (org scan, API, verified)                  [github_enum.py:49]
trufflehog github --org=ClientOrg --json <--token=***> <--include-members> \
     <--issue-comments --pr-comments --gist-comments>

# gitleaks  (clones each public repo, scans locally)     [github_enum.py:250]
# (per repo:)  git clone --quiet <--depth N> <clone_url> <dest>
gitleaks git <dest> --report-format json ...
# NOTE: gitleaks only scans LOCAL clones — no native third-party remote scan.

--------------------------------------------------------------------------
## PHASE 1/2 — FunnelWeb + email/breach
--------------------------------------------------------------------------

# FunnelWeb  (Playwright/patchright crawler, one per target)  [funnelweb.py:64]
python FunnelWeb.py --url https://target/ <--workers N> <--rate-limit R> <--proxy P> <--stealth>
# NOTE: build_command does NOT pass a page/depth limit — crawler uses its own default.
# NOTE: delete stale results/<client>/**/frontier.json before a re-run (resume fix).

# emailenum / snov / partyon  — API-driven (SerpAPI / Snov / DeHashed), no single CLI line

--------------------------------------------------------------------------
## The campaign child itself                              [campaign.py:520]
--------------------------------------------------------------------------
python -m prima_materia recon --config results/<client>/recon_config.json --no-prompt

--------------------------------------------------------------------------
## Quick manual reachability check (the thing to test FIRST for nomore403/ferox)
--------------------------------------------------------------------------
# From the SAME box Nigredo runs on, against ONE of the exact 403 URLs:
curl -k -m 10 -sS -o /dev/null -w "%{http_code} %{time_total}s\n" https://client.com/admin/
# hangs/timeout  -> host unreachable from this box (routing/DNS/firewall) = NOT a tool bug
# instant code   -> host reachable; tool is doing something different, dig into that tool
