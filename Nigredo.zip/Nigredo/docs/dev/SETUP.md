# nigredo — setup

## Quick start

```bash
./setup.sh                       # create the venv, install Python deps, then
                                 # OFFER to install each missing external tool [Y/n]
chmod +x nigredo.sh              # once, after unzipping (zip drops the +x bit)
./nigredo.sh init                # set up the engagement + enter targets
./nigredo.sh start               # start the run
```

The `nigredo.sh` launcher handles the secure invocation for you — it
auto-elevates with `sudo` (prompts for your password) and runs inside the `uv`
virtualenv, so you don't type the long `sudo -E env "PATH=$PATH" uv run …` line
by hand. To adjudicate a finished run:

```bash
./nigredo.sh adjudicator --folder results/<engagement>              # full
./nigredo.sh adjudicator --folder results/<engagement> --audit-only # verdict only
```

## What setup.sh does

1. **Creates a `uv` virtualenv** named `nigredo-venv` (falls back to `python -m
   venv` if `uv` isn't installed — it'll tell you how to get uv).
2. **Installs the Python dependencies** from `requirements.txt` into the venv.
3. **Installs the Playwright browser** (Chromium) that FunnelWeb needs.
4. **Checks every external tool** and, for each missing one, **offers to run its
   Kali install command right then** — you answer [Y/n] per tool.
5. **Offers the sudo/PATH symlink fix** — links Go tools into `/usr/local/bin`
   so they resolve when the pipeline runs under `sudo`.

## setup.sh flags

| Flag | Effect |
|------|--------|
| *(none)* | interactive — offers each install/symlink as it's found [Y/n] |
| `--yes` / `-y` | auto-accept every install/symlink prompt (no questions) |
| `--check-only` | only report what's present/missing, install nothing |

## Why the venv

The pipeline pulls in a fair number of Python packages. A virtualenv keeps that
isolated from your system Python — no version conflicts. `uv` is used because
it's fast and it's the project's workflow. The venv is named `nigredo-venv` (not
`nigredo`) to avoid a folder-vs-venv name collision.

## Why root / the symlink matters

nmap's SYN/stealth scans need **root**, which is why `nigredo.sh` runs under
`sudo`. But `sudo` resets PATH to root's, and Go tools installed to `~/go/bin`
fall off it — so under sudo they look "missing" even though they work for your
user. The launcher passes `-E env "PATH=$PATH"` to carry your PATH through, and
`setup.sh --symlink` links the Go tools into `/usr/local/bin` (on root's PATH)
as a belt-and-suspenders fix.

Alternative — grant nmap raw-packet capability so root isn't needed for the scan:

```bash
sudo setcap cap_net_raw,cap_net_admin,cap_net_bind_service+eip $(which nmap)
```

## Tools you supply yourself (script-path)

Not auto-installable — set their path in `recon_config.json`:

- **PartyOn.py** — `partyon_script` (phase 2 breach/credential lookup)
- **FunnelWeb-RV5.py** — `funnelweb_script` (phase 1 crawler)
- **cloud_enum.py** — `cloud_enum_script` (phase 1 bucket brute-force)

## External tools by category

**Go tools:** subfinder, shuffledns, dnsx, nuclei, ffuf, feroxbuster, gitleaks,
trufflehog, sns, katana, gau, nomore403
**System tools:** nmap, dnsrecon, dnstwist, dig (dnsutils), git, testssl.sh,
ssh-audit, exiftool, libmagic

## API keys (set in `recon_config.json` or as env vars)

SERPAPI_KEY, SNOV_CLIENT_ID, SNOV_CLIENT_SECRET, GRAYHAT_API_KEY, GITHUB_TOKEN,
DEHASHED_API_KEY (PartyOn prompts and offers to save on first run if unset).

## The sudo + uv details (what the launcher does under the hood)

nigredo needs root; deps live in a uv venv; so it launches through uv as root:

```bash
sudo -E env "PATH=$PATH" uv run python run.py engagement-init
sudo -E env "PATH=$PATH" uv run python run.py engagement
sudo -E env "PATH=$PATH" uv run python -m nigredo.adjudicator --folder <path>
```

`nigredo.sh` runs exactly these for you. If you ever need to run them manually:

### Making `sudo uv` work (secure_path)

Kali's sudo uses a locked `secure_path` that ignores your user dirs, so `sudo
uv` may say "command not found" even when uv is installed. Two fixes:

- **Full path:** `sudo /home/<user>/.local/bin/uv run python run.py ...`
- **Permanent (recommended on a pentest VM):** symlink uv into `/usr/local/bin`
  (`sudo ln -s $(which uv) /usr/local/bin/uv`), then add `:/usr/local/bin` to the
  `secure_path=` line via `sudo visudo`. On a single-user/disposable pentest VM
  this is safe — `/usr/local/bin` is root-owned (not user-writable), so it adds
  no privilege-escalation vector and is a standard secure_path entry anyway.
