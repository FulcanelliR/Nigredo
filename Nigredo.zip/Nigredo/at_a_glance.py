#!/usr/bin/env python3
"""
at_a_glance.py — solo FunnelWeb's deduplicated actionable-intelligence summary.

Standalone port of the same ingest + rendering logic Nigredo uses, so a solo
FunnelWeb run produces the SAME "At a Glance" view without needing Nigredo.

Solo FunnelWeb output flow:
  - during the crawl, rows stream to raw.csv (crash-safe, incremental)
  - at finalize, this module ingests raw.csv and writes a workbook:
        <domain>/<domain>_report.xlsx
    with two tabs:
        "At a Glance" (primary) — dedup dashboard + actionable listings
        "Raw Data"              — the full raw.csv content, every row

Ingest rules (identical to Nigredo's, so the two match):
  - HTML-decode URLs (&amp; -> &)
  - dedup emails on address; dedup JS URLs by PATH (drop query string)
  - split JS endpoints/files first-party (target + subdomains) vs third-party
  - HIGH secrets listed (type + value + where); MED/LOW counted
  - JS endpoints and below are count-only

Requires openpyxl (pip install openpyxl).
"""
from __future__ import annotations

import csv
import html
from pathlib import Path
from urllib.parse import urlparse


def _is_first_party(url: str, base_domains: list[str]) -> bool:
    try:
        host = urlparse(url).netloc.lower().split(":")[0]
    except Exception:
        return False
    for b in base_domains:
        b = b.lower().split(":")[0]
        if host == b or host.endswith("." + b):
            return True
    return False


def _path_key(url: str) -> str:
    try:
        p = urlparse(html.unescape(url))
        return f"{p.scheme.lower()}://{p.netloc.lower()}{p.path or '/'}"
    except Exception:
        return url


def ingest(raw_csv: Path, base_domains: list[str]) -> dict:
    """Parse raw.csv into a deduplicated summary dict."""
    s = {
        "emails": set(), "files": {}, "secrets_high": [], "secrets_other": 0,
        "ep_first": set(), "ep_third": set(),
        "jsf_first": set(), "jsf_third": set(),
        "documents": 0, "cdn_documents": 0, "external_documents": 0,
        "external_doc_list": [], "doc_metadata": [], "skipped": 0,
        "jsluice_flag": False,
        "php_source_disclosed": 0, "semgrep_findings": 0, "semgrep_high": 0,
        "retire_findings": [], "retire_high": 0,
    }
    raw_csv = Path(raw_csv)
    if not raw_csv.is_file():
        return s
    with open(raw_csv, newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        try:
            next(reader)
        except StopIteration:
            return s
        for row in reader:
            if len(row) < 2:
                continue
            while len(row) < 5:
                row.append("")
            cat, detail, source, local, notes = row[:5]
            detail = html.unescape(detail)
            source = html.unescape(source)
            if cat == "Email":
                s["emails"].add(detail.strip().lower())
            elif cat == "Secret":
                conf, stype = "LOW", ""
                if notes.startswith("["):
                    conf = notes[1:notes.find("]")] if "]" in notes else "LOW"
                    after = notes[notes.find("]") + 1:].strip()
                    stype = after.split(" (entropy")[0].strip()
                if conf.upper() == "HIGH":
                    s["secrets_high"].append((stype, detail, local or source))
                else:
                    s["secrets_other"] += 1
            elif cat == "JS Endpoint":
                key = _path_key(detail)
                (s["ep_first"] if _is_first_party(detail, base_domains)
                 else s["ep_third"]).add(key)
            elif cat == "JavaScript":
                key = _path_key(source or detail)
                (s["jsf_first"] if _is_first_party(source or detail, base_domains)
                 else s["jsf_third"]).add(key)
            elif cat == "Document":
                s["documents"] += 1
                if detail:
                    s["files"][detail] = source
            elif cat == "CDN Document":
                s["cdn_documents"] += 1
                if detail:
                    s["files"][detail] = source
            elif cat == "External Document":
                s["external_documents"] += 1
                s["external_doc_list"].append((detail, source))
            elif cat == "Metadata":
                # notes is the raw exiftool dump joined by " | " — pull the
                # high-value fields (matches Nigredo FileEnum: internal usernames,
                # producing app/version, org).
                fld = {}
                for _piece in (notes or "").split(" | "):
                    _k, _sep, _v = _piece.partition(":")
                    if _sep and _k.strip() and _v.strip():
                        fld[_k.strip()] = _v.strip()
                au = fld.get("Author", "")
                cr = fld.get("Creator", "")
                pr = fld.get("Producer") or fld.get("Creator Tool") or ""
                lm = fld.get("Last Modified By", "")
                co = fld.get("Company", "")
                sw = fld.get("Software") or fld.get("Application") or ""
                if any([au, cr, pr, lm, co, sw]):
                    s["doc_metadata"].append((detail, au, cr, pr, lm, co, sw))
            elif cat == "Skipped Link":
                s["skipped"] += 1
            elif cat == "PHP Semgrep Finding":
                s["semgrep_findings"] += 1
                if notes.startswith("[ERROR]"):
                    s["semgrep_high"] += 1
            elif cat == "Retire.js Finding":
                sev = (notes[1:notes.find("]")].upper()
                       if notes.startswith("[") and "]" in notes else "")
                s["retire_findings"].append((detail, sev, source, local))
                if sev in ("HIGH", "CRITICAL"):
                    s["retire_high"] += 1
    js_secrets = raw_csv.parent / "js" / "jsluice_secrets.txt"
    try:
        s["jsluice_flag"] = js_secrets.is_file() and js_secrets.stat().st_size > 0
    except OSError:
        s["jsluice_flag"] = False
    # PHP source-disclosure count from the php manifest (Is Source == Y)
    php_manifest = raw_csv.parent / "php" / "php_manifest.csv"
    if php_manifest.is_file():
        try:
            with open(php_manifest, newline="", encoding="utf-8", errors="replace") as pf:
                pr = csv.reader(pf)
                next(pr, None)
                for prow in pr:
                    # columns: URL, Local, Source Path, Is Source, ...
                    if len(prow) >= 4 and prow[3].strip() == "Y":
                        s["php_source_disclosed"] += 1
        except OSError:
            pass
    return s


def write_workbook(raw_csv: Path, out_xlsx: Path, base_domains: list[str]) -> bool:
    """Build <domain>_report.xlsx with At a Glance (primary) + Raw Data tabs.
    Returns True on success, False if openpyxl is unavailable."""
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, PatternFill, Alignment
    except ImportError:
        return False

    s = ingest(raw_csv, base_domains)
    secrets_high = sorted(set(s["secrets_high"]), key=lambda t: (t[0].lower(), t[1]))

    FONT = "Roboto"
    HEADER_FILL = PatternFill("solid", start_color="1F2937")
    HEADER_FONT = Font(name=FONT, size=11, bold=True, color="FFFFFF")
    BODY_FONT = Font(name=FONT, size=11)
    SECTION_FILL = PatternFill("solid", start_color="374151")
    SECTION_FONT = Font(name=FONT, size=11, bold=True, color="FFFFFF")
    LABEL_FONT = Font(name=FONT, size=11, bold=True)

    wb = Workbook()
    wb.remove(wb.active)

    # ---- At a Glance (primary tab) ----
    ws = wb.create_sheet("At a Glance")
    ws.sheet_properties.tabColor = "B91C1C"

    def section(row, title):
        c = ws.cell(row=row, column=1, value=title)
        c.font = SECTION_FONT
        c.fill = SECTION_FILL
        c.alignment = Alignment(horizontal="left", vertical="center")
        ws.cell(row=row, column=2, value="").fill = SECTION_FILL
        return row + 1

    def count(row, label, value):
        ws.cell(row=row, column=1, value=label).font = LABEL_FONT
        ws.cell(row=row, column=2, value=value).font = BODY_FONT
        return row + 1

    r = 1
    t = ws.cell(row=r, column=1, value="At a Glance — FunnelWeb actionable intelligence")
    t.font = Font(name=FONT, size=14, bold=True)
    if base_domains:
        ws.cell(row=r, column=4, value="domain: " + base_domains[0]).font = BODY_FONT
    r += 2

    r = section(r, "COUNTS")
    r = count(r, "Unique Emails", len(s["emails"]))
    r = count(r, "Secrets (HIGH)", len(secrets_high))
    r = count(r, "Secrets (MED/LOW)", s["secrets_other"])
    r = count(r, "Documents", s["documents"])
    r = count(r, "CDN Documents", s["cdn_documents"])
    r = count(r, "External Docs (off-domain, logged)", s["external_documents"])
    r = count(r, "JS Endpoints (first-party)", len(s["ep_first"]))
    r = count(r, "JS Endpoints (third-party)", len(s["ep_third"]))
    r = count(r, "JavaScript files (first-party)", len(s["jsf_first"]))
    r = count(r, "JavaScript files (third-party)", len(s["jsf_third"]))
    r = count(r, "Skipped Links", s["skipped"])
    r = count(r, "Jsluice Secret? (Y/N)", "Y" if s["jsluice_flag"] else "N")
    r = count(r, "PHP Source Disclosed", s["php_source_disclosed"])
    r = count(r, "Semgrep Findings (PHP)", s["semgrep_findings"])
    r = count(r, "Semgrep High-Severity", s["semgrep_high"])
    r = count(r, "Retire.js Findings (vuln JS libs)", len(s["retire_findings"]))
    r = count(r, "Retire.js High/Critical", s["retire_high"])
    r += 1

    r = section(r, "HIGH-VALUE SECRETS  ([type] value — where found)")
    if secrets_high:
        for stype, value, where in secrets_high:
            label = f"{stype}: " if stype else ""
            ws.cell(row=r, column=1, value=f"{label}{value}").font = BODY_FONT
            ws.cell(row=r, column=3, value=where).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    r = section(r, "RETIRE.JS — VULNERABLE JS LIBRARIES  ([sev] component version — advisory)")
    if s["retire_findings"]:
        for comp, sev, where, advisory in s["retire_findings"]:
            label = f"[{sev}] " if sev else ""
            ws.cell(row=r, column=1, value=f"{label}{comp}").font = BODY_FONT
            ws.cell(row=r, column=3, value=where).font = BODY_FONT
            if advisory:
                ws.cell(row=r, column=4, value=advisory).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    r = section(r, "FILES  (name — source URL)")
    if s["files"]:
        for name in sorted(s["files"]):
            ws.cell(row=r, column=1, value=name).font = BODY_FONT
            ws.cell(row=r, column=3, value=s["files"][name]).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    r = section(r, "DOCUMENT METADATA (exiftool — internal users / producing app+version / org)")
    if s["doc_metadata"]:
        for _c, _h in enumerate(["File", "Author", "Creator", "Producer/Tool",
                                 "Last Modified By", "Company", "Software"], 1):
            ws.cell(row=r, column=_c, value=_h).font = LABEL_FONT
        r += 1
        for _row in s["doc_metadata"]:
            for _c, _v in enumerate(_row, 1):
                ws.cell(row=r, column=_c, value=_v).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    r = section(r, "UNIQUE EMAILS")
    if s["emails"]:
        for e in sorted(s["emails"]):
            ws.cell(row=r, column=1, value=e).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    r = section(r, "EXTERNAL DOCUMENTS (off-domain/third-party — URL + referring page; NOT downloaded)")
    if s["external_doc_list"]:
        for _url, _src in s["external_doc_list"]:
            ws.cell(row=r, column=1, value=_url).font = BODY_FONT
            ws.cell(row=r, column=3, value=_src).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1

    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 70
    ws.column_dimensions["D"].width = 40
    ws.freeze_panes = "A2"

    # ---- Findings by Tool (FW-4): stacked per-category sections + per-tool tally ----
    ws3 = wb.create_sheet("Findings by Tool")
    _rows_by_cat: dict = {}
    _rc = Path(raw_csv)
    if _rc.is_file():
        with open(_rc, newline="", encoding="utf-8", errors="replace") as f:
            rdr = csv.reader(f)
            next(rdr, None)   # header
            for row in rdr:
                if not row:
                    continue
                cat = (row[0] or "").strip() or "Uncategorized"
                _rows_by_cat.setdefault(cat, []).append(row)
    _order = ["Secret", "API Key", "Retire.js Finding", "JS Endpoint",
              "Login Portal", "PHP Source", "PHP Endpoint", "JavaScript",
              "Document", "CDN Document", "External Document", "Metadata", "Email", "Skipped Link"]
    _cats = [c for c in _order if c in _rows_by_cat] + \
            [c for c in sorted(_rows_by_cat) if c not in _order]
    rr = 1
    _tc = ws3.cell(row=rr, column=1, value="Findings by Tool — detailed, with per-tool tally")
    _tc.font = HEADER_FONT
    _tc.fill = HEADER_FILL
    rr += 2
    for cat in _cats:
        items = _rows_by_cat[cat]
        _hc = ws3.cell(row=rr, column=1, value=f"{cat} ({len(items)})")
        _hc.font = SECTION_FONT
        _hc.fill = SECTION_FILL
        rr += 1
        for col, lbl in enumerate(["Detail", "Source URL", "Local Path", "Notes"], 1):
            _c = ws3.cell(row=rr, column=col, value=lbl)
            _c.font = LABEL_FONT
        rr += 1
        for row in items:   # raw.csv cols: Category, Detail, Source URL, Local Path, Notes
            for col in range(1, 5):
                ws3.cell(row=rr, column=col, value=(row[col] if len(row) > col else ""))
            rr += 1
        rr += 1
    for col, w in (("A", 45), ("B", 60), ("C", 40), ("D", 60)):
        ws3.column_dimensions[col].width = w

    # ---- Raw Data (second tab): the full raw.csv ----
    ws2 = wb.create_sheet("Raw Data")
    raw_csv = Path(raw_csv)
    if raw_csv.is_file():
        with open(raw_csv, newline="", encoding="utf-8", errors="replace") as f:
            for ridx, row in enumerate(csv.reader(f), start=1):
                for cidx, val in enumerate(row, start=1):
                    cell = ws2.cell(row=ridx, column=cidx, value=val)
                    if ridx == 1:
                        cell.font = HEADER_FONT
                        cell.fill = HEADER_FILL
        ws2.freeze_panes = "A2"
        for col, w in (("A", 16), ("B", 40), ("C", 60), ("D", 40), ("E", 60)):
            ws2.column_dimensions[col].width = w

    try:
        wb.save(out_xlsx)
        return True
    except OSError:
        return False
