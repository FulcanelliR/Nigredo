#!/usr/bin/env python3
"""
Web Crawler for Security Analysis with Concurrent Browser Tabs

Features:
  - Per-worker CSV shards (no lock contention on writes), merged + deduped at end.
  - Strict domain matching for downloaded files, with CDN allowlist.
  - Target-domain email filtering (subdomains included).
  - Adaptive rate limiting with backoff on HTTP 429 + per-worker cooldown.
  - Periodic checkpointing every CHECKPOINT_INTERVAL pages.
  - Always finalizes the CSV, even on Ctrl-C or crash.
  - Writes a per-run error_YYMMDDHHMM.log alongside report.csv.
  - Non-HTML URLs (documents, vCards, archives) are never navigated by the
    browser. Documents go through the aiohttp downloader; other interesting
    resources are recorded as 'Skipped Link' rows for manual review.
  - Failed downloads are recorded in the CSV with the failure reason so the
    final report doubles as a manual-fix worklist.
  - Known-CDN documents (allowlist) download inline during the crawl into
    documents/cdn/. Unknown off-domain documents are deferred to an end-of-run
    second pass that probes response headers for CDN fingerprints; matches are
    downloaded (and exiftool'd) as 'CDN Document', the rest become 'Skipped Link'.
  - PHASE A: external JavaScript referenced by <script src> is discovered on
    every page, fetched once each (dedup by URL then content hash), saved to
    <domain>/js/, and recorded with full provenance in js/js_manifest.csv.
    (Requires js_harvest.py in the same folder — hard dependency.)
"""

import asyncio
import re
import csv
import os
import aiohttp
import aiofiles
import magic
import hashlib
import logging
import time
import argparse
import shutil
import subprocess
from collections import deque
from datetime import datetime
from pathlib import Path
from urllib.parse import urlparse, urljoin
from patchright.async_api import async_playwright

# PHASE A: external JS discovery + fetch + save (guarded — missing module
# degrades gracefully instead of crashing the crawl).
try:
    from js_harvest import JSHarvester, discover_js_urls
    _HAS_JS_HARVEST = True
except ImportError:
    _HAS_JS_HARVEST = False
# PHASE A: PHP endpoint fetch + source-disclosure hunt + save (guarded).
try:
    from php_harvest import PHPHarvester, discover_php_urls
    _HAS_PHP_HARVEST = True
except ImportError:
    _HAS_PHP_HARVEST = False
# PHASE A: login-portal detection (content-analysis, zero extra requests)
try:
    from login_detect import detect_login, LoginRegistry
    _HAS_LOGIN_DETECT = True
except ImportError:
    _HAS_LOGIN_DETECT = False

# ---------------- Configuration ----------------

DEFAULT_RATE_LIMIT = 0.3       # seconds, per-worker
DEFAULT_NUM_WORKERS = 10
CHECKPOINT_INTERVAL = 250      # pages between checkpoint snapshots

# Adaptive rate limit ladder (seconds). Index 0 is the configured base rate.
# Values above index 0 form the escalation ladder. 2.0s is the ceiling.
RATE_LIMIT_LADDER = [0.3, 0.5, 1.0, 2.0]
RATE_LIMIT_CEILING = 2.0

# Sliding window for the global 429 trigger
RATE_WINDOW_SIZE = 20          # last N requests tracked
RATE_WINDOW_TRIGGER_429 = 8    # 8 of 20 = 40% triggers escalation
RECOVERY_SUCCESS_STREAK = 50   # consecutive successes to step back down

# Ceiling behavior: when stuck at max rate with still-high failures
CEILING_PAUSE_SECONDS = 60     # all workers pause this long
CEILING_WARN_INTERVAL = 30     # seconds between "still hitting 429s" warnings

# Per-worker 429 cooldown
WORKER_COOLDOWN_SHORT = 10

# Multi-label public suffixes (partial PSL) so registrable-domain extraction works
# for the common ccTLDs (foo.co.uk -> foo.co.uk, not co.uk). Falls back to last-2.
_MULTI_SUFFIXES = frozenset({
    "co.uk", "org.uk", "gov.uk", "ac.uk", "me.uk", "net.uk", "sch.uk", "ltd.uk",
    "plc.uk", "com.au", "net.au", "org.au", "gov.au", "edu.au", "co.nz", "org.nz",
    "govt.nz", "ac.nz", "co.za", "org.za", "gov.za", "co.jp", "ne.jp", "or.jp",
    "go.jp", "ac.jp", "com.br", "gov.br", "com.cn", "gov.cn", "edu.cn", "co.in",
    "gov.in", "net.in", "org.in", "com.mx", "gob.mx", "com.tr", "gov.tr", "co.kr",
    "or.kr", "go.kr", "com.sg", "gov.sg", "com.hk", "gov.hk", "com.ua", "gov.ua",
    "co.il", "org.il", "gov.il", "com.ar", "gob.ar", "com.co", "gov.co",
})


def _registrable_domain(host: str) -> str:
    """Primary (registrable) domain: www.business.com -> business.com,
    portal.agency.gov.uk -> agency.gov.uk. Partial public-suffix handling for the
    common multi-label ccTLDs; otherwise the last two labels."""
    host = (host or "").lower().split(':')[0].rstrip('.')
    labels = host.split('.')
    if len(labels) <= 2:
        return host
    if '.'.join(labels[-2:]) in _MULTI_SUFFIXES:
        return '.'.join(labels[-3:])
    return '.'.join(labels[-2:])
WORKER_COOLDOWN_LONG = 30
WORKER_COOLDOWN_ESCALATE_WINDOW = 60  # 2nd 429 within this many seconds -> long

DOWNLOAD_EXTENSIONS = {'.pdf', '.doc', '.docx', '.xlsx', '.xls', '.ppt', '.pptx'}

# Non-navigable resources we should never feed to page.goto.
# Recorded as "Skipped Link" rows in the CSV for manual review.
NON_NAVIGABLE_INTERESTING = {
    '.vcf',                                  # contact cards
    '.zip', '.tar', '.gz', '.tgz', '.7z', '.rar', '.bz2',  # archives
    '.dmg', '.iso', '.exe', '.msi', '.apk', '.deb', '.rpm',  # binaries / installers
    '.csv', '.tsv', '.json', '.xml', '.txt',  # data files (often interesting)
    '.rtf', '.odt', '.ods', '.odp',           # other office formats
    '.epub', '.mobi',                         # ebooks
}

# Media / asset extensions: silently skip from CSV, only note in error log.
NON_NAVIGABLE_MEDIA = {
    '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.svg', '.webp', '.ico', '.tiff', '.tif',
    '.mp3', '.mp4', '.wav', '.ogg', '.m4a', '.m4v', '.mov', '.avi', '.wmv', '.flv', '.webm', '.mkv',
    '.css', '.js', '.mjs', '.map',
    '.woff', '.woff2', '.ttf', '.otf', '.eot',
}


def _url_extension(url: str) -> str:
    """Return the lowercase extension of the path portion of a URL, or ''."""
    try:
        path = urlparse(url).path
        return os.path.splitext(path)[1].lower()
    except Exception:
        return ''

# CDN / cloud-storage suffixes that may legitimately host a target's files.
# Matched as case-insensitive suffixes against the URL's netloc.
ALLOWED_CDN_SUFFIXES = {
    # ---- Generic cloud / CDN infrastructure ----
    'cloudfront.net',          # AWS CloudFront
    'amazonaws.com',           # AWS S3 / general
    'azureedge.net',           # Azure CDN
    'azurefd.net',             # Azure Front Door
    'blob.core.windows.net',   # Azure Blob storage
    'azurewebsites.net',       # Azure App Service
    'googleusercontent.com',   # Google user content
    'storage.googleapis.com',  # Google Cloud Storage
    'appspot.com',             # Google App Engine
    'firebasestorage.googleapis.com',  # Firebase storage
    'akamaihd.net',            # Akamai
    'akamaized.net',           # Akamai
    'akamai.net',              # Akamai
    'edgekey.net',             # Akamai edge
    'edgesuite.net',           # Akamai edge
    'fastly.net',              # Fastly
    'fastlylb.net',            # Fastly
    'cloudflare.com',          # Cloudflare
    'cloudflare.net',          # Cloudflare
    'r2.cloudflarestorage.com',  # Cloudflare R2
    'cdn77.org',               # CDN77
    'stackpathcdn.com',        # StackPath
    'stackpathdns.com',        # StackPath
    'kxcdn.com',               # KeyCDN
    'bunnycdn.com',            # Bunny CDN
    'b-cdn.net',               # Bunny CDN
    'jsdelivr.net',            # jsDelivr
    'cdninstagram.com',        # Meta
    # ---- Static-site / app hosting ----
    'netlify.app',
    'vercel.app',
    'github.io',
    'githubusercontent.com',   # GitHub raw/user content
    'pages.dev',               # Cloudflare Pages
    'wpengine.com',            # WP Engine
    'wp.com',                  # WordPress.com / Jetpack CDN
    'wordpress.com',
    'squarespace.com',         # Squarespace
    'squarespace-cdn.com',     # Squarespace CDN
    'wixstatic.com',           # Wix static assets
    'wixsite.com',             # Wix
    'weebly.com',              # Weebly
    'editmysite.com',          # Weebly assets
    # ---- Document / file hosting services ----
    'box.com',                 # Box
    'boxcloud.com',            # Box content
    'dropbox.com',             # Dropbox
    'dropboxusercontent.com',  # Dropbox content
    'sharepoint.com',          # Microsoft SharePoint
    '1drv.com',                # OneDrive
    'docs.google.com',         # Google Docs/Drive (public links)
    'drive.google.com',        # Google Drive
    'scribd.com',              # Scribd
    'issuu.com',               # Issuu
    'smartsheet.com',          # Smartsheet
    'filestackcontent.com',    # Filestack
    'cloudinary.com',          # Cloudinary
    'res.cloudinary.com',      # Cloudinary delivery
    'imgix.net',               # imgix
    # ---- Adobe-managed CDNs ----
    'adobeaemcloud.com',
    'adobedtm.com',
    'adobeio-static.net',
    # ---- K-12 / education CMS & file-hosting platforms ----
    'thrillshare.com',         # Apptegy / Thrillshare
    'apptegy.com',             # Apptegy
    'finalsite.com',           # Finalsite
    'finalsitecdn.com',        # Finalsite CDN
    'fs-cdn.net',              # Finalsite CDN (alt)
    'edlio.com',               # Edlio
    'edliocdn.com',            # Edlio CDN
    'edliostatic.com',         # Edlio static
    'schoolmessenger.com',     # SchoolMessenger
    'schoolwires.com',         # Blackboard / Schoolwires
    'blackboard.com',          # Blackboard
    'campussuite.com',         # Campus Suite
    'campussuitecdn.com',      # Campus Suite CDN
    'schoolblocks.com',        # SchoolBlocks
    'schoolinsites.com',       # SchoolInsites
    'sharpschool.com',         # SharpSchool
    'catapultcms.com',         # Catapult CMS
    'gabbart.com',             # Gabbart Communications
    'edlioschool.com',         # Edlio (alt)
    'parentlink.net',          # ParentLink
    'blackboardcdn.com',       # Blackboard CDN
}

# ---- Heuristic CDN detection ----
# When an off-domain document URL is NOT on the allowlist, the second pass
# fetches its response headers and checks for these CDN fingerprints.
# header name (lowercase) -> optional substring that must appear in the value.
# A value of None means "presence of the header alone is a signal."
HEURISTIC_CDN_HEADER_SIGNALS = {
    'x-cache': None,            # Varnish / CloudFront / Fastly
    'x-served-by': None,        # Fastly
    'x-cache-hits': None,       # Fastly
    'cf-ray': None,             # Cloudflare
    'cf-cache-status': None,    # Cloudflare
    'x-amz-cf-id': None,        # CloudFront
    'x-amz-cf-pop': None,       # CloudFront
    'x-fastly-request-id': None,  # Fastly
    'x-akamai-transformed': None,  # Akamai
    'x-edge-location': None,    # generic edge
    'x-cdn': None,              # generic CDN header
    'x-cache-status': None,     # generic
    'fastly-debug-digest': None,
}
# 'via' and 'server' headers checked separately for these substrings:
HEURISTIC_CDN_VIA_SUBSTRINGS = (
    'cloudfront', 'varnish', 'fastly', 'akamai', 'cache', 'cloudflare',
)
HEURISTIC_CDN_SERVER_SUBSTRINGS = (
    'cloudflare', 'cloudfront', 'akamai', 'amazons3', 'awselb', 'ecs',
    'gse', 'gws', 'fastly', 'nginx-cdn', 'bunnycdn', 'keycdn',
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


# ---------------- Adaptive rate limiter ----------------

class AdaptiveRateLimiter:
    """
    Global controller for per-worker request pacing.
    - Tracks recent request outcomes in a sliding window.
    - Escalates the per-worker rate limit when 429 rate exceeds threshold.
    - Recovers (steps down) after a streak of successful requests.
    - At the ceiling, periodically pauses all workers and emits warnings,
      but never stops the crawl.
    """

    def __init__(self, base_rate: float, error_logger):
        self.error_logger = error_logger
        # Clamp base into the ladder if needed
        self.ladder = list(RATE_LIMIT_LADDER)
        if base_rate not in self.ladder:
            self.ladder = sorted(set(self.ladder + [base_rate]))
        self.base_index = self.ladder.index(base_rate) if base_rate in self.ladder else 0
        self.level = self.base_index
        self.outcomes = deque(maxlen=RATE_WINDOW_SIZE)  # True=success, False=429
        self.success_streak = 0
        self.last_ceiling_warn = 0.0
        self.last_ceiling_pause = 0.0
        self.global_pause_until = 0.0
        self.lock = asyncio.Lock()

    @property
    def current_delay(self) -> float:
        return self.ladder[self.level]

    @property
    def at_ceiling(self) -> bool:
        return self.current_delay >= RATE_LIMIT_CEILING

    async def record_outcome(self, success: bool, status: int | None = None):
        """Record a request outcome and possibly adjust rate limit."""
        async with self.lock:
            self.outcomes.append(success)
            if success:
                self.success_streak += 1
                # Recovery: step down after a sustained success streak
                if self.success_streak >= RECOVERY_SUCCESS_STREAK and self.level > self.base_index:
                    self.level -= 1
                    self.success_streak = 0
                    logger.info(f"[rate-limit] recovering: per-worker delay -> {self.current_delay}s")
            else:
                self.success_streak = 0
                # Escalate if 429 rate over threshold in current window
                if len(self.outcomes) >= RATE_WINDOW_SIZE:
                    fails = sum(1 for o in self.outcomes if not o)
                    if fails >= RATE_WINDOW_TRIGGER_429 and not self.at_ceiling:
                        old = self.current_delay
                        self.level = min(self.level + 1, len(self.ladder) - 1)
                        # Clear window so we don't immediately re-escalate
                        self.outcomes.clear()
                        logger.warning(
                            f"[rate-limit] {fails}/{RATE_WINDOW_SIZE} recent requests 429'd "
                            f"-- per-worker delay {old}s -> {self.current_delay}s"
                        )

                # Ceiling behavior: pause-all + periodic warnings
                if self.at_ceiling:
                    now = time.time()
                    fails = sum(1 for o in self.outcomes if not o)
                    if fails >= RATE_WINDOW_TRIGGER_429:
                        if now - self.last_ceiling_pause >= CEILING_PAUSE_SECONDS:
                            self.global_pause_until = now + CEILING_PAUSE_SECONDS
                            self.last_ceiling_pause = now
                            logger.warning(
                                f"[rate-limit] still hitting 429s at ceiling -- "
                                f"pausing ALL workers for {CEILING_PAUSE_SECONDS}s. "
                                f"Press Ctrl-C to stop the crawl if this persists."
                            )
                        elif now - self.last_ceiling_warn >= CEILING_WARN_INTERVAL:
                            self.last_ceiling_warn = now
                            logger.warning(
                                f"[rate-limit] at ceiling ({self.current_delay}s) and "
                                f"still seeing 429s. Consider cancelling (Ctrl-C)."
                            )

    async def wait_if_paused(self):
        """Called by workers; blocks if a global ceiling pause is active."""
        while True:
            remaining = self.global_pause_until - time.time()
            if remaining <= 0:
                return
            await asyncio.sleep(min(remaining, 1.0))


# ---------------- Per-worker cooldown ----------------

class WorkerCooldown:
    """Tracks cooldown state for a single worker."""

    def __init__(self):
        self.last_cooldown_at = 0.0
        self.last_cooldown_duration = 0.0

    async def trigger(self, retry_after: float | None) -> float:
        """
        Decide and perform a cooldown sleep on this worker.
        Returns the number of seconds slept.
        """
        now = time.time()
        if retry_after is not None and retry_after > 0:
            sleep_s = retry_after
        else:
            recent = (now - self.last_cooldown_at) <= WORKER_COOLDOWN_ESCALATE_WINDOW
            sleep_s = WORKER_COOLDOWN_LONG if recent else WORKER_COOLDOWN_SHORT
        self.last_cooldown_at = now
        self.last_cooldown_duration = sleep_s
        await asyncio.sleep(sleep_s)
        return sleep_s


# ---------------- Crawler ----------------

class WebCrawler:
    def __init__(self, rate_limit: float, num_workers: int,
                 proxy: str = "", stealth: bool = False,
                 show_browser: bool = False):
        self.base_rate = rate_limit
        self.num_workers = num_workers
        self.proxy = proxy or ""       # one proxy for all request paths; "" = direct
        self.stealth = stealth         # --stealth: real Chrome, persistent ctx, headed, no-viewport
        self.show_browser = show_browser  # --show-browser: show the window instead of hiding it in Xvfb
        self.stop_requested = False    # set by Ctrl-C: stop CRAWLING gracefully
        self.base_domain = None
        self.output_dir = None
        self.documents_dir = None
        self.cdn_documents_dir = None     # documents/cdn/ for CDN-hosted files
        self.csv_path = None
        self.shard_paths = []
        self.errors_log_path = None
        self.downloaded_files = []        # target-domain + known-CDN inline downloads
        self.cdn_downloaded_files = []    # files pulled in the second pass
        self.deferred_unknown_docs = {}   # url -> source_page_url (off-domain, not allowlisted)
        self.js_harvester = None          # PHASE A: set in setup_directories()
        self.php_harvester = None         # PHASE A: PHP source hunt (set in setup)
        self.login_registry = LoginRegistry() if _HAS_LOGIN_DETECT else None  # login portals
        self.jsluice_secret_flag = False  # PHASE B: jsluice found secrets? (Y/N)
        self.semgrep_finding_count = 0    # PHASE B: semgrep PHP findings
        self.semgrep_high_count = 0       # PHASE B: semgrep high-severity findings
        self.retirejs_count = 0           # PHASE B: retire.js JS-lib findings
        self.retirejs_high = 0            # PHASE B: retire.js high/critical
        self.login_portal_count = 0       # PHASE A: login portals detected
        self.file_hashes = set()
        self.pages_since_checkpoint = 0
        self.mime = magic.Magic(mime=True)
        self.has_exiftool = shutil.which('exiftool') is not None

        # Locks (kept minimal: only for genuinely shared mutable state)
        self.file_hashes_lock = asyncio.Lock()
        self.downloaded_files_lock = asyncio.Lock()
        self.pages_crawled_lock = asyncio.Lock()
        self.errors_log_lock = asyncio.Lock()
        self.deferred_lock = asyncio.Lock()

        self.rate_limiter = None  # set in scrape_website

        self.ALLOWED_MIME_TYPES = {
            '.pdf':  ['application/pdf'],
            '.doc':  ['application/msword'],
            '.docx': ['application/vnd.openxmlformats-officedocument.wordprocessingml.document'],
            '.xlsx': ['application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
            '.xls':  ['application/vnd.ms-excel'],
            '.ppt':  ['application/vnd.ms-powerpoint'],
            '.pptx': ['application/vnd.openxmlformats-officedocument.presentationml.presentation'],
        }

    # ---------- Domain helpers ----------

    def _is_target_domain(self, netloc: str) -> bool:
        if not netloc:
            return False
        # Compare at the PRIMARY (registrable) domain level: EVERY subdomain of the
        # target's primary domain is on-domain (www., api., files., the bare apex).
        # Only a genuinely DIFFERENT primary domain (business.com -> charity.org /
        # agency.gov) is off-domain. Fixes the bug where a www./subdomain SEED made
        # sibling subdomains + the apex look external (and got skipped by the crawler
        # AND mislabeled as External Documents).
        return (_registrable_domain(netloc)
                == _registrable_domain(self.base_domain))

    def _is_allowed_cdn(self, netloc: str) -> bool:
        if not netloc:
            return False
        netloc = netloc.lower().split(':')[0]
        return any(netloc == suf or netloc.endswith('.' + suf) for suf in ALLOWED_CDN_SUFFIXES)

    def _classify_file_host(self, url: str) -> str | None:
        netloc = urlparse(url).netloc
        if self._is_target_domain(netloc):
            return 'target'
        if self._is_allowed_cdn(netloc):
            return 'cdn'
        return None

    # ---------- Setup ----------

    def _normalize_url(self, url: str) -> str:
        """Canonicalize a URL so the same page in different forms de-dupes to
        ONE entry in visited_urls. Fixes the 'crawled the landing page twice'
        bug where https://site.com, https://site.com/, and site.com were treated
        as different pages. Lowercases scheme+host, strips fragment, strips a
        trailing slash on the path, drops a default port."""
        try:
            p = urlparse(url)
        except Exception:
            return url
        scheme = (p.scheme or "https").lower()
        netloc = p.netloc.lower()
        # drop default ports
        if netloc.endswith(":80") and scheme == "http":
            netloc = netloc[:-3]
        elif netloc.endswith(":443") and scheme == "https":
            netloc = netloc[:-4]
        path = p.path or "/"
        # strip a single trailing slash (but keep root as "/")
        if len(path) > 1 and path.endswith("/"):
            path = path.rstrip("/")
        if not path:
            path = "/"
        # keep query (different query = different page), drop fragment
        norm = f"{scheme}://{netloc}{path}"
        if p.query:
            norm += f"?{p.query}"
        return norm

    def setup_directories(self, start_url: str):
        parsed_url = urlparse(start_url)
        self.base_domain = parsed_url.netloc
        self.output_dir = Path(self.base_domain)
        self.output_dir.mkdir(exist_ok=True)
        self.documents_dir = self.output_dir / 'documents'
        self.documents_dir.mkdir(exist_ok=True)
        self.cdn_documents_dir = self.documents_dir / 'cdn'
        self.cdn_documents_dir.mkdir(exist_ok=True)
        self.csv_path = self.output_dir / 'raw.csv'
        # Per-run timestamped log (error_YYMMDDHHMM.log) so re-runs / resumes on
        # the same domain NEVER overwrite a previous run's errors.
        self.errors_log_path = self.output_dir / f'error_{datetime.now():%y%m%d%H%M}.log'
        # PHASE A: JS harvester saves external .js into <domain>/js/ (guarded)
        if _HAS_JS_HARVEST:
            self.js_harvester = JSHarvester(
                self.output_dir,
                rate_delay=self.base_rate,
                proxy=self.proxy,             # one proxy for all request paths
                is_target_domain=self._is_target_domain,
            )
        else:
            self.js_harvester = None
            logger.info("[phase-a] js_harvest module not found — JS harvest disabled")
        # PHASE A: PHP harvester saves .php into <domain>/php/, confirmed source
        # into <domain>/php/source/ (semgrep's target). Variant-hunt on by
        # default — it's what feeds real source to semgrep. (guarded)
        if _HAS_PHP_HARVEST:
            self.php_harvester = PHPHarvester(
                self.output_dir,
                rate_delay=self.base_rate,
                proxy=self.proxy,
                is_target_domain=self._is_target_domain,
                hunt_variants=getattr(self, 'php_hunt_variants', True),
            )
        else:
            self.php_harvester = None
            logger.info("[phase-a] php_harvest module not found — PHP harvest disabled")
        # Fresh per-run file (append mode: a same-minute re-run adds to it rather
        # than truncating, so errors are always preserved across crashes/restarts).
        with open(self.errors_log_path, 'a', encoding='utf-8') as f:
            f.write(f"# Error log started {datetime.now().isoformat()}\n")

    def _shard_path(self, worker_id: int) -> Path:
        return self.output_dir / f"report.worker{worker_id}.csv"

    def _init_shard(self, worker_id: int) -> Path:
        path = self._shard_path(worker_id)
        # Fresh file with header
        with open(path, 'w', newline='', encoding='utf-8') as f:
            w = csv.writer(f)
            w.writerow(["Category", "Detail", "Source URL", "Local Path", "Notes"])
        if path not in self.shard_paths:
            self.shard_paths.append(path)
        return path

    # ---------- Logging ----------

    async def _log_error(self, kind: str, url: str, detail: str):
        line = f"{datetime.now().isoformat()}\t{kind}\t{url}\t{detail}\n"
        async with self.errors_log_lock:
            try:
                async with aiofiles.open(self.errors_log_path, 'a', encoding='utf-8') as f:
                    await f.write(line)
            except Exception as e:
                logger.error(f"Failed writing error log: {e}")

    # ---------- Extraction ----------

    async def extract_emails(self, text: str) -> set:
        email_pattern = r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"
        all_emails = set(re.findall(email_pattern, text))
        matched = set()
        for email in all_emails:
            try:
                domain = email.split('@', 1)[1].lower()
            except IndexError:
                continue
            if self._is_target_domain(domain):
                matched.add(email.lower())
        return matched

    async def extract_api_keys(self, text: str) -> set:
        api_key_patterns = [
            r"AIza[0-9A-Za-z\-_]{35}",
            r"sk_live_[0-9a-zA-Z]{24}",
            r"AKIA[0-9A-Z]{16}",
            r"ghp_[0-9a-zA-Z]{36}",
            r"SG\.[a-zA-Z0-9_\-]{22}\.[a-zA-Z0-9_\-]{43}",
            r"sk-[a-zA-Z0-9]{32,}",
            r"twilio_[a-zA-Z0-9]{32}",
            r"xoxb-[0-9a-zA-Z]{24,34}",
            r"discord\.com/api/webhooks/[0-9]+/[A-Za-z0-9_\-]+",
        ]
        keys_found = set()
        for pattern in api_key_patterns:
            keys_found.update(re.findall(pattern, text))
        return keys_found

    # ---------- File handling ----------

    async def verify_file_type(self, file_path: Path, expected_extension: str) -> bool:
        try:
            file_mime = self.mime.from_file(str(file_path))
            allowed_mimes = self.ALLOWED_MIME_TYPES.get(expected_extension.lower(), [])
            return file_mime in allowed_mimes if allowed_mimes else False
        except Exception as e:
            logger.error(f"Error verifying file type for {file_path}: {e}")
            return False

    async def calculate_file_hash(self, file_path: Path) -> str | None:
        try:
            async with aiofiles.open(file_path, 'rb') as f:
                content = await f.read()
                return hashlib.sha256(content).hexdigest()
        except Exception as e:
            logger.error(f"Error calculating hash for {file_path}: {e}")
            return None

    async def is_duplicate_content(self, file_path: Path) -> bool:
        file_hash = await self.calculate_file_hash(file_path)
        if not file_hash:
            return True
        async with self.file_hashes_lock:
            if file_hash in self.file_hashes:
                return True
            self.file_hashes.add(file_hash)
            return False

    async def download_file(self, url: str, session, shard_writer, source_page: str = "") -> bool:
        """
        Inline download path used during the crawl.
        - target / known-CDN documents are downloaded immediately.
        - unknown off-domain documents are deferred to the end-of-run second pass.
        """
        host_class = self._classify_file_host(url)
        if host_class is None:
            # Unknown off-domain document: defer for heuristic checking later.
            async with self.deferred_lock:
                if url not in self.deferred_unknown_docs:
                    self.deferred_unknown_docs[url] = source_page
            return False

        target_dir = self.cdn_documents_dir if host_class == 'cdn' else self.documents_dir
        note = "CDN-hosted (known)" if host_class == 'cdn' else "Target domain"
        files_list = self.cdn_downloaded_files if host_class == 'cdn' else self.downloaded_files
        return await self._download_core(
            url, session, shard_writer, target_dir, note, files_list,
            category="CDN Document" if host_class == 'cdn' else "Document",
        )

    async def _download_core(self, url: str, session, shard_writer, target_dir: Path,
                             note: str, files_list: list, category: str) -> bool:
        """Shared download + verify + dedupe + record logic."""
        parsed_url = urlparse(url)
        original_filename = (os.path.basename(parsed_url.path)
                             or f"document_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf")
        _, extension = os.path.splitext(original_filename.lower())
        if extension not in DOWNLOAD_EXTENSIONS:
            return False

        safe_filename = ''.join(c for c in original_filename if c.isalnum() or c in '._-')
        file_path = target_dir / safe_filename
        counter = 1
        while file_path.exists():
            name, ext = os.path.splitext(safe_filename)
            file_path = target_dir / f"{name}_{counter}{ext}"
            counter += 1

        def record_failure(reason: str):
            shard_writer.writerow([
                category, safe_filename, url, "",
                f"Download failed: {reason}"
            ])

        try:
            async with session.get(url, proxy=self.proxy or None) as response:
                if response.status != 200:
                    reason = f"HTTP {response.status}"
                    if response.status == 429:
                        await self._log_error("429-download", url, f"status={response.status}")
                    await self._log_error("download-error", url, reason)
                    record_failure(reason)
                    return False
                temp_path = file_path.with_suffix(file_path.suffix + '.temp')
                async with aiofiles.open(temp_path, mode='wb') as f:
                    await f.write(await response.read())

            if not await self.verify_file_type(temp_path, extension):
                os.remove(temp_path)
                reason = f"MIME mismatch for {extension}"
                await self._log_error("download-error", url, reason)
                record_failure(reason)
                return False
            if await self.is_duplicate_content(temp_path):
                os.remove(temp_path)
                return False

            os.rename(temp_path, file_path)
            file_info = {
                'url': url,
                'local_path': str(file_path),
                'file_name': file_path.name,
                'file_size': os.path.getsize(file_path),
            }
            async with self.downloaded_files_lock:
                files_list.append(file_info)
            shard_writer.writerow([category, file_path.name, url, str(file_path), note])
            logger.info(f"Downloaded [{category}] file: {url}")
            return True
        except aiohttp.ClientConnectionError as e:
            reason = f"connection error: {e.__class__.__name__}"
            await self._log_error("download-error", url, f"{reason}: {e}")
            record_failure(reason)
            return False
        except asyncio.TimeoutError:
            await self._log_error("download-error", url, "timeout")
            record_failure("timeout")
            return False
        except Exception as e:
            await self._log_error("download-error", url, f"{e.__class__.__name__}: {e}")
            record_failure(f"{e.__class__.__name__}")
            return False

    # ---------- Metadata ----------

    async def scan_metadata(self, shard_writer, files=None, category="Metadata"):
        if not self.has_exiftool:
            logger.info("Exiftool not found, skipping metadata scan")
            return
        if files is None:
            files = self.downloaded_files
        for file_info in files:
            try:
                result = subprocess.run(
                    ['exiftool', file_info['local_path']],
                    capture_output=True, text=True, timeout=60,
                )
                compact = ' | '.join(
                    line.strip() for line in result.stdout.splitlines() if line.strip()
                )[:4000]
                shard_writer.writerow([
                    category,
                    file_info['file_name'],
                    file_info['url'],
                    file_info['local_path'],
                    compact,
                ])
            except Exception as e:
                await self._log_error("metadata-error", file_info['url'], str(e))

    # ---------- Heuristic CDN detection (second pass) ----------

    async def _detect_cdn_via_headers(self, url: str, session) -> str | None:
        """
        Fetch response headers for a URL and look for CDN fingerprints.
        Returns a short description of the matched signal, or None.
        Uses a HEAD request first, falling back to a ranged GET if needed.
        """
        async def _examine(headers) -> str | None:
            lowered = {k.lower(): (v or "") for k, v in headers.items()}
            for hname in HEURISTIC_CDN_HEADER_SIGNALS:
                if hname in lowered:
                    return f"header:{hname}"
            via = lowered.get('via', '').lower()
            for sub in HEURISTIC_CDN_VIA_SUBSTRINGS:
                if sub in via:
                    return f"via:{sub}"
            server = lowered.get('server', '').lower()
            for sub in HEURISTIC_CDN_SERVER_SUBSTRINGS:
                if sub in server:
                    return f"server:{sub}"
            return None

        try:
            async with session.head(url, allow_redirects=True,
                                    proxy=self.proxy or None) as resp:
                signal = await _examine(resp.headers)
                if signal:
                    return signal
        except Exception:
            pass  # some hosts reject HEAD; fall through to GET

        try:
            # Ranged GET to avoid pulling the whole file just for headers
            async with session.get(url, headers={'Range': 'bytes=0-0'},
                                   proxy=self.proxy or None) as resp:
                return await _examine(resp.headers)
        except Exception as e:
            await self._log_error("heuristic-error", url, str(e))
            return None

    async def process_deferred_documents(self, shard_writer):
        """
        Second pass over off-domain document URLs that weren't on the allowlist.
        For each unique URL:
          - run heuristic CDN detection via response headers
          - if detected: download to documents/cdn/, record as 'CDN Document'
          - if not detected: record as 'Skipped Link' for manual review
        """
        async with self.deferred_lock:
            deferred = dict(self.deferred_unknown_docs)

        if not deferred:
            logger.info("No off-domain (external) documents to log.")
            return

        # Operator policy: these are off-domain AND not on the CDN allowlist, i.e.
        # THIRD-PARTY content (e.g. apple.com, *.gov). They are frequently served
        # via a CDN, but they belong to ANOTHER site, not the target's CDN — so we
        # do NOT download them (no traffic to out-of-scope third parties) and we do
        # NOT header-probe them (that probe mislabeled CDN-fronted external sites as
        # "CDN Document"). We LOG each as an "External Document" with its source host
        # so the analyst can audit which, if any, are worth a manual look.
        logger.info(f"Logging {len(deferred)} off-domain EXTERNAL document URL(s) "
                    f"(third-party content — recorded, not downloaded).")
        for url, source_page in deferred.items():
            netloc = urlparse(url).netloc
            shard_writer.writerow([
                "External Document", url, source_page, "",
                f"Off-domain / third-party host: {netloc} (not downloaded)"
            ])


    # ---------- Page scraping ----------

    async def find_documents(self, page) -> list:
        try:
            links = await page.eval_on_selector_all(
                "a",
                """elements => elements.map(e => ({href: e.href, text: e.textContent}))"""
            )
            return [link['href'] for link in links
                    if link.get('href')
                    and any(link['href'].lower().split('?')[0].endswith(ext) for ext in DOWNLOAD_EXTENSIONS)]
        except Exception as e:
            logger.error(f"Error finding documents: {e}")
            return []

    async def scrape_page(self, page, url: str, shard_writer, cooldown: WorkerCooldown) -> tuple:
        """
        Scrape a single page. Returns (emails, api_keys, new_links).
        Records request outcome with the rate limiter.
        """
        # Defensive guard: never navigate the browser to a non-HTML resource.
        # These should be filtered before enqueue, but check again here in case
        # something slipped past (e.g. from the initial start_url or a redirect).
        ext = _url_extension(url)
        if ext in DOWNLOAD_EXTENSIONS:
            # A document URL ended up in the crawl queue. Try to download it
            # via aiohttp instead of navigating the browser to it.
            async with aiohttp.ClientSession() as session:
                await self.download_file(url, session, shard_writer, source_page=url)
            return (set(), set(), set())
        if ext in NON_NAVIGABLE_INTERESTING:
            shard_writer.writerow([
                "Skipped Link", url, url, "",
                f"Non-navigable: {ext}"
            ])
            return (set(), set(), set())
        if ext in NON_NAVIGABLE_MEDIA:
            await self._log_error("skipped-media", url, f"ext={ext}")
            return (set(), set(), set())

        await self.rate_limiter.wait_if_paused()

        try:
            logger.info(f"Scanning: {url}")
            response = await page.goto(url, timeout=30000)
            status = response.status if response else None

            # 429 handling at the page-fetch level
            if status == 429:
                retry_after = None
                try:
                    if response and 'retry-after' in response.headers:
                        retry_after = float(response.headers['retry-after'])
                except (ValueError, TypeError):
                    retry_after = None
                await self.rate_limiter.record_outcome(False, status=429)
                slept = await cooldown.trigger(retry_after)
                await self._log_error("429", url, f"slept={slept}s retry_after={retry_after}")
                return (set(), set(), set())

            try:
                await page.wait_for_load_state("networkidle", timeout=15000)
            except Exception:
                pass

            content = await page.content()
            # PHASE A: note every <script src> on this page for later fetching
            if self.js_harvester is not None:
                self.js_harvester.note_urls(discover_js_urls(content, url), url)
            # PHASE A: note every .php endpoint referenced on this page
            if self.php_harvester is not None:
                self.php_harvester.note_urls(discover_php_urls(content, url), url)
            # PHASE A: login-portal detection (content-analysis, no extra requests)
            if self.login_registry is not None:
                try:
                    title = await page.title()
                except Exception:  # noqa: BLE001
                    title = ""
                self.login_registry.add(detect_login(content, url, title))
            await self.rate_limiter.record_outcome(True, status=status)

            emails_found = await self.extract_emails(content)
            api_keys_found = await self.extract_api_keys(content)

            for email in emails_found:
                shard_writer.writerow(["Email", email, url, "", ""])
            for key in api_keys_found:
                shard_writer.writerow(["API Key", key, url, "", ""])

            async with aiohttp.ClientSession() as session:
                for link in await self.find_documents(page):
                    await self.download_file(link, session, shard_writer, source_page=url)

            links = await page.eval_on_selector_all("a", "elements => elements.map(e => e.href)")
            valid_links = set()
            for link in links:
                if not link:
                    continue
                absolute = urljoin(url, link)
                parsed = urlparse(absolute)
                if parsed.scheme not in ('http', 'https'):
                    continue
                link_ext = _url_extension(absolute)

                # Document links: never navigated by the browser.
                # find_documents() above already routed same-page docs to the
                # downloader (which downloads known hosts and defers unknown
                # off-domain ones). Anything caught here that wasn't handled is
                # deferred too, so it gets a heuristic check in the second pass.
                if link_ext in DOWNLOAD_EXTENSIONS:
                    if self._classify_file_host(absolute) is None:
                        async with self.deferred_lock:
                            if absolute not in self.deferred_unknown_docs:
                                self.deferred_unknown_docs[absolute] = url
                    # Don't enqueue.
                    continue

                # Non-navigable but interesting -> record for manual review.
                if link_ext in NON_NAVIGABLE_INTERESTING:
                    shard_writer.writerow([
                        "Skipped Link", absolute, url, "",
                        f"Non-navigable: {link_ext}"
                    ])
                    continue

                # Media / asset extensions -> silent, error log only.
                if link_ext in NON_NAVIGABLE_MEDIA:
                    await self._log_error("skipped-media", absolute, f"from={url}")
                    continue

                # Normal page: enqueue if on target domain (normalized so the
                # same page in different URL forms doesn't get crawled twice).
                if self._is_target_domain(parsed.netloc):
                    valid_links.add(self._normalize_url(absolute))
            return (emails_found, api_keys_found, valid_links)
        except Exception as e:
            await self._log_error("scrape-error", url, f"{e.__class__.__name__}: {e}")
            await self.rate_limiter.record_outcome(True, status=None)  # don't penalize rate for non-429 issues
            return (set(), set(), set())

    # ---------- Worker ----------

    async def worker(self, worker_id: int, browser, queue: asyncio.Queue,
                     visited_urls: set, pages_crawled: list, stop_event: asyncio.Event):
        shard_path = self._init_shard(worker_id)
        shard_file = open(shard_path, 'a', newline='', encoding='utf-8', buffering=1)  # line-buffered
        shard_writer = csv.writer(shard_file)
        cooldown = WorkerCooldown()

        try:
            page = await browser.new_page()
        except Exception as e:
            logger.error(f"Worker {worker_id} could not open page: {e}")
            shard_file.close()
            return

        last_request_at = 0.0

        try:
            while not stop_event.is_set():
                # graceful stop: operator hit Ctrl-C. Stop pulling NEW pages;
                # in-flight pages in other workers finish on their own.
                if self.stop_requested:
                    break

                try:
                    url = await asyncio.wait_for(queue.get(), timeout=2.0)
                except asyncio.TimeoutError:
                    # queue empty for 2s -> this worker is done (site exhausted)
                    break

                try:
                    norm = self._normalize_url(url)
                    async with self.pages_crawled_lock:
                        if norm in visited_urls:
                            continue
                        visited_urls.add(norm)
                        pages_crawled[0] += 1
                        current_count = pages_crawled[0]
                        self.pages_since_checkpoint += 1
                        do_checkpoint = self.pages_since_checkpoint >= CHECKPOINT_INTERVAL
                        if do_checkpoint:
                            self.pages_since_checkpoint = 0

                    # Per-worker pacing
                    delay = self.rate_limiter.current_delay
                    elapsed = time.time() - last_request_at
                    if elapsed < delay:
                        await asyncio.sleep(delay - elapsed)
                    last_request_at = time.time()

                    _, _, new_links = await self.scrape_page(page, url, shard_writer, cooldown)

                    # don't enqueue new work once a stop was requested
                    if not self.stop_requested:
                        for link in new_links:
                            if self._normalize_url(link) not in visited_urls:
                                await queue.put(link)

                    logger.info(f"Worker {worker_id} done with {url} -- "
                                f"{current_count} pages crawled "
                                f"(delay={self.rate_limiter.current_delay}s)")

                    if do_checkpoint:
                        await self.checkpoint()
                except Exception as e:
                    await self._log_error("worker-error", url, str(e))
                finally:
                    queue.task_done()
        finally:
            try:
                await page.close()
            except Exception:
                pass
            try:
                shard_file.close()
            except Exception:
                pass

    # ---------- Checkpoint ----------

    async def checkpoint(self):
        """Copy each shard to a .checkpoint sibling. Cheap; shards are already on disk."""
        try:
            for shard in self.shard_paths:
                ckpt = shard.with_suffix(shard.suffix + '.checkpoint')
                shutil.copyfile(shard, ckpt)
            # FW-8: persist the crawl frontier (visited + pending) so a crash /
            # Ctrl-C can resume instead of re-crawling from the seed.
            try:
                import json as _json
                q = getattr(self, "_queue_ref", None)
                pending = list(getattr(q, "_queue", [])) if q is not None else []
                frontier = {
                    "seed": getattr(self, "_frontier_seed", ""),
                    "visited": sorted(getattr(self, "_visited_ref", set()) or set()),
                    "pending": pending,
                }
                (self.output_dir / "frontier.json").write_text(_json.dumps(frontier))
            except Exception as _fe:
                logger.error(f"Frontier persist error: {_fe}")
            logger.info(f"Checkpoint snapshot written for {len(self.shard_paths)} shards")
        except Exception as e:
            logger.error(f"Checkpoint error: {e}")

    # ---------- Orchestrate ----------

    async def scrape_website(self, start_url: str):
        self.setup_directories(start_url)
        self.rate_limiter = AdaptiveRateLimiter(self.base_rate, self._log_error)
        # FW-8: real intra-crawl resume. If a frontier.json from a prior run of the
        # SAME seed exists, reload the visited set + pending queue and continue,
        # instead of re-crawling from page 1 (crawls routinely hit 10k+ pages).
        seed_norm = self._normalize_url(start_url)
        queue = asyncio.Queue()
        visited_urls = set()
        resumed = False
        _fpath = self.output_dir / "frontier.json"
        if _fpath.is_file():
            try:
                import json as _json
                _fr = _json.loads(_fpath.read_text())
                _pending = list(_fr.get("pending", []))
                # Only RESUME when the same seed has REAL pending work left, i.e.
                # the prior run was interrupted mid-crawl. A COMPLETED crawl leaves
                # visited=<everything>, pending=[] — reloading that made the run
                # start with an empty queue against a fully-visited set and crawl
                # nothing (stopping after ~1 page). That stale-completed frontier is
                # exactly what made every previously-crawled target do 1 page on the
                # next run. So: resume only if pending is non-empty; otherwise start
                # fresh from the seed (and drop the stale frontier).
                if _fr.get("seed") == seed_norm and _pending:
                    visited_urls = set(_fr.get("visited", []))
                    for _u in _pending:
                        await queue.put(_u)
                    resumed = queue.qsize() > 0
                    if resumed:
                        logger.info(f"[resume] frontier loaded: {len(visited_urls)} "
                                    f"visited, {queue.qsize()} pending")
                else:
                    # completed or different-seed frontier: don't resume; clear it
                    # so this fresh crawl writes its own.
                    try:
                        _fpath.unlink()
                    except OSError:
                        pass
            except Exception as _e:
                logger.error(f"[resume] frontier load failed, starting fresh: {_e}")
        if not resumed:
            await queue.put(seed_norm)
        self._queue_ref = queue
        self._visited_ref = visited_urls
        self._frontier_seed = seed_norm
        pages_crawled = [0]
        stop_event = asyncio.Event()

        # Graceful stop: first Ctrl-C stops CRAWLING (workers stop pulling new
        # pages, in-flight pages finish), then the final stages (JS harvest,
        # Phase B, report) run to completion. A second Ctrl-C hard-aborts.
        import signal
        loop = asyncio.get_event_loop()

        def _request_stop():
            if not self.stop_requested:
                self.stop_requested = True
                logger.warning("\n[stop] Ctrl-C received -- finishing in-flight "
                               "pages, then running final stages. "
                               "Press Ctrl-C again to hard-abort.")
            else:
                logger.warning("\n[stop] second Ctrl-C -- hard abort.")
                raise KeyboardInterrupt()

        try:
            loop.add_signal_handler(signal.SIGINT, _request_stop)
            _sig_installed = True
        except (NotImplementedError, RuntimeError):
            # add_signal_handler not available on some platforms (e.g. Windows);
            # fall back to default KeyboardInterrupt behavior.
            _sig_installed = False

        # --stealth uses a HEADED browser. By default we hide it in an INVISIBLE
        # virtual display (Xvfb) so it renders off-screen — no window, no keyboard/
        # mouse grab, identical on a desktop or a headless box. --show-browser skips
        # this to put the real window on screen. Falls back to a visible window if
        # Xvfb / pyvirtualdisplay aren't installed (setup.sh installs them).
        _vdisp = None
        if self.stealth and not self.show_browser:
            try:
                from pyvirtualdisplay import Display
                _vdisp = Display(visible=False, size=(1920, 1080))
                _vdisp.start()
                logger.info("[stealth] invisible virtual display started (Xvfb) — headed "
                            "Chrome renders off-screen; no window or input grab.")
            except Exception as _e:
                logger.warning(f"[stealth] couldn't start a virtual display ({_e}); the "
                               f"headed window WILL be visible. Install xvfb + "
                               f"pyvirtualdisplay (setup.sh does this) to hide it, or pass "
                               f"--show-browser to silence this.")
                _vdisp = None
        try:
            async with async_playwright() as p:
                if self.stealth:
                    # Patchright authors' recommended "completely undetected" config:
                    # REAL Chrome (channel="chrome"), PERSISTENT context, HEADED,
                    # native resolution. launch_persistent_context returns a context
                    # with the same .new_page()/.close() the workers use, so only this
                    # branch differs. Needs `patchright install chrome` + a display
                    # (wrap in `xvfb-run` on a headless server).
                    _profile = str(self.output_dir / ".chrome-profile")
                    _kw = {"user_data_dir": _profile, "channel": "chrome",
                           "headless": False, "no_viewport": True}
                    if self.proxy:
                        _kw["proxy"] = {"server": self.proxy}
                    logger.info("[stealth] REAL Chrome (channel=chrome), persistent "
                                "context, headed, no-viewport. Needs `patchright "
                                "install chrome` + a display (xvfb-run on headless).")
                    try:
                        browser = await p.chromium.launch_persistent_context(**_kw)
                    except Exception as _e:
                        logger.error(f"[stealth] launch failed: {_e}. Real Chrome must "
                                     f"be installed (`patchright install chrome`) and a "
                                     f"display available (use `xvfb-run` on a headless "
                                     f"server).")
                        raise
                else:
                    launch_kwargs = {"headless": True}
                    if self.proxy:
                        launch_kwargs["proxy"] = {"server": self.proxy}
                    browser = await p.chromium.launch(**launch_kwargs)
                try:
                    workers = [
                        asyncio.create_task(
                            self.worker(i, browser, queue, visited_urls, pages_crawled, stop_event)
                        )
                        for i in range(self.num_workers)
                    ]
                    await asyncio.gather(*workers, return_exceptions=True)
                finally:
                    try:
                        await browser.close()
                    except Exception:
                        pass

            if self.stop_requested:
                logger.info(f"Crawl stopped by operator. {pages_crawled[0]} pages crawled. "
                            f"Running final stages...")
            else:
                logger.info(f"Website fully exhausted. {pages_crawled[0]} pages crawled.")
        finally:
            if _sig_installed:
                try:
                    loop.remove_signal_handler(signal.SIGINT)
                except Exception:
                    pass
            if _vdisp is not None:
                try:
                    _vdisp.stop()
                except Exception:
                    pass
            await self.finalize_csv()

    # ---------- Phase B: JS analysis (secrets + jsluice) ----------

    async def _run_phase_b(self, shard_writer):
        """Post-crawl analysis of the harvested JS files:
          - secret_scan: our regex/entropy secret detector (Gitleaks+SecretFinder
            patterns), writes 'Secret' rows with full value + source location.
          - jsluice urls: AST endpoint extraction, writes 'JS Endpoint' rows.
          - jsluice secrets: raw capture to js/jsluice_secrets.txt; sets the
            Jsluice Secret? (Y/N) flag from empty/non-empty output.
        Each analyzer degrades gracefully if its dependency is missing."""
        js_paths = self.js_harvester.saved_files()
        if not js_paths:
            logger.info("[phase-b] no saved JS files to analyze (PHP/semgrep "
                        "still runs below)")

        # --- our own regex secret scan (JS) ---
        if js_paths:
            try:
                from secret_scan import scan_folder
                findings = scan_folder(self.js_harvester.js_dir)
                for f in findings:
                    shard_writer.writerow(f.as_row())
                logger.info(f"[phase-b] secret scan: {len(findings)} finding(s)")
            except ImportError:
                logger.info("[phase-b] secret_scan module not found, skipping")
            except Exception as e:  # noqa: BLE001
                logger.error(f"[phase-b] secret scan error: {e}")

        # --- jsluice (external Go tool) ---
        if js_paths:
            try:
                from jsluice_scan import (jsluice_available, run_urls,
                                          run_secrets_raw)
                if jsluice_available():
                    base = f"https://{self.base_domain}"
                    urls = run_urls(js_paths, resolve_base=base)
                    for u in urls:
                        shard_writer.writerow(u.as_row())
                    logger.info(f"[phase-b] jsluice urls: {len(urls)} endpoint(s)")

                    secrets_out = self.js_harvester.js_dir / "jsluice_secrets.txt"
                    self.jsluice_secret_flag = run_secrets_raw(js_paths, secrets_out)
                    logger.info(f"[phase-b] jsluice secrets: "
                                f"{'FOUND (see jsluice_secrets.txt)' if self.jsluice_secret_flag else 'none'}")
                else:
                    logger.info("[phase-b] jsluice not installed, skipping "
                                "(go install github.com/BishopFox/jsluice/cmd/jsluice@latest)")
            except ImportError:
                logger.info("[phase-b] jsluice_scan module not found, skipping")
            except Exception as e:  # noqa: BLE001
                logger.error(f"[phase-b] jsluice error: {e}")

        # --- semgrep over confirmed PHP source (php/source/) ---
        try:
            import semgrep_scan
            if self.php_harvester is not None:
                src_dir = self.php_harvester.source_dir
                out_json = self.php_harvester.php_dir / "semgrep_findings.json"
                findings = semgrep_scan.run(src_dir, out_json)
                for f in findings:
                    shard_writer.writerow(f.as_row())
                if findings:
                    self.semgrep_finding_count = len(findings)
                    self.semgrep_high_count = semgrep_scan.high_severity_count(findings)
                    logger.info(f"[phase-b] semgrep: {len(findings)} finding(s), "
                                f"{self.semgrep_high_count} high-severity")
        except ImportError:
            logger.info("[phase-b] semgrep_scan module not found, skipping")
        except Exception as e:  # noqa: BLE001
            logger.error(f"[phase-b] semgrep error: {e}")

        # --- retire.js over the downloaded JS (js/) ---
        if js_paths:
            try:
                import retirejs_scan
                out_json = self.js_harvester.js_dir / "retirejs_findings.json"
                rfindings = retirejs_scan.run(self.js_harvester.js_dir, out_json)
                for rf in rfindings:
                    shard_writer.writerow(rf.as_row())
                if rfindings:
                    self.retirejs_count = len(rfindings)
                    self.retirejs_high = retirejs_scan.high_count(rfindings)
                    logger.info(f"[phase-b] retire.js: {len(rfindings)} finding(s), "
                                f"{self.retirejs_high} high/critical")
            except ImportError:
                logger.info("[phase-b] retirejs_scan module not found, skipping")
            except Exception as e:  # noqa: BLE001
                logger.error(f"[phase-b] retire.js error: {e}")

        # --- login portals discovered during the crawl ---
        if self.login_registry is not None and self.login_registry.count():
            for row in self.login_registry.rows():
                shard_writer.writerow(row)
            self.login_portal_count = self.login_registry.count()
            logger.info(f"[phase-b] login portals: {self.login_registry.count()} "
                        f"({self.login_registry.high_count()} high-confidence)")

    # ---------- Finalize: merge shards + metadata, dedupe, sort ----------

    async def finalize_csv(self):
        try:
            # Metadata + second-pass go into a dedicated finalize shard
            meta_path = self.output_dir / "report.metadata.csv"
            with open(meta_path, 'w', newline='', encoding='utf-8') as f:
                w = csv.writer(f)
                w.writerow(["Category", "Detail", "Source URL", "Local Path", "Notes"])
                # 1) metadata for inline target-domain downloads
                await self.scan_metadata(w, files=self.downloaded_files, category="Metadata")
                # 2) metadata for inline known-CDN downloads
                await self.scan_metadata(w, files=self.cdn_downloaded_files, category="Metadata")
                # 3) second pass: off-domain/third-party docs -> logged as
                #    External Documents (NOT downloaded, NOT header-probed)
                try:
                    await self.process_deferred_documents(w)   # FW-6: contained
                except Exception as _e:
                    logger.error(f"[finalize] deferred-docs step failed: {_e}")
                # 4) PHASE A: fetch all discovered JS, save to js/, write rows
                if self.js_harvester is not None:
                    try:   # FW-6: contain so a harvest error can't skip the merge
                        await self.js_harvester.fetch_all()
                        for row in self.js_harvester.report_rows():
                            w.writerow(row)
                        self.js_harvester.write_manifest()
                        logger.info(self.js_harvester.summary())
                    except Exception as _e:
                        logger.error(f"[finalize] JS harvest step failed: {_e}")

                # 4b) PHASE A: fetch discovered PHP + hunt source-disclosure
                #     variants, save to php/ (+ confirmed source to php/source/)
                if self.php_harvester is not None:
                    try:   # FW-6: contain so a harvest error can't skip the merge
                        await self.php_harvester.fetch_all()
                        for row in self.php_harvester.report_rows():
                            w.writerow(row)
                        self.php_harvester.write_manifest()
                        disclosed = self.php_harvester.disclosed_count()
                        logger.info(f"[phase-a] php: {len(self.php_harvester.files)} "
                                    f"endpoint(s), {disclosed} with disclosed source")
                    except Exception as _e:
                        logger.error(f"[finalize] PHP harvest step failed: {_e}")

                # 5) PHASE B: analyze the harvested JS (secrets + jsluice).
                #    Runs as a post-crawl pass over the saved js/ files.
                if self.js_harvester is not None:
                    await self._run_phase_b(w)
            if meta_path not in self.shard_paths:
                self.shard_paths.append(meta_path)

            # Merge all shards
            header = ["Category", "Detail", "Source URL", "Local Path", "Notes"]
            seen = set()
            merged = []
            for shard in self.shard_paths:
                if not shard.exists():
                    continue
                with open(shard, 'r', newline='', encoding='utf-8') as f:
                    reader = csv.reader(f)
                    try:
                        next(reader)  # skip header
                    except StopIteration:
                        continue
                    for row in reader:
                        if not row:
                            continue
                        # Pad short rows defensively
                        while len(row) < 5:
                            row.append("")
                        t = tuple(row[:5])
                        if t in seen:
                            continue
                        seen.add(t)
                        merged.append(row[:5])

            # Sort order
            category_order = {
                "Email": 0, "API Key": 1, "Secret": 2, "JS Endpoint": 3,
                "JavaScript": 4, "Document": 5, "CDN Document": 6,
                "Skipped Link": 7, "Metadata": 8,
                "Login Portal": 9, "Retire.js Finding": 10,
            }
            merged.sort(key=lambda r: (category_order.get(r[0], 99), (r[1] or "").lower()))

            # Write final CSV
            with open(self.csv_path, 'w', newline='', encoding='utf-8') as f:
                writer = csv.writer(f)
                writer.writerow(header)
                writer.writerows(merged)

            # Summary counts
            counts = {"Email": 0, "API Key": 0, "Secret": 0, "JS Endpoint": 0,
                      "JavaScript": 0, "Document": 0, "CDN Document": 0,
                      "Skipped Link": 0, "Metadata": 0,
                      "Login Portal": 0, "Retire.js Finding": 0}
            for r in merged:
                if r[0] in counts:
                    counts[r[0]] += 1

            # Count failed-download rows (Document/CDN Document with empty Local Path)
            failed_downloads = sum(
                1 for r in merged
                if r[0] in ("Document", "CDN Document") and not r[3]
            )

            logger.info(f"Final CSV written: {self.csv_path} ({len(merged)} unique rows)")
            logger.info(f"Summary -- Emails: {counts['Email']}, "
                        f"API keys: {counts['API Key']}, "
                        f"Secrets: {counts['Secret']}, "
                        f"JS Endpoints: {counts['JS Endpoint']}, "
                        f"JavaScript files: {counts['JavaScript']}, "
                        f"Documents: {counts['Document']}, "
                        f"CDN Documents: {counts['CDN Document']} "
                        f"({failed_downloads} failed downloads total), "
                        f"Skipped Links: {counts['Skipped Link']}, "
                        f"Metadata rows: {counts['Metadata']}")
            logger.info(f"Jsluice Secret? (Y/N): "
                        f"{'Y' if self.jsluice_secret_flag else 'N'}"
                        + ("  -> read js/jsluice_secrets.txt"
                           if self.jsluice_secret_flag else ""))
            logger.info(f"Target-domain files: {self.documents_dir}/")
            logger.info(f"CDN files: {self.cdn_documents_dir}/")
            logger.info(f"Errors log: {self.errors_log_path}")
            logger.info(f"Shard files retained in {self.output_dir}/ for inspection")

            # Build the workbook: At a Glance (primary) + Raw Data tabs.
            # Solo runs get the same actionable summary Nigredo produces.
            try:
                from at_a_glance import write_workbook
                xlsx_path = self.output_dir / f"{self.base_domain}_report.xlsx"
                ok = write_workbook(self.csv_path, xlsx_path, [self.base_domain])
                if ok:
                    logger.info(f"Workbook written: {xlsx_path} "
                                f"(At a Glance + Raw Data tabs)")
                else:
                    logger.info("Workbook skipped (install openpyxl for the "
                                "At a Glance workbook: pip install openpyxl)")
            except ImportError:
                logger.info("at_a_glance module not found — workbook skipped "
                            "(raw.csv still written)")
            except Exception as e:  # noqa: BLE001
                logger.error(f"Workbook build error: {e} (raw.csv still written)")
        except Exception as e:
            logger.error(f"Error finalizing CSV: {e}")


# ---------------- CLI ----------------

def validate_url(url: str) -> str:
    if not url.startswith(('http://', 'https://')):
        url = 'https://' + url
    parsed = urlparse(url)
    if not all([parsed.scheme, parsed.netloc]):
        raise ValueError("Invalid URL")
    return url


def parse_arguments():
    parser = argparse.ArgumentParser(description="Web Crawler for Document Collection")
    parser.add_argument("--url", type=str, help="Starting URL to crawl")
    parser.add_argument("--rate-limit", type=float, default=DEFAULT_RATE_LIMIT,
                        help="Per-worker delay between requests in seconds (default: 0.3)")
    parser.add_argument("--workers", type=int, default=DEFAULT_NUM_WORKERS,
                        help=f"Number of concurrent workers (default: {DEFAULT_NUM_WORKERS})")
    parser.add_argument("--proxy", type=str, default="",
                        help="Proxy URL for ALL requests (browser, downloads, JS "
                             "fetches), e.g. http://127.0.0.1:8080 or "
                             "socks5://127.0.0.1:9050. Blank = direct (no proxy).")
    parser.add_argument("--php-no-hunt", action="store_true",
                        help="Disable the PHP source-disclosure variant hunt "
                             "(.bak/.phps/~ etc.). The hunt is ON by default because "
                             "it's what feeds real PHP source to semgrep; disable for "
                             "a quieter crawl (semgrep will then have little to scan).")
    parser.add_argument("--stealth", action="store_true",
                        help="MAX-STEALTH mode — the Patchright authors' recommended "
                             "'completely undetected' config: REAL Chrome "
                             "(channel=chrome) in a persistent context, HEADED, "
                             "no-viewport. Requires `patchright install chrome` AND a "
                             "display: on a headless box wrap the command in xvfb, e.g. "
                             "`xvfb-run python FunnelWeb.py --url https://t --stealth`. "
                             "Default is headless Chromium.")
    parser.add_argument("--show-browser", action="store_true",
                        help="With --stealth, put the real Chrome window ON SCREEN "
                             "instead of hiding it in an invisible virtual display "
                             "(Xvfb). Use it to watch the crawl or solve a challenge by "
                             "hand. Ignored without --stealth.")
    return parser.parse_args()


if __name__ == "__main__":
    try:
        args = parse_arguments()
        start_url = args.url or input("Enter the website URL: ").strip()
        start_url = validate_url(start_url)
        crawler = WebCrawler(
            rate_limit=args.rate_limit,
            num_workers=args.workers,
            proxy=args.proxy,
            stealth=args.stealth,
            show_browser=args.show_browser,
        )
        crawler.php_hunt_variants = not args.php_no_hunt
        if args.php_no_hunt:
            logger.info("PHP source-disclosure variant hunt DISABLED "
                        "(semgrep will have limited input)")
        if args.proxy:
            logger.info(f"Routing all requests through proxy: {args.proxy}")
        asyncio.run(crawler.scrape_website(start_url))
    except KeyboardInterrupt:
        logger.info("Crawl interrupted by user")
    except Exception as e:
        logger.error(f"An error occurred: {e}")
