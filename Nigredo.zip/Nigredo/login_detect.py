#!/usr/bin/env python3
"""
login_detect.py — login-portal detection for FunnelWeb (content-analysis).

Inspects HTML FunnelWeb already fetched (zero extra requests) to flag login /
auth portals. Signals (any 2+ -> flag; a password field alone -> HIGH):
  - <input type="password">                      (strongest)
  - <form> whose action/id/class ~ login/signin/auth/logon/session
  - URL or <title> ~ login/signin/sso/admin/portal/dashboard
  - known-platform / protocol markers (OAuth, SAML, Okta/Auth0/ADFS, wp-login)

Detection ONLY — never interacts with the portal (no cred submission, no probing).
External IdP pages (Okta/Auth0/Google SSO) are flagged but labeled so they aren't
mistaken for a target-owned portal.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from urllib.parse import urlparse

_PW_RE = re.compile(r'<input[^>]+type\s*=\s*["\']?password', re.IGNORECASE)
_USER_RE = re.compile(r'<input[^>]+(?:name|id)\s*=\s*["\']?(?:user(?:name)?|email|userid|uid|login)\b', re.IGNORECASE)
_FORM_RE = re.compile(r'<form\b[^>]*>', re.IGNORECASE)
_LOGIN_WORDS = ("login", "signin", "sign-in", "log-in", "logon", "auth",
                "session", "sso", "authenticate")
_URL_TITLE_HINTS = ("login", "signin", "sign-in", "sso", "auth", "admin",
                    "portal", "dashboard", "account", "logon")
_EXTERNAL_IDP = ("okta.com", "auth0.com", "login.microsoftonline.com",
                 "accounts.google.com", "onelogin.com", "pingidentity.com",
                 "adfs", "login.salesforce.com")
_PROTO_MARKERS = {
    "oauth": re.compile(r'response_type=|/oauth/|/authorize\?', re.IGNORECASE),
    "saml": re.compile(r'SAMLRequest|/saml/|/adfs/', re.IGNORECASE),
    "wordpress": re.compile(r'wp-login\.php|/wp-admin', re.IGNORECASE),
    "basic-auth-form": re.compile(r'www-authenticate', re.IGNORECASE),
}


@dataclass
class LoginFinding:
    url: str = ""
    confidence: str = ""       # HIGH / MEDIUM / LOW
    auth_type: str = ""        # form / oauth / saml / platform / basic
    signals: list = field(default_factory=list)
    is_external_idp: bool = False

    def as_row(self) -> list:
        note = f"{self.confidence} · {self.auth_type}"
        if self.is_external_idp:
            note += " · EXTERNAL IdP (not target-owned)"
        note += " · " + ", ".join(self.signals)
        return ["Login Portal", self.url, self.url, "", note]


def _form_looks_like_login(html: str) -> bool:
    for m in _FORM_RE.finditer(html):
        tag = m.group(0).lower()
        if any(w in tag for w in _LOGIN_WORDS):
            return True
    return False


def detect_login(content: str, url: str, title: str = "") -> LoginFinding | None:
    """Return a LoginFinding if this page looks like a login portal, else None."""
    if not content:
        return None
    signals = []
    auth_type = "form"

    has_pw = bool(_PW_RE.search(content))
    if has_pw:
        signals.append("password-field")
    has_user = bool(_USER_RE.search(content))
    if has_user:
        signals.append("username-field")

    if _form_looks_like_login(content):
        signals.append("login-named-form")

    u = url.lower()
    t = (title or "").lower()
    if any(h in u for h in _URL_TITLE_HINTS):
        signals.append("url-hint")
    if any(h in t for h in _URL_TITLE_HINTS):
        signals.append("title-hint")

    # protocol / platform markers
    for name, rx in _PROTO_MARKERS.items():
        if rx.search(content) or rx.search(url):
            signals.append(name)
            if name in ("oauth", "saml"):
                auth_type = name
            elif name == "wordpress":
                auth_type = "platform"
            elif name == "basic-auth-form":
                auth_type = "basic"

    # external IdP?
    host = urlparse(url).hostname or ""
    is_external = any(idp in host or idp in content.lower()[:5000]
                      for idp in _EXTERNAL_IDP)
    if is_external:
        signals.append("external-idp")
        if auth_type == "form":
            auth_type = "platform"

    # FW-2: require a STRONG anchor to flag at all — a password OR username/email
    # input field, or a login-named form. Bare url/title keyword hints are
    # corroborating only, never a sole trigger (kills the over-flagging where any
    # /account or /author page matched).
    # Operator policy: require BOTH a password field AND a username/email field.
    # A real login portal has both. Contact/newsletter/search forms carry an
    # email or text input but NO password, so they no longer match (this killed
    # the ~173 false positives from a contact form). SSO-only pages (a
    # "Sign in with X" button, no fields) are intentionally NOT flagged — one SSO
    # covers everything and is trivial to find by hand.
    if not (has_pw and has_user):
        return None
    confidence = "HIGH"   # both anchors present

    return LoginFinding(url=url, confidence=confidence, auth_type=auth_type,
                        signals=signals, is_external_idp=is_external)


class LoginRegistry:
    """Collects login portals across the crawl, deduped by normalized URL."""

    def __init__(self):
        self._by_url: dict[str, LoginFinding] = {}

    def add(self, finding: LoginFinding | None) -> None:
        if finding is None:
            return
        key = finding.url.rstrip("/").lower()
        # keep the higher-confidence version if seen twice
        existing = self._by_url.get(key)
        rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        if existing is None or rank.get(finding.confidence, 3) < rank.get(existing.confidence, 3):
            self._by_url[key] = finding

    def add_external(self, url: str, source: str) -> None:
        """Fold in a login portal detected by ANOTHER tool (e.g. httpx status/
        title) into the master list."""
        f = LoginFinding(url=url, confidence="MEDIUM", auth_type="form",
                         signals=[f"detected-by-{source}"])
        self.add(f)

    def findings(self) -> list[LoginFinding]:
        rank = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}
        return sorted(self._by_url.values(),
                      key=lambda f: (rank.get(f.confidence, 3), f.url))

    def rows(self) -> list[list]:
        return [f.as_row() for f in self.findings()]

    def count(self) -> int:
        return len(self._by_url)

    def high_count(self) -> int:
        return sum(1 for f in self._by_url.values() if f.confidence == "HIGH")
