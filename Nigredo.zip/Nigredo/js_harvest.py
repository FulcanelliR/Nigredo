#!/usr/bin/env python3
"""
js_harvest.py — External JavaScript discovery, fetch, and save for FunnelWeb.

Phase A of the FunnelWeb secrets/analysis upgrade. The crawler only ever saw
rendered HTML, so secrets and endpoints hiding in linked .js files were missed.
This module:

  1. discover_js_urls()  -- pull every <script src> out of a page's HTML and
     resolve it to an absolute URL (handles absolute, protocol-relative //,
     root-relative /, and path-relative forms). Logic mirrors SecretFinder's
     extractjsurl() so we resolve the same edge cases.

  2. JSHarvester       -- fetches each UNIQUE js URL exactly once (the same
     bundle is linked from many pages; content is identical regardless of which
     page referenced it), saves it to <output>/js/, and records:
        - the JS file's own URL
        - EVERY page that referenced it (so you can trace where it's used)
        - the local saved path
     De-dupes by URL first, then by content hash (two URLs, same bytes).

The saved js/ folder + the manifest this produces are what Phase B consumes:
the regex secret scanner, the jsluice pass, and Retire.js all run against these
files. This module only gets the JS onto disk reliably and records provenance;
it does no scanning itself.

Designed to plug into FunnelWeb with a few small hooks (see PHASE_A_HOOKS.md):
it reuses the crawler's aiohttp session model, honors a passed-in rate-limit
delay, and an optional proxy.
"""
from __future__ import annotations

import asyncio
import hashlib
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse, urljoin

try:
    import aiohttp
    import aiofiles
except ImportError:  # allows import for unit tests without the deps present
    aiohttp = None
    aiofiles = None


# ---- JS URL discovery ----

_SCRIPT_SRC_RE = re.compile(
    r"""<script[^>]*\bsrc\s*=\s*["']([^"']+)["']""",
    re.IGNORECASE,
)


def discover_js_urls(html_content: str, base_url: str) -> list[str]:
    """Extract and resolve every <script src> URL from a page's HTML.

    Resolution rules (mirrors SecretFinder.extractjsurl):
      https://x/a.js         -> as-is
      //cdn/a.js             -> scheme + //cdn/a.js
      /assets/a.js           -> scheme://host/assets/a.js
      assets/a.js            -> resolved relative to the page URL
    Returns a de-duplicated, order-preserving list of absolute http(s) URLs.
    """
    if not html_content:
        return []
    parsed = urlparse(base_url)
    scheme = parsed.scheme or "https"

    seen: set[str] = set()
    out: list[str] = []
    for raw in _SCRIPT_SRC_RE.findall(html_content):
        src = raw.strip()
        if not src:
            continue
        if src.startswith(("http://", "https://")):
            resolved = src
        elif src.startswith("//"):
            resolved = f"{scheme}:{src}"
        elif src.startswith("/"):
            resolved = f"{scheme}://{parsed.netloc}{src}"
        else:
            resolved = urljoin(base_url, src)
        # only http(s) JS
        if not resolved.startswith(("http://", "https://")):
            continue
        # normalize: drop fragments
        resolved = resolved.split("#", 1)[0]
        if resolved not in seen:
            seen.add(resolved)
            out.append(resolved)
    return out


def _safe_js_filename(url: str) -> str:
    """Build a filesystem-safe filename for a JS URL, keeping it recognizable
    and unique (short hash suffix guards against collisions across paths)."""
    parsed = urlparse(url)
    base = os.path.basename(parsed.path) or "script.js"
    if not base.lower().endswith((".js", ".mjs")):
        base += ".js"
    safe = "".join(c for c in base if c.isalnum() or c in "._-")
    if not safe or safe in (".js",):
        safe = "script.js"
    # short hash of the full URL for uniqueness (different paths, same basename)
    h = hashlib.sha1(url.encode("utf-8", "replace")).hexdigest()[:8]
    name, ext = os.path.splitext(safe)
    return f"{name}.{h}{ext}"


@dataclass
class JSFile:
    """One harvested JS file and where it came from."""
    url: str
    local_path: str = ""
    referring_pages: set = field(default_factory=set)
    sha256: str = ""
    bytes_len: int = 0
    error: str = ""

    def as_rows(self) -> list[list[str]]:
        """CSV rows for FunnelWeb's report: one 'JavaScript' row per JS file,
        Notes lists how many pages referenced it (full list in the manifest)."""
        ref = sorted(self.referring_pages)
        note = (f"referenced by {len(ref)} page(s)"
                + (f"; first: {ref[0]}" if ref else ""))
        if self.error:
            note = f"FETCH FAILED: {self.error}"
        return [["JavaScript", os.path.basename(self.local_path) or self.url,
                 self.url, self.local_path, note]]


class JSHarvester:
    """Fetches and saves unique JS files, tracking provenance.

    Usage from the crawler:
        harvester = JSHarvester(output_dir, rate_delay=0.3, proxy="")
        # during page scrape, after getting page HTML + the page url:
        harvester.note_urls(discover_js_urls(html, page_url), page_url)
        # after the crawl (in finalize), fetch them all + write rows:
        await harvester.fetch_all()
        rows = harvester.report_rows()          # feed into the CSV
        harvester.write_manifest()              # js/js_manifest.csv
    """

    def __init__(self, output_dir: Path, rate_delay: float = 0.3,
                 proxy: str = "", is_target_domain=None):
        self.output_dir = Path(output_dir)
        self.js_dir = self.output_dir / "js"
        self.js_dir.mkdir(parents=True, exist_ok=True)
        self.rate_delay = rate_delay
        self.proxy = proxy or None
        # optional callable(netloc)->bool so we can tag first/third-party JS
        self.is_target_domain = is_target_domain
        self.files: dict[str, JSFile] = {}       # url -> JSFile
        self._hashes: dict[str, str] = {}        # sha256 -> first url (content dedupe)
        self._lock = asyncio.Lock()

    def note_urls(self, js_urls, referring_page: str) -> None:
        """Register discovered JS URLs and the page that referenced them.
        Safe to call many times; de-dupes by URL and accumulates referrers."""
        for u in js_urls:
            jf = self.files.get(u)
            if jf is None:
                jf = JSFile(url=u)
                self.files[u] = jf
            jf.referring_pages.add(referring_page)

    async def fetch_all(self, session=None) -> None:
        """Fetch every unique JS file once, save to js/, record hash/size.
        Reuses a passed aiohttp session if given, else makes its own."""
        if aiohttp is None:
            return
        own_session = session is None
        if own_session:
            timeout = aiohttp.ClientTimeout(total=30)
            session = aiohttp.ClientSession(timeout=timeout)
        try:
            for url, jf in self.files.items():
                await self._fetch_one(url, jf, session)
                if self.rate_delay:
                    await asyncio.sleep(self.rate_delay)
        finally:
            if own_session:
                await session.close()

    async def _fetch_one(self, url: str, jf: JSFile, session) -> None:
        try:
            kwargs = {}
            if self.proxy:
                kwargs["proxy"] = self.proxy
            async with session.get(url, **kwargs) as resp:
                if resp.status != 200:
                    jf.error = f"HTTP {resp.status}"
                    return
                body = await resp.read()
        except asyncio.TimeoutError:
            jf.error = "timeout"
            return
        except Exception as e:  # noqa: BLE001
            jf.error = f"{e.__class__.__name__}"
            return

        digest = hashlib.sha256(body).hexdigest()
        # content-level dedupe: if we already saved identical bytes, point to it
        async with self._lock:
            if digest in self._hashes:
                twin_url = self._hashes[digest]
                twin = self.files.get(twin_url)
                if twin and twin.local_path:
                    jf.local_path = twin.local_path
                    jf.sha256 = digest
                    jf.bytes_len = len(body)
                    return
            self._hashes[digest] = url

        fname = _safe_js_filename(url)
        path = self.js_dir / fname
        counter = 1
        while path.exists():
            stem, ext = os.path.splitext(fname)
            path = self.js_dir / f"{stem}_{counter}{ext}"
            counter += 1
        try:
            if aiofiles is not None:
                async with aiofiles.open(path, "wb") as f:
                    await f.write(body)
            else:
                path.write_bytes(body)
        except Exception as e:  # noqa: BLE001
            jf.error = f"save failed: {e.__class__.__name__}"
            return
        jf.local_path = str(path)
        jf.sha256 = digest
        jf.bytes_len = len(body)

    def report_rows(self) -> list[list[str]]:
        """Rows to merge into FunnelWeb's report.csv (one per JS file)."""
        rows = []
        for jf in self.files.values():
            rows.extend(jf.as_rows())
        return rows

    def saved_files(self) -> list[str]:
        """Local paths of successfully-saved JS files (for Phase B consumers)."""
        seen = set()
        out = []
        for jf in self.files.values():
            if jf.local_path and jf.local_path not in seen:
                seen.add(jf.local_path)
                out.append(jf.local_path)
        return out

    def write_manifest(self) -> Path:
        """Full provenance manifest: every JS URL, its saved path, hash, size,
        and the COMPLETE list of referring pages (the CSV row only summarizes)."""
        import csv
        manifest = self.js_dir / "js_manifest.csv"
        with open(manifest, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["JS URL", "Local Path", "SHA256", "Bytes",
                        "Referring Page Count", "Referring Pages", "Error"])
            for jf in self.files.values():
                w.writerow([
                    jf.url, jf.local_path, jf.sha256, jf.bytes_len,
                    len(jf.referring_pages),
                    " | ".join(sorted(jf.referring_pages)),
                    jf.error,
                ])
        return manifest

    def summary(self) -> str:
        total = len(self.files)
        saved = sum(1 for jf in self.files.values() if jf.local_path and not jf.error)
        failed = sum(1 for jf in self.files.values() if jf.error)
        return (f"JS harvest: {total} unique JS URL(s), {saved} saved, "
                f"{failed} failed -> {self.js_dir}/")
