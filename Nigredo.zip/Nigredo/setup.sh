#!/usr/bin/env bash
#
# nigredo setup — creates a uv virtualenv, installs the Python deps, and
# interactively offers to install any missing external tools (Kali commands).
#
# Usage:
#   ./setup.sh              # venv + python deps, then OFFER to install missing tools [Y/n]
#   ./setup.sh --yes        # auto-accept every install/symlink prompt (no questions)
#   ./setup.sh --check-only # only report what's present/missing, install nothing
#
# Safe to re-run. The Python venv side is deterministic; external tools are
# offered one at a time with their known Kali install command.
#
set -u
VENV_NAME="nigredo-venv"          # NOT 'nigredo' — avoids the folder/venv name collision
AUTO_YES=0
CHECK_ONLY=0
for arg in "$@"; do
    case "$arg" in
        --yes|-y) AUTO_YES=1 ;;
        --check-only) CHECK_ONLY=1 ;;
        -h|--help) grep '^#' "$0" | sed 's/^# \{0,1\}//'; exit 0 ;;
    esac
done

say()  { printf "\033[1;36m[setup]\033[0m %s\n" "$*"; }
ok()   { printf "  \033[1;32m✓\033[0m %s\n" "$*"; }
miss() { printf "  \033[1;31m✗\033[0m %s\n" "$*"; }
warn() { printf "  \033[1;33m!\033[0m %s\n" "$*"; }

# ask "question" -> returns 0 for yes, 1 for no. Honors --yes / --check-only.
ask() {
    [ "$CHECK_ONLY" -eq 1 ] && return 1
    [ "$AUTO_YES" -eq 1 ] && return 0
    local q="$1" a
    read -r -p "      $q [Y/n]: " a
    case "${a:-y}" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

# ---------------------------------------------------------------- 1. uv + venv
say "Setting up the Python virtual environment (uv)…"
if ! command -v uv >/dev/null 2>&1; then
    warn "uv not found. Install it with:"
    echo "      curl -LsSf https://astral.sh/uv/install.sh | sh"
    warn "Falling back to python -m venv for now."
    python3 -m venv "$VENV_NAME" || { miss "venv creation failed"; exit 1; }
    # shellcheck disable=SC1090
    source "$VENV_NAME/bin/activate"
    pip install --upgrade pip >/dev/null
    pip install -r requirements.txt || { miss "pip install failed"; exit 1; }
else
    uv venv "$VENV_NAME" || { miss "uv venv failed"; exit 1; }
    # shellcheck disable=SC1090
    source "$VENV_NAME/bin/activate"
    uv pip install -r requirements.txt || { miss "uv pip install failed"; exit 1; }
fi
ok "venv '$VENV_NAME' ready and Python deps installed"

# ---------------------------------------------------------------------------
# Verify the CRITICAL Python deps actually IMPORT in the venv — not just that the
# bulk `pip install` returned 0. aiohttp/aiofiles have C-extension builds that can
# install a broken/incompatible wheel (or fail to compile) while the overall
# install still exits 0, which then crashes FunnelWeb at runtime with an obscure
# ImportError hours into a run. Catch it HERE, loudly, at install time.
# We're still inside the activated venv, but prefer `uv run --project .` when uv is
# present so we check the exact interpreter the tool will use.
say "Verifying critical Python deps import…"
if command -v uv >/dev/null 2>&1; then
    _PYCHECK=(uv run --project . python -c)
else
    _PYCHECK=(python -c)
fi
_DEP_FAIL=0
for mod in aiohttp aiofiles patchright dns; do
    if "${_PYCHECK[@]}" "import $mod" >/dev/null 2>&1; then
        ok "  import $mod"
    else
        miss "  import $mod FAILED — needed by nigredo (aiohttp/aiofiles/patchright = \
FunnelWeb; dns = DKIM). Reinstall: uv pip install --force-reinstall \
$( [ "$mod" = dns ] && echo dnspython || echo "$mod" )  (build errors: \
sudo apt install -y python3-dev gcc libffi-dev)"
        _DEP_FAIL=1
    fi
done
if [ "$_DEP_FAIL" -eq 1 ]; then
    warn "One or more critical deps failed to import — FunnelWeb will not run until fixed."
fi

# ---------------------------------------------------------------------------
# IMPORTANT — HOW TO LAUNCH
# Use the ./nigredo.sh wrapper. It handles the whole sudo/env/PATH/uv
# incantation for you (raw scans need root; `sudo python3` would use ROOT's env
# instead of this venv, so the wrapper routes THROUGH uv where the deps live):
#
#     ./nigredo.sh init        # set up the engagement + enter targets
#     ./nigredo.sh start       # start the run
#     ./nigredo.sh tools       # install missing external tools
#
# Under the hood the wrapper runs, e.g.:
#     sudo -E env "PATH=$PATH" uv run python run.py engagement-init
# so the venv interpreter is always used and deps + runtime share one
# environment — no more "installed but not detected". `tools` installs via
# `uv pip install` into this same venv for the same reason.
#
# Note: if uv lives in your user's ~/.cargo/bin, sudo may strip it from PATH;
# the `env "PATH=$PATH"` above preserves it. (nigredo also resolves uv's path
# internally for its own installs.)
# ---------------------------------------------------------------------------

say "Installing Patchright browser (undetected Chromium — used by FunnelWeb AND ffuf's browser liveness gate)…"
if python -c "import patchright" 2>/dev/null; then
    patchright install chromium >/dev/null 2>&1 && ok "patchright chromium installed (default browser)" \
        || warn "patchright install chromium failed — FunnelWeb crawler + ffuf browser gate may not work"
    patchright install chrome >/dev/null 2>&1 && ok "patchright chrome installed (for FunnelWeb --stealth)" \
        || warn "patchright chrome failed — for --stealth run: patchright install chrome"
    # Browser SYSTEM libraries (Debian/Kali need these to LAUNCH the fallback build).
    # The 'BEWARE: OS not officially supported ... ubuntu24.04 fallback' warning during
    # the downloads above is EXPECTED on Debian-family and safe to ignore.
    _pr="$(command -v patchright)"
    if [ -n "$_pr" ]; then
        sudo "$_pr" install-deps chromium >/dev/null 2>&1 && ok "browser system deps installed" \
            || warn "install-deps failed — if the browser won't launch: sudo $_pr install-deps chromium"
        # xvfb: lets FunnelWeb --stealth run the headed browser in an INVISIBLE display
        # (no window / no input grab). pyvirtualdisplay (the wrapper) is a pip dep.
        if command -v apt-get >/dev/null 2>&1; then
            sudo apt-get install -y xvfb >/dev/null 2>&1 && ok "xvfb installed (invisible --stealth display)" \
                || warn "xvfb install failed — --stealth shows a window (or: sudo apt install xvfb)"
        fi
    fi
else
    warn "patchright python package missing — pip install patchright (FunnelWeb + ffuf need it)"
fi

# ------------------------------------------------------ 2. external tool check
# name|check-binary|install-command  (interactively offered if missing)
say "Checking external tools (will offer to install any that are missing)…"

TOOLS=(
    # Go tools
    "subfinder|subfinder|go install -v github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"
    "shuffledns|shuffledns|go install -v github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"
    "dnsx|dnsx|go install -v github.com/projectdiscovery/dnsx/cmd/dnsx@latest"
    "nuclei|nuclei|go install -v github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"
    "ffuf|ffuf|go install github.com/ffuf/ffuf/v2@latest"
    "feroxbuster|feroxbuster|sudo apt install -y feroxbuster"
    "gitleaks|gitleaks|sudo apt install -y gitleaks"
    "trufflehog|trufflehog|go install github.com/trufflesecurity/trufflehog/v3@latest"
    "sns|sns|go install github.com/sw33tLie/sns@latest"
    # System tools
    "nmap|nmap|sudo apt install -y nmap"
    "dnsrecon|dnsrecon|sudo apt install -y dnsrecon"
    "dnstwist|dnstwist|sudo apt install -y dnstwist"
    "dig|dig|sudo apt install -y dnsutils"
    "git|git|sudo apt install -y git"
    "ssh-audit|ssh-audit|sudo apt install -y ssh-audit"
    # FunnelWeb analyzers (bundled with nigredo) — retire needs sudo for the -g install
    "retire|retire|sudo npm install -g retire"
    "semgrep|semgrep|uv pip install semgrep"
    # jsbeautifier: pure pip lib (also pinned in requirements.txt). It imports as
    # the module 'jsbeautifier' but has NO reliable CLI on the venv PATH, so we
    # verify it by IMPORT (4th field) rather than `which`. Same pattern for any
    # pip lib whose presence isn't a PATH binary.
    "jsbeautifier|js-beautify|uv pip install jsbeautifier|jsbeautifier"
    "jsluice|jsluice|go install github.com/BishopFox/jsluice/cmd/jsluice@latest"
    "exiftool|exiftool|sudo apt install -y libimage-exiftool-perl"
)

# SecLists is a WORDLIST directory, not a binary — ffuf/feroxbuster need it or they
# SILENTLY SKIP (no output, empty workbook). Check the common install locations.
say "Wordlists:"
_SECLISTS_FOUND=""
for _b in /usr/share/seclists /usr/share/wordlists/seclists /usr/share/wordlists/SecLists \
          /opt/seclists /opt/SecLists "$HOME/.local/share/seclists" "$HOME/SecLists"; do
    if [ -d "$_b/Discovery/Web-Content" ]; then _SECLISTS_FOUND="$_b"; break; fi
done
if [ -n "$_SECLISTS_FOUND" ]; then
    ok "SecLists ($_SECLISTS_FOUND)"
else
    miss "SecLists NOT found — ffuf & feroxbuster will skip without it.  →  \
sudo apt install -y seclists   (or: git clone https://github.com/danielmiessler/SecLists \
/usr/share/seclists)"
fi

STILL_MISSING=()
GO_WARNED=0
for entry in "${TOOLS[@]}"; do
    IFS='|' read -r name bin method import_mod <<< "$entry"
    if command -v "$bin" >/dev/null 2>&1; then
        ok "$name"
        continue
    fi
    # Tools installed into the uv venv (method starts with "uv pip install") won't
    # be on the system PATH. Verify them INSIDE the project venv:
    #   - if a 4th 'import_mod' field is given, check by importing it (correct for
    #     pip LIBRARIES like jsbeautifier/patchright that have no CLI on PATH), else
    #   - fall back to locating the CLI binary in the project venv.
    # NOTE: use `uv run --project .` (the PROJECT env, where `uv pip install` put
    # it) — NOT `--no-project`, which resolves a different environment and is what
    # caused the false "installed but still reported missing" warnings.
    if [[ "$method" == uv\ pip\ install* ]]; then
        if [ -n "$import_mod" ]; then
            if uv run --project . python -c "import $import_mod" >/dev/null 2>&1; then
                ok "$name (in uv venv)"
                continue
            fi
        elif uv run --project . which "$bin" >/dev/null 2>&1; then
            ok "$name (in uv venv)"
            continue
        fi
    fi
    miss "$name  →  $method"
    # warn once if a go install is needed but Go is absent
    if [[ "$method" == go\ install* ]] && ! command -v go >/dev/null 2>&1 && [ "$GO_WARNED" -eq 0 ]; then
        warn "Go isn't installed — 'go install' tools will fail. Install Go: sudo apt install -y golang-go"
        GO_WARNED=1
    fi
    if ask "install $name now?"; then
        say "installing $name…"
        if eval "$method"; then ok "$name installed"; else
            warn "$name install failed — install it manually: $method"
            STILL_MISSING+=("$name"); fi
    else
        STILL_MISSING+=("$name")
    fi
done

# testssl.sh — special (git clone + symlink, not a package)
if command -v testssl.sh >/dev/null 2>&1; then
    ok "testssl.sh"
else
    miss "testssl.sh  →  git clone + symlink"
    if ask "clone testssl.sh and symlink it into /usr/local/bin now?"; then
        if git clone --depth 1 https://github.com/drwetter/testssl.sh /opt/testssl.sh 2>/dev/null; then
            sudo ln -sf /opt/testssl.sh/testssl.sh /usr/local/bin/testssl.sh && ok "testssl.sh installed" \
                || warn "symlink failed"
        else
            warn "clone failed — do it manually"; STILL_MISSING+=("testssl.sh")
        fi
    else
        STILL_MISSING+=("testssl.sh")
    fi
fi

# FunnelWeb.py is BUNDLED with nigredo (ships in the package). cloud_enum is
# a standard installable tool (pip/apt). PartyOn.py is fetched from GitHub below
# and dropped at the tool root, where nigredo resolves it (like FunnelWeb.py).
say "Script tools:"
if [ -f "FunnelWeb.py" ]; then ok "FunnelWeb.py (bundled)"; else
    warn "FunnelWeb.py missing from package — fetch it from \
https://github.com/FulcanelliR/FunnelWeb (git clone, or download FunnelWeb.py \
plus its companion modules into this directory)"; fi
if command -v cloud_enum >/dev/null 2>&1 || command -v cloud-enum >/dev/null 2>&1 \
        || [ -f "cloud_enum.py" ]; then ok "cloud_enum"; else
    warn "cloud_enum not found — install it (pip install cloud_enum / apt)"; fi
if [ -f "PartyOn.py" ]; then
    ok "PartyOn.py (at tool root)"
else
    # Fetch the repo once if we don't already have a local copy.
    if [ ! -f "PartyOn/PartyOn.py" ] && command -v git >/dev/null 2>&1; then
        say "Fetching PartyOn (breach/credential, DeHashed) from GitHub…"
        git clone --depth 1 https://github.com/FulcanelliR/PartyOn PartyOn >/dev/null 2>&1 \
            || warn "git clone of PartyOn failed"
    fi
    if [ -f "PartyOn/PartyOn.py" ]; then
        # nigredo resolves PartyOn.py at the tool root (like FunnelWeb.py), so drop a
        # copy here. PartyOn.py is a single self-contained script (no companion
        # imports), so the one file is all it needs.
        cp -f PartyOn/PartyOn.py ./PartyOn.py
        # nigredo hands the DeHashed key to PartyOn via the DEHASHED_API_KEY env var
        # (kept out of the command log). Stock PartyOn.py ignores the environment and
        # uses a hardcoded `apikey = "API Key"` placeholder, so its pre-flight probe
        # 401s and nothing runs. Rewrite that one line to read the env, falling back to
        # any key pasted into the file. Idempotent: only the untouched placeholder line
        # matches, so re-runs and hand-edited copies are left alone.
        sed -i 's/^apikey = "API Key"$/apikey = os.getenv("DEHASHED_API_KEY", "").strip() or "API Key"/' ./PartyOn.py
        ok "PartyOn ready -> ./PartyOn.py (reads DEHASHED_API_KEY from nigredo)"
    else
        warn "PartyOn.py not found — install git, or clone \
https://github.com/FulcanelliR/PartyOn into this directory manually"
    fi
fi

# ------------------------------------------------------ 3. sudo/PATH symlinks
# nmap needs root (-sS); under sudo, Go tools in ~/go/bin fall off PATH. Offer to
# symlink them into /usr/local/bin (on root's PATH) so they resolve under sudo.
say "Sudo PATH fix:"
NEED_LINK=()
for b in subfinder shuffledns dnsx nuclei ffuf feroxbuster gitleaks trufflehog sns; do
    src="$(command -v "$b" 2>/dev/null)"
    [ -n "$src" ] && [ ! -e "/usr/local/bin/$b" ] && NEED_LINK+=("$b|$src")
done
if [ "${#NEED_LINK[@]}" -gt 0 ]; then
    warn "${#NEED_LINK[@]} Go tool(s) not in /usr/local/bin — they'll be invisible under sudo."
    if ask "symlink them into /usr/local/bin so they work under sudo?"; then
        for entry in "${NEED_LINK[@]}"; do
            IFS='|' read -r b src <<< "$entry"
            sudo ln -s "$src" "/usr/local/bin/$b" && ok "linked $b" || warn "link $b failed"
        done
    fi
else
    ok "Go tools already resolve under sudo (or none installed yet)"
fi

# ------------------------------------------------------------------- summary
echo
say "Setup summary:"
ok "venv: source $VENV_NAME/bin/activate"
if [ "${#STILL_MISSING[@]}" -eq 0 ]; then
    ok "all external tools present"
else
    warn "still missing: ${STILL_MISSING[*]}"
fi
echo
say "Next:  ./nigredo.sh init"

# ---- external tools ----
# For the full external toolset (subfinder, nuclei, ffuf, feroxbuster, gitleaks,
# trufflehog, cloud-enum, jsluice, patchright, serpapi, etc.), use the built-in
# interactive installer, which knows the exact install command for each and
# handles Go PATH setup. The wrapper routes it THROUGH uv so it installs into
# THIS venv (plain `sudo python3` runs root's interpreter, which can't see the
# venv and produces false "installed but missing" reports):
#
#     ./nigredo.sh tools
#     # (wraps: sudo -E env "PATH=$PATH" uv run python run.py install-missing)
#
echo ""
echo "[setup] For external tools, run:  ./nigredo.sh tools"
