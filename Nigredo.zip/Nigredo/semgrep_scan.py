#!/usr/bin/env python3
"""
semgrep_scan.py — semgrep integration for harvested PHP source (Phase B).

Runs semgrep over the confirmed-PHP-source files that php_harvest.py isolated in
<domain>/php/source/. Those are files that actually contained `<?php` (i.e. a
source-disclosure — semgrep gets real code, not rendered HTML).

  semgrep --config p/php --config p/security-audit --json <source_dir>

Output (semgrep JSON) is parsed into findings: rule id, severity, file, line,
message. Raw JSON is always saved so nothing is lost if the schema shifts.

semgrep is optional: if the binary isn't found, the scan skips gracefully (like
jsluice/exiftool). Requires the php/source/ files on disk (php_harvest provides).
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

# default rulesets — PHP + general security audit. Configurable via run().
DEFAULT_CONFIGS = ["p/php", "p/security-audit"]


def semgrep_available() -> bool:
    return shutil.which("semgrep") is not None


@dataclass
class SemgrepFinding:
    rule_id: str = ""
    severity: str = ""
    path: str = ""
    line: int = 0
    message: str = ""

    def as_row(self) -> list:
        """CSV row aligned with FunnelWeb's summary rows:
        Category, Detail, Source File, Local Path, Notes."""
        where = f"{Path(self.path).name}:{self.line}"
        note = f"[{self.severity}] {self.rule_id} — {self.message[:160]}"
        return ["PHP Semgrep Finding", where, self.path, self.path, note]


def run(source_dir: Path, out_json: Path, configs: list[str] | None = None,
        timeout: int = 900) -> list[SemgrepFinding]:
    """Run semgrep over source_dir with the given rulesets. Saves raw JSON to
    out_json and returns parsed findings. Empty list if semgrep missing, no
    source files, or no findings."""
    source_dir = Path(source_dir)
    if not semgrep_available():
        print("[semgrep] not installed — skipping PHP source scan "
              "(pip install semgrep)")
        return []
    # any real source files to scan?
    php_files = list(source_dir.rglob("*.php")) if source_dir.is_dir() else []
    if not php_files:
        print("[semgrep] no confirmed PHP source to scan (php/source/ empty)")
        return []

    configs = configs or DEFAULT_CONFIGS
    # --metrics off: no telemetry to semgrep's registry (privacy/egress hygiene).
    cmd = ["semgrep", "--metrics", "off", "--json", "--quiet", "--timeout", "0"]
    for c in configs:
        cmd += ["--config", c]
    cmd.append(str(source_dir))

    print(f"[semgrep] scanning {len(php_files)} PHP source file(s) with "
          f"{', '.join(configs)}")
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        print("[semgrep] timed out")
        return []
    except OSError as e:
        print(f"[semgrep] failed to run: {e}")
        return []

    # semgrep prints JSON to stdout even with findings; save it raw regardless
    raw = proc.stdout or ""
    try:
        Path(out_json).write_text(raw)
    except OSError:
        pass

    try:
        data = json.loads(raw) if raw.strip() else {}
    except ValueError:
        print("[semgrep] could not parse JSON output (raw saved)")
        return []

    findings = []
    for r in data.get("results", []) or []:
        extra = r.get("extra", {}) or {}
        start = r.get("start", {}) or {}
        findings.append(SemgrepFinding(
            rule_id=r.get("check_id", ""),
            severity=(extra.get("severity", "") or "").upper(),
            path=r.get("path", ""),
            line=start.get("line", 0) or 0,
            message=extra.get("message", "") or "",
        ))
    # sort: ERROR > WARNING > INFO, then by file
    sev_rank = {"ERROR": 0, "WARNING": 1, "INFO": 2}
    findings.sort(key=lambda f: (sev_rank.get(f.severity, 3), f.path, f.line))
    print(f"[semgrep] {len(findings)} finding(s)")
    return findings


def summary_rows(findings: list[SemgrepFinding]) -> list[list]:
    return [f.as_row() for f in findings]


def high_severity_count(findings: list[SemgrepFinding]) -> int:
    return sum(1 for f in findings if f.severity == "ERROR")
