"""php_harvest.py — PHP endpoint fetch, source-disclosure hunt, and save for FunnelWeb.

Mirrors js_harvest.py's pattern (discover -> fetch unique -> save -> manifest ->
Phase B consumes the folder), with two PHP-specific additions:

  1. SOURCE DETECTION. Requesting `page.php` normally returns the RENDERED HTML
     (the server executes the PHP), not source. But a misconfigured server may
     serve `.php` as text. We detect responses that actually contain PHP source
     (a `<?php` / `<?=` tag) — that's a source-disclosure FINDING, and it's the
     only content worth handing to semgrep.

  2. SOURCE-DISCLOSURE VARIANT HUNT (default on — it's semgrep's feeder). For
     each discovered `.php` URL we also try common backup/source leftovers
     (page.php.bak, page.php~, page.phps, page.php.txt, ...). These return raw
     source when present. This is the main mechanism that produces real PHP code
     for semgrep to scan. It adds N extra GETs per PHP URL (mostly 404s), through
     FunnelWeb's existing session/proxy/rate-limiter (same politeness controls).

Layout:
  <domain>/php/            all saved .php responses (incl. rendered HTML)
  <domain>/php/source/     confirmed PHP SOURCE only  <-- semgrep scans THIS
  <domain>/php/php_manifest.csv

Requires this file alongside FunnelWeb-RV4.py (hard dependency, like js_harvest).
"""
from __future__ import annotations

import asyncio
import hashlib
import os
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse

try:
    import aiofiles
except ImportError:  # pragma: no cover
    aiofiles = None


# backup/source-leftover extensions appended to a discovered .php URL. These are
# where exposed PHP SOURCE actually shows up (feeds semgrep).
SOURCE_VARIANT_SUFFIXES = [
    ".bak", "~", ".phps", ".txt", ".old", ".save", ".swp", ".orig", ".copy",
    ".php.bak", ".inc",
]

# markers that a response body is actual PHP SOURCE, not rendered HTML output
PHP_SOURCE_MARKERS = (b"<?php", b"<?=")


def discover_php_urls(html_content: str, base_url: str, links: list[str] | None = None) -> list[str]:
    """Pull .php endpoints referenced by a page. Uses already-extracted links
    when available (FunnelWeb has them), else a light scan of the HTML."""
    found = set()
    candidates = list(links or [])
    if not candidates:
        import re
        # hrefs/srcs pointing at .php (with optional query)
        for m in re.finditer(r'(?:href|src|action)\s*=\s*["\']([^"\']+\.php[^"\']*)["\']',
                             html_content, re.IGNORECASE):
            candidates.append(m.group(1))
    from urllib.parse import urljoin
    for c in candidates:
        c = c.strip()
        if not c:
            continue
        path = urlparse(c).path.lower()
        if path.endswith(".php"):
            found.add(urljoin(base_url, c))
    return sorted(found)


def _safe_php_filename(url: str) -> str:
    p = urlparse(url)
    name = (p.path.strip("/").replace("/", "_") or "index")
    if p.query:
        qh = hashlib.sha1(p.query.encode()).hexdigest()[:8]
        name = f"{name}__{qh}"
    # keep it filesystem-safe
    name = "".join(c if (c.isalnum() or c in "._-~") else "_" for c in name)
    return name[:180] or "index.php"


@dataclass
class PHPFile:
    url: str
    local_path: str = ""
    source_path: str = ""            # set if this was confirmed PHP source
    sha256: str = ""
    bytes_len: int = 0
    is_source: bool = False          # response contained <?php (source disclosure)
    is_variant: bool = False         # came from the backup/source-variant hunt
    referring_pages: set = field(default_factory=set)
    error: str = ""

    def as_rows(self) -> list[list[str]]:
        note = []
        if self.is_source:
            note.append("PHP SOURCE DISCLOSED")
        if self.is_variant:
            note.append("backup/source variant")
        return [[
            self.url, self.local_path, "Y" if self.is_source else "",
            "; ".join(note), self.error,
        ]]


class PHPHarvester:
    """Fetches .php endpoints, hunts source-disclosure variants, saves them, and
    isolates confirmed PHP source into php/source/ for semgrep.

    Usage (mirrors JSHarvester):
        h = PHPHarvester(output_dir, proxy=..., is_target_domain=...)
        h.note_urls(php_urls, referring_page)
        await h.fetch_all(session)
        h.write_manifest()
        h.source_dir   # <- semgrep target
    """

    def __init__(self, output_dir: Path, rate_delay: float = 0.3,
                 proxy: str = "", is_target_domain=None,
                 hunt_variants: bool = True):
        self.php_dir = Path(output_dir) / "php"
        self.php_dir.mkdir(parents=True, exist_ok=True)
        self.source_dir = self.php_dir / "source"
        self.source_dir.mkdir(parents=True, exist_ok=True)
        self.rate_delay = rate_delay
        self.proxy = proxy
        self.is_target_domain = is_target_domain or (lambda u: True)
        self.hunt_variants = hunt_variants
        self.files: dict[str, PHPFile] = {}
        self._hashes: dict[str, str] = {}
        self._lock = asyncio.Lock()

    def note_urls(self, php_urls, referring_page: str) -> None:
        # Option (a): scope the PHP harvest to ON-DOMAIN only. Third-party PHP
        # (facebook etc.) is out of scope for an external pentest, can't be
        # source-disclosed anyway, and probing it is noise + off-scope traffic —
        # so skip it. (Unlike js_harvest, where third-party JS = real supply-chain
        # value.) The old filter was only removed because it was CALLED with a full
        # URL; _is_target_domain wants a NETLOC, so we pass urlparse(u).netloc.
        for u in php_urls:
            try:
                _netloc = urlparse(u).netloc
            except Exception:
                _netloc = ""
            if not self.is_target_domain(_netloc):
                continue   # off-domain / third-party PHP -> not harvested
            pf = self.files.get(u)
            if pf is None:
                pf = PHPFile(url=u)
                self.files[u] = pf
            if referring_page:
                pf.referring_pages.add(referring_page)

    def _variant_urls(self, php_url: str) -> list[str]:
        """Build the backup/source-leftover URLs to try for a given .php URL."""
        base = php_url.split("?", 1)[0]          # drop query for variant probing
        out = []
        for suf in SOURCE_VARIANT_SUFFIXES:
            if suf == "~":
                out.append(base + "~")
            elif suf == ".php.bak":
                # page.php -> page.php.bak (already ends .php)
                out.append(base + ".bak")
            else:
                out.append(base + suf)
        # dedupe while preserving order
        seen, uniq = set(), []
        for u in out:
            if u not in seen:
                seen.add(u)
                uniq.append(u)
        return uniq

    async def fetch_all(self, session=None) -> None:
        """Fetch each unique .php URL; if variant-hunting, also probe backup/
        source leftovers. Confirmed source goes to php/source/ for semgrep.
        Reuses a passed aiohttp session if given, else makes its own."""
        try:
            import aiohttp
        except ImportError:
            return
        own_session = session is None
        if own_session:
            timeout = aiohttp.ClientTimeout(total=30)
            session = aiohttp.ClientSession(timeout=timeout)
        try:
            base_urls = list(self.files.keys())
            for url in base_urls:
                pf = self.files[url]
                await self._fetch_one(url, pf, session, is_variant=False)
                if self.rate_delay:
                    await asyncio.sleep(self.rate_delay)
                # hunt source-disclosure variants (semgrep's feeder)
                if self.hunt_variants:
                    for vurl in self._variant_urls(url):
                        if vurl in self.files:
                            continue
                        vpf = PHPFile(url=vurl, is_variant=True)
                        vpf.referring_pages.add(f"(variant of {url})")
                        self.files[vurl] = vpf
                        await self._fetch_one(vurl, vpf, session, is_variant=True)
                        if self.rate_delay:
                            await asyncio.sleep(self.rate_delay)
        finally:
            if own_session:
                await session.close()

    async def _fetch_one(self, url: str, pf: PHPFile, session, is_variant: bool) -> None:
        try:
            kwargs = {}
            if self.proxy:
                kwargs["proxy"] = self.proxy
            async with session.get(url, **kwargs) as resp:
                if resp.status != 200:
                    pf.error = f"HTTP {resp.status}"
                    return
                body = await resp.read()
        except asyncio.TimeoutError:
            pf.error = "timeout"
            return
        except Exception as e:  # noqa: BLE001
            pf.error = f"{e.__class__.__name__}"
            return

        if not body:
            pf.error = "empty"
            return

        # is this actual PHP SOURCE (disclosure) or just rendered HTML output?
        is_source = any(m in body for m in PHP_SOURCE_MARKERS)
        pf.is_source = is_source

        digest = hashlib.sha256(body).hexdigest()
        async with self._lock:
            if digest in self._hashes:
                twin = self.files.get(self._hashes[digest])
                if twin and twin.local_path:
                    pf.local_path = twin.local_path
                    pf.source_path = twin.source_path
                    pf.sha256 = digest
                    pf.bytes_len = len(body)
                    return
            self._hashes[digest] = url

        fname = _safe_php_filename(url)
        if not fname.endswith((".php", ".phps", ".txt", ".bak", ".inc")):
            fname += ".php"
        path = self.php_dir / fname
        counter = 1
        while path.exists():
            stem, ext = os.path.splitext(fname)
            path = self.php_dir / f"{stem}_{counter}{ext}"
            counter += 1
        try:
            if aiofiles is not None:
                async with aiofiles.open(path, "wb") as f:
                    await f.write(body)
            else:
                path.write_bytes(body)
        except Exception as e:  # noqa: BLE001
            pf.error = f"save failed: {e.__class__.__name__}"
            return
        pf.local_path = str(path)
        pf.sha256 = digest
        pf.bytes_len = len(body)

        # confirmed source -> also drop a .php copy in php/source/ for semgrep
        if is_source:
            src_name = fname
            if not src_name.endswith(".php"):
                src_name += ".php"
            spath = self.source_dir / src_name
            c = 1
            while spath.exists():
                stem, ext = os.path.splitext(src_name)
                spath = self.source_dir / f"{stem}_{c}.php"
                c += 1
            try:
                spath.write_bytes(body)
                pf.source_path = str(spath)
            except Exception:  # noqa: BLE001
                pass

    def source_files(self) -> list[str]:
        """Paths of confirmed PHP-source files (semgrep's input set)."""
        seen, out = set(), []
        for pf in self.files.values():
            if pf.source_path and pf.source_path not in seen:
                seen.add(pf.source_path)
                out.append(pf.source_path)
        return out

    def disclosed_count(self) -> int:
        return sum(1 for pf in self.files.values() if pf.is_source)

    def report_rows(self) -> list[list[str]]:
        rows = []
        # FW-5: 200/useful results first; non-200 (pf.error set) are NOT dropped,
        # just deprioritized to the bottom of the PHP group so the useful hits
        # (disclosed source, live pages) list higher.
        for pf in sorted(self.files.values(), key=lambda pf: (bool(pf.error), pf.url)):
            if pf.local_path or pf.error:      # skip pure 404 variant noise
                rows.extend(pf.as_rows())
        return rows

    def write_manifest(self) -> Path:
        import csv
        manifest = self.php_dir / "php_manifest.csv"
        with open(manifest, "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["PHP URL", "Local Path", "Source Path", "Is Source",
                        "Is Variant", "SHA256", "Bytes", "Referring Pages",
                        "Error"])
            for pf in self.files.values():
                if not (pf.local_path or pf.error):
                    continue           # don't log the 404 variant misses
                w.writerow([
                    pf.url, pf.local_path, pf.source_path,
                    "Y" if pf.is_source else "", "Y" if pf.is_variant else "",
                    pf.sha256, pf.bytes_len,
                    " | ".join(sorted(pf.referring_pages)), pf.error,
                ])
        return manifest
