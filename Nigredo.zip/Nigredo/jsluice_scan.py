#!/usr/bin/env python3
"""
jsluice_scan.py — jsluice integration for harvested JavaScript (Phase B, Wave 1).

Shells out to jsluice (BishopFox's AST-based JS analyzer, a Go binary) against
the .js files saved by js_harvest.py. Two modes:

  urls    -- `jsluice urls -S -R <base>` : extract endpoints/paths WITH the
             source snippet and relative paths resolved to absolute. Output is
             NDJSON, one object per line:
               {url, queryParams[], bodyParams[], method, type, source, filename}
             `type` tells us HOW it was found — real requests (e.get,
             locationAssignment, fetch/xhr) rank above bare stringLiteral.

  secrets -- `jsluice secrets` : AST-based secret detection. We do NOT parse its
             output yet (schema unconfirmed until we see a real hit). Instead we
             capture the RAW output to a file and set a simple Y/N flag:
             empty output = no secrets, non-empty = something to read.

jsluice is optional: if the binary isn't found, both passes skip gracefully
(like exiftool). Requires the .js files on disk (Phase A provides them).
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

# request-ish types are real endpoints; stringLiteral is just a found string
_REQUEST_TYPES = {
    "locationAssignment", "e.get", "e.post", "e.ajax", "fetch", "xhr",
    "XMLHttpRequest.open", "$.get", "$.post", "$.ajax", "axios.get",
    "axios.post", "navigator.sendBeacon",
}


def jsluice_available() -> bool:
    return shutil.which("jsluice") is not None


# ---- markdown-corruption cleanup (terminal/markdown can mangle URLs) ----
_MD_LINK = re.compile(r"\[([^\]]+)\]\((?:[^)]+)\)")


def _unwrap_md(s: str) -> str:
    """Turn a markdown-linkified '[text](url)' back into plain 'text'.
    Some pipelines corrupt jsluice URLs this way; strip it defensively."""
    if not s:
        return s
    return _MD_LINK.sub(r"\1", s).replace("\\(", "(").replace("\\)", ")").replace("\\", "")


@dataclass
class JSUrl:
    url: str
    type: str = ""
    method: str = ""
    query_params: list = field(default_factory=list)
    source: str = ""
    filename: str = ""

    @property
    def is_request(self) -> bool:
        return self.type in _REQUEST_TYPES

    def rank(self) -> int:
        # lower sorts first: real requests, then things with a method, then strings
        if self.is_request:
            return 0
        if self.method:
            return 1
        return 2

    def as_row(self) -> list:
        """CSV row: Category, Detail(url), Source URL(js file), Local Path, Notes."""
        kind = "request" if self.is_request else "reference"
        q = f" ?{','.join(self.query_params)}" if self.query_params else ""
        note = f"[{kind}] via {self.type}{q} | src: {self.source[:120]}"
        return ["JS Endpoint", self.url, self.filename, "", note]


def run_urls(js_paths: list[str], resolve_base: str = "") -> list[JSUrl]:
    """Run `jsluice urls -S [-R base]` across the given js files. Returns a
    de-duplicated, ranked list of JSUrl (best type kept per url)."""
    if not jsluice_available() or not js_paths:
        return []
    cmd = ["jsluice", "urls", "-S"]
    if resolve_base:
        cmd += ["-R", resolve_base]
    cmd += list(js_paths)
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except (subprocess.TimeoutExpired, OSError):
        return []

    best: dict[str, JSUrl] = {}
    for line in proc.stdout.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except ValueError:
            continue
        url = _unwrap_md(obj.get("url", ""))
        if not url:
            continue
        ju = JSUrl(
            url=url,
            type=obj.get("type", ""),
            method=obj.get("method", ""),
            query_params=obj.get("queryParams", []) or [],
            source=_unwrap_md(obj.get("source", "")),
            filename=obj.get("filename", ""),
        )
        # dedupe by url, keep the highest-interest (lowest rank) occurrence
        prev = best.get(url)
        if prev is None or ju.rank() < prev.rank():
            best[url] = ju
    return sorted(best.values(), key=lambda u: (u.rank(), u.url))


def run_secrets_raw(js_paths: list[str], out_file: Path) -> bool:
    """Run `jsluice secrets` and save the RAW output. Returns True if jsluice
    reported anything (non-empty output = potential secrets to read), else False.

    We intentionally don't parse the secrets schema yet — save raw, flag Y/N."""
    if not jsluice_available() or not js_paths:
        out_file.write_text("")
        return False
    cmd = ["jsluice", "secrets", *js_paths]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=600)
    except (subprocess.TimeoutExpired, OSError):
        out_file.write_text("")
        return False
    output = proc.stdout.strip()
    out_file.write_text(proc.stdout)
    return bool(output)      # non-empty = jsluice found something


def summary_url_rows(urls: list[JSUrl]) -> list[list]:
    return [u.as_row() for u in urls]
