#!/usr/bin/env bash
#
# nigredo — convenience launcher
#
# Wraps the secure run command so you don't have to type the whole
# sudo/env/PATH/uv incantation by hand. It does exactly this, nothing hidden:
#
#     sudo -E env "PATH=$PATH" uv run python run.py <subcommand>
#     sudo -E env "PATH=$PATH" uv run python -m prima_materia.adjudicator <args>
#
# The env/PATH bits just let root find `uv` and the Go tools (nuclei, ffuf,
# katana, …). Everything runs inside uv's managed virtual environment.
#
# Usage:
#     ./nigredo.sh init                    # set up the engagement + enter targets
#     ./nigredo.sh start                   # start the run
#     ./nigredo.sh tools                   # install missing external tools
#     ./nigredo.sh adjudicator --folder P  # score a finished run (--audit-only ok)
#
set -euo pipefail

# run from the tool's own directory, wherever it was invoked from
cd "$(dirname "$(readlink -f "$0")")"

usage() {
    echo "Usage: ./nigredo.sh <command> [args]"
    echo
    echo "  Single engagement (one target set, one run):"
    echo "    init                     set up the engagement and enter targets"
    echo "    start                    start the run"
    echo
    echo "  Campaign (several clients, each configured, run in parallel):"
    echo "    campaign-init <c1> <c2>  create a folder per client (or run with no"
    echo "                             names to be prompted for them)"
    echo "    campaign-configure       set each client's scan settings"
    echo "                             (add --mode each | --mode same)"
    echo "    campaign-run --all       run every ready client in parallel"
    echo "                             (or name clients; --max-parallel N, --dry-run)"
    echo "    campaign-status          show which clients are ready/running/done"
    echo
    echo "  Other:"
    echo "    tools                    install missing external tools (interactive)"
    echo "                             (alias: install-missing)"
    echo "    adjudicator --folder P   score/adjudicate a finished run's results"
    echo "                             (add --audit-only for a verdict-only pass;"
    echo "                              any extra flags are forwarded as-is)"
    echo
    exit 1
}

[ $# -ge 1 ] || usage

CMD="$1"; shift || true
case "$CMD" in
    init)   MODE="run";    SUBCMD="engagement-init" ;;
    start)  MODE="run";    SUBCMD="engagement" ;;
    campaign-init)      MODE="run"; SUBCMD="campaign init" ;;
    campaign-configure) MODE="run"; SUBCMD="campaign configure" ;;
    campaign-run)       MODE="run"; SUBCMD="campaign run" ;;
    campaign-status)    MODE="run"; SUBCMD="campaign status" ;;
    tools|install-missing)
            MODE="run";    SUBCMD="install-missing" ;;
    adjudicator|adjudicate)
            MODE="module"; SUBCMD="prima_materia.adjudicator" ;;
    -h|--help|help) usage ;;
    *) echo "Unknown command: $CMD"; echo; usage ;;
esac

# nigredo always needs root (raw sockets / SYN scans / privileged ports). If we're
# not already root, re-invoke THIS SAME command under sudo so the user never has
# to remember the sudo/env/PATH prefix. sudo prompts for the password. -E keeps
# the environment (API keys, config); the explicit PATH= makes sure root can
# still find uv and the Go-based tools. Any extra args ("$@") — e.g. the
# adjudicator's --folder <path> / --audit-only — are forwarded verbatim.
if [ "$MODE" = "module" ]; then
    if [ "$(id -u)" -ne 0 ]; then
        exec sudo -E env "PATH=$PATH" uv run python -m "$SUBCMD" "$@"
    else
        exec uv run python -m "$SUBCMD" "$@"
    fi
else
    # $SUBCMD is intentionally UNQUOTED here: campaign commands set it to two
    # tokens ("campaign init") that must split into two argv words. The other
    # subcommands are single tokens with no spaces, so word-splitting is a no-op
    # for them. Extra user args ("$@") stay quoted and are forwarded verbatim.
    if [ "$(id -u)" -ne 0 ]; then
        exec sudo -E env "PATH=$PATH" uv run python run.py $SUBCMD "$@"
    else
        exec uv run python run.py $SUBCMD "$@"
    fi
fi
