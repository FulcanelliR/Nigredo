"""Regression test: the standalone `report` subcommand must rebuild the At a
Glance tab from disk.

The bug: a live run hands report.build_report() an in-memory list of
FunnelWebSummary objects, but the standalone `report` rebuild passed
funnelweb_summaries=None, so the `if funnelweb_summaries:` guard was false and
the At a Glance tab silently never got created. reconstruct_summaries_from_disk
rebuilds that list by scanning the engagement dir, so a rebuilt report gets the
same tab a fresh run would.

No network, no real tools, no scan data — just the known raw.csv shape.
"""
import csv
import tempfile
from pathlib import Path

from prima_materia import funnelweb


_HEADER = ["Category", "Detail", "Source URL", "Local Path", "Notes"]


def _write_engagement(eng: Path, host: str, rows: list) -> None:
    d = eng / host
    d.mkdir(parents=True)
    with open(d / "raw.csv", "w", newline="") as f:
        csv.writer(f).writerows([_HEADER] + rows)


def test_reconstruct_finds_every_crawled_host():
    with tempfile.TemporaryDirectory() as td:
        eng = Path(td)
        _write_engagement(eng, "sub1.target1.example.com", [
            ["Email", "admin@target1.example.com",
             "https://sub1.target1.example.com", "", ""],
            ["Secret", "AKIAIOSFODNN7EXAMPLE",
             "https://sub1.target1.example.com", "app.js",
             "[HIGH] AWS Access Key (entropy=4.2)"],
            ["Document", "/files/report.pdf",
             "https://sub1.target1.example.com", "", ""],
        ])
        _write_engagement(eng, "sub2.target1.example.com:8443", [
            ["Retire.js Finding", "jquery 1.7.1",
             "https://sub2.target1.example.com", "", "[HIGH]"],
        ])

        summaries = funnelweb.reconstruct_summaries_from_disk(eng)
        assert len(summaries) == 2, f"expected 2 hosts, got {len(summaries)}"

        by_label = {s.domain: s for s in summaries}
        a = by_label["sub1.target1.example.com"]
        b = by_label["sub2.target1.example.com:8443"]
        assert "admin@target1.example.com" in a.emails
        assert len(a.secrets_high) == 1
        assert a.documents == 1
        assert b.retire_high == 1


def test_empty_engagement_returns_empty_not_crash():
    with tempfile.TemporaryDirectory() as td:
        assert funnelweb.reconstruct_summaries_from_disk(Path(td)) == []


def test_legacy_report_csv_is_found():
    # older FunnelWeb builds wrote report.csv instead of raw.csv
    with tempfile.TemporaryDirectory() as td:
        eng = Path(td)
        d = eng / "legacy.example.com"
        d.mkdir(parents=True)
        with open(d / "report.csv", "w", newline="") as f:
            csv.writer(f).writerows([
                _HEADER,
                ["Email", "x@legacy.example.com",
                 "https://legacy.example.com", "", ""],
            ])
        summaries = funnelweb.reconstruct_summaries_from_disk(eng)
        assert len(summaries) == 1
        assert "x@legacy.example.com" in summaries[0].emails


def test_raw_csv_wins_over_report_csv_no_double_ingest():
    # if a host has BOTH raw.csv and report.csv, ingest once (raw wins)
    with tempfile.TemporaryDirectory() as td:
        eng = Path(td)
        d = eng / "dup.example.com"
        d.mkdir(parents=True)
        for name in ("raw.csv", "report.csv"):
            with open(d / name, "w", newline="") as f:
                csv.writer(f).writerows([
                    _HEADER,
                    ["Email", "x@dup.example.com",
                     "https://dup.example.com", "", ""],
                ])
        summaries = funnelweb.reconstruct_summaries_from_disk(eng)
        assert len(summaries) == 1, "host with raw.csv + report.csv ingested twice"
