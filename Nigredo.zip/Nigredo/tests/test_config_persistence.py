"""Regression: the interview answers that used to be stash-ONLY must now be
persisted to the client's recon_config.json AND read back by the consumer in the
unattended campaign child (which SKIPS the interview, so its runmode stash is
empty). This locks in the fix for the recurring "answer never reached the child"
bug class.

For each key we:
  1) write it with the interview's own _save_config_key (the configure step),
  2) reload via ReconConfig.load / Config.load (what the child does),
  3) reproduce the CONSUMER's real read expression and assert it sees the value.

Offline, no tools, no network.
"""
import os
import tempfile

import prima_materia.runmode as RM
from prima_materia.recon_config import ReconConfig
from prima_materia.config import Config
from prima_materia.interview import _save_config_key
from prima_materia.tools import build_tool_config


def _fresh_client_config(**answers):
    """Seed a client recon_config.json from defaults, persist the given answers
    exactly as the interview would, and return (path, clean-runmode)."""
    d = tempfile.mkdtemp()
    path = os.path.join(d, "recon_config.json")
    ReconConfig().dump(path)
    for k, v in answers.items():
        _save_config_key(path, k, v)
    RM._ANSWERS.clear()          # child never ran the interview -> empty stash
    return path


def test_company_persists_and_reads():
    path = _fresh_client_config(company="AcmeCorp")
    cfg = ReconConfig.load(path)
    # orchestrator._get_company: stash wins, else cfg.company, else domain base
    got = (RM.answer("company", "acme") if RM.has_answer("company")
           else (getattr(cfg, "company", "") or "acme"))
    assert got == "AcmeCorp", got


def test_grayhat_tier_persists_and_reads():
    path = _fresh_client_config(grayhat_tier="high")
    cfg = ReconConfig.load(path)
    got = (RM.answer("grayhat_tier", "low") if RM.has_answer("grayhat_tier")
           else getattr(cfg, "grayhat_tier", "low"))
    assert got == "high", got


def test_fileenum_mode_persists_and_reads():
    path = _fresh_client_config(fileenum_mode="full")
    cfg = ReconConfig.load(path)
    got = (str(RM.answer("fileenum_mode", "basic")).lower()
           if RM.has_answer("fileenum_mode")
           else str(getattr(cfg, "fileenum_mode", "basic")).lower())
    assert got == "full", got


def test_forward_proxy_persists_and_reads():
    path = _fresh_client_config(forward_proxy="http://127.0.0.1:8080")
    cfg = ReconConfig.load(path)
    # ReconConfig must carry it (was only on Phase-0 Config before the fix)
    got = ((RM.answer("forward_proxy", "") or "")
           if RM.has_answer("forward_proxy")
           else (getattr(cfg, "forward_proxy", "") or ""))
    assert got == "http://127.0.0.1:8080", got


def test_follow_same_host_redirects_persists_and_reads():
    # persist the NON-default (True) so we prove the value survives, not the default
    path = _fresh_client_config(follow_same_host_redirects=True)
    cfg = ReconConfig.load(path)
    got = (bool(RM.answer("follow_same_host_redirects", False))
           if RM.has_answer("follow_same_host_redirects")
           else getattr(cfg, "follow_same_host_redirects", False))
    assert got is True, got


def test_ferox_custom_wordlist_persists_and_reads():
    # feroxbuster is Phase-0: the child does Config.load on the SAME json, then
    # build_tool_config -> ToolConfig. Prove the custom path flows all the way.
    path = _fresh_client_config(ferox_mode="c",
                                ferox_custom_wordlist="/tmp/custom.txt")
    c0 = Config.load(path)
    tc = build_tool_config(c0)
    got = str(RM.answer("ferox_custom_wordlist",
                        getattr(tc, "ferox_custom_wordlist", "")) or "").strip()
    assert got == "/tmp/custom.txt", got
    assert tc.ferox_mode == "c", tc.ferox_mode


def test_partyon_spray_defaults_off_and_persists():
    # SECURITY-SENSITIVE: unset must be OFF; explicit True must survive.
    path_default = _fresh_client_config()          # nothing set
    cfg_default = ReconConfig.load(path_default)
    assert bool(getattr(cfg_default, "partyon_spray", False)) is False

    path = _fresh_client_config(partyon_spray=True,
                                partyon_proxy="http://spray:9000",
                                partyon_seconds=7)
    cfg = ReconConfig.load(path)
    assert bool(getattr(cfg, "partyon_spray", False)) is True
    assert (getattr(cfg, "partyon_proxy", "") or "") == "http://spray:9000"
    assert getattr(cfg, "partyon_seconds", 3) == 7


def test_all_gap_keys_roundtrip_through_dump():
    """A configured value must survive a full ReconConfig.load->dump->load cycle
    (campaign_run rewrites the config before launching the child)."""
    path = _fresh_client_config(
        company="AcmeCorp", grayhat_tier="high", fileenum_mode="full",
        forward_proxy="http://p:1", follow_same_host_redirects=True,
        ferox_custom_wordlist="/tmp/c.txt", partyon_spray=True,
        partyon_proxy="http://s:2", partyon_seconds=9)
    cfg = ReconConfig.load(path)
    cfg.dump(path)                      # what campaign._launch does
    cfg2 = ReconConfig.load(path)
    assert cfg2.company == "AcmeCorp"
    assert cfg2.grayhat_tier == "high"
    assert cfg2.fileenum_mode == "full"
    assert cfg2.forward_proxy == "http://p:1"
    assert cfg2.follow_same_host_redirects is True
    assert cfg2.ferox_custom_wordlist == "/tmp/c.txt"
    assert cfg2.partyon_spray is True
    assert cfg2.partyon_proxy == "http://s:2"
    assert cfg2.partyon_seconds == 9


if __name__ == "__main__":
    for name, fn in sorted(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn()
            print("PASS", name)
    print("all config-persistence tests passed")
