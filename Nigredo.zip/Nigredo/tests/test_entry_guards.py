"""Regression: the fuzzer entry guards (and the scan-authority gate) tested
`st_size > 0`, not "has at least one real target line". A urls.txt containing
only whitespace/newlines has a non-zero size but zero targets, so it passed the
gate and every tool "ran" over an empty list -- writing no output while looking
like it worked. The fix gates on a decode-safe non-blank-line count instead.

These tests confirm a blank-only target file is now SKIPPED with a clear reason
by ffuf / feroxbuster / nuclei, and a real target file still passes the guard.

Run directly (`python tests/test_entry_guards.py`) or via pytest.
"""
import io
import sys
import tempfile
from pathlib import Path

import prima_materia.tools as T
import prima_materia.ffuf_tool as F


def _tmp() -> Path:
    return Path(tempfile.mkdtemp())


def _capture(fn) -> str:
    buf = io.StringIO()
    old = sys.stdout
    sys.stdout = buf
    try:
        fn()
    finally:
        sys.stdout = old
    return buf.getvalue()


def test_blank_only_file_is_skipped_with_reason():
    """A whitespace-only urls.txt (size > 0, zero real lines) must be skipped by
    all three fuzzers, each stating the file is empty/blank-only."""
    d = _tmp()
    blank = d / "urls.txt"
    blank.write_text("\n  \n\t\n")
    assert blank.stat().st_size > 0, "precondition: file must pass the old size gate"
    cmdlog = d / "c.log"
    cmdlog.write_text("")
    tc = T.ToolConfig()

    out_ffuf = _capture(
        lambda: F.run_ffuf(tc, blank, d, cmdlog, assume_yes=True, dry_run=True))
    out_ferox = _capture(
        lambda: T.run_feroxbuster(tc, blank, d, cmdlog, assume_yes=True, dry_run=True))
    out_nuclei = _capture(
        lambda: T.run_nuclei(tc, blank, d, cmdlog, assume_yes=True, dry_run=True))

    assert "skipping" in out_ffuf and "blank-only" in out_ffuf, out_ffuf
    assert "skipping" in out_ferox and "blank-only" in out_ferox, out_ferox
    assert "skipping" in out_nuclei and "blank-only" in out_nuclei, out_nuclei


def test_real_file_passes_the_guard():
    """A urls.txt with a real target must NOT trip the 'no web targets' guard."""
    d = _tmp()
    real = d / "real.txt"
    real.write_text("https://10.0.0.1\n")
    cmdlog = d / "c.log"
    cmdlog.write_text("")
    tc = T.ToolConfig()

    out = _capture(
        lambda: F.run_ffuf(tc, real, d, cmdlog, assume_yes=True, dry_run=True))
    assert "no web targets" not in out, \
        f"real target file was wrongly skipped: {out!r}"


def test_helpers_agree_on_blank_vs_real():
    """The pipeline and tools helpers must classify targets identically."""
    import prima_materia.pipeline as P
    d = _tmp()
    real = d / "r.txt"
    real.write_text("https://x\n")
    blank = d / "b.txt"
    blank.write_text("\n\n")
    assert P._has_real_targets(real) is T._file_has_real_targets(real) is True
    assert P._has_real_targets(blank) is T._file_has_real_targets(blank) is False


if __name__ == "__main__":
    test_blank_only_file_is_skipped_with_reason()
    test_real_file_passes_the_guard()
    test_helpers_agree_on_blank_vs_real()
    print("test_entry_guards: all passed")
