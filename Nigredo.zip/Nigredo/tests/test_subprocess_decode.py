"""Regression: the reorder-era crash had a SECOND decode surface that the
file-read fix didn't cover -- subprocess output. `subprocess.run(..., text=True)`
decodes the child's stdout/stderr as UTF-8 *strict*, so when httpx (or any tool)
echoes a scraped URL/title containing a Windows-1252 byte (0x92), the decode
happens inside subprocess.communicate() and crashes Phase 0 -- before any
file-read guard applies. Observed at web_discovery.run_httpx_liveness.

The fix adds errors="replace" to every text=True subprocess call on the scan
path. These tests assert (1) no such call is left unguarded in the package, and
(2) the real run_httpx_liveness survives a 0x92 byte in the child's output.

Run directly (`python tests/test_subprocess_decode.py`) or via pytest.
"""
import re
import subprocess
import tempfile
from pathlib import Path


PKG = Path(__file__).resolve().parent.parent / "prima_materia"


def test_no_unguarded_text_subprocess_calls():
    """Every text=True / universal_newlines=True on a subprocess call must carry
    errors=. (openpyxl's wrap_text=True is not a subprocess arg and is ignored.)"""
    offenders = []
    call_re = re.compile(r"subprocess|_sp\.(run|Popen|check_output)|\.run\(|\.Popen\(")
    for py in sorted(PKG.glob("*.py")):
        text = py.read_text()
        # collapse multi-line calls so text=True and errors= on different lines
        # are seen together: scan each logical call region crudely by line window.
        lines = text.splitlines()
        for i, ln in enumerate(lines):
            if "text=True" not in ln and "universal_newlines=True" not in ln:
                continue
            if "wrap_text=True" in ln and "text=True" not in ln.replace("wrap_text=True", ""):
                continue  # openpyxl alignment, not subprocess
            window = "\n".join(lines[max(0, i - 4):i + 5])
            if not call_re.search(window):
                continue  # not a subprocess call
            if "errors=" not in window:
                offenders.append(f"{py.name}:{i + 1}: {ln.strip()}")
    assert not offenders, "unguarded text=True subprocess decode(s):\n" + "\n".join(offenders)


def test_httpx_liveness_survives_bad_byte_in_child_output():
    """run_httpx_liveness must not crash when httpx emits a 0x92 byte."""
    import prima_materia.web_discovery as WD

    d = Path(tempfile.mkdtemp())
    disc = d / "discovered_urls_raw.txt"
    disc.write_text("https://example.com/a\nhttps://example.com/b\n")
    cmdlog = d / "commands.log"
    cmdlog.write_text("")

    WD._find_pd_httpx = lambda: "/usr/bin/httpx"
    real_run = subprocess.run

    def fake_run(cmd, *a, **k):
        # emulate httpx echoing a scraped URL containing 0x92 on stdout,
        # preserving the real kwargs the code passes (text=True, errors=replace)
        return real_run([r"printf", r"https://example.com/li\x92ve\n"], *a, **k)

    WD.subprocess.run = fake_run
    try:
        result = WD.run_httpx_liveness(
            disc, d, cmdlog, proxy="", retries=3, dry_run=False)
    finally:
        WD.subprocess.run = real_run
    # returns a set (possibly empty) rather than raising
    assert result is None or isinstance(result, set)


if __name__ == "__main__":
    test_no_unguarded_text_subprocess_calls()
    test_httpx_liveness_survives_bad_byte_in_child_output()
    print("test_subprocess_decode: all passed")
