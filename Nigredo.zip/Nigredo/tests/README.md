# Nigredo regression tests

Offline regression tests for the Batch-2 reorder fixes. No network and no real
external tools are required — the binary-execution layer is mocked, so these run
anywhere the package imports.

## What they lock in

- **`test_decode_safety.py`** — the root-cause fix. A Windows-1252 byte (`0x92`,
  a smart apostrophe) in scraped gau/httpx output used to make a strict UTF-8
  `read_text()` raise `UnicodeDecodeError`, which `_run_phase0`'s `except
  ValueError` swallowed and mislabeled as "Phase 0 not run" — silently skipping
  every web tool. Asserts (1) scan-path reads are decode-safe, and (2) a decode
  crash is now surfaced as a visible `[ERROR]`, not masked.

- **`test_entry_guards.py`** — a whitespace-only `urls.txt` has a non-zero size
  but zero real targets. The old `st_size > 0` guards let it through and the
  tools "ran" over an empty list. Asserts ffuf/feroxbuster/nuclei now skip a
  blank-only file with a clear reason, and a real file still passes.

- **`test_dataflow_chain.py`** — drives the real tool entry functions in the real
  pipeline order over synthetic data and asserts every stage is reached and each
  hand-off connects (ffuf hits → feroxbuster; ffuf+ferox 403s + 403.txt →
  nomore403; urls/tls → sns/testssl), plus workbook ingest + dedup + nuclei
  severity tally.

## Running

From the package root (the directory containing `prima_materia/`):

```sh
# plain, no dependencies
python tests/test_decode_safety.py
python tests/test_entry_guards.py
python tests/test_dataflow_chain.py

# or all at once
python tests/run_all.py

# or with pytest if installed
pytest tests/
```
