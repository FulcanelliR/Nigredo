"""Data-flow regression: drive the REAL tool entry functions in the REAL
pipeline order over synthetic data, mocking only the binary-execution layer
(subprocess / shutil.which) and the network-dependent ffuf liveness gate.

Verifies the chain the reorder was supposed to preserve:
  urls.txt -> nuclei / ffuf / feroxbuster -> their JSON artifacts
           -> ffuf_hits.txt feeds feroxbuster
           -> ffuf + feroxbuster 403s (+ 403.txt) feed nomore403
           -> tls_endpoints feeds testssl ; urls feed sns

No network and no real tools are used, so this runs anywhere. It asserts each
stage is REACHED with a non-empty target file and that each hand-off connects.

Run directly (`python tests/test_dataflow_chain.py`) or via pytest.
"""
import json
import shutil
import subprocess
import tempfile
import types
from pathlib import Path

import prima_materia.tools as T
import prima_materia.ffuf_tool as F
import prima_materia.nomore403_tool as NM
import prima_materia.runmode as RM
import prima_materia.wordlist_select as WS
import prima_materia.resources as RES


def _install_mocks():
    """Patch the execution layer so real tool entry logic runs offline."""
    RM.is_unattended = lambda: True
    RM.answer = lambda key, default=None: default
    T._confirm = lambda *a, **k: True
    T._choose = lambda *a, **k: (k.get("default") or "d")
    T._ask_text = lambda *a, **k: (k.get("default") or "")

    shutil.which = lambda name, *a, **k: f"/usr/bin/{name}"
    T.shutil.which = shutil.which
    F.shutil.which = shutil.which
    NM.shutil.which = shutil.which

    # ffuf liveness gate: report every host live (no network in the sandbox)
    F._resolve_live_url = lambda base: base

    wl = Path(tempfile.mkdtemp()) / "raft.txt"
    wl.write_text("admin\nlogin\nconfig\n")
    WS.prompt_size = lambda *a, **k: str(wl)
    WS.raft_path = lambda *a, **k: str(wl)

    RES.popen_kwargs = lambda *a, **k: {}
    RES.kill_tree = lambda *a, **k: None

    def _out_of(cmd):
        for i, a in enumerate(cmd):
            if a in ("-o", "--output") and i + 1 < len(cmd):
                return cmd[i + 1]
        return None

    class _Proc:
        returncode = 0
        stdout = iter(())
        stderr = iter(())

        def wait(self, *a, **k):
            return 0

        def poll(self):
            return 0

        def communicate(self, *a, **k):
            return ("", "")

        def terminate(self):
            pass

        def kill(self):
            pass

    def fake_run(cmd, *a, **k):
        exe = Path(cmd[0]).name if cmd else "?"
        out = _out_of(cmd)
        if out:
            p = Path(out)
            if exe == "ffuf":
                base = None
                for i, x in enumerate(cmd):
                    if x == "-u" and i + 1 < len(cmd):
                        base = cmd[i + 1].replace("/FUZZ", "")
                p.write_text(json.dumps({"results": [
                    {"url": f"{base}/admin", "status": 403},
                    {"url": f"{base}/login", "status": 200},
                ]}))
            elif exe == "feroxbuster":
                base = None
                for i, x in enumerate(cmd):
                    if x == "-u" and i + 1 < len(cmd):
                        base = cmd[i + 1]
                p.write_text(
                    json.dumps({"type": "response", "status": 403,
                                "url": f"{base}/secret"}) + "\n"
                    + json.dumps({"type": "response", "status": 200,
                                  "url": f"{base}/home"}) + "\n")
            else:
                p.write_text("")
        return types.SimpleNamespace(returncode=0, stdout="", stderr="")

    def fake_popen(cmd, *a, **k):
        fake_run(cmd, *a, **k)
        p = _Proc()
        p.stdout = iter(())
        p.stderr = iter(())
        return p

    subprocess.run = fake_run
    subprocess.Popen = fake_popen
    T.subprocess.run = fake_run
    T.subprocess.Popen = fake_popen
    F.subprocess.run = fake_run
    NM.subprocess.run = fake_run


def _count(fp):
    try:
        return len([l for l in Path(fp).read_text().splitlines() if l.strip()])
    except Exception:
        return 0


def test_web_tools_chain_reaches_all_stages_in_order():
    _install_mocks()
    outdir = Path(tempfile.mkdtemp(prefix="engage_"))
    urls = outdir / "urls.txt"
    urls.write_text(
        "https://10.0.0.1\nhttp://10.0.0.2:8080\nhttps://app.example.com\n")
    forb = outdir / "403.txt"
    forb.write_text("https://10.0.0.1/admin\n")
    tls = outdir / "tls_endpoints.txt"
    tls.write_text("10.0.0.1:443\nmail.example.com:993\n")
    cmdlog = outdir / "commands.log"
    cmdlog.write_text("")
    tc = T.ToolConfig()

    # 1. nuclei (full) over urls.txt
    assert _count(urls) == 3
    T.run_nuclei(tc, urls, outdir, cmdlog, assume_yes=True, dry_run=False,
                 takeover_only=False, out_prefix="nuclei")

    # 2. ffuf over urls.txt -> ffuf_*.json + ffuf_hits.txt
    ffuf_hits = F.run_ffuf(tc, urls, outdir, cmdlog, assume_yes=True, dry_run=False)
    assert sorted(outdir.glob("ffuf_*.json")), "ffuf wrote no JSON"
    assert ffuf_hits and Path(ffuf_hits).exists(), "ffuf produced no hits file"

    # 3. feroxbuster consumes roots + ffuf hits
    roots = [u.strip() for u in urls.read_text().splitlines() if u.strip()]
    dirs = [u.strip() for u in Path(ffuf_hits).read_text().splitlines() if u.strip()]
    merged, seen = [], set()
    for u in roots + dirs:
        if u not in seen:
            seen.add(u)
            merged.append(u)
    ferox_input = outdir / "feroxbuster_targets.txt"
    ferox_input.write_text("\n".join(merged) + "\n")
    assert _count(ferox_input) >= _count(urls), "ffuf->ferox hand-off lost targets"
    T.run_feroxbuster(tc, ferox_input, outdir, cmdlog, assume_yes=True, dry_run=False)
    assert sorted(outdir.glob("feroxbuster_*.json")), "feroxbuster wrote no JSON"

    # 4. nomore403 collects 403s from ffuf + feroxbuster + 403.txt
    found = NM.collect_403_urls(outdir, extra_403_file=str(forb))
    assert len(found) >= 3, f"nomore403 found too few 403s: {found}"

    # 5. testssl over tls endpoints
    assert _count(tls) == 2
    T.run_testssl(tc, tls, outdir, cmdlog, assume_yes=True, dry_run=False)

    # 6. sns over urls
    sns_urls = [u for u in urls.read_text().splitlines() if u.strip()]
    assert len(sns_urls) == 3
    T.run_sns(tc, sns_urls, outdir, cmdlog, assume_yes=True, dry_run=False)


def test_workbook_ingest_and_dedup():
    """ffuf/feroxbuster JSON -> workbook rows, with exact-duplicate collapse,
    and nuclei.jsonl -> per-host:port severity tally."""
    import prima_materia.scan_summary as SS
    outdir = Path(tempfile.mkdtemp())
    (outdir / "ffuf_10.0.0.1_443_dirs.json").write_text(json.dumps({"results": [
        {"url": "https://10.0.0.1/admin", "status": 403},
        {"url": "https://10.0.0.1/login", "status": 200},
    ]}))
    (outdir / "ffuf_10.0.0.1_443_dirs2.json").write_text(json.dumps({"results": [
        {"url": "https://10.0.0.1/admin", "status": 403},   # exact dup
        {"url": "https://10.0.0.1/uploads", "status": 301},
    ]}))
    (outdir / "feroxbuster_10.0.0.1_443_words.json").write_text(
        json.dumps({"type": "response", "status": 403,
                    "url": "https://10.0.0.1/secret"}) + "\n"
        + json.dumps({"type": "response", "status": 200,
                      "url": "https://10.0.0.1/home"}) + "\n"
        + json.dumps({"type": "response", "status": 403,
                      "url": "https://10.0.0.1/secret"}) + "\n")  # dup
    (outdir / "nuclei.jsonl").write_text("\n".join(json.dumps(
        {"template-id": f"t{i}", "info": {"severity": sev},
         "matched-at": "https://10.0.0.1:443/x"})
        for i, sev in enumerate(
            ["high", "medium", "medium", "low", "info", "critical"])) + "\n")

    rows = SS._ffuf_ferox_rows(outdir)
    seen, uniq = set(), []
    for r in rows:
        k = (r["tool"], r["host"], r["port"], r["status"], r["url"])
        if k not in seen:
            seen.add(k)
            uniq.append(r)
    assert len(rows) == 7 and len(uniq) == 5, \
        f"expected 7 raw / 5 unique, got {len(rows)} / {len(uniq)}"

    tally = SS.nuclei_tally(outdir)
    key = ("10.0.0.1", 443)
    assert tally.get(key, {}).get("medium") == 2
    assert tally.get(key, {}).get("critical") == 1


if __name__ == "__main__":
    test_web_tools_chain_reaches_all_stages_in_order()
    test_workbook_ingest_and_dedup()
    print("test_dataflow_chain: all passed")
