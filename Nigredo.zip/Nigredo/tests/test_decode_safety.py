"""Regression: the reorder put a large-file read (scraped gau/httpx output) on
the Phase-0 scan path. A Windows-1252 byte (0x92, a smart apostrophe) made a
strict UTF-8 `read_text()` raise UnicodeDecodeError, which `_run_phase0`'s
`except ValueError` swallowed and mislabeled as a benign "Phase 0 not run" skip
-- silently killing every web tool (nuclei/ffuf/feroxbuster/nomore403/testssl/
sns) while recon carried on.

These tests lock in both halves of the fix:
  1. reads on the scan path are decode-safe (errors="replace"), so 0x92 no
     longer crashes; and
  2. if a decode error does occur, `_run_phase0` SURFACES it as a visible ERROR
     with a traceback instead of masking it as a scope/config skip.

Run directly (`python tests/test_decode_safety.py`) or via pytest.
"""
import io
import sys
import tempfile
from pathlib import Path

import prima_materia.pipeline as P
import prima_materia.__main__ as M


def _tmp() -> Path:
    return Path(tempfile.mkdtemp())


def test_load_lines_is_decode_safe():
    """A gau-like file with a 0x92 byte ~84KB in must read without crashing."""
    d = _tmp()
    big = d / "gau_out.txt"
    big.write_bytes(
        ("https://example.com/p\n" * 3500).encode()
        + b"https://example.com/it\x92s-here\n"
    )
    lines = P._load_lines(big)
    assert len(lines) == 3501, f"expected 3501 lines, got {len(lines)}"


def test_has_real_targets_semantics():
    """Non-blank-line detection: real content True; blank-only/missing False;
    a 0x92-containing real line still True (decode-safe)."""
    d = _tmp()
    real = d / "real.txt"
    real.write_text("https://10.0.0.1\n")
    blank = d / "blank.txt"
    blank.write_text("\n  \n\t\n")
    smart = d / "smart.txt"
    smart.write_bytes(b"https://example.com/what\x92s\n")

    assert P._has_real_targets(real) is True
    assert P._has_real_targets(blank) is False
    assert P._has_real_targets(d / "nope.txt") is False
    assert P._has_real_targets(smart) is True


def test_phase0_surfaces_decode_crash_not_masks_it():
    """A UnicodeDecodeError raised inside the scan phase must be reported as a
    visible ERROR (with the 0x92 message), NOT swallowed as 'Phase 0 not run'."""
    class _Args:
        config = None
        dry_run = False
        yes = True

    orig = M.Config.load

    def _boom(*a, **k):
        b"\x92".decode("utf-8")  # raises UnicodeDecodeError

    M.Config.load = staticmethod(_boom)
    buf = io.StringIO()
    old = sys.stderr
    sys.stderr = buf
    try:
        ret = M._run_phase0(_Args(), "acme", ["example.com"])
    finally:
        sys.stderr = old
        M.Config.load = orig

    err = buf.getvalue()
    assert ret is False
    assert "CRASHED on a text-decoding error" in err, \
        "decode crash was not surfaced as an ERROR"
    assert not ("Phase 0 not run" in err and "ERROR" not in err), \
        "decode crash was masked as a benign notice"


if __name__ == "__main__":
    test_load_lines_is_decode_safe()
    test_has_real_targets_semantics()
    test_phase0_surfaces_decode_crash_not_masks_it()
    print("test_decode_safety: all passed")
