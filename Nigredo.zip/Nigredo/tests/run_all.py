"""Run all Nigredo regression tests without pytest.

Usage (from the package root, the dir containing prima_materia/):
    python tests/run_all.py
"""
import importlib
import sys
import traceback
from pathlib import Path

# allow running from anywhere: ensure the package root is importable
ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

MODULES = [
    "tests.test_decode_safety",
    "tests.test_entry_guards",
    "tests.test_dataflow_chain",
    "tests.test_subprocess_decode",
    "tests.test_nuclei_proxy_and_outcome",
    "tests.test_ffuf_ferox_handoff",
    "tests.test_at_a_glance_rebuild",
    "tests.test_logging",
    "tests.test_campaign",
    "tests.test_config_persistence",
    "tests.test_funnelweb_interrupt",
]


def main() -> int:
    failures = 0
    for modname in MODULES:
        mod = importlib.import_module(modname)
        fns = [getattr(mod, n) for n in dir(mod)
               if n.startswith("test_") and callable(getattr(mod, n))]
        for fn in fns:
            try:
                fn()
                print(f"  PASS  {modname}.{fn.__name__}")
            except Exception:  # noqa: BLE001
                failures += 1
                print(f"  FAIL  {modname}.{fn.__name__}")
                traceback.print_exc()
    print()
    if failures:
        print(f"{failures} test(s) FAILED")
        return 1
    print("all regression tests passed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
