"""FunnelWeb is the one tool that crawls MANY targets in a single run, so a
Ctrl+C during it is ambiguous: skip this target, or the whole tool? These tests
lock in the four-way sub-menu behavior (this / tool / retry / quit) so one Ctrl+C
skips only the current target by default, matching every single-target tool.
"""
from pathlib import Path
from unittest import mock

from prima_materia import funnelweb

_TARGETS = ["a.com", "b.com", "c.com"]
_OUT = Path("/tmp")
_LOG = Path("/tmp/cmd.log")


def _run_multi():
    return funnelweb.run_funnelweb_multi(_TARGETS, _OUT, _LOG, dry_run=True)


def _interrupt_on(target):
    def _fake(t, *a, **k):
        if t == target:
            raise KeyboardInterrupt
        return True
    return _fake


def test_skip_this_target_continues_to_next():
    with mock.patch.object(funnelweb, "run_funnelweb",
                           side_effect=_interrupt_on("a.com")):
        with mock.patch("prima_materia.interrupt._prompt_multitarget_menu",
                        return_value="this"):
            launched = _run_multi()
    assert launched == ["b.com", "c.com"]


def test_skip_whole_tool_stops_remaining_targets():
    with mock.patch.object(funnelweb, "run_funnelweb",
                           side_effect=_interrupt_on("a.com")):
        with mock.patch("prima_materia.interrupt._prompt_multitarget_menu",
                        return_value="tool"):
            launched = _run_multi()
    assert launched == []          # b.com, c.com never run


def test_quit_propagates_keyboardinterrupt():
    with mock.patch.object(funnelweb, "run_funnelweb",
                           side_effect=_interrupt_on("a.com")):
        with mock.patch("prima_materia.interrupt._prompt_multitarget_menu",
                        return_value="quit"):
            try:
                _run_multi()
                assert False, "quit should re-raise KeyboardInterrupt"
            except KeyboardInterrupt:
                pass


def test_retry_recrawls_current_target_then_continues():
    hits = {"a": 0}

    def _fake(t, *a, **k):
        if t == "a.com":
            hits["a"] += 1
            if hits["a"] == 1:
                raise KeyboardInterrupt
        return True

    with mock.patch.object(funnelweb, "run_funnelweb", side_effect=_fake):
        with mock.patch("prima_materia.interrupt._prompt_multitarget_menu",
                        return_value="retry"):
            launched = _run_multi()
    assert launched == ["a.com", "b.com", "c.com"]
    assert hits["a"] == 2          # tried twice: interrupted, then retried
