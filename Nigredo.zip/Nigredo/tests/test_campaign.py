"""Campaign launcher tests: readiness detection, the explicit-run guardrails
(bare run refuses, completed clients skipped unless --force), and the
spawn/poll/collect loop. No real scans — children are faked — and no pytest
fixtures, so this runs under the plain run_all.py runner anywhere.
"""
import contextlib
import os
import subprocess
import tempfile
import time
import types
from pathlib import Path

import prima_materia.campaign as C
from prima_materia.recon_config import ReconConfig


@contextlib.contextmanager
def _workspace():
    prev = os.getcwd()
    with tempfile.TemporaryDirectory() as td:
        os.chdir(td)
        Path("recon_config.json").write_text(
            '{"output_dir": "results", "engagement_name": "engagement"}')
        try:
            yield Path(td)
        finally:
            os.chdir(prev)


def _mkclient(results, name, body, marker=True):
    (results / name).mkdir(parents=True, exist_ok=True)
    # Recon readiness now keys on domains.txt (recon scope), NOT targets.txt
    # (scan scope) — feeding scan targets as recon domains made recon run against
    # IPs. Write both so the client is recon-ready and has scan scope.
    (results / name / "domains.txt").write_text(body)
    (results / name / "targets.txt").write_text(body)
    if marker:
        (results / name / C.CAMPAIGN_MARKER).write_text("x")


@contextlib.contextmanager
def _fake_popen(rc_for):
    orig = subprocess.Popen

    class FakePopen:
        def __init__(self, cmd, **kw):
            cfg = cmd[cmd.index("--config") + 1]
            self.client = Path(cfg).parent.name
            self._start = time.time()
            self._rc = rc_for(self.client)
            self._logf = kw.get("stdout")

        def poll(self):
            if time.time() - self._start > 0.2:
                if hasattr(self._logf, "close"):
                    self._logf.close()
                return self._rc
            return None

        def terminate(self):
            pass

    subprocess.Popen = FakePopen
    try:
        yield
    finally:
        subprocess.Popen = orig


def _args(**kw):
    base = dict(recon_config="recon_config.json", clients=[], max_parallel=2,
                dry_run=False, all=False, force=False)
    base.update(kw)
    return types.SimpleNamespace(**base)


def test_ready_targets_parses_and_skips_empty():
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "# scope\nacme.com\napi.acme.com\n")
        _mkclient(results, "empty", "# nothing yet\n")
        assert C._ready_targets(results, "acme") == ["acme.com", "api.acme.com"]
        assert C._ready_targets(results, "empty") is None
        assert C._ready_targets(results, "missing") is None


def test_init_scaffolds_and_marks():
    with _workspace():
        assert C.cmd_campaign_init(_args(clients=["acme", "globex"])) == 0
        for c in ("acme", "globex"):
            assert (Path("results") / c / "targets.txt").is_file()
            assert (Path("results") / c / C.CAMPAIGN_MARKER).is_file()
        assert set(C._discover_clients(Path("results"))) == {"acme", "globex"}


def test_bare_run_refuses_and_spawns_nothing():
    # no names + no --all: must refuse (return 2), never launch
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "acme.com\n")

        def _boom(*a, **k):
            raise AssertionError("bare run must not spawn")

        orig = subprocess.Popen
        subprocess.Popen = _boom
        try:
            assert C.cmd_campaign_run(_args(clients=[])) == 2
        finally:
            subprocess.Popen = orig


def test_named_client_runs_only_that_client():
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "acme.com\n")
        _mkclient(results, "globex", "globex.com\n")
        with _fake_popen(lambda c: 0):
            rc = C.cmd_campaign_run(_args(clients=["acme"]))
        assert rc == 0
        assert (results / "acme" / "recon_config.json").is_file()
        assert not (results / "globex" / "recon_config.json").is_file()


def test_all_skips_completed_unless_forced():
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "acme.com\n")
        _mkclient(results, "globex", "globex.com\n")
        # acme already completed
        (results / "acme" / "final_report.xlsx").write_text("done")

        with _fake_popen(lambda c: 0):
            rc = C.cmd_campaign_run(_args(all=True))
        assert rc == 0
        # acme skipped (completed), globex ran. domains.txt now exists for BOTH
        # from _mkclient (operator seeds it), so use the launch log as the
        # "did this client actually run" signal instead.
        assert not (results / "acme" / "campaign_run.log").exists()
        assert (results / "globex" / "campaign_run.log").exists()

        # now force: acme runs too
        with _fake_popen(lambda c: 0):
            rc = C.cmd_campaign_run(_args(all=True, force=True))
        assert rc == 0
        assert (results / "acme" / "campaign_run.log").exists()


def test_all_collects_mixed_exit_codes():
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "acme.com\n")
        _mkclient(results, "globex", "globex.com\n")
        with _fake_popen(lambda c: 1 if c == "acme" else 0):
            rc = C.cmd_campaign_run(_args(all=True))
        assert rc == 1     # one failed -> overall non-zero
        assert (results / "globex" / "recon_config.json").is_file()


def test_dry_run_spawns_nothing():
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "acme.com\n")

        def _boom(*a, **k):
            raise AssertionError("dry-run must not spawn")

        orig = subprocess.Popen
        subprocess.Popen = _boom
        try:
            assert C.cmd_campaign_run(_args(clients=["acme"], dry_run=True)) == 0
        finally:
            subprocess.Popen = orig


def test_done_marker_marks_completed():
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "acme.com\n")
        assert C._is_completed(results, "acme") is False
        (results / "acme" / C.DONE_MARKER).write_text("done")
        assert C._is_completed(results, "acme") is True


def test_report_file_is_completion_fallback():
    with _workspace():
        results = Path("results")
        _mkclient(results, "acme", "acme.com\n")
        (results / "acme" / "final_report.xlsx").write_text("x")
        assert C._is_completed(results, "acme") is True   # fallback path


def test_resume_prompt_runs_interrupted_when_confirmed(monkeypatch=None):
    # bare run with an interrupted client: answering 'y' resumes just that client
    import builtins
    with _workspace():
        results = Path("results")
        _mkclient(results, "globex", "globex.com\n")
        # interrupted = has state, no done-marker
        (results / "globex" / "recon_state.json").write_text('{"done":{}}')

        orig_input = builtins.input
        builtins.input = lambda *a, **k: "y"
        ran = {}
        with _fake_popen(lambda c: 0):
            try:
                rc = C.cmd_campaign_run(_args(clients=[]))
            finally:
                builtins.input = orig_input
        # globex should have been launched (per-client config written)
        assert (results / "globex" / "recon_config.json").is_file()


def test_bare_run_declined_resume_leaves_alone():
    import builtins
    with _workspace():
        results = Path("results")
        _mkclient(results, "globex", "globex.com\n")
        (results / "globex" / "recon_state.json").write_text('{"done":{}}')

        orig_input = builtins.input
        builtins.input = lambda *a, **k: "n"

        def _boom(*a, **k):
            raise AssertionError("declining resume must not spawn")

        orig_popen = subprocess.Popen
        subprocess.Popen = _boom
        try:
            rc = C.cmd_campaign_run(_args(clients=[]))
        finally:
            builtins.input = orig_input
            subprocess.Popen = orig_popen
        assert not (results / "globex" / "recon_config.json").is_file()
