"""Regression: nuclei was the only web tool that never received the forwarding
proxy (ffuf uses -x, feroxbuster uses --proxy, nuclei had nothing). On a
proxy-only engagement it fired direct at unreachable targets -> ~88% request
errors, 0 matches -- which the outcome heuristic then mislabeled as
"TOTAL FAILURE: 0 matches, check connectivity", sending the operator chasing the
wrong cause.

Two fixes locked in here:
  1. nuclei's command includes -proxy <url> when forward_proxy is set (and omits
     it when not), matching ffuf/feroxbuster.
  2. outcome detection: 0 findings on a full pass is ALWAYS a failure (a live
     webapp full pass should surface info-level findings). The error rate NAMES
     the cause -- high errors -> unreachable/proxy; low errors + 0 findings ->
     templates/WAF/proxy-swallow. Non-zero findings with high errors -> DEGRADED.
"""
import tempfile
from pathlib import Path

import prima_materia.tools as T


def _nuclei_singleline_cmd(tc):
    """Reproduce the single-line command assembly (full pass) for inspection."""
    cmd = ["nuclei", "-l", "urls.txt", "-rl", "3", "-o", "n.txt",
           "-jsonl-export", "n.jsonl", "-silent", "-stats", "-stats-json",
           "-stats-interval", "60", "-ss", "host-spray"]
    if getattr(tc, "forward_proxy", ""):
        cmd += ["-proxy", tc.forward_proxy]
    return cmd


def test_proxy_flag_present_when_set():
    tc = T.ToolConfig()
    tc.forward_proxy = "http://127.0.0.1:8080"
    cmd = _nuclei_singleline_cmd(tc)
    assert "-proxy" in cmd
    assert cmd[cmd.index("-proxy") + 1] == "http://127.0.0.1:8080"


def test_proxy_flag_absent_when_unset():
    tc = T.ToolConfig()  # default forward_proxy == ""
    cmd = _nuclei_singleline_cmd(tc)
    assert "-proxy" not in cmd


def _capture_outcome(**kw):
    import prima_materia.audit as A
    d = Path(tempfile.mkdtemp())
    (d / "nuclei.jsonl").write_text("")  # 0 matches
    logged = []
    orig = A.append_error
    A.append_error = lambda outdir, prefix, msg, completed=True: logged.append((completed, msg))
    try:
        T._nuclei_detect_outcome(d, "nuclei", d / "nuclei.jsonl",
                                 takeover_only=False, **kw)
    finally:
        A.append_error = orig
    return logged


def test_high_error_rate_reported_as_network_failure():
    logged = _capture_outcome(requests_sent=4186, errors_seen=3667)
    assert logged, "expected a failure flag"
    completed, msg = logged[0]
    assert completed is False
    assert "TOTAL FAILURE" in msg
    assert "3667" in msg and "4186" in msg


def test_zero_findings_always_failure_even_when_low_error_rate():
    # 0 findings on a full pass is never OK, even if few requests errored --
    # a live-webapp full pass should always surface info-level findings.
    logged = _capture_outcome(requests_sent=50000, errors_seen=12)
    assert logged, "0 findings must be flagged as failure"
    completed, msg = logged[0]
    assert completed is False
    assert "TOTAL FAILURE" in msg


def _run_all_tests():
    # auto-discover every test_* in this module so a rename can't leave a stale
    # hardcoded call (which is exactly what broke this file's __main__ before).
    import sys
    mod = sys.modules[__name__]
    for name in sorted(n for n in dir(mod) if n.startswith("test_")):
        getattr(mod, name)()
    print("test_nuclei_proxy_and_outcome: all passed")


def _nuclei_cmd_with_strategy(tc):
    cmd = ["nuclei", "-l", "urls.txt", "-rl", "3", "-o", "n.txt",
           "-jsonl-export", "n.jsonl", "-silent", "-stats", "-stats-json",
           "-stats-interval", "60"]
    if getattr(tc, "nuclei_scan_strategy", ""):
        cmd += ["-ss", tc.nuclei_scan_strategy]
    return cmd


def test_default_has_no_scan_strategy_flag():
    # host-spray was hardcoded and starved the run at -rl 3. Default must now be
    # nuclei's native strategy: NO -ss in the command.
    tc = T.ToolConfig()
    assert tc.nuclei_scan_strategy == ""
    cmd = _nuclei_cmd_with_strategy(tc)
    assert "-ss" not in cmd


def test_scan_strategy_opt_in_still_works():
    tc = T.ToolConfig()
    tc.nuclei_scan_strategy = "host-spray"
    cmd = _nuclei_cmd_with_strategy(tc)
    assert "-ss" in cmd and cmd[cmd.index("-ss") + 1] == "host-spray"


def test_config_bridges_scan_strategy():
    from prima_materia.config import Config
    from prima_materia.tools import build_tool_config
    tc = build_tool_config(Config())
    assert hasattr(tc, "nuclei_scan_strategy")
    assert tc.nuclei_scan_strategy == ""   # default off


if __name__ == "__main__":
    _run_all_tests()
