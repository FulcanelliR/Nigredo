"""Regression: ffuf matches a wide status set (200,204,301,302,307,308,401,403,
405,500) but pure redirects (3xx) are signposts, not resources — recursing into
them with feroxbuster re-walks ground the redirect target already covers. The
ffuf->feroxbuster hand-off (_extract_hits) now keeps only recurse-worthy codes
(200,204,401,403,405,500) and drops redirects, trimming feroxbuster's workload
without losing real surface. Missing/garbled status fails OPEN (kept) so a schema
quirk never silently drops a hit.
"""
import json
import tempfile
from pathlib import Path

import prima_materia.ffuf_tool as F


def _mk(results):
    d = Path(tempfile.mkdtemp())
    j = d / "ffuf_x.json"
    j.write_text(json.dumps({"results": results}))
    return j


def test_redirects_dropped_real_codes_kept():
    j = _mk([
        {"url": "https://h/admin", "status": 200},
        {"url": "https://h/empty", "status": 204},
        {"url": "https://h/login", "status": 401},
        {"url": "https://h/secret", "status": 403},
        {"url": "https://h/api", "status": 405},
        {"url": "https://h/err", "status": 500},
        {"url": "https://h/r301", "status": 301},
        {"url": "https://h/r302", "status": 302},
        {"url": "https://h/r307", "status": 307},
        {"url": "https://h/r308", "status": 308},
    ])
    hits = F._extract_hits(j)
    tails = {u.rsplit("/", 1)[-1] for u in hits}
    assert tails == {"admin", "empty", "login", "secret", "api", "err"}
    assert not any(t.startswith("r3") for t in tails), "a redirect leaked through"


def test_missing_or_bad_status_fails_open():
    j = _mk([
        {"url": "https://h/nostatus"},                 # no status key
        {"url": "https://h/badstatus", "status": "x"},  # unparseable
    ])
    hits = F._extract_hits(j)
    tails = {u.rsplit("/", 1)[-1] for u in hits}
    assert tails == {"nostatus", "badstatus"}, "fail-open dropped a hit"


def test_recurse_codes_constant_has_no_redirects():
    for code in (301, 302, 303, 307, 308):
        assert code not in F._FEROX_RECURSE_CODES
    for code in (200, 204, 401, 403, 405, 500):
        assert code in F._FEROX_RECURSE_CODES


if __name__ == "__main__":
    test_redirects_dropped_real_codes_kept()
    test_missing_or_bad_status_fails_open()
    test_recurse_codes_constant_has_no_redirects()
    print("test_ffuf_ferox_handoff: all passed")
