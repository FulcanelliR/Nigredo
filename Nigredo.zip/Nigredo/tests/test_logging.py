"""The logging helper must: keep the [name] prefix, respect NIGREDO_DEBUG for
level, and not double-emit through the root logger. These are the properties
report.py (and future modules) rely on when they swap print() for log calls.
"""
import importlib
import logging
import os


def _fresh_log():
    # reload so NIGREDO_DEBUG is re-read and handlers are rebuilt clean
    import prima_materia.log as L
    importlib.reload(L)
    return L


def test_level_follows_nigredo_debug_env():
    os.environ.pop("NIGREDO_DEBUG", None)
    L = _fresh_log()
    assert L.get_logger("t_info").level == logging.INFO

    os.environ["NIGREDO_DEBUG"] = "1"
    try:
        L = _fresh_log()
        assert L.get_logger("t_debug").level == logging.DEBUG
    finally:
        os.environ.pop("NIGREDO_DEBUG", None)


def test_prefix_is_the_logger_name():
    L = _fresh_log()
    log = L.get_logger("subdomains")
    handler = log.handlers[0]
    # formatter renders the [name] prefix the tool has always used
    rec = logging.LogRecord("subdomains", logging.INFO, "x", 0, "hi", None, None)
    assert handler.formatter.format(rec) == "[subdomains] hi"


def test_does_not_propagate_to_root():
    # propagate=False prevents a second copy via the root logger
    L = _fresh_log()
    assert L.get_logger("no_double").propagate is False


def test_repeat_get_logger_does_not_stack_handlers():
    L = _fresh_log()
    a = L.get_logger("same")
    b = L.get_logger("same")
    assert a is b
    assert len(a.handlers) == 1     # configured once, not per call
