"""FQDN<->IP confirmed-scope resolver — the "expanded scope" builder.

PURPOSE
  targets.txt is the immutable authorization boundary. But a target given as an IP
  often has a real FQDN (and vice-versa), and IP vs FQDN can serve DIFFERENT
  content (host-header/vhost routing, CNAME vs A load order). So we want to scan
  both — BUT only when we're confident the FQDN truly maps to that in-scope IP.

CONFIRMATION RULE (2-of-3)
  A (IP, FQDN) pair is CONFIRMED only if at least 2 of 3 independent sources agree
  that the FQDN maps to that IP:
    1. dnsx (subfinder subdomain enumeration -> A records)
    2. nessus (.nessus host-fqdn / hostnames per IP)
    3. dig   (dig +short A <fqdn>, or reverse dig -x <ip>)
  Two independent agreements is the bar. One source alone is NOT enough to promote.

PROMOTION TIERS (safeguards-first)
  - CONFIRMED 1:1 (one IP <-> exactly one FQDN, both confirmed): FULL promotion.
    Both the IP and the FQDN become scannable by EVERYTHING (Part 1 active scan +
    Part 2 client-side harvest).
  - CONFIRMED one-to-many (an IP with multiple confirmed FQDNs, or vice-versa):
    the extra FQDNs go to PART 2 ONLY (FunnelWeb / JS+PHP parsers / retire.js /
    login-detect — the content-harvest tools). The IP still scans as-is in Part 1.
    Rationale: multi-FQDN means we've lost 1:1 identity certainty, so we don't
    unleash the full active battery, but the light content-harvest is safe+useful
    (catches vhost-routed panels).
  - UNCONFIRMED (only 1 source, or conflicting): NOT promoted. Recorded in the
    report tab for the analyst to review and promote by hand if warranted.

  Cloud-generic PTR names (ec2-...compute.amazonaws.com) usually only get 1 vote
  (reverse dig) so they land UNCONFIRMED by the strict rule — recorded, low
  priority, not auto-promoted. (The operator can still scan them manually.)

OUTPUT
  Writes fqdn_pairs.json (the full derivation: every candidate pair, which sources
  voted, the tier) so the report tab can show exactly how resolution flowed —
  auditable end to end. targets.txt is NEVER modified.

SAFEGUARDS-FIRST
  This module DERIVES scannable targets from DNS data, which is scope-sensitive.
  By default it only PROMOTES; it never removes or overrides targets.txt, and the
  2-of-3 bar is deliberately strict. Loosening (e.g. accept 1 source, or auto-scan
  cloud-generic names) is a conscious future change, not a default.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class PairVote:
    """One (ip, fqdn) candidate and which sources confirmed it."""
    ip: str
    fqdn: str
    sources: list[str] = field(default_factory=list)   # subset of dnsx/nessus/dig

    @property
    def votes(self) -> int:
        return len(set(self.sources))

    @property
    def confirmed(self) -> bool:
        # CONFIDENCE MODEL: the subfinder->shuffledns->dnsx sequence does heavy
        # validation (passive discovery + mass resolution + active A-record
        # confirmation), so a dnsx-resolved pair is AUTHORITATIVE on its own.
        # dig/nessus are gap-catchers: they let a pair dnsx MISSED get confirmed
        # if two of them agree. So: confirmed if dnsx resolved it, OR >=2 sources.
        s = set(self.sources)
        return "dnsx" in s or len(s) >= 2

    @property
    def is_cloud_generic(self) -> bool:
        """Cloud-provider backend PTR names (ec2-…compute.amazonaws.com, etc.).
        These are the backend resolution target, not the client's front door —
        ranked lowest and never picked over a real FQDN."""
        f = self.fqdn.lower()
        markers = ("compute.amazonaws.com", "amazonaws.com", "cloudapp.azure.com",
                   "cloudapp.net", "azure.com", "bc.googleusercontent.com",
                   "googleusercontent.com", "compute.internal", "ec2.internal")
        return any(m in f for m in markers)


@dataclass
class ResolveResult:
    confirmed_1to1: list[PairVote] = field(default_factory=list)   # full promote
    confirmed_multi: list[PairVote] = field(default_factory=list)  # part-2 only
    unconfirmed: list[PairVote] = field(default_factory=list)      # report only

    def part1_fqdns(self) -> list[str]:
        """FQDNs that earn FULL active scanning (1:1 confirmed only)."""
        return sorted({p.fqdn for p in self.confirmed_1to1})

    def part2_fqdns(self) -> list[str]:
        """FQDNs for client-side harvest (1:1 + multi, all confirmed)."""
        return sorted({p.fqdn for p in self.confirmed_1to1 + self.confirmed_multi})


def _norm_fqdn(s: str) -> str:
    return (s or "").strip().lower().rstrip(".")


def _norm_ip(s: str) -> str:
    return (s or "").strip()


def gather_dnsx_pairs(outdir: Path) -> dict[tuple[str, str], set[str]]:
    """From subdomains_*.clean.csv (subdomain,type,value): FQDN--A-->IP pairs.
    Returns {(ip, fqdn): {"dnsx"}}."""
    import csv
    pairs: dict[tuple[str, str], set[str]] = {}
    for csvf in sorted(Path(outdir).glob("subdomains_*.clean.csv")):
        try:
            with open(csvf, newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    if (row.get("type") or "").strip().upper() != "A":
                        continue
                    fqdn = _norm_fqdn(row.get("subdomain", ""))
                    ip = _norm_ip(row.get("value", ""))
                    if fqdn and ip:
                        pairs.setdefault((ip, fqdn), set()).add("dnsx")
        except (OSError, csv.Error):
            continue
    return pairs


def gather_nessus_pairs(nessus_hosts: dict) -> dict[tuple[str, str], set[str]]:
    """From a parsed nessus {ip: {hostnames:[...]}} dict: IP<->FQDN pairs.
    Returns {(ip, fqdn): {"nessus"}}."""
    pairs: dict[tuple[str, str], set[str]] = {}
    for ip, host in (nessus_hosts or {}).items():
        ip = _norm_ip(ip)
        for fqdn in host.get("hostnames", []) or []:
            fqdn = _norm_fqdn(fqdn)
            if fqdn and ip:
                pairs.setdefault((ip, fqdn), set()).add("nessus")
    return pairs


def gather_dig_pairs(candidate_fqdns, candidate_ips, dig_forward, dig_reverse
                     ) -> dict[tuple[str, str], set[str]]:
    """Confirm candidate pairs with dig, in BOTH directions:
      - forward: dig +short A <fqdn> -> IPs   (dig_forward(fqdn) -> [ip,...])
      - reverse: dig -x <ip>         -> FQDNs (dig_reverse(ip)  -> [fqdn,...])
    Only confirms pairs already proposed by another source (we don't invent new
    FQDNs from reverse DNS here — that would be a scope expansion; reverse names
    are gathered separately as low-priority candidates). Returns {(ip,fqdn):{"dig"}}.
    """
    pairs: dict[tuple[str, str], set[str]] = {}
    # forward-confirm each candidate FQDN
    for fqdn in candidate_fqdns:
        fqdn = _norm_fqdn(fqdn)
        try:
            for ip in dig_forward(fqdn) or []:
                pairs.setdefault((_norm_ip(ip), fqdn), set()).add("dig")
        except Exception:  # noqa: BLE001 (dig failure = no vote, never fatal)
            continue
    # reverse-confirm each candidate IP against candidate FQDNs
    cand_fqdn_set = {_norm_fqdn(f) for f in candidate_fqdns}
    for ip in candidate_ips:
        ip = _norm_ip(ip)
        try:
            for fqdn in dig_reverse(ip) or []:
                fqdn = _norm_fqdn(fqdn)
                if fqdn in cand_fqdn_set:      # only confirm KNOWN candidates
                    pairs.setdefault((ip, fqdn), set()).add("dig")
        except Exception:  # noqa: BLE001
            continue
    return pairs


def _merge(*pair_maps) -> dict[tuple[str, str], set[str]]:
    merged: dict[tuple[str, str], set[str]] = {}
    for pm in pair_maps:
        for key, srcs in pm.items():
            merged.setdefault(key, set()).update(srcs)
    return merged


def resolve_pairs(dnsx_pairs, nessus_pairs, dig_forward, dig_reverse
                  ) -> ResolveResult:
    """Combine sources, apply dig confirmation, then the 2-of-3 rule and tiering.

    dig_forward / dig_reverse are callables so this stays testable without a real
    dig binary. Pass no-op lambdas to skip dig (then only dnsx+nessus vote)."""
    # candidate universe from the two data sources
    base = _merge(dnsx_pairs, nessus_pairs)
    cand_fqdns = {f for (_ip, f) in base}
    cand_ips = {ip for (ip, _f) in base}

    # dig as the third voter (confirming existing candidates only)
    dig_pairs = gather_dig_pairs(cand_fqdns, cand_ips, dig_forward, dig_reverse)

    allp = _merge(base, dig_pairs)
    votes = [PairVote(ip=ip, fqdn=fqdn, sources=sorted(srcs))
             for (ip, fqdn), srcs in allp.items()]

    confirmed = [v for v in votes if v.confirmed]
    unconfirmed = [v for v in votes if not v.confirmed]

    # tier the confirmed pairs by 1:1 vs one-to-many
    by_ip: dict[str, list[PairVote]] = {}
    by_fqdn: dict[str, list[PairVote]] = {}
    for v in confirmed:
        by_ip.setdefault(v.ip, []).append(v)
        by_fqdn.setdefault(v.fqdn, []).append(v)

    one_to_one, multi = [], []
    for v in confirmed:
        # 1:1 means this IP has exactly one confirmed FQDN AND that FQDN has
        # exactly one confirmed IP. Any one-to-many on either side -> multi.
        if len(by_ip[v.ip]) == 1 and len(by_fqdn[v.fqdn]) == 1:
            one_to_one.append(v)
        else:
            multi.append(v)

    return ResolveResult(confirmed_1to1=sorted(one_to_one, key=lambda p: (p.ip, p.fqdn)),
                         confirmed_multi=sorted(multi, key=lambda p: (p.ip, p.fqdn)),
                         unconfirmed=sorted(unconfirmed, key=lambda p: (p.ip, p.fqdn)))


def write_pairs_json(result: ResolveResult, outdir: Path) -> Path:
    """Persist the full derivation for the report tab + audit trail."""
    out = Path(outdir) / "fqdn_pairs.json"
    payload = {
        "confirmed_1to1": [asdict(p) for p in result.confirmed_1to1],
        "confirmed_multi": [asdict(p) for p in result.confirmed_multi],
        "unconfirmed": [asdict(p) for p in result.unconfirmed],
        "summary": {
            "part1_fqdns": result.part1_fqdns(),   # full scan
            "part2_fqdns": result.part2_fqdns(),   # client-side harvest
        },
    }
    out.write_text(json.dumps(payload, indent=2))
    return out
