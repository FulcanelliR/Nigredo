"""Parse nmap -oX XML output into structured objects, using only the standard
library so the tool has no parsing dependencies beyond nmap itself.
"""
from __future__ import annotations

import defusedxml.ElementTree as ET
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Port:
    portid: int
    protocol: str
    state: str                      # open | closed | filtered | open|filtered | ...
    reason: str = ""
    service: str = ""
    product: str = ""
    version: str = ""
    extrainfo: str = ""
    # richer service-detection fields from -sV
    ostype: str = ""                # OS the service reveals (e.g. "Windows")
    cpe: list[str] = field(default_factory=list)  # e.g. cpe:/a:microsoft:iis:10.0
    tunnel: str = ""                # "ssl" when nmap sees TLS wrapping the service
    method: str = ""               # "probed" | "table" — how service was identified
    conf: str = ""                 # confidence 0-10
    servicefp: str = ""            # service fingerprint (raw)
    hostname: str = ""             # hostname the service presented (cert CN, etc.)
    devicetype: str = ""           # router/switch/printer/etc.
    scripts: dict[str, str] = field(default_factory=dict)


@dataclass
class OSClass:
    vendor: str = ""
    osfamily: str = ""
    osgen: str = ""
    type: str = ""
    accuracy: str = ""


@dataclass
class Host:
    address: str
    hostnames: list[str] = field(default_factory=list)
    status: str = ""
    os_matches: list[str] = field(default_factory=list)
    os_classes: list[OSClass] = field(default_factory=list)
    os_accuracy: str = ""           # accuracy of the top osmatch
    uptime_seconds: str = ""
    distance: str = ""              # network hops
    ports: list[Port] = field(default_factory=list)

    @property
    def open_ports(self) -> list[Port]:
        return [p for p in self.ports if p.state == "open"]

    @property
    def filtered_ports(self) -> list[Port]:
        return [p for p in self.ports if "filtered" in p.state]

    def open_port_spec(self) -> str:
        """Comma-separated list of open TCP ports for feeding back to nmap -p."""
        return ",".join(str(p.portid) for p in self.open_ports if p.protocol == "tcp")


def parse(xml_path: str | Path) -> list[Host]:
    tree = ET.parse(xml_path)
    root = tree.getroot()
    hosts: list[Host] = []

    for host_el in root.findall("host"):
        status_el = host_el.find("status")
        status = status_el.get("state", "") if status_el is not None else ""

        # prefer the IPv4/IPv6 address; fall back to any addr
        address = ""
        for addr_el in host_el.findall("address"):
            if addr_el.get("addrtype") in ("ipv4", "ipv6"):
                address = addr_el.get("addr", "")
                break
        if not address:
            a = host_el.find("address")
            address = a.get("addr", "") if a is not None else ""

        hostnames = [
            hn.get("name", "")
            for hn in host_el.findall("hostnames/hostname")
            if hn.get("name")
        ]

        os_matches = [
            om.get("name", "")
            for om in host_el.findall("os/osmatch")
            if om.get("name")
        ]

        # richer OS data: accuracy of top match, osclass breakdown
        os_accuracy = ""
        first_match = host_el.find("os/osmatch")
        if first_match is not None:
            os_accuracy = first_match.get("accuracy", "")
        os_classes = []
        for oc in host_el.findall("os/osmatch/osclass"):
            os_classes.append(OSClass(
                vendor=oc.get("vendor", ""),
                osfamily=oc.get("osfamily", ""),
                osgen=oc.get("osgen", ""),
                type=oc.get("type", ""),
                accuracy=oc.get("accuracy", ""),
            ))
        # also catch osclass directly under <os> (some nmap versions)
        for oc in host_el.findall("os/osclass"):
            os_classes.append(OSClass(
                vendor=oc.get("vendor", ""),
                osfamily=oc.get("osfamily", ""),
                osgen=oc.get("osgen", ""),
                type=oc.get("type", ""),
                accuracy=oc.get("accuracy", ""),
            ))

        uptime_el = host_el.find("uptime")
        uptime_seconds = uptime_el.get("seconds", "") if uptime_el is not None else ""
        distance_el = host_el.find("distance")
        distance = distance_el.get("value", "") if distance_el is not None else ""

        host = Host(address=address, hostnames=hostnames, status=status,
                    os_matches=os_matches, os_classes=os_classes,
                    os_accuracy=os_accuracy, uptime_seconds=uptime_seconds,
                    distance=distance)

        for port_el in host_el.findall("ports/port"):
            state_el = port_el.find("state")
            service_el = port_el.find("service")
            port = Port(
                portid=int(port_el.get("portid", "0")),
                protocol=port_el.get("protocol", "tcp"),
                state=state_el.get("state", "") if state_el is not None else "",
                reason=state_el.get("reason", "") if state_el is not None else "",
            )
            if service_el is not None:
                port.service = service_el.get("name", "")
                port.product = service_el.get("product", "")
                port.version = service_el.get("version", "")
                port.extrainfo = service_el.get("extrainfo", "")
                port.ostype = service_el.get("ostype", "")
                port.tunnel = service_el.get("tunnel", "")
                port.method = service_el.get("method", "")
                port.conf = service_el.get("conf", "")
                port.servicefp = service_el.get("servicefp", "")
                port.hostname = service_el.get("hostname", "")
                port.devicetype = service_el.get("devicetype", "")
                # CPEs: one service can carry several <cpe> children
                port.cpe = [c.text for c in service_el.findall("cpe") if c.text]
            for script_el in port_el.findall("script"):
                sid = script_el.get("id", "")
                out = script_el.get("output", "")
                if sid:
                    port.scripts[sid] = out
            host.ports.append(port)

        hosts.append(host)

    return hosts
