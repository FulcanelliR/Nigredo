"""Web discovery expansion: httpx, katana, gau + a deduplicated URL pool.

These three ProjectDiscovery-family / passive tools expand the set of URLs the
list-consuming scanners (nuclei, the 403 collection) work from, so those tools
become more thorough without changing how the brute-forcers (ffuf/feroxbuster)
operate.

  httpx   - fast HTTP prober + tech/CDN fingerprinting over the live hosts.
            Complements probe.py (stdlib liveness + server/title); httpx adds
            deeper tech detection, CDN detection, and bulk speed.
  katana  - fast crawler that DISCOVERS urls to feed downstream tools. Runs
            shallow/fast (FunnelWeb is the deep JS crawler, runs last).
  gau     - passive historical URL mining (Wayback, Common Crawl, OTX, URLScan).
            Key-free by default; optional keys can raise rate limits later.

URL POOL: katana + gau (+ the existing web_urls seeds) are merged and
DEDUPLICATED BY PATH (query string dropped) with static assets removed, so we
scan unique end directories/endpoints once — not the same directory many times
because of all the items on it. The clean pool feeds nuclei and the 403 pool.

Each tool's RAW output is preserved on disk (and gets its own report tab).
All three are optional Go tools — each skips gracefully if not installed.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from urllib.parse import urlparse


# static-asset extensions we drop from the discovery pool (we want end
# directories/endpoints, not every image/font/style on a page)
STATIC_ASSET_EXTS = {
    ".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".ico", ".bmp", ".tiff",
    ".css", ".js", ".map", ".woff", ".woff2", ".ttf", ".eot", ".otf",
    ".mp4", ".webm", ".avi", ".mov", ".mp3", ".wav", ".ogg",
    ".pdf", ".zip", ".gz", ".tar", ".rar", ".7z",
    ".class", ".swf",
}


def _proxy_for_go_tools(proxy: str) -> str:
    """Normalize a proxy URL for the ProjectDiscovery/Go tools (httpx, katana,
    gau). These reject an https:// SCHEME proxy ("unsupported proxy scheme:
    https"). A forwarding proxy that intercepts HTTPS (Burp, ZAP, mitmproxy) is
    still addressed as http://host:port — the scheme describes how you REACH the
    proxy, not what it forwards. So downgrade https->http; leave http/socks alone."""
    if proxy and proxy.lower().startswith("https://"):
        return "http://" + proxy[len("https://"):]
    return proxy


def _find_pd_httpx() -> str:
    """Locate ProjectDiscovery's httpx (the Go binary), NOT the Python httpx
    library's CLI which is also named 'httpx' but uses a different interface
    (no -l flag). We verify by checking the help output for PD-specific flags.

    Prefers common Go install locations, then anything on PATH that verifies as
    the PD tool. Returns '' if only the Python httpx (or nothing) is found."""
    import os
    candidates = []
    # explicit Go bin locations first (most reliable)
    for base in (os.path.expanduser("~/go/bin"), "/root/go/bin",
                 "/usr/local/bin", "/usr/bin"):
        p = os.path.join(base, "httpx")
        if os.path.isfile(p):
            candidates.append(p)
    # then whatever is on PATH
    which = shutil.which("httpx")
    if which and which not in candidates:
        candidates.append(which)

    for c in candidates:
        try:
            # PD httpx supports -version and prints "projectdiscovery"; the Python
            # httpx CLI does not have -version and errors differently.
            res = subprocess.run([c, "-version"], capture_output=True, text=True, errors="replace",
                                 timeout=10)
            blob = (res.stdout + res.stderr).lower()
            if "projectdiscovery" in blob or "httpx version" in blob:
                return c
            # some builds print just a version string to stderr with -version;
            # fall back to checking help for the -l flag (PD has it, Python doesn't)
            res2 = subprocess.run([c, "-h"], capture_output=True, text=True, errors="replace",
                                  timeout=10)
            if "-l," in (res2.stdout + res2.stderr) or "-list" in (res2.stdout + res2.stderr):
                return c
        except (OSError, subprocess.TimeoutExpired):
            continue
    return ""


def _has_static_ext(path: str) -> bool:
    p = path.lower()
    dot = p.rfind(".")
    if dot == -1:
        return False
    # take the extension, guard against querystring leftovers
    ext = p[dot:]
    return ext in STATIC_ASSET_EXTS


def path_key(url: str) -> str:
    """Canonical dedup key: scheme://host/path with the QUERY STRING DROPPED,
    so /blog/?p=1 /blog/?p=2 ... collapse to one /blog/ entry."""
    try:
        p = urlparse(url.strip())
        host = p.netloc.lower()
        path = p.path or "/"
        return f"{p.scheme.lower()}://{host}{path}"
    except Exception:  # noqa: BLE001
        return url.strip()


def dedup_urls(urls, drop_static: bool = True) -> list[str]:
    """Dedup a URL iterable by path (drop query), optionally removing static
    assets. Returns unique end-directory/endpoint URLs, order preserved."""
    seen = set()
    out = []
    for u in urls:
        u = (u or "").strip()
        if not u:
            continue
        try:
            path = urlparse(u).path or "/"
        except Exception:  # noqa: BLE001
            path = u
        if drop_static and _has_static_ext(path):
            continue
        key = path_key(u)
        if key in seen:
            continue
        seen.add(key)
        out.append(key)     # store the canonical path-key form (query dropped)
    return out


# ----------------------------- httpx -----------------------------

def _save_tool_targets(outdir, tool, path):
    try:
        from . import audit as _a
        from pathlib import Path as _P
        f = _P(path)
        if f.exists():
            _a.save_targets(outdir, tool, f.read_text(errors="replace").splitlines())
    except Exception:
        pass


def run_httpx(web_file: Path, outdir: Path, command_log: Path,
              proxy: str = "", dry_run: bool = False) -> Path | None:
    """Probe/fingerprint live hosts with httpx. Writes raw JSONL to
    httpx_output.jsonl. Returns that path, or None if skipped."""
    _save_tool_targets(outdir, "httpx", web_file)
    script = _find_pd_httpx()
    if not script:
        if shutil.which("httpx"):
            print("[httpx] the 'httpx' on PATH is the Python library CLI, NOT "
                  "ProjectDiscovery httpx. Install the Go tool: go install "
                  "github.com/projectdiscovery/httpx/cmd/httpx@latest "
                  "(and ensure ~/go/bin precedes the python bin on PATH)")
        else:
            print("[httpx] not installed — skipping "
                  "(go install github.com/projectdiscovery/httpx/cmd/httpx@latest)")
        return None
    if not Path(web_file).is_file():
        return None
    out_jsonl = Path(outdir) / "httpx_output.jsonl"
    cmd = [script, "-l", str(web_file), "-json", "-o", str(out_jsonl),
           "-title", "-tech-detect", "-status-code", "-web-server",
           "-cdn", "-silent", "-no-color"]
    if proxy:
        cmd += ["-http-proxy", _proxy_for_go_tools(proxy)]
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + "\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd))
        return None
    print(f"[httpx] fingerprinting live hosts from {Path(web_file).name}")
    try:
        # capture so httpx's per-host output doesn't flood the terminal
        # (results go to the JSONL -o file); surface a count
        subprocess.run(cmd, capture_output=True, text=True, errors="replace", check=False)
    except OSError as e:
        print(f"[httpx] failed: {e}")
        return None
    if out_jsonl.is_file():
        try:
            n = sum(1 for _ in open(out_jsonl))
        except OSError:
            n = 0
        print(f"[httpx] fingerprinted {n} host(s) -> {out_jsonl.name}")
        return out_jsonl
    return None


def parse_httpx(jsonl_path: Path) -> list[dict]:
    """Parse httpx JSONL into rows: url, status, title, webserver, tech, cdn."""
    rows = []
    p = Path(jsonl_path)
    if not p.is_file():
        return rows
    for line in p.read_text(errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            o = json.loads(line)
        except json.JSONDecodeError:
            continue
        tech = o.get("tech") or o.get("technologies") or []
        if isinstance(tech, list):
            tech = ", ".join(str(t) for t in tech)
        rows.append({
            "url": o.get("url", "") or o.get("input", ""),
            "status": o.get("status_code", o.get("status-code", "")),
            "title": o.get("title", ""),
            "webserver": o.get("webserver", o.get("web-server", "")),
            "tech": tech,
            "cdn": o.get("cdn_name", o.get("cdn", "")),
        })
    return rows


# ----------------------------- katana -----------------------------

def run_katana(web_file: Path, outdir: Path, command_log: Path,
               proxy: str = "", depth: int = 2, dry_run: bool = False) -> Path | None:
    """Fast crawl to discover URLs (shallow — FunnelWeb does the deep JS crawl).
    Writes raw URLs to katana_output.txt. Returns that path, or None."""
    _save_tool_targets(outdir, "katana", web_file)
    script = shutil.which("katana")
    if not script:
        print("[katana] not installed — skipping "
              "(go install github.com/projectdiscovery/katana/cmd/katana@latest)")
        return None
    if not Path(web_file).is_file():
        return None
    out_txt = Path(outdir) / "katana_output.txt"
    # -d depth (shallow), -jc pull js-referenced endpoints, -silent quiet.
    # -fs rdn: field-scope = root domain name — keeps the crawl within the
    # target's root domain (and its subdomains), so katana doesn't wander off to
    # third-party sites it finds links to.
    cmd = [script, "-list", str(web_file), "-d", str(depth),
           "-fs", "rdn", "-jc", "-silent", "-o", str(out_txt)]
    if proxy:
        cmd += ["-proxy", _proxy_for_go_tools(proxy)]
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + "\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd))
        return None
    print(f"[katana] crawling to discover URLs (depth {depth})")
    try:
        # capture output so katana's per-URL crawl stream doesn't flood the
        # terminal (results go to the -o file); surface only a count
        subprocess.run(cmd, capture_output=True, text=True, errors="replace", check=False)
    except OSError as e:
        print(f"[katana] failed: {e}")
        return None
    if out_txt.is_file():
        try:
            n = sum(1 for _ in open(out_txt))
        except OSError:
            n = 0
        print(f"[katana] found {n} URL(s) -> {out_txt.name}")
        return out_txt
    return None


# ----------------------------- gau -----------------------------

def run_gau(domains, outdir: Path, command_log: Path,
            proxy: str = "", extra: list | None = None,
            dry_run: bool = False) -> Path | None:
    """Passive historical URL mining via gau (Wayback/CommonCrawl/OTX/URLScan).
    Key-free by default. Writes raw URLs to gau_output.txt. Returns that path.

    `domains` is an iterable of registrable domains/hosts to mine. gau reads
    domains from stdin."""
    script = shutil.which("gau")
    if not script:
        print("[gau] not installed — skipping "
              "(go install github.com/lc/gau/v2/cmd/gau@latest)")
        return None
    domains = [d.strip() for d in domains if d and d.strip()]
    if not domains:
        return None
    out_txt = Path(outdir) / "gau_output.txt"
    # --threads for speed; --subs include subdomains. Key-free by default.
    cmd = [script, "--threads", "5", "--subs", "--o", str(out_txt)]
    if proxy:
        gau_proxy = _proxy_for_go_tools(proxy)
        if gau_proxy != proxy:
            print(f"[gau] adjusted proxy scheme https->http (gau rejects https:// "
                  f"proxies): {gau_proxy}")
        cmd += ["--proxy", gau_proxy]
    if extra:
        cmd += list(extra)
    with open(command_log, "a") as log:
        log.write(f"printf '%s\\n' {' '.join(domains)} | " + " ".join(cmd) + "\n")
    if dry_run:
        print("[dry-run] (stdin domains) ", " ".join(cmd))
        return None
    print(f"[gau] mining historical URLs for {len(domains)} domain(s)")
    try:
        # Capture stdout/stderr so gau's full URL dump doesn't flood the terminal
        # (it already writes results to the --o file). We only surface a count.
        res = subprocess.run(cmd, input="\n".join(domains) + "\n",
                             text=True, errors="replace", capture_output=True, check=False)
    except OSError as e:
        print(f"[gau] failed: {e}")
        return None
    if out_txt.is_file():
        try:
            n = sum(1 for _ in open(out_txt))
        except OSError:
            n = 0
        print(f"[gau] found {n} historical URL(s) -> {out_txt.name}")
        return out_txt
    return None


# --------------------- merge into the URL pool ---------------------

def _read_lines(path) -> list[str]:
    try:
        return [l.strip() for l in Path(path).read_text(errors="replace").splitlines()
                if l.strip()]
    except (OSError, TypeError):
        return []


def run_httpx_liveness(urls_file: Path, outdir: Path, command_log: Path,
                       proxy: str = "", retries: int = 3,
                       dry_run: bool = False) -> "set | None":
    """Run httpx over a URL list purely to check LIVENESS. Returns the set of
    URLs that returned a live response. Used to filter katana/gau discoveries
    (which are unverified) before they reach nuclei — so we don't waste scans on
    dead historical/crawled URLs. Retries guard against transient false-drops.

    (Separate from run_httpx, which fingerprints the known seed hosts.)"""
    script = _find_pd_httpx()
    if not script:
        # PD httpx missing: can't filter, so DON'T drop anything — pass all through
        print("[httpx] ProjectDiscovery httpx not found — skipping liveness filter "
              "(katana/gau URLs pass through unverified)")
        return None
    urls_file = Path(urls_file)
    if not urls_file.is_file() or urls_file.stat().st_size == 0:
        return set()
    live_out = Path(outdir) / "httpx_liveness.txt"
    # -silent + plain URL output; -retries guards transient errors; we only want
    # the list of live URLs here (not full fingerprint json).
    cmd = [script, "-l", str(urls_file), "-silent", "-no-color",
           "-retries", str(retries), "-o", str(live_out)]
    if proxy:
        cmd += ["-http-proxy", _proxy_for_go_tools(proxy)]
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + "   # liveness filter\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd))
        return None
    print(f"[httpx] liveness-filtering {urls_file.name} (retries {retries})")
    try:
        # capture so httpx's per-URL output doesn't flood the terminal
        subprocess.run(cmd, capture_output=True, text=True, errors="replace", check=False)
    except OSError as e:
        print(f"[httpx] liveness filter failed: {e} — passing URLs through unfiltered")
        return None
    if not live_out.is_file():
        return set()
    live = {l.strip() for l in live_out.read_text(errors="replace").splitlines()
            if l.strip()}
    print(f"[httpx] {len(live)} live URL(s) after liveness filter")
    return live


def resolution_filter(pool_file: Path, command_log=None) -> Path:
    """DNS-resolution pre-filter for the takeover pool.

    Drops NXDOMAIN ghosts (hosts that no longer resolve at all — the stale gau/
    katana historical hosts that flooded nuclei with ~100% connection errors and
    0 findings). KEEPS anything that resolves, INCLUDING dangling CNAMEs — because
    a resolving-but-dangling host is exactly a subdomain-takeover candidate, which
    is what the takeover pass exists to find.

    Cheap: one DNS lookup per unique host (seconds), vs. nuclei running its full
    template battery against dead hosts (the expensive waste). Writes a filtered
    pool next to the original and returns its path. Fail-open: if resolution can't
    run, returns the original pool unfiltered (better to scan a few dead hosts than
    drop live ones)."""
    import socket
    from urllib.parse import urlparse
    try:
        urls = _read_lines(pool_file)
    except Exception:
        return Path(pool_file)
    if not urls:
        return Path(pool_file)

    # group URLs by host so we resolve each host once
    host_urls: dict[str, list[str]] = {}
    for u in urls:
        try:
            host = urlparse(u if "://" in u else f"http://{u}").hostname or ""
        except Exception:
            host = ""
        host_urls.setdefault(host.lower(), []).append(u)

    resolved_cache: dict[str, bool] = {}

    def _resolves(host: str) -> bool:
        if not host:
            return True  # can't parse a host -> keep (fail-open)
        ok = False
        # prefer dig (catches CNAME chains / dangling that still resolve); fall
        # back to socket. Any answer at all = keep.
        try:
            if shutil.which("dig"):
                out = subprocess.run(["dig", "+short", host],
                                     capture_output=True, text=True, errors="replace", timeout=8)
                ok = bool(out.stdout.strip())
            else:
                socket.gethostbyname(host)
                ok = True
        except Exception:
            try:
                socket.gethostbyname(host)
                ok = True
            except Exception:
                ok = False
        return ok

    # Resolve hosts CONCURRENTLY — serial 8s-timeout lookups over a big takeover
    # pool (144 hosts) could take ~19 min worst case. A thread pool turns that
    # into ~seconds. DNS/subprocess lookups are I/O-bound, so threads are ideal.
    from concurrent.futures import ThreadPoolExecutor
    unique_hosts = list(host_urls.keys())
    workers = min(20, max(1, len(unique_hosts)))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        results = list(ex.map(_resolves, unique_hosts))
    for host, ok in zip(unique_hosts, results):
        resolved_cache[host] = ok

    kept, dropped = [], 0
    for host, group in host_urls.items():
        if resolved_cache.get(host, True):
            kept.extend(group)
        else:
            dropped += len(group)

    if command_log:
        try:
            with open(command_log, "a") as log:
                log.write(f"# takeover resolution-filter: kept {len(kept)}, "
                          f"dropped {dropped} NXDOMAIN\n")
        except OSError:
            pass

    out_file = Path(pool_file).parent / "web_urls_takeover_resolved.txt"
    Path(out_file).write_text("\n".join(kept) + ("\n" if kept else ""))
    print(f"[takeover] DNS-resolution filter: {len(urls)} -> {len(kept)} "
          f"resolving hosts' URLs (dropped {dropped} NXDOMAIN ghosts; "
          f"dangling CNAMEs kept as takeover candidates)")
    return Path(out_file)


def build_url_pool(seed_file: Path, katana_out=None, gau_out=None,
                   pool_file: Path | None = None, live_urls: set | None = None) -> Path:
    """Merge the seed web_urls with katana + gau discoveries, dedup by path,
    drop static assets. Writes the clean pool and returns its path. This is what
    nuclei consumes.

    Seeds are already liveness-verified by probe.py, so they always pass through.
    If `live_urls` is provided (from httpx liveness filter), katana/gau URLs are
    kept ONLY if their live form is in that set — so nuclei scans a fully-live
    pool. If `live_urls` is None (httpx missing/failed), katana/gau pass through
    unfiltered (fail-open: better to scan a few dead URLs than drop live ones)."""
    seeds = _read_lines(seed_file)
    katana = _read_lines(katana_out) if katana_out else []
    gau = _read_lines(gau_out) if gau_out else []

    # seeds always kept (probe-verified). katana/gau filtered by liveness if we
    # have the live set.
    discovered = katana + gau
    if live_urls is not None:
        live_keys = {path_key(u) for u in live_urls}
        before = len(discovered)
        discovered = [u for u in discovered if path_key(u) in live_keys
                      or u.strip() in live_urls]
        print(f"[httpx] liveness filter: {before} -> {len(discovered)} live "
              f"katana/gau URLs")

    merged = dedup_urls(list(seeds) + discovered, drop_static=True)
    if pool_file is None:
        pool_file = Path(seed_file).parent / "web_urls_expanded.txt"
    Path(pool_file).write_text("\n".join(merged) + ("\n" if merged else ""))
    print(f"[url-pool] {len(seeds)} seed + {len(katana)} katana + {len(gau)} gau "
          f"-> {len(merged)} unique (deduped by path, static dropped"
          + (", liveness-filtered)" if live_urls is not None else ")"))
    return Path(pool_file)
