"""submutate.py — target-specific subdomain mutation (a scoped-safe steal of
BBOT's word-cloud + DNSMutator idea).

The insight: the best words to brute-force are the ones the TARGET already uses.
After the normal enumeration sources finish, we:

  1. Build a WORD CLOUD from the confirmed in-scope subdomains — tokenize their
     labels into words + tally frequency, so we learn this org's naming
     vocabulary (its abbreviations, its numbering, its conventions).
  2. Generate MUTATIONS by recombining those words in the separator/affix styles
     the target actually uses (word-test, word1, www-word, ...).
  3. Resolve the candidates against ONLY the in-scope domain via the same
     shuffledns|dnsx path, one bounded pass — NO recursion, NO scope spread.
     Every candidate is `<mutation>.<in-scope-domain>`, so we never leave scope.

This is enumeration of in-scope names only. Whether the discovered hosts get
scanned/tested is a separate, already-gated decision elsewhere in the pipeline.

Tokenization: a dependency-free regex splitter handles delimited/numbered names
(the majority). If the optional `wordsegment` package is present, it ALSO cracks
glued no-delimiter names (prodapivpn -> prod api vpn) — the ~20% the regex
misses. Degrades gracefully when wordsegment isn't installed.
"""
from __future__ import annotations

import re
import shlex
import subprocess
import shutil
from collections import Counter
from pathlib import Path

# optional glued-name splitter (see install notes). Pure-python, zero deps.
try:
    import wordsegment as _ws
    _ws.load()                      # one-time load of the bundled corpus
    _HAS_WORDSEG = True
except Exception:                   # noqa: BLE001 (not installed / load failed)
    _HAS_WORDSEG = False


# tokens we consider "words" once split; drop pure-noise fragments
_TOKEN_RE = re.compile(r"[a-z]+|\d+")
# numeric affixes the target might use (learned + a few sane defaults)
_DEFAULT_NUMS = ["1", "2", "01", "02", "3", "0"]
# common infra affixes as a light seed (kept small; the target's own words
# dominate). These are NOT a static brute list — they only combine WITH the
# target's learned vocabulary.
_SEED_AFFIXES = ["dev", "test", "staging", "stage", "prod", "qa", "uat", "admin",
                 "api", "vpn", "portal", "internal", "int", "corp", "new", "old"]


def _split_label(label: str) -> list[str]:
    """Tokenize a single DNS label into component words.
    Regex core: split on non-alnum, then separate letter-runs from digit-runs.
    If wordsegment is available, additionally crack glued letter-runs."""
    label = label.lower().strip()
    if not label:
        return []
    words: list[str] = []
    for chunk in re.split(r"[^a-z0-9]+", label):
        if not chunk:
            continue
        for tok in _TOKEN_RE.findall(chunk):
            if tok.isdigit():
                words.append(tok)
                continue
            # letter run: try to crack glued words if we have wordsegment AND
            # the run is long enough to plausibly be multiple words
            if _HAS_WORDSEG and len(tok) > 6:
                try:
                    parts = _ws.segment(tok)
                    # only accept the split if it actually breaks into >1 real
                    # word (avoid over-splitting short/odd tokens)
                    if len(parts) > 1 and all(len(p) > 1 for p in parts):
                        words.extend(parts)
                        continue
                except Exception:  # noqa: BLE001
                    pass
            words.append(tok)
    return words


def build_word_cloud(subdomains: list[str], base_domain: str) -> Counter:
    """Tally the target's vocabulary from its confirmed subdomains. Strips the
    base domain so we only learn the LABEL words (the interesting part)."""
    base = base_domain.lower().strip(".")
    cloud: Counter = Counter()
    for sub in subdomains:
        s = sub.lower().strip().rstrip(".")
        # remove the base domain suffix to isolate the label portion
        if s.endswith("." + base):
            s = s[: -(len(base) + 1)]
        elif s == base:
            continue
        for word in _split_label(s):
            # skip pure numbers as standalone cloud words (kept as affixes), and
            # skip 1-char noise
            if word.isdigit() or len(word) < 2:
                continue
            cloud[word] += 1
    return cloud


def generate_mutations(cloud: Counter, base_domain: str,
                       max_words: int = 40, max_candidates: int = 5000) -> list[str]:
    """Recombine the target's words into candidate subdomains, in the affix
    styles BBOT-style mutators use: word-affix, wordaffix, affix-word, word+num.

    Bounded: takes the top `max_words` most-common target words, combines them
    with each other + seed affixes + numeric suffixes, and caps the total at
    `max_candidates` so the resolve pass stays sane. Returns FQDNs
    (<mutation>.<base_domain>), deduped."""
    base = base_domain.lower().strip(".")
    top_words = [w for w, _ in cloud.most_common(max_words)]
    # the affix pool = the target's own top words + a small infra seed
    affixes = list(dict.fromkeys(top_words + _SEED_AFFIXES))

    seps = ["", "-"]           # the two separator styles seen in real subdomains
    candidates: set[str] = set()

    def _add(label: str):
        label = label.strip("-").lower()
        if label and re.fullmatch(r"[a-z0-9-]{1,63}", label):
            candidates.add(f"{label}.{base}")

    for word in top_words:
        # word + numeric suffix (learned "they number things")
        for num in _DEFAULT_NUMS:
            _add(f"{word}{num}")
        # word (+sep+) affix   and   affix (+sep+) word
        for aff in affixes:
            if aff == word:
                continue
            for sep in seps:
                _add(f"{word}{sep}{aff}")
                _add(f"{aff}{sep}{word}")
        if len(candidates) >= max_candidates:
            break

    # also mutate the bare top words themselves (in case they aren't live yet)
    for word in top_words:
        _add(word)

    out = sorted(candidates)
    if len(out) > max_candidates:
        out = out[:max_candidates]
    return out


def resolve_candidates(candidates: list[str], resolvers: str, outdir: Path,
                       command_log: Path, base_domain: str,
                       dnsx_threads: int = 25, dnsx_retries: int = 3,
                       shuffledns_threads: int = 1000,
                       dry_run: bool = False) -> list[str]:
    """Resolve the mutation candidates via shuffledns|dnsx and return the live
    ones. In-scope by construction (all candidates are <x>.<base_domain>)."""
    if not candidates:
        return []
    safe = base_domain.replace("/", "_")
    cand_file = outdir / f"mutations_{safe}.candidates.txt"
    cand_file.write_text("\n".join(candidates) + "\n")
    live_out = outdir / f"mutations_{safe}.resolved.txt"

    shuffledns = shutil.which("shuffledns")
    dnsx = shutil.which("dnsx")
    if not dnsx:
        print("[submutate] dnsx not found — skipping mutation resolve")
        return []

    # Prefer shuffledns (mass resolve) -> dnsx (A/CNAME confirm), mirroring the
    # main subdomain path. Fall back to dnsx alone if shuffledns is absent.
    # shlex.quote() every scope-derived / user-influenced value that reaches the
    # shell. base_domain and resolvers come from config/scope; cand_file is derived
    # from base_domain so it inherits the taint. Thread/retry counts are ints and
    # are not shell-injectable, so they stay bare.
    q_cand_file = shlex.quote(str(cand_file))
    q_base_domain = shlex.quote(base_domain)
    q_resolvers = shlex.quote(str(resolvers)) if resolvers else ""
    if shuffledns and resolvers:
        pipeline = (f"cat {q_cand_file} | shuffledns -d {q_base_domain} -r {q_resolvers} "
                    f"-mode resolve -t {shuffledns_threads} "
                    f"| dnsx -a -cname -resp -t {dnsx_threads} -retry {dnsx_retries}")
    else:
        pipeline = (f"cat {q_cand_file} | dnsx -a -cname -resp -t {dnsx_threads} "
                    f"-retry {dnsx_retries}")

    with open(command_log, "a") as log:
        log.write(pipeline + f"  > {live_out}   # subdomain mutations\n")
    if dry_run:
        print("[dry-run]", pipeline)
        return []

    print(f"[submutate] resolving {len(candidates)} mutation candidate(s) "
          f"(in-scope: *.{base_domain})")
    try:
        with open(live_out, "w") as out:
            subprocess.run(pipeline, shell=True, stdout=out, check=False)
    except OSError as e:
        print(f"[submutate] resolve failed: {e}")
        return []

    # extract the resolved hostnames (dnsx -resp lines start with the host)
    live = []
    if live_out.is_file():
        for line in live_out.read_text(errors="replace").splitlines():
            host = line.strip().split(" ")[0].split("[")[0].strip()
            if host.endswith("." + base_domain) or host == base_domain:
                live.append(host.lower())
    live = sorted(set(live))
    print(f"[submutate] {len(live)} live mutation hit(s)")
    return live


def validate_and_merge(new_hits: list[str], domain: str, outdir: Path,
                       command_log: Path, proxy: str = "",
                       httpx_retries: int = 3, dry_run: bool = False) -> dict:
    """Option A: service-validate the DNS-resolved mutation hits with httpx, then
    merge them into the subdomain INVENTORY (subdomains_<domain>.clean.csv) as
    first-class subdomains — but DELIBERATELY NOT into web_urls, so they do NOT
    get auto-fed to the active scanners (nuclei/ffuf/feroxbuster). Scanning the
    mutation hits stays a separate, conscious decision.

    Returns {'dns': [...], 'live': [...]} — DNS-resolved hits and the subset
    httpx confirmed serving.
    """
    result = {"dns": list(new_hits), "live": []}
    if not new_hits:
        return result
    safe = domain.replace("/", "_")

    # ---- httpx SERVICE validation (are they actually serving?) ----
    httpx_bin = shutil.which("httpx")
    live_hosts: list[str] = []
    if httpx_bin and not dry_run:
        cand_urls = outdir / f"mutations_{safe}.httpx_in.txt"
        # probe both schemes; httpx will report whichever answers
        cand_urls.write_text("\n".join(new_hits) + "\n")
        httpx_out = outdir / f"mutations_{safe}.httpx.txt"
        cmd = [httpx_bin, "-l", str(cand_urls), "-silent", "-no-color",
               "-retries", str(httpx_retries), "-o", str(httpx_out)]
        if proxy:
            cmd += ["-http-proxy", proxy]
        with open(command_log, "a") as log:
            log.write(" ".join(cmd) + "   # mutation service-validation\n")
        print(f"[submutate] httpx-validating {len(new_hits)} mutation hit(s)")
        try:
            subprocess.run(cmd, check=False)
            if httpx_out.is_file():
                for line in httpx_out.read_text(errors="replace").splitlines():
                    host = (line.strip().split("//")[-1].split("/")[0]
                            .split(":")[0].lower())
                    if host.endswith("." + domain) or host == domain:
                        live_hosts.append(host)
        except OSError as e:
            print(f"[submutate] httpx validation failed: {e}")
    elif not httpx_bin:
        print("[submutate] httpx not installed — mutation hits merged as "
              "DNS-resolved only (no service validation)")

    live_hosts = sorted(set(live_hosts))
    result["live"] = live_hosts

    if dry_run:
        return result

    # ---- merge into the subdomain INVENTORY (not web_urls) ----
    clean_csv = outdir / f"subdomains_{safe}.clean.csv"
    existing = set()
    if clean_csv.is_file():
        import csv as _csv
        with open(clean_csv, newline="", encoding="utf-8", errors="replace") as f:
            r = _csv.reader(f)
            next(r, None)
            for row in r:
                if row:
                    existing.add(row[0].strip().lower())
    live_set = set(live_hosts)
    to_add = [h for h in new_hits if h.lower() not in existing]
    if to_add:
        import csv as _csv
        with open(clean_csv, "a", newline="", encoding="utf-8") as f:
            w = _csv.writer(f)
            for h in to_add:
                # mark origin + whether httpx confirmed it serving. Type column
                # notes it's a mutation so it's traceable in the inventory.
                note = "mutation+httpx" if h.lower() in live_set else "mutation"
                w.writerow([h, note, ""])
        print(f"[submutate] merged {len(to_add)} mutation hit(s) into the "
              f"subdomain inventory ({len(live_hosts)} httpx-confirmed live). "
              f"NOT added to the active-scan pool.")
    return result


def process_domain(domain: str, outdir: Path, command_log: Path,
                   resolvers: str = "", max_words: int = 40,
                   max_candidates: int = 5000, proxy: str = "",
                   dry_run: bool = False) -> list[str]:
    """Full mutation pass for one domain: read the confirmed subdomains, build
    the word cloud, generate mutations, resolve in-scope, service-validate with
    httpx, and merge into the subdomain inventory (NOT the active-scan pool).
    Returns the list of newly-discovered live subdomains (may be empty)."""
    safe = domain.replace("/", "_")
    clean_csv = outdir / f"subdomains_{safe}.clean.csv"
    if not clean_csv.is_file():
        print(f"[submutate] no subdomains file for {domain} — skipping mutations")
        return []

    # read confirmed subdomains (first column of the cleaned CSV)
    subs = []
    import csv as _csv
    with open(clean_csv, newline="", encoding="utf-8", errors="replace") as f:
        reader = _csv.reader(f)
        next(reader, None)   # header
        for row in reader:
            if row and row[0].strip():
                subs.append(row[0].strip())
    if not subs:
        print(f"[submutate] {domain}: no subdomains to learn from")
        return []

    cloud = build_word_cloud(subs, domain)
    if not cloud:
        print(f"[submutate] {domain}: empty word cloud")
        return []
    top = ", ".join(w for w, _ in cloud.most_common(8))
    print(f"[submutate] {domain}: learned {len(cloud)} words "
          f"(top: {top}){' [wordsegment on]' if _HAS_WORDSEG else ''}")

    candidates = generate_mutations(cloud, domain, max_words=max_words,
                                    max_candidates=max_candidates)
    live = resolve_candidates(candidates, resolvers, outdir, command_log,
                              domain, dry_run=dry_run)

    # new unique hits (subdomains not already known)
    known = {s.lower() for s in subs}
    new_hits = sorted(h for h in live if h not in known)
    if new_hits:
        (outdir / f"mutations_{safe}.new.txt").write_text("\n".join(new_hits) + "\n")
        print(f"[submutate] {domain}: {len(new_hits)} NEW subdomain(s) via mutation")
        # Option A: httpx service-validate + merge into inventory (not web_urls)
        validate_and_merge(new_hits, domain, outdir, command_log,
                           proxy=proxy, dry_run=dry_run)
    return new_hits
