#!/usr/bin/env python3
"""Phase 2 — Email enumeration (LinkedIn via SerpAPI).

Enumerates employee names from LinkedIn and turns them into candidate emails:

  1. Every result URL is saved (one CSV row per URL), so the operator can audit.
  2. The business name is prompted for explicitly (kept separate from the domain
     argument so the two can't be conflated).
  3. Name/format handling routes URLs into categories instead of silently
     dropping the messy ones:
       - clean           : first-last
       - initial_trunc   : first-l (single-letter last)
       - credential      : first-l-md / first-last-phd ... (trailing credential)
       - rejected        : any slug whose name tokens contain a digit, or that
                           otherwise can't be turned into a clean first/last.
     Any token containing a digit means the name can't be cleanly formed -> the
     entry is rejected (URL saved with a reason) rather than guessed.

  4. One CSV holds every URL tagged by category, the parsed first/last, the
     attempted email (blank when rejected), and a reason.

This is discovery only: it generates candidate addresses from public LinkedIn
result titles/URLs. It does NOT send mail or test credentials.
"""
from __future__ import annotations

import csv
import re
import time
import unicodedata
from dataclasses import dataclass
from pathlib import Path

try:
    from serpapi import search as serp_search
except Exception:
    serp_search = None


# ---- name-token vocabulary ----
HONORIFICS = {"mr", "mrs", "ms", "miss", "mx", "dr", "prof", "sir", "madam", "dame"}
CREDENTIALS = {
    "jr", "sr", "ii", "iii", "iv", "v", "md", "phd", "dds", "dvm", "esq", "mba",
    "pe", "rn", "cpa", "do", "jd", "pmp", "msn", "np", "pa", "edd", "psyd",
}
PARTICLES = {"da", "de", "del", "della", "der", "di", "du", "la", "le", "los",
             "las", "van", "von", "st", "san", "santa"}


def strip_accents(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFKD", s)
                   if not unicodedata.combining(c))


def normalize_for_email(s: str) -> str:
    s = strip_accents(s).lower()
    for ch in (" ", "'", "-", "."):
        s = s.replace(ch, "")
    return re.sub(r"[^a-z0-9]", "", s)


def render_email(fmt: str, first: str, last: str, email_domain: str) -> str:
    f, l = normalize_for_email(first), normalize_for_email(last)
    mapping = {"first": f, "last": l, "f": f[:1], "l": l[:1]}
    out = fmt
    for k, v in mapping.items():
        out = out.replace("{" + k + "}", v)
    if "@" not in out:
        out += "@" + email_domain.strip()
    return out


@dataclass
class EmailRow:
    category: str          # clean | initial_trunc | credential | rejected
    linkedin_url: str
    parsed_first: str = ""
    parsed_last: str = ""
    attempted_email: str = ""
    reason: str = ""


def slug_from_url(url: str) -> str:
    """Extract the <slug> from linkedin.com/in/<slug>."""
    m = re.search(r"linkedin\.com/in/([^/?#]+)", url, re.IGNORECASE)
    return m.group(1) if m else ""


def _has_digit(tok: str) -> bool:
    return any(c.isdigit() for c in tok)


def classify_slug(slug: str) -> tuple[str, str, str, str]:
    """Classify a LinkedIn slug and extract (category, first, last, reason).

    Rules:
      - URL-decode-ish: split on '-'.
      - If ANY name token contains a digit, reject (can't cleanly form a name).
      - Strip a leading honorific and a trailing credential.
      - first-last           -> clean
      - first-l (1-char last) -> initial_trunc
      - first-(l|last)-<cred> -> credential
      - everything else       -> rejected with reason.
    """
    if not slug:
        return ("rejected", "", "", "empty slug")

    raw = slug.lower().strip()
    tokens = [t for t in raw.split("-") if t]
    if not tokens:
        return ("rejected", "", "", "no tokens")

    # LinkedIn appends a disambiguation serial to many slugs, e.g.
    # 'john-smith-4a2b9c' or 'john-smith-1a2'. Strip a TRAILING token that is a
    # serial (contains a digit and isn't a plain name) before the digit check,
    # so these parse cleanly instead of being rejected wholesale. Only the LAST
    # token is treated this way — a digit in a middle token still rejects.
    if len(tokens) > 2 and _has_digit(tokens[-1]):
        # trailing token looks like a serial (has a digit) -> drop it
        tokens = tokens[:-1]

    # Any digit remaining in the (now serial-stripped) name tokens => reject.
    if any(_has_digit(t) for t in tokens):
        return ("rejected", "", "", "slug contains digit(s) / serial")

    # drop leading honorific
    if tokens and tokens[0] in HONORIFICS:
        tokens = tokens[1:]

    # detect & strip a trailing credential token
    credential = ""
    if tokens and tokens[-1] in CREDENTIALS:
        credential = tokens[-1]
        tokens = tokens[:-1]

    if len(tokens) < 2:
        return ("rejected", "", "",
                "insufficient name tokens after cleanup")

    first = tokens[0]
    # attach particles to the last name (e.g. van-der-berg)
    last_tokens = tokens[1:]
    # if leading particles chain before the final token, fold them in
    last = " ".join(last_tokens)

    # single-letter last name => initial-truncated form
    is_initial = (len(last_tokens) == 1 and len(last_tokens[0]) == 1)

    if credential:
        return ("credential", first, last, f"trailing credential '{credential}'")
    if is_initial:
        return ("initial_trunc", first, last, "single-letter last name")
    return ("clean", first, last, "")


def discover_company_url(domain: str, api_key: str, business: str = "",
                         sleep_s: float = 2.0, assume_yes: bool = False) -> str:
    """Auto-discover the LinkedIn COMPANY page URL when it wasn't provided.

    Queries SerpAPI with the DOMAIN (the strong disambiguator) + linkedin.com,
    then filters the results for the linkedin.com/company/<slug> pattern —
    skipping /in/ employee profiles, /jobs/ posts, and aggregators. Rebuilds the
    canonical https://www.linkedin.com/company/<slug>/ and asks the operator to
    CONFIRM before returning it (guards against enumerating the wrong org, which
    would be a scope problem since LinkThief's output drives who gets enumerated).

    Returns the confirmed canonical URL, or "" if none found / declined.
    Only meant to run as a FALLBACK when the URL field is blank."""
    if serp_search is None:
        return ""
    query = f'{domain} linkedin.com'
    if business:
        query = f'{business} {domain} linkedin.com'
    try:
        params = {"engine": "google", "q": query, "api_key": api_key,
                  "start": 0, "num": 10}
        results = serp_search(params)
    except Exception as e:  # noqa: BLE001
        print(f"[LinkThief] company-URL discovery search failed: {e}")
        return ""
    organic = results.get("organic_results", [])
    slug = ""
    for r in organic:
        link = (r.get("link") or "").strip()
        m = re.search(r"linkedin\.com/company/([^/?#]+)", link, re.I)
        if m:
            slug = m.group(1).strip("/")
            break  # first company-pattern hit wins
    if not slug:
        print(f"[LinkThief] no linkedin.com/company/<slug> found for {domain}")
        return ""
    canonical = f"https://www.linkedin.com/company/{slug}/"
    print(f"[LinkThief] discovered LinkedIn company page: {canonical}")
    if not assume_yes:
        try:
            from .runmode import is_unattended
            if is_unattended():
                # headless run: don't hang on input(). Auto-SKIP the discovered
                # URL (safer than auto-accepting the wrong org into enumeration).
                print("[LinkThief] unattended run — discovered company URL "
                      "skipped (no operator to confirm).")
                return ""
        except Exception:  # noqa: BLE001
            pass
        try:
            ans = input(f"  Use this LinkedIn company URL? [Y/n]: ").strip().lower()
        except EOFError:
            ans = "y"
        if ans in ("n", "no"):
            print("[LinkThief] discovered company URL declined.")
            return ""
    return canonical


def linkedin_search(business: str, api_key: str, max_results: int,
                    sleep_s: float) -> list[str]:
    """Return the list of unique linkedin.com/in/ URLs for the business.

    Paces requests to SerpAPI (which proxies Google) and BACKS OFF on 503 /
    rate-limit responses instead of dying. SerpAPI + Google throttle aggressively;
    a fixed fast cadence trips 503s, so each page request is retried with
    exponential backoff before giving up.
    """
    if serp_search is None:
        raise RuntimeError("serpapi not installed")
    query = f'site:linkedin.com/in "{business}"'
    seen: set[str] = set()
    urls: list[str] = []

    def _search_with_backoff(params, max_retries=4):
        """Call serp_search; on 503 / rate-limit / transient error, wait and
        retry with exponential backoff (2s, 4s, 8s, 16s). Returns {} if all
        retries fail, so the caller degrades (stops paging) rather than crashes."""
        delay = 2.0
        for attempt in range(max_retries + 1):
            try:
                res = serp_search(params)
                # SerpAPI returns an 'error' field on throttle/quota problems
                err = (res.get("error") or "") if isinstance(res, dict) else ""
                if err and ("503" in err or "rate" in err.lower()
                            or "too many" in err.lower() or "temporarily" in err.lower()):
                    raise RuntimeError(err)
                return res
            except Exception as e:  # noqa: BLE001
                if attempt >= max_retries:
                    print(f"[LinkThief] SerpAPI still failing after "
                          f"{max_retries} retries ({e}); stopping pagination early")
                    return {}
                print(f"[LinkThief] SerpAPI throttled/error ({e}); "
                      f"backing off {delay:.0f}s (retry {attempt+1}/{max_retries})")
                time.sleep(delay)
                delay *= 2
        return {}

    for start in range(0, max_results, 10):
        print(f"[+] (linkedin) offset {start}")
        params = {"engine": "google", "q": query, "api_key": api_key,
                  "start": start, "num": 10}
        results = _search_with_backoff(params)
        organic = results.get("organic_results", [])
        if not organic:
            break
        for r in organic:
            link = (r.get("link") or "").strip()
            if "linkedin.com/in/" in link and link not in seen:
                seen.add(link)
                urls.append(link)
        time.sleep(sleep_s)
    return urls


def build_rows(urls: list[str], email_format: str,
               email_domain: str) -> list[EmailRow]:
    rows: list[EmailRow] = []
    for url in urls:
        slug = slug_from_url(url)
        category, first, last, reason = classify_slug(slug)
        row = EmailRow(category=category, linkedin_url=url,
                       parsed_first=first, parsed_last=last, reason=reason)
        if category != "rejected" and first and last:
            try:
                row.attempted_email = render_email(email_format, first, last,
                                                   email_domain)
            except Exception as e:
                row.category = "rejected"
                row.reason = f"email render failed: {e}"
        rows.append(row)
    return rows


CSV_COLUMNS = ["category", "linkedin_url", "parsed_first", "parsed_last",
               "attempted_email", "reason"]

# category ordering for the output: clean first, then the altered forms, then rejected
_CAT_ORDER = {"clean": 0, "initial_trunc": 1, "credential": 2, "rejected": 3}


def write_csv(rows: list[EmailRow], csv_path: Path) -> None:
    ordered = sorted(rows, key=lambda r: (_CAT_ORDER.get(r.category, 9),
                                          r.parsed_last, r.parsed_first,
                                          r.linkedin_url))
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CSV_COLUMNS)
        w.writeheader()
        for r in ordered:
            w.writerow({k: getattr(r, k) for k in CSV_COLUMNS})


def process(business: str, email_domain: str, email_format: str,
            api_key: str, outdir, max_results: int = 300,
            sleep_s: float = 2.0):
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    urls = linkedin_search(business, api_key, max_results, sleep_s)
    print(f"[LinkThief] {len(urls)} unique LinkedIn URLs")
    rows = build_rows(urls, email_format, email_domain)
    safe = re.sub(r"[^\w.-]+", "_", business).strip("_") or "business"
    csv_path = outdir / f"linkthief_{safe}.csv"
    write_csv(rows, csv_path)

    counts: dict[str, int] = {}
    for r in rows:
        counts[r.category] = counts.get(r.category, 0) + 1
    print(f"[LinkThief] categories: {counts}")
    print(f"[LinkThief] CSV: {csv_path}")
    return csv_path


def prompt_business(config_default: str = "") -> str:
    from .runmode import is_unattended, answer
    if is_unattended():
        # Prefer the persisted per-client config value; fall back to the stash
        # (single-engagement flow). The config value is what makes the campaign
        # child use the REAL business name instead of an empty stash.
        return (config_default or "").strip() or answer("email_business", "")
    try:
        return input("Business name (exact, as it appears on LinkedIn): ").strip()
    except EOFError:
        return ""


def prompt_email_format(default: str = "{first}.{last}") -> str:
    """Ask the operator for the client's email format. Format changes per client,
    so this is prompted rather than fixed in config. Blank = the default.

    Tokens:  {first} {last} {f} (first initial) {l} (last initial)
    Examples: {f}{last}=jsmith  {first}.{last}=john.smith  {first}=john
              {first}{l}=johns   {f}.{last}=j.smith
    """
    print("\nEmail format for this client. Tokens: {first} {last} {f} {l}")
    print("  examples: {f}{last} -> jsmith   {first}.{last} -> john.smith")
    print(f"  (press Enter for the most common default: {default})")
    from .runmode import is_unattended, answer
    if is_unattended():
        return answer("email_format", default)
    try:
        ans = input("Email format: ").strip()
    except EOFError:
        ans = ""
    return ans or default
