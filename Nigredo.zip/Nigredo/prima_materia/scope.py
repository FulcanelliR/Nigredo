"""Scope guard.

Structurally prevents the pipeline from touching anything outside the authorized
engagement scope. Every target is checked against an allowlist of CIDRs and
hostnames before any nmap process is launched. A target outside scope raises
ScopeViolation and halts the run — this is intentional and must not be caught
and ignored.

The allowlist supports:
  - IPv4/IPv6 addresses              e.g. 203.0.113.10
  - IPv4/IPv6 CIDR ranges            e.g. 203.0.113.0/24
  - exact hostnames                  e.g. app.client.com
  - wildcard hostname suffixes       e.g. *.client.com

Hostnames are NOT resolved to IPs for the scope check (resolution can be
attacker-influenced via DNS). A hostname target is authorized only by hostname
rules; an IP target only by IP/CIDR rules. If you want a hostname authorized by
its IP, put the IP/CIDR in scope explicitly.
"""
from __future__ import annotations

import ipaddress
from pathlib import Path


class ScopeViolation(Exception):
    """Raised when a target is not covered by the authorization allowlist."""


class ScopeGuard:
    def __init__(self) -> None:
        self._networks: list[ipaddress._BaseNetwork] = []
        self._exact_hosts: set[str] = set()
        self._wildcards: list[str] = []   # stored as ".client.com" suffixes

    # ---- loading ----
    @classmethod
    def from_file(cls, path: str | Path) -> "ScopeGuard":
        guard = cls()
        for raw in Path(path).read_text().splitlines():
            line = raw.strip()
            if not line or line.startswith("#"):
                continue
            guard.add_rule(line)
        if not guard._networks and not guard._exact_hosts and not guard._wildcards:
            raise ValueError(f"Scope file {path} contained no usable rules")
        return guard

    def add_rule(self, rule: str) -> None:
        rule = rule.strip().lower()
        if rule.startswith("*."):
            # wildcard suffix: *.client.com -> matches a.client.com, a.b.client.com
            self._wildcards.append(rule[1:])  # store ".client.com"
            return
        try:
            # strict=False so a bare IP or a CIDR both parse
            net = ipaddress.ip_network(rule, strict=False)
            self._networks.append(net)
            return
        except ValueError:
            pass
        # treat as an exact hostname
        self._exact_hosts.add(rule)

    # ---- checking ----
    def _is_ip_in_scope(self, ip: ipaddress._BaseAddress) -> bool:
        return any(ip in net for net in self._networks)

    def _is_host_in_scope(self, host: str) -> bool:
        if host in self._exact_hosts:
            return True
        return any(host.endswith(suffix) for suffix in self._wildcards)

    def check(self, target: str) -> None:
        """Raise ScopeViolation if target is not authorized.

        Handles three target forms:
          - single IP        (1.2.3.4)      -> in scope if inside an authorized net
          - CIDR network     (1.2.3.0/29)   -> in scope if it's a SUBSET of (or
                                               equal to) an authorized network
          - hostname         (app.client.com) -> in scope if it matches a host rule

        Two caller patterns (both intentional):
          - HARD HALT: filter_targets() lets the exception propagate, halting the
            run before any packet (the active-scan scope gate).
          - SOFT FILTER: pipeline._scope_filter_urls() catches the exception to
            DROP an out-of-scope URL from the nuclei full-template pass (keeping
            in-scope ones). Same check, different handling of the raise.
        """
        t = target.strip().lower()

        # CIDR network target (has a prefix): authorized only if it's fully
        # contained within one of the allowlisted networks. ip_address() below
        # can't parse a CIDR, so this must be handled FIRST — otherwise a valid
        # in-scope CIDR falls through to the hostname branch and is wrongly
        # rejected as "Hostname .../29 is not in the authorized allowlist".
        if "/" in t:
            try:
                net = ipaddress.ip_network(t, strict=False)
                if any(net.subnet_of(a) for a in self._networks
                       if a.version == net.version):
                    return
                raise ScopeViolation(
                    f"Network {target} is not within any authorized CIDR/range")
            except ValueError:
                # not a parseable network -> fall through to hostname handling
                pass

        try:
            ip = ipaddress.ip_address(t)
            if self._is_ip_in_scope(ip):
                return
            raise ScopeViolation(f"IP {target} is not within any authorized CIDR/range")
        except ValueError:
            # not an IP literal -> treat as hostname
            if self._is_host_in_scope(t):
                return
            raise ScopeViolation(f"Hostname {target} is not in the authorized allowlist")

    def filter_targets(self, targets: list[str]) -> list[str]:
        """Validate all targets up front. Raises on the first violation so the
        run halts before any packet is sent."""
        for t in targets:
            self.check(t)
        return targets

    def scannable_targets(self, max_hosts: int = 4096) -> list[str]:
        """Expand the scope rules into concrete scannable targets, used as a
        fallback when targets.txt is empty (scope == targets, the common case).

        - exact hostnames -> included as-is
        - single IPs / CIDR networks -> expanded to host addresses
        - wildcard rules (*.client.com) -> SKIPPED (can't enumerate hostnames
          from a wildcard; those still require an explicit targets.txt entry)

        Raises ValueError if expansion would exceed max_hosts, to avoid
        accidentally launching a massive scan from a broad CIDR.
        """
        targets: list[str] = []

        # exact hostnames first
        targets.extend(sorted(self._exact_hosts))

        # networks: expand, but guard against huge ranges
        total = 0
        for net in self._networks:
            n = net.num_addresses
            # for a single-host network (/32 or /128) hosts() may be empty,
            # so handle that explicitly
            if n == 1:
                targets.append(str(net.network_address))
                total += 1
                continue
            hosts = list(net.hosts())
            total += len(hosts)
            if total > max_hosts:
                raise ValueError(
                    f"scope.txt expands to more than {max_hosts} hosts; "
                    f"list specific hosts in targets.txt instead of relying on "
                    f"the scope fallback for a range this large")
            targets.extend(str(h) for h in hosts)

        # de-dupe, preserve order
        seen: set[str] = set()
        uniq: list[str] = []
        for t in targets:
            if t not in seen:
                seen.add(t)
                uniq.append(t)
        return uniq


# ---------------------------------------------------------------------------
# CIDR handling subsystem
# ---------------------------------------------------------------------------
# Principle: targets.txt is the TRUE SOURCE and is never mangled. Different
# consumers need the targets in different forms:
#   - nmap handles CIDR natively -> pass it through as-is (efficient range scan)
#   - many web tools (httpx/nuclei/etc.) can't take a CIDR -> they need the
#     individual host IPs, which normally come from nmap's live-host discovery.
# These helpers expand a CIDR to concrete IPs ONLY for the consumers that need
# it, with a size guard so a broad range doesn't silently launch a huge job.

# Prefix at/below which we ask "are you sure?" before expanding (IPv4).
# /16 = 65k hosts; anything broader (smaller prefix number) is worth confirming.
CIDR_CONFIRM_PREFIXV4 = 16
# Hard sanity cap for a single expansion unless the operator confirms.
CIDR_SOFT_MAX_HOSTS = 8192


def is_cidr(entry: str) -> bool:
    """True if entry is CIDR notation (has a prefix and parses as a network)."""
    e = (entry or "").strip()
    if "/" not in e:
        return False
    try:
        ipaddress.ip_network(e, strict=False)
        return True
    except ValueError:
        return False


def cidr_host_count(entry: str) -> int:
    """Number of usable hosts a CIDR expands to (0 if not a CIDR)."""
    try:
        net = ipaddress.ip_network(entry.strip(), strict=False)
    except ValueError:
        return 0
    if net.num_addresses <= 2:
        return net.num_addresses      # /31, /32 etc.
    return net.num_addresses - 2      # minus network + broadcast


def expand_cidr(entry: str) -> list[str]:
    """Expand ONE CIDR (or pass a bare IP/host through) to individual addresses.
    A /32 or /31 yields its address(es); a bare host/IP returns itself."""
    e = (entry or "").strip()
    if not is_cidr(e):
        return [e] if e else []
    net = ipaddress.ip_network(e, strict=False)
    if net.num_addresses == 1:
        return [str(net.network_address)]
    hosts = [str(h) for h in net.hosts()]
    return hosts or [str(net.network_address)]


def expand_targets_for_tool(entries: list[str], confirm=None,
                            soft_max: int = CIDR_SOFT_MAX_HOSTS) -> list[str]:
    """Expand a mixed list (IPs, CIDRs, hostnames) into individual scannable
    entries for a tool that CAN'T take CIDR. Hostnames pass through untouched.

    `confirm` is an optional callable(prompt)->bool used to ask the operator
    before expanding a very large range (prefix <= CIDR_CONFIRM_PREFIXV4 or an
    expansion beyond soft_max). If confirm is None, large ranges are expanded
    with just a printed warning (non-interactive/unattended runs proceed).
    The TRUE SOURCE list is never modified; this returns a new expanded list.
    """
    out: list[str] = []
    seen: set[str] = set()
    for entry in entries:
        e = (entry or "").strip()
        if not e:
            continue
        if not is_cidr(e):
            if e not in seen:
                seen.add(e); out.append(e)
            continue
        net = ipaddress.ip_network(e, strict=False)
        count = cidr_host_count(e)
        big = (net.version == 4 and net.prefixlen <= CIDR_CONFIRM_PREFIXV4) \
            or count > soft_max
        if big:
            prompt = (f"CIDR {e} expands to ~{count} hosts. Expand and scan all "
                      f"of them?")
            if confirm is not None:
                if not confirm(prompt):
                    print(f"[scope] skipping expansion of {e} (operator declined)")
                    continue
            else:
                print(f"[scope] WARNING: {e} -> ~{count} hosts (large range); "
                      f"expanding. Narrow the CIDR if this is unintended.")
        for ip in expand_cidr(e):
            if ip not in seen:
                seen.add(ip); out.append(ip)
    return out
