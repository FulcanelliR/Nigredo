"""Interactive run menu for nigredo.

Presented at the start of `engagement`. Lets the operator choose:
  1) Everything (full chain: phase 0 -> 1 -> 2)
  2) Start from a phase (0, 1, or 2) and run to the end
  3) Run a single tool
  4) Quit

Tools that need prior data (e.g. testssl needs the phase-0 nmap scan's
results.json) are shown with their prerequisite and disabled until it exists.
Single-tool and partial runs build a TIMESTAMPED workbook so the previous
report is never overwritten.
"""
from __future__ import annotations

from pathlib import Path


# tool -> (phase, human label, prerequisite description or None)
# prerequisite is checked at runtime against the client output dir.
PHASE0_TOOLS = ["httpx", "katana", "gau", "nuclei", "ffuf", "feroxbuster", "nomore403", "testssl", "sns", "sshaudit"]
PHASE1_TOOLS = ["dnsrecon", "dnstwist", "dkim", "subdomains", "takeover", "submutate", "cvemap", "fileenum", "buckets", "cloud_enum", "trufflehog", "gitleaks", "funnelweb"]
PHASE2_TOOLS = ["emailenum", "partyon", "snov"]

TOOL_LABELS = {
    "nuclei": "nuclei (web vuln templates)",
    "ffuf": "ffuf (calibrated discovery -> feeds feroxbuster)",
    "feroxbuster": "feroxbuster (recursive content discovery)",
    "nomore403": "nomore403 (403 bypass testing on feroxbuster's forbidden URLs)",
    "httpx": "httpx (HTTP prober + tech/CDN fingerprint)",
    "katana": "katana (fast crawler -> feeds nuclei + 403 pool)",
    "gau": "gau (passive historical URL mining)",
    "testssl": "testssl.sh (TLS audit)",
    "sns": "sns (IIS short-name check)",
    "sshaudit": "ssh-audit (SSH algorithm audit)",
    "dnsrecon": "dnsrecon (DNS records)",
    "dnstwist": "dnstwist (look-alike domains)",
    "dkim": "dkim (DKIM selector brute)",
    "subdomains": "subdomains (subfinder|shuffledns|dnsx)",
    "takeover": "subdomain takeover (nuclei takeover templates, CNAME hotlist first)",
    "submutate": "subdomain mutations (learn target vocab -> resolve in-scope)",
    "cvemap": "CVE lookup on discovered technologies (httpx tech + shodan CPEs)",
    "fileenum": "fileenum (file/metadata enum)",
    "buckets": "buckets (GrayHatWarfare cloud storage)",
    "cloud_enum": "cloud_enum (active bucket brute-force)",
    "trufflehog": "trufflehog (GitHub org secret scan)",
    "gitleaks": "gitleaks (GitHub repo clone + scan)",
    "funnelweb": "funnelweb (web crawler)",
    "emailenum": "LinkThief (LinkedIn email enumeration)",
    "partyon": "partyon (breach/credential lookup)",
    "snov": "SnovFall (domain emails)",
}

# phase-0 web/ssh tools need the nmap scan's results.json to know what to hit
PHASE0_NEEDS_SCAN = {"nuclei", "ffuf", "feroxbuster", "testssl", "sns", "sshaudit"}


def _prompt(msg: str) -> str:
    try:
        return input(msg).strip()
    except EOFError:
        return ""


def _scan_results_exist(results_dir: Path) -> bool:
    """True if a phase-0 results.json exists for any client under results_dir."""
    if not results_dir.exists():
        return False
    return any(results_dir.glob("*/results.json"))


def main_menu(results_dir: Path) -> dict | None:
    """Show the top menu. Returns a dict describing the choice, or None to quit.

    Returned dict shapes:
      {"mode": "all"}
      {"mode": "from_phase", "phase": 0|1|2}
      {"mode": "single", "tool": "<name>"}
    """
    print("\n" + "=" * 60)
    print(" nigredo — run menu")
    print("=" * 60)
    print("  1) Everything            (phase 0 scan -> recon -> email)")
    print("  2) Start from a phase    (pick 0, 1, or 2 and run to the end)")
    print("  3) Run a single tool")
    print("  4) Quit")
    choice = _prompt("\nChoose [1-4]: ")

    if choice == "1":
        return {"mode": "all"}
    if choice == "2":
        return _phase_menu()
    if choice == "3":
        return _single_tool_menu(results_dir)
    if choice in ("4", "q", "quit", ""):
        return None
    print("  (not a valid choice)")
    return main_menu(results_dir)


def _phase_menu() -> dict | None:
    print("\nStart from which phase? (runs that phase through to the end)")
    print("  0) Phase 0 — active scanning")
    print("  1) Phase 1 — passive recon")
    print("  2) Phase 2 — email enumeration")
    print("  b) back")
    c = _prompt("Choose [0-2/b]: ")
    if c in ("0", "1", "2"):
        return {"mode": "from_phase", "phase": int(c)}
    return None


def _single_tool_menu(results_dir: Path) -> dict | None:
    have_scan = _scan_results_exist(results_dir)
    rows: list[tuple[int, str]] = []
    idx = 1
    index_map: dict[int, str] = {}

    def section(title, tools):
        nonlocal idx
        print(f"\n  --- {title} ---")
        for t in tools:
            label = TOOL_LABELS.get(t, t)
            blocked = t in PHASE0_NEEDS_SCAN and not have_scan
            if blocked:
                print(f"   --) {label}  (unavailable — requires phase 0 nmap scan)")
            else:
                print(f"   {idx:>2}) {label}")
                index_map[idx] = t
                idx += 1

    print("\nRun a single tool:")
    section("Phase 0 — active scanning", PHASE0_TOOLS)
    section("Phase 1 — passive recon", PHASE1_TOOLS)
    section("Phase 2 — email", PHASE2_TOOLS)
    print("\n    b) back")

    c = _prompt("Choose a number: ")
    if c in ("b", "back", ""):
        return None
    try:
        n = int(c)
    except ValueError:
        print("  (not a number)")
        return _single_tool_menu(results_dir)
    if n not in index_map:
        print("  (not an available choice)")
        return _single_tool_menu(results_dir)
    return {"mode": "single", "tool": index_map[n]}
