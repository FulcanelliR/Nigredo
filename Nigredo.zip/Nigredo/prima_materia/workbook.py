"""Workbook structure builder — the final deliverable, organized front-to-back
as an inverted pyramid (concise/actionable -> raw/audit).

Tab order:
  1. At a Glance            — vuln-type findings by CVSS 3.1 severity (actionable)
  2. Cleaned PDF sections   — chart-ready tabs (DNSRecon, DNSTwist, Subdomains,
                              DeHashed Emails, Automated Emails, NS Takeover)
  3. Master Target list     — every target across all tools
  4. Master Error log       — errors sorted by tool
  5. PartyOn CredStuffing    — cred-stuffing list (+ results if engaged)
  6. Analytics              — runtime, API cost, per-tool status
  7. Vuln-type findings     — per-source vuln tabs (feed At a Glance; chartable)
  8. Per-tool audit clusters — for each tool: Concise / Raw / Error / Cmd+Target
  9. Run Data               — copies of the log/data files (viewable), and the
                              original files embedded in the .xlsx archive as a
                              travelling backup.

This module only ADDS structure; the existing report.py tab-builders are reused.
Everything is defensive: a missing input file just yields an empty/edited tab.
"""
from __future__ import annotations

import csv
import glob
import os
import re
import zipfile
from pathlib import Path

# CVSS 3.1 severity bands (score -> label), most severe first for At a Glance
_SEVERITY_ORDER = ["Critical", "High", "Medium", "Low", "Informational", "None"]
_SEVERITY_RANK = {s: i for i, s in enumerate(_SEVERITY_ORDER)}


def cvss_band(score) -> str:
    """CVSS 3.1 qualitative band for a numeric base score."""
    try:
        s = float(score)
    except (TypeError, ValueError):
        return "None"
    if s >= 9.0:
        return "Critical"
    if s >= 7.0:
        return "High"
    if s >= 4.0:
        return "Medium"
    if s > 0.0:
        return "Low"
    return "None"


# --------------------------- file discovery ---------------------------

def _glob(outdir: Path, pattern: str):
    return sorted(Path(outdir).glob(pattern))


def _read_text(p: Path, limit_lines: int = 5000) -> list[str]:
    """Read a text/log file into lines, capped so a giant log can't blow up the
    workbook. Returns lines with a truncation marker if capped."""
    try:
        lines = Path(p).read_text(errors="replace").splitlines()
    except OSError:
        return []
    if len(lines) > limit_lines:
        kept = lines[:limit_lines]
        kept.append(f"... [truncated — {len(lines) - limit_lines} more lines; "
                    f"full file embedded in the workbook archive]")
        return kept
    return lines


def _read_csv_rows(p: Path):
    try:
        with open(p, newline="", encoding="utf-8", errors="replace") as f:
            return list(csv.reader(f))
    except OSError:
        return []


# --------------------------- At a Glance ---------------------------

def collect_severity_findings(outdir: Path) -> list[dict]:
    """Gather vuln-type findings from every source into one severity-ranked list.

    Sources: nuclei, cvemap (tech CVEs), nessus_exploitable, Cache/PoC, SSL.
    Each finding: {severity, score, source, target, name, detail}. Returns them
    sorted Critical -> None so the At a Glance page leads with what matters.
    """
    findings: list[dict] = []

    # nessus_exploitable.txt — the exploit-available findings (high priority)
    ne = Path(outdir) / "nessus_exploitable.txt"
    if ne.is_file():
        for line in ne.read_text(errors="replace").splitlines():
            if line.startswith("#") or not line.strip():
                continue
            parts = line.split("\t")
            if len(parts) >= 2:
                findings.append({
                    "severity": "Critical",   # public exploit available => treat high
                    "score": "", "source": "Nessus (exploit avail)",
                    "target": parts[0],
                    "name": f"Exploitable service {parts[1]}",
                    "detail": " ".join(parts[2:])[:300],
                })

    # nuclei findings (jsonl per run) — severity is in the template info
    for p in _glob(outdir, "**/nuclei*.jsonl"):
        findings.extend(_parse_nuclei(p))

    # cvemap tech CVEs (csv)
    for p in _glob(outdir, "cvemap_findings*.csv"):
        rows = _read_csv_rows(p)
        if not rows:
            continue
        hdr = [h.lower() for h in rows[0]]
        for r in rows[1:]:
            rec = dict(zip(hdr, r))
            score = rec.get("cvss") or rec.get("cvss_score") or ""
            findings.append({
                "severity": cvss_band(score), "score": score,
                "source": "cvemap", "target": rec.get("product") or rec.get("tech") or "",
                "name": rec.get("cve") or rec.get("id") or "CVE",
                "detail": (rec.get("description") or "")[:300],
            })

    # SSL/TLS findings from testssl (HIGH/CRITICAL/MEDIUM) — B5
    import json as _json
    for p in _glob(outdir, "testssl_*.json"):
        try:
            data = _json.loads(Path(p).read_text(errors="replace"))
        except (ValueError, OSError):
            continue
        items = data if isinstance(data, list) else data.get("scanResult", [])
        for it in (items or []):
            sev = str(it.get("severity", "")).upper()
            band = {"CRITICAL": "Critical", "HIGH": "High", "MEDIUM": "Medium"}.get(sev)
            if not band:
                continue
            findings.append({
                "severity": band, "score": "", "source": "testssl",
                "target": str(it.get("ip", "") or it.get("target", "")),
                "name": str(it.get("id", "SSL/TLS")),
                "detail": str(it.get("finding", ""))[:300],
            })

    # Web-cache deception / PoC findings — B5 (cache.py writes cache_pocs.json)
    cp = Path(outdir) / "cache_pocs.json"
    if cp.is_file():
        try:
            cdata = _json.loads(cp.read_text(errors="replace"))
            recs = cdata if isinstance(cdata, list) else cdata.get("results", [])
            for r in (recs or []):
                if not isinstance(r, dict):
                    continue
                findings.append({
                    "severity": str(r.get("severity") or "Medium").capitalize(),
                    "score": "", "source": "cache/PoC",
                    "target": r.get("url") or r.get("target") or "",
                    "name": r.get("type") or r.get("name") or "Web cache issue",
                    "detail": str(r.get("detail") or r.get("poc") or "")[:300],
                })
        except (ValueError, OSError):
            pass

    # de-dup identical (source,target,name) and sort by severity then score
    seen = set()
    uniq = []
    for f in findings:
        k = (f["source"], f["target"], f["name"])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(f)
    uniq.sort(key=lambda f: (_SEVERITY_RANK.get(f["severity"], 99),
                             -_score_num(f["score"])))
    return uniq


def _score_num(s) -> float:
    try:
        return float(s)
    except (TypeError, ValueError):
        return 0.0


def _parse_nuclei(p: Path) -> list[dict]:
    import json
    out = []
    try:
        for line in Path(p).read_text(errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except ValueError:
                continue
            info = d.get("info", {}) or {}
            sev = (info.get("severity") or "").capitalize() or "Informational"
            # nuclei uses info/low/medium/high/critical — map 'Info' -> Informational
            if sev.lower().startswith("info"):
                sev = "Informational"
            out.append({
                "severity": sev if sev in _SEVERITY_RANK else "Informational",
                "score": info.get("classification", {}).get("cvss-score", "") if isinstance(info.get("classification"), dict) else "",
                "source": "nuclei",
                "target": d.get("host") or d.get("matched-at") or "",
                "name": d.get("template-id") or info.get("name") or "finding",
                "detail": (info.get("name") or "")[:300],
            })
    except OSError:
        pass
    return out


def severity_summary(findings: list[dict]) -> dict:
    """Count findings per severity band — the analytics block for At a Glance."""
    counts = {s: 0 for s in _SEVERITY_ORDER}
    for f in findings:
        counts[f["severity"]] = counts.get(f["severity"], 0) + 1
    return counts


# --------------------------- master lists ---------------------------

def collect_master_targets(outdir: Path) -> list[list[str]]:
    """Every tool's <tool>_targets.txt -> rows [tool, target]. First-column sort."""
    rows = []
    for p in _glob(outdir, "*_targets.txt"):
        tool = p.name[:-len("_targets.txt")]
        for line in _read_text(p, limit_lines=100000):
            if line.strip():
                rows.append([tool, line.strip()])
    rows.sort(key=lambda r: r[0])
    return rows


def collect_master_errors(outdir: Path) -> list[list[str]]:
    """Every tool's error output -> rows [tool, error line]. Sorted by tool
    (first column only, as requested)."""
    rows = []
    # per-tool error files, plus the unified command log FAILED entries
    for p in _glob(outdir, "*_errors.txt") + _glob(outdir, "*.err"):
        tool = re.sub(r"(_errors\.txt|\.err)$", "", p.name)
        for line in _read_text(p):
            if line.strip():
                rows.append([tool, line.strip()])
    # FAILED lines in commands.log (from the audit dispatch)
    cl = Path(outdir) / "commands.log"
    if cl.is_file():
        for line in cl.read_text(errors="replace").splitlines():
            if "FAILED:" in line:
                m = re.search(r"\[([^\]]+)\]\s*FAILED:", line)
                tool = m.group(1) if m else "unknown"
                rows.append([tool, line.strip()])
    rows.sort(key=lambda r: r[0])       # first-column sort only
    return rows


# --------------------------- run data + file backup ---------------------------

# files worth copying into the Run Data tab (viewable) and archiving (backup)
_RUN_DATA_GLOBS = [
    "commands.log", "resource_log.txt", "honeypots.txt",
    "nessus_exploitable.txt", "*.log", "*_targets.txt", "*_errors.txt",
]


def run_data_files(outdir: Path) -> list[Path]:
    seen = set()
    files = []
    for pat in _RUN_DATA_GLOBS:
        for p in _glob(outdir, pat):
            rp = p.resolve()
            if rp not in seen and p.is_file():
                seen.add(rp)
                files.append(p)
    return files


def embed_files_in_xlsx(xlsx_path: Path, files: list[Path],
                        arc_prefix: str = "run_data_backup") -> int:
    """Inject copies of the original files INTO the .xlsx archive (an xlsx is a
    zip). They travel with the workbook as a backup and can be extracted later
    with any unzip tool. Originals on disk are untouched. Returns count embedded.

    Note: these are stored in the archive, not shown as an Excel sheet — the
    Run Data tab holds the *viewable* text; this is the full-fidelity backup.
    """
    xlsx_path = Path(xlsx_path)
    if not xlsx_path.is_file() or not files:
        return 0
    n = 0
    try:
        with zipfile.ZipFile(xlsx_path, "a", zipfile.ZIP_DEFLATED) as z:
            existing = set(z.namelist())
            for f in files:
                try:
                    if f.stat().st_size > 25 * 1024 * 1024:   # skip >25MB
                        continue
                    arc = f"{arc_prefix}/{f.name}"
                    if arc in existing:
                        arc = f"{arc_prefix}/{f.parent.name}_{f.name}"
                    z.write(f, arc)
                    n += 1
                except OSError:
                    continue
    except (OSError, zipfile.BadZipFile):
        return 0
    return n


# --------------------------- per-tool audit clusters ---------------------------

# tool -> the glob patterns for its output files, in the engagement folder.
# Concise builders pull the cleaned view; Raw shows everything the tool wrote.
# Anything not matched just yields an empty sub-tab (defensive).
_TOOL_FILE_PATTERNS = {
    "nuclei":     ["nuclei_*", "*nuclei*.jsonl", "*nuclei*.txt"],
    "ffuf":       ["ffuf_*", "*ffuf*.json"],
    "feroxbuster":["feroxbuster_*", "ferox_*", "*ferox*.json"],
    "nomore403":  ["nomore403_*", "*403*"],
    "httpx":      ["httpx_*"],
    "katana":     ["katana_*"],
    "gau":        ["gau_*"],
    "testssl":    ["testssl_*", "*testssl*.json", "*testssl*.txt"],
    "sns":        ["sns_*", "iis_*"],
    "sshaudit":   ["sshaudit_*", "ssh_audit_*", "sshaudit*.txt"],
    "dnsrecon":   ["dnsrecon_*"],
    "dnstwist":   ["dnstwist_*"],
    "dkim":       ["dkim_*"],
    "subdomains": ["subdomains_*", "subfinder_*", "*subdomains*.txt"],
    "takeover":   ["takeover_*"],
    "submutate":  ["submutate_*", "mutations_*"],
    "cvemap":     ["cvemap_*"],
    "fileenum":   ["fileenum_*", "files_*", "*metadata*"],
    "buckets":    ["grayhat_*", "buckets_*"],
    "cloud_enum": ["cloud_enum_*", "cloudenum_*"],
    "trufflehog": ["trufflehog_*"],
    "gitleaks":   ["gitleaks_*", "gitleaks_*/*"],
    "funnelweb":  ["funnelweb_*", "*funnelweb*/*"],
    "emailenum":  ["linkthief_*", "emails_*"],
    "partyon":    ["partyon_*", "dehashed_*"],
    "snov":       ["snov_*", "snovfall_*"],
}

# friendly display names for the cluster group headers
_TOOL_DISPLAY = {
    "emailenum": "LinkThief", "partyon": "PartyOn", "snov": "SnovFall",
    "cvemap": "cvemap", "sns": "SNS (IIS)", "sshaudit": "ssh-audit",
}


def tool_output_files(outdir: Path, tool: str) -> list[Path]:
    """All files a given tool wrote, by naming convention. Deduped."""
    seen, out = set(), []
    for pat in _TOOL_FILE_PATTERNS.get(tool, [f"{tool}_*"]):
        for p in _glob(outdir, pat):
            if p.is_file():
                rp = p.resolve()
                if rp not in seen:
                    seen.add(rp)
                    out.append(p)
    return out


def tool_command_lines(outdir: Path, tool: str) -> list[str]:
    """Command + target lines for a tool: the command/action lines from
    commands.log PLUS the full target list from <tool>_targets.txt. Both belong
    in the workbook's 'Target + Command' column so the run is fully traceable —
    what was run AND what it was run against."""
    out = []
    outdir = Path(outdir)
    # 1) the exact target list the tool ran against
    for p in _glob(outdir, f"{tool}_targets.txt"):
        lines = _read_text(p)
        if lines:
            out.append(f"--- targets ({p.name}) ---")
            out.extend(lines)
            out.append("")
    # also try the display-name variant (e.g. LinkThief_targets.txt)
    disp = _TOOL_DISPLAY.get(tool, tool)
    if disp.lower() != tool.lower():
        for p in _glob(outdir, f"{disp}_targets.txt"):
            lines = _read_text(p)
            if lines:
                out.append(f"--- targets ({p.name}) ---")
                out.extend(lines)
                out.append("")
    # 2) the command/action lines from commands.log
    cl = outdir / "commands.log"
    if cl.is_file():
        tl = tool.lower()
        dl = disp.lower()
        cmd_hits = []
        for line in cl.read_text(errors="replace").splitlines():
            low = line.lower()
            if f"[{tl}]" in low or f"[{dl}]" in low or low.strip().startswith(tl):
                cmd_hits.append(line.rstrip())
        if cmd_hits:
            out.append("--- commands ---")
            out.extend(cmd_hits)
    return out


def tool_error_lines(outdir: Path, tool: str) -> list[str]:
    """Error/FAILED lines for a tool: its *_errors.txt plus FAILED commands.log
    lines tagged with the tool."""
    out = []
    for p in _glob(outdir, f"{tool}_errors.txt") + _glob(outdir, f"{tool}*.err"):
        out.extend(_read_text(p))
    cl = Path(outdir) / "commands.log"
    if cl.is_file():
        tl = tool.lower()
        for line in cl.read_text(errors="replace").splitlines():
            if "FAILED:" in line and (f"[{tl}]" in line.lower()):
                out.append(line.rstrip())
    return out


def per_tool_clusters(outdir: Path) -> list[dict]:
    """Build the data for each tool's audit cluster: for every tool that produced
    ANY output, return {tool, display, raw_files, commands, errors}. The report
    layer turns each into Concise / Raw / Error / Command+Target sub-tabs.

    Clusters are returned SORTED ALPHABETICALLY by display name so related tabs
    group together (all IIS/SNS together, all nuclei together, etc.) instead of
    appearing in arbitrary dict order."""
    clusters = []
    # Every tool that runs gets a RAW scribe tab (for auditing/analysing the raw
    # output), EVEN IF it also has a dedicated formatted tab. Only Snov is
    # excluded — it has its own self-formatted output page already.
    _scribe_skip = {"snov"}
    for tool in _TOOL_FILE_PATTERNS:
        if tool in _scribe_skip:
            continue
        files = tool_output_files(outdir, tool)
        cmds = tool_command_lines(outdir, tool)
        errs = tool_error_lines(outdir, tool)
        if not files and not cmds and not errs:
            continue        # tool didn't run / produced nothing — no cluster
        clusters.append({
            "tool": tool,
            "display": _TOOL_DISPLAY.get(tool, tool),
            "raw_files": files,
            "commands": cmds,
            "errors": errs,
        })
    # alphabetical by display name (case-insensitive) so tabs cluster sensibly
    clusters.sort(key=lambda c: (c["display"] or c["tool"]).lower())
    return clusters



def write_aggregated_error_log(outdir: Path) -> Path | None:
    """Aggregate every tool's error output into ONE file at the engagement root:
    error_log.txt. Pulls from *_errors.txt, *.err, and FAILED lines in
    commands.log. Sorted by tool. This is the single place to see everything that
    went wrong in a run (separate from the workbook's Master Errors tab)."""
    outdir = Path(outdir)
    lines = []
    # per-tool error files
    for p in sorted(outdir.glob("*_errors.txt")) + sorted(outdir.glob("*.err")):
        tool = re.sub(r"(_errors\.txt|\.err)$", "", p.name)
        try:
            body = p.read_text(errors="replace").splitlines()
        except OSError:
            continue
        for ln in body:
            if ln.strip():
                lines.append(f"[{tool}] {ln.rstrip()}")
    # FAILED lines from commands.log
    cl = outdir / "commands.log"
    if cl.is_file():
        try:
            for ln in cl.read_text(errors="replace").splitlines():
                if "FAILED:" in ln:
                    lines.append(ln.rstrip())
        except OSError:
            pass
    # FunnelWeb's own errors.log (nested under <domain>/)
    for elog in outdir.glob("*/errors.log"):
        try:
            for ln in elog.read_text(errors="replace").splitlines():
                if ln.strip() and not ln.startswith("#"):
                    lines.append(f"[funnelweb] {ln.rstrip()}")
        except OSError:
            continue
    if not lines:
        return None
    lines.sort()
    out = outdir / "error_log.txt"
    try:
        header = f"# Aggregated error log — {len(lines)} entries across all tools\n"
        out.write_text(header + "\n".join(lines) + "\n")
    except OSError:
        return None
    return out
