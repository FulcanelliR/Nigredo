#!/usr/bin/env python3
"""Cloud storage (bucket/blob) enumeration via GrayHatWarfare (phase 1).

Queries GrayHatWarfare's v2 API for publicly-indexed cloud storage across all
providers it covers — Amazon S3 (type "bucket"), Azure Blob (type "container"),
Google Cloud Storage (type "google"), and DigitalOcean Spaces (type
"digitalocean") — matching the target domain, company name, and any storage
hostnames harvested from prior recon (the rDNS/S3-hostname clue).

Records BOTH open (public) and private buckets with a status column: a confirmed
private bucket still tells you it exists for manual brute-forcing. For each
bucket it also pulls the file listing (capped, configurable) — but the bucket
URL and total file count are ALWAYS recorded so nothing is lost even when the
per-bucket file listing is truncated.

Auth: Bearer token from grayhat_api_key (config) or GRAYHAT_API_KEY env var.
Discovery only — queries a third-party index, never touches the target's infra.
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path

import requests

API_BASE = "https://buckets.grayhatwarfare.com/api/v2"
BUCKETS_URL = f"{API_BASE}/buckets"
FILES_URL = f"{API_BASE}/files"

# type -> friendly provider label
PROVIDER = {
    "bucket": "AWS S3",
    "container": "Azure Blob",
    "google": "Google Cloud Storage",
    "digitalocean": "DigitalOcean Spaces",
}

# filename fragments that suggest a sensitive/high-value file (triage flag)
SENSITIVE_HINTS = [
    "backup", "bak", "dump", "sql", "db", "database", ".env", "env.",
    "config", "conf", "secret", "password", "passwd", "creds", "credential",
    "private", "key", ".pem", ".ppk", "id_rsa", "token", "aws", "azure",
    "confidential", "internal", "payroll", "invoice", "ssn", "salary",
    "archive", ".zip", ".tar", ".gz", ".7z", ".rar", "export", "backup",
]

# hostnames in prior recon that reveal a bucket name
_STORAGE_HOST_RE = re.compile(
    r"([a-z0-9][a-z0-9.\-]{1,62})"
    r"\.(?:s3[.-][a-z0-9\-]*\.amazonaws\.com|s3\.amazonaws\.com"
    r"|blob\.core\.windows\.net|storage\.googleapis\.com"
    r"|[a-z0-9\-]+\.digitaloceanspaces\.com)",
    re.IGNORECASE,
)


class GrayhatError(RuntimeError):
    pass


# ---- Tier lever: maps operator's GrayHatWarfare subscription to concrete API
# behavior. Higher tiers unlock features that ERROR on lower tiers (regex is
# Premium+; unlimited scroll is Enterprise), so the tier both protects the key
# from unusable calls AND unlocks capability. Defaults to 'low' (free) — an
# unattended run never assumes paid features.
TIERS = {
    "low":    {"regex": False, "max_keywords": 4,  "file_cap": 200,
               "max_pages": 1,  "exclusions": 0,  "sort": False},
    "medium": {"regex": False, "max_keywords": 8,  "file_cap": 1000,
               "max_pages": 3,  "exclusions": 5,  "sort": False},
    "high":   {"regex": True,  "max_keywords": 16, "file_cap": 1000,
               "max_pages": 10, "exclusions": 15, "sort": True},
    "max":    {"regex": True,  "max_keywords": 32, "file_cap": 1000,
               "max_pages": 50, "exclusions": 999, "sort": True},
}


def tier_settings(tier: str) -> dict:
    return TIERS.get((tier or "low").lower(), TIERS["low"])


def _cache_path(outdir: Path) -> Path:
    return Path(outdir) / ".grayhat_search_cache.json"


def _load_cache(outdir: Path) -> dict:
    p = _cache_path(outdir)
    if p.is_file():
        try:
            return json.loads(p.read_text())
        except (ValueError, OSError):
            return {}
    return {}


def _save_cache(outdir: Path, cache: dict) -> None:
    try:
        _cache_path(outdir).write_text(json.dumps(cache))
    except OSError:
        pass


def search_files_regex(api_key: str, regex: str, limit: int = 1000,
                       timeout: int = 30) -> list[dict]:
    """Regex file search (GrayHat Premium+ ONLY). Hunts sensitive files directly
    by pattern instead of keyword.

    Per GrayHat's docs, regex search expects the pattern BASE64-encoded in the
    keywords field alongside regexp=1. Also: the engine matches the whole
    filename with ^/$ implicit (and stripped if provided), and matches only the
    filename part (not domain/protocol). A non-Premium+ key gets 401 here — the
    caller detects that and skips the regex phase.
    """
    import base64
    # strip redundant anchors (GrayHat makes ^/$ implicit) then base64-encode
    pattern = regex
    if pattern.startswith("^"):
        pattern = pattern[1:]
    if pattern.endswith("$"):
        pattern = pattern[:-1]
    b64 = base64.b64encode(pattern.encode()).decode()
    params = {"keywords": b64, "regexp": 1, "limit": limit}
    _count_call()
    resp = requests.get(FILES_URL, headers=_headers(api_key),
                        params=params, timeout=timeout)
    resp.raise_for_status()
    return resp.json().get("files", []) or []


def _headers(api_key: str) -> dict:
    return {"Authorization": f"Bearer {api_key}"}


# module-level counter of live GrayHat API searches this run (for credit report)
_ghw_call_count = 0


def _count_call():
    global _ghw_call_count
    _ghw_call_count += 1


def harvest_storage_hostnames(outdir: Path) -> list[str]:
    """Pull candidate bucket names from prior recon output (the rDNS clue).

    Scans dnsrecon reports, results.json, and subdomain output for storage
    hostnames like <bucket>.s3.amazonaws.com and extracts the <bucket> part to
    use as an extra GHW search term.
    """
    candidates: set[str] = set()
    patterns = ["dnsrecon_*.txt", "results.json", "subdomains_*.csv",
                "dnsrecon_*.json"]
    for pat in patterns:
        for p in outdir.glob(pat):
            try:
                text = p.read_text(errors="replace")
            except OSError:
                continue
            for m in _STORAGE_HOST_RE.finditer(text):
                name = m.group(1).split(".")[0]   # left-most label = bucket name
                if name and len(name) > 2 and name not in ("www", "s3"):
                    candidates.add(name.lower())
    return sorted(candidates)


def search_buckets(api_key: str, keyword: str, limit: int = 100,
                   timeout: int = 30) -> list[dict]:
    """Search buckets by keyword. Returns raw bucket dicts (public + private)."""
    params = {"keywords": keyword, "limit": limit}
    _count_call()
    resp = requests.get(BUCKETS_URL, headers=_headers(api_key),
                        params=params, timeout=timeout)
    resp.raise_for_status()
    body = resp.json()
    return body.get("buckets", []) or []


def search_files(api_key: str, keyword: str = "", buckets: str = "",
                 limit: int = 1000, timeout: int = 30) -> list[dict]:
    """Search files by keyword and/or specific bucket(s). buckets is a
    comma-separated list of bucket URLs. Returns raw file dicts."""
    params: dict = {"limit": limit}
    if keyword:
        params["keywords"] = keyword
    if buckets:
        params["buckets"] = buckets
    _count_call()
    resp = requests.get(FILES_URL, headers=_headers(api_key),
                        params=params, timeout=timeout)
    resp.raise_for_status()
    body = resp.json()
    return body.get("files", []) or []


def _is_sensitive(filename: str, fullpath: str = "") -> str:
    hay = (filename + " " + fullpath).lower()
    for hint in SENSITIVE_HINTS:
        if hint in hay:
            return "Y"
    return ""


def _provider(bucket_type: str) -> str:
    return PROVIDER.get((bucket_type or "").lower(), bucket_type or "unknown")


def process(domain: str, outdir, command_log,
            company: str = "", api_key: str = "",
            file_cap_per_bucket: int = 1000, tier: str = "low",
            file_prompt_threshold: int = 500, assume_yes: bool = False,
            ledger=None, dry_run: bool = False) -> Path | None:
    """Run GHW enumeration for a domain. Writes raw JSON + cleaned CSVs.
    Returns the buckets CSV path (or None).

    tier: low/medium/high/max — maps to concrete API behavior (regex search,
    result caps, sorting). Defaults to low (free); unattended runs don't assume
    paid features. See TIERS.
    """
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    safe = domain.replace("/", "_")

    ts = tier_settings(tier)
    cache = _load_cache(outdir)

    api_key = api_key or os.getenv("GRAYHAT_API_KEY", "")
    if not api_key:
        print("[grayhat] no API key (grayhat_api_key / GRAYHAT_API_KEY) — skipping")
        return None

    # build the keyword set: domain, its base name, company, harvested hostnames
    keywords: list[str] = []
    keywords.append(domain)
    base = domain.split(".")[0]
    if base and base != domain:
        keywords.append(base)
    if company:
        keywords.append(company)
    harvested = harvest_storage_hostnames(outdir)
    keywords.extend(harvested)
    # dedupe, preserve order, then CAP by tier (conserve searches on low tiers)
    seen, kw = set(), []
    for k in keywords:
        kl = k.strip().lower()
        if kl and kl not in seen:
            seen.add(kl)
            kw.append(kl)
    if len(kw) > ts["max_keywords"]:
        print(f"[grayhat] tier '{tier}': capping {len(kw)} keywords to "
              f"{ts['max_keywords']} (conserving API budget)")
        kw = kw[:ts["max_keywords"]]

    with open(command_log, "a") as log:
        log.write(f"grayhatwarfare tier={tier} buckets/files keywords={kw}\n")
    if dry_run:
        print(f"[dry-run] grayhat ({tier}) search for {domain}: keywords={kw}")
        return None

    print(f"[grayhat] tier '{tier}' | searching {len(kw)} keyword(s): {', '.join(kw)}")
    if harvested:
        print(f"[grayhat] (incl. {len(harvested)} bucket name(s) harvested from recon)")

    # --- 1) collect buckets across all keywords (cache-aware) ---
    buckets_by_url: dict[str, dict] = {}
    raw_buckets: list[dict] = []
    for k in kw:
        ckey = f"buckets:{k}"
        if ckey in cache:
            found = cache[ckey]
            print(f"[grayhat] '{k}': {len(found)} bucket(s) from cache (no credit spent)")
        else:
            try:
                found = search_buckets(api_key, k)
            except requests.HTTPError as e:
                print(f"[grayhat] bucket search '{k}' failed: {e}")
                continue
            cache[ckey] = found
        raw_buckets.extend(found)
        for b in found:
            url = b.get("url", "")
            if url and url not in buckets_by_url:
                buckets_by_url[url] = b
    _save_cache(outdir, cache)

    # --- 2) pull files per bucket (tier-capped), plus regex sensitive search ---
    from .sensitive_patterns import categorize, SENSITIVE_REGEXES

    file_cap = ts["file_cap"]
    # Volume prompt: if the buckets collectively hold a lot of files, ask before
    # pulling everything — but ALWAYS keep sensitive-flagged files regardless.
    total_available = sum(
        (b.get("num_files", b.get("files_count", 0)) or 0)
        for b in buckets_by_url.values())
    sensitive_only = False
    if total_available > file_prompt_threshold and not assume_yes:
        print(f"[grayhat] {total_available:,} files across "
              f"{len(buckets_by_url)} bucket(s) (> {file_prompt_threshold} threshold).")
        try:
            ans = input("[grayhat] pull (a)ll files, or just (s)ensitive-flagged? "
                        "[a/S]: ").strip().lower()
        except EOFError:
            ans = "s"
        sensitive_only = (ans != "a")   # default to sensitive-only (safer/cheaper)
        print(f"[grayhat] pulling {'sensitive-flagged only' if sensitive_only else 'all'} files")

    raw_files: list[dict] = []
    files_rows: list[dict] = []
    seen_files = set()

    def _record(f: dict, bucket_url: str, provider: str):
        fn = f.get("filename", "")
        fp = f.get("fullPath", f.get("full_path", ""))
        furl = f.get("url", "")
        if furl in seen_files:
            return
        seen_files.add(furl)
        cat = categorize(fn, fp)
        # if sensitive_only, skip non-sensitive files (but always keep flagged)
        if sensitive_only and not cat:
            return
        files_rows.append({
            "provider": provider, "bucket": bucket_url,
            "filename": fn, "fullpath": fp, "file_url": furl,
            "size": f.get("size", ""),
            "sensitive": "Y" if cat else "",
            "category": cat,
        })

    for url, b in buckets_by_url.items():
        prov = _provider(b.get("type", ""))
        try:
            files = search_files(api_key, buckets=url, limit=file_cap)
        except requests.HTTPError as e:
            print(f"[grayhat] file listing for {url} failed: {e}")
            files = []
        raw_files.extend(files)
        for f in files:
            _record(f, url, prov)
        total = b.get("num_files", b.get("files_count", len(files)))
        if isinstance(total, int) and total > len(files):
            print(f"[grayhat] {url}: listed {len(files)} of {total} files "
                  f"(tier '{tier}' cap; full contents at the bucket URL)")

    # --- regex sensitive-file search (Premium+ ONLY) ---
    # GrayHat gates regex search behind Premium+ packages. A key on a lower tier
    # gets 401 on EVERY regex call. Rather than spray one error per pattern, we
    # detect the first 401, explain it once, and skip the whole regex phase (the
    # keyword searches above already ran and don't need Premium+).
    if ts["regex"]:
        print(f"[grayhat] tier '{tier}': running {len(SENSITIVE_REGEXES)} "
              f"regex sensitive-file searches (best-shot-first)")
        regex_unauthorized = False
        for rgx in SENSITIVE_REGEXES:
            ckey = f"regex:{rgx}"
            if ckey in cache:
                found = cache[ckey]
            else:
                try:
                    found = search_files_regex(api_key, rgx, limit=file_cap)
                except requests.HTTPError as e:
                    status = getattr(e.response, "status_code", None)
                    if status == 401:
                        # tier doesn't include regex search — stop the whole phase
                        print("[grayhat] regex search is a GrayHat Premium+ feature "
                              "and this API key's plan doesn't include it (401). "
                              "Skipping the regex sensitive-file phase — keyword "
                              "results above are unaffected.")
                        regex_unauthorized = True
                        break
                    # any other HTTP error: note this one, try the next pattern
                    print(f"[grayhat] regex '{rgx}' failed: {e}")
                    continue
                cache[ckey] = found
            raw_files.extend(found)
            for f in found:
                # regex hits aren't bucket-scoped; label provider from the file
                _record(f, f.get("bucket", ""), _provider(f.get("type", "")))
        if not regex_unauthorized:
            _save_cache(outdir, cache)

    # best-shot-first: sort so sensitive-flagged files surface at the top
    if ts["sort"]:
        files_rows.sort(key=lambda r: (0 if r["sensitive"] else 1,
                                       r.get("category", "")))

    # --- write raw JSON (full audit) ---
    raw_path = outdir / f"grayhat_{safe}.raw.json"
    raw_path.write_text(json.dumps(
        {"keywords": kw, "buckets": raw_buckets, "files": raw_files}, indent=2))

    # --- write cleaned buckets CSV (every bucket, uncapped) ---
    import csv
    buckets_csv = outdir / f"grayhat_{safe}.buckets.csv"
    with open(buckets_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["Provider", "Bucket URL", "Status", "File Count",
                    "First Discovered"])
        for url, b in sorted(buckets_by_url.items()):
            w.writerow([_provider(b.get("type", "")), url,
                        b.get("status", ""),
                        b.get("num_files", b.get("files_count", "")),
                        b.get("first_discovered", "")])

    # --- write cleaned files CSV (capped per bucket) ---
    files_csv = outdir / f"grayhat_{safe}.files.csv"
    with open(files_csv, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["Provider", "Bucket URL", "Filename", "Full Path",
                    "File URL", "Size", "Sensitive", "Category"])
        for r in files_rows:
            w.writerow([r["provider"], r["bucket"], r["filename"],
                        r["fullpath"], r["file_url"], r["size"], r["sensitive"],
                        r.get("category", "")])

    n_sensitive = sum(1 for r in files_rows if r["sensitive"])
    print(f"[\u2713] grayhat: {len(buckets_by_url)} bucket(s), "
          f"{len(files_rows)} file(s) listed"
          + (f", {n_sensitive} flagged sensitive" if n_sensitive else ""))
    print(f"    buckets -> {buckets_csv}")
    print(f"    files   -> {files_csv}")

    # record GrayHat usage: count of live API searches actually made this run
    # (cache hits don't re-spend — part D). GrayHat bills by subscription/usage
    # rather than per-credit, so this is an estimated call count for the report.
    if ledger is not None:
        calls = globals().get("_ghw_call_count", 0)
        if calls:
            try:
                ledger.record("grayhat", calls, kind="estimated",
                              note=f"{calls} API search(es) / {domain}")
            except Exception as e:  # noqa: BLE001
                print(f"[grayhat] {e}")
    return buckets_csv
