"""Final report collation.

Combines the already-cleaned per-tool, per-domain outputs into ONE multi-tab
xlsx workbook, grouping like with like across all domains. This step does not
re-format anything — each tool already produced its cleaned shape; here we just
stack and merge.

Tabs:
  Emails        - merged unique non-DeHashed emails (linkedin, snov, fileenum,
                  funnelweb) with a 'sources' column, for the manual spraying
                  validation phase. Lowercased + deduped.
  DeHashed      - kept separate: unique on-domain emails + the cred-stuff pairs.
  Files         - merged file-metadata rows from fileenum + FunnelWeb document
                  rows mapped into the same columns.
  DNS           - dnsrecon cleaned reports, per domain.
  Lookalikes    - dnstwist rows stacked (type, domain, registrar, ns_records).
  DKIM          - DKIM findings per domain.
  Subdomains    - cleaned subdomain rows stacked (subdomain, type, value).

Inputs are read from the engagement output directory by filename convention
(the names each tool writes). Missing inputs are simply skipped.
"""
from __future__ import annotations

import csv
import glob
import os
import re
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

from .log import get_logger

log = get_logger("report")


def _safe_sheet_title(title: str, wb=None) -> str:
    """Make a string safe as an Excel worksheet name. Excel forbids : \\ / ? * [ ]
    and caps names at 31 chars. This prevents 'X cannot be used in worksheets'
    errors (e.g. hostnames like 'host [A] [1.2.3.4]' or org names with brackets).

    When `wb` is given, also de-duplicate against the workbook's existing sheet
    titles CASE-INSENSITIVELY (Excel treats sheet names case-insensitively), so
    two builders targeting the same name don't produce a silent 'Name1' tab that
    then escapes the front-order reorder.
    """
    s = str(title or "Sheet")
    for ch in ':\\/?*[]':
        s = s.replace(ch, "_")
    s = s.replace("'", "")            # apostrophes are legal but noisy in tab names
    s = s.strip() or "Sheet"
    s = s[:31]
    if wb is not None:
        existing = {t.lower() for t in wb.sheetnames}
        if s.lower() in existing:
            base, n = s, 2
            while s.lower() in existing:
                suffix = f" ({n})"
                s = base[:31 - len(suffix)] + suffix
                n += 1
    return s

FONT = "Roboto"
FONT_SIZE = 11
HEADER_FILL = PatternFill("solid", start_color="1F2937")
HEADER_FONT = Font(name=FONT, size=FONT_SIZE, bold=True, color="FFFFFF")
BODY_FONT = Font(name=FONT, size=FONT_SIZE)
BOLD_FONT = Font(name=FONT, size=FONT_SIZE, bold=True)

_email_re = re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[A-Za-z]{2,}")


def _read_csv(path: Path) -> tuple[list[str], list[list[str]]]:
    with open(path, newline="", encoding="utf-8", errors="replace") as f:
        rows = [r for r in csv.reader(f) if r]
    if not rows:
        return ([], [])
    return (rows[0], rows[1:])


def _glob(outdir: Path, pattern: str) -> list[Path]:
    return [Path(p) for p in sorted(glob.glob(str(outdir / pattern)))]


# ---------- collectors (each returns (headers, rows)) ----------

def collect_spray(outdir: Path, spray_domains=None) -> tuple[list[str], list[list[str]]]:
    """The TOTAL unique email list — every source combined, INCLUDING DeHashed —
    filtered to the user-defined primary domain(s), lowercased, deduplicated.
    Also writes a plain spray_emails.txt (one address per line) to the output
    folder for later use (e.g. password spraying).

    `spray_domains` is the user-defined domain list (may be multiple). Only
    addresses ending in `@<domain>` for one of those domains are kept — a spray
    list must be on-target, so off-domain breach/vendor addresses (gmail.com,
    third parties) are excluded. If no domains are given, no filtering is applied
    (returns the full combined list) and a note is printed.

    This is the union of collect_emails() (snov/linkedin/fileenum/funnelweb) plus
    the DeHashed addresses — one clean, final, on-domain, deduped list."""
    all_emails: set[str] = set()

    # everything collect_emails already merges (snov, linkedin, fileenum, funnelweb)
    _, merged_rows = collect_emails(outdir)
    for r in merged_rows:
        if r and r[0]:
            all_emails.add(r[0].strip().lower())

    # DeHashed addresses (folded in here; breach data often carries off-domain
    # personal addresses, which the domain filter below removes)
    for p in _glob(outdir, "dehashed_*.emails.txt"):
        for line in p.read_text(errors="replace").splitlines():
            e = line.strip().lower()
            if e and "@" in e:
                all_emails.add(e)

    # PartyOn valid accounts: <domain>_valid_usernames.txt (emails), which live in
    # the DeHashed_Engagements/ folder PartyOn writes into the engagement dir.
    for p in list(_glob(outdir, "*_valid_usernames.txt")) + \
            sorted(Path(outdir).rglob("*_valid_usernames.txt")):
        try:
            for line in p.read_text(errors="replace").splitlines():
                e = line.strip().lower()
                if e and "@" in e:
                    all_emails.add(e)
        except OSError:
            continue

    # ---- filter to the user-defined primary domain(s) ----
    domains = [d.strip().lower().lstrip("@") for d in (spray_domains or []) if d and d.strip()]
    if domains:
        suffixes = tuple("@" + d for d in domains)
        filtered = {e for e in all_emails if e.endswith(suffixes)}
        dropped = len(all_emails) - len(filtered)
        if dropped:
            print(f"[spray] filtered to {', '.join(domains)}: kept {len(filtered)}, "
                  f"dropped {dropped} off-domain address(es)")
        all_emails = filtered
    else:
        print("[spray] no spray_domains given — spray list NOT domain-filtered "
              "(includes any address found)")

    final = sorted(all_emails)

    # write the plain .txt for later use (spraying / follow-on)
    try:
        (Path(outdir) / "spray_emails.txt").write_text(
            "\n".join(final) + ("\n" if final else ""))
    except OSError:
        pass

    return (["email"], [[e] for e in final])


def collect_emails(outdir: Path) -> tuple[list[str], list[list[str]]]:
    """Merge non-DeHashed emails from snov, linkedin (emailenum), fileenum,
    funnelweb -> unique address with a sources list."""
    sources: dict[str, set[str]] = {}

    def add(email: str, src: str):
        e = email.strip().lower()
        if e and "@" in e:
            sources.setdefault(e, set()).add(src)

    # snov: snov_<domain>.emails.txt (one per line)
    for p in _glob(outdir, "snov_*.emails.txt"):
        for line in p.read_text().splitlines():
            add(line, "snov")

    # LinkThief (LinkedIn email enum): linkthief_<business>.csv -> attempted_email
    # column. Also read legacy emails_*.csv from older runs (backward-compat).
    for pattern in ("linkthief_*.csv", "emails_*.csv"):
        for p in _glob(outdir, pattern):
            header, rows = _read_csv(p)
            if "attempted_email" in [h.lower() for h in header]:
                idx = [h.lower() for h in header].index("attempted_email")
                for r in rows:
                    if len(r) > idx and r[idx]:
                        add(r[idx], "linkedin")

    # fileenum: emails surface in the raw CSV TextFindings; also harvest any
    # address-looking strings from the cleaned file rows' columns.
    for p in _glob(outdir, "fileenum_*.raw.csv"):
        text = p.read_text(errors="replace")
        for m in _email_re.findall(text):
            add(m, "fileenum")

    # funnelweb: <domain>/report.csv -> rows with Category == Email
    for p in _glob(outdir, "*/report.csv"):
        header, rows = _read_csv(p)
        low = [h.lower() for h in header]
        if "category" in low and "detail" in low:
            ci, di = low.index("category"), low.index("detail")
            for r in rows:
                if len(r) > max(ci, di) and r[ci].strip().lower() == "email":
                    add(r[di], "funnelweb")

    headers = ["email", "sources"]
    out_rows = [[email, ", ".join(sorted(srcs))]
                for email, srcs in sorted(sources.items())]
    return (headers, out_rows)


def collect_dehashed(outdir: Path) -> tuple[tuple[list[str], list[list[str]]],
                                            tuple[list[str], list[list[str]]]]:
    """DeHashed stays separate: (emails tab data, credstuff tab data)."""
    emails: set[str] = set()
    for p in _glob(outdir, "dehashed_*.emails.txt"):
        for line in p.read_text().splitlines():
            e = line.strip().lower()
            if e:
                emails.add(e)
    email_rows = [[e] for e in sorted(emails)]

    cred_rows: list[list[str]] = []
    seen = set()
    for p in _glob(outdir, "dehashed_*.credstuff.txt"):
        for line in p.read_text().splitlines():
            if "\t" in line:
                email, pw = line.split("\t", 1)
                key = (email.lower(), pw)
                if key not in seen:
                    seen.add(key)
                    cred_rows.append([email.lower(), pw])
    cred_rows.sort()
    return (["email"], email_rows), (["email", "password"], cred_rows)


def _dewrap_list_cell(v) -> str:
    """PartyOn sterilizes DeHashed values as a str(list): "['x']" or "['a', 'b']".
    Strip that skin for the final workbook. Single value -> bare; multiple values ->
    newline-joined within the cell. Any cell that is NOT actually a list literal is
    returned unchanged, so real brackets/commas inside a value are never mangled."""
    if v is None:
        return ""
    s = str(v)
    st = s.strip()
    if st.startswith("[") and st.endswith("]"):
        import ast
        try:
            parsed = ast.literal_eval(st)
        except (ValueError, SyntaxError):
            return s
        if isinstance(parsed, (list, tuple)):
            return "\n".join(str(x) for x in parsed if str(x) != "")
        return str(parsed)
    return s


_PARTYON_XLSX = "*_dehashed_report.xlsx"
_DEHASHED_16 = ["email", "ip_address", "username", "password", "hashed_password",
                "name", "dob", "license_plate", "address", "phone", "company",
                "url", "social", "cryptocurrency_address", "database_name",
                "raw_record"]


def _partyon_reports(outdir: Path) -> list[Path]:
    """Every PartyOn workbook under the engagement dir (one per domain), found in
    the DeHashed_Engagements/ folder PartyOn writes into the run's cwd."""
    seen: dict[str, Path] = {}
    for p in list(_glob(outdir, _PARTYON_XLSX)) + \
            sorted(Path(outdir).rglob(_PARTYON_XLSX)):
        seen.setdefault(str(p.resolve()), p)
    return list(seen.values())


def _domain_from_partyon(path: Path) -> str:
    n = path.name
    suf = "_dehashed_report.xlsx"
    return n[:-len(suf)] if n.lower().endswith(suf) else path.stem


def add_partyon_sheets(wb, outdir: Path, client_domain: str = "") -> int:
    """Build one 'PartyOn (DeHashed)' tab per domain from PartyOn's own workbook,
    stacked feed-style (each section led by a ===== label =====):
        Valid Accounts (from <domain>_valid_usernames.txt, no count)
        Combo Lists     (count; split <email> TAB <password> into two columns)
        Unique Emails   (count; verbatim)
        Omitted Backups (16 cols; ['..'] skin stripped)
        Breach Records  (16 cols; ['..'] skin stripped)
    Also builds a separate 'DeHashed Raw Results' tab (pretty-printed raw JSON).
    Returns the number of PartyOn tabs created."""
    from openpyxl import load_workbook
    outdir = Path(outdir)
    reports = _partyon_reports(outdir)
    if not reports:
        return 0
    multi = len(reports) > 1
    made = 0

    for rpt in reports:
        domain = _domain_from_partyon(rpt)
        try:
            ext = load_workbook(rpt, data_only=True, read_only=True)
        except Exception as e:  # noqa: BLE001
            log.warning("PartyOn workbook unreadable (%s): %s", rpt.name, e, exc_info=True)
            continue

        # map native sheet titles case-insensitively (tolerate a suffix on Breach)
        sheets = {s.lower(): ext[s] for s in ext.sheetnames}

        def _find(*names):
            for want in names:
                for key, ws in sheets.items():
                    if key == want or key.startswith(want):
                        return ws
            return None

        title = "PartyOn (DeHashed)" if not multi else f"PartyOn (DeHashed) {domain}"
        dst = wb.create_sheet(_safe_sheet_title(title, wb))
        r = 1

        def _section(label: str, count=None):
            nonlocal r
            hc = dst.cell(row=r, column=1, value=f"===== {label} =====")
            try:
                hc.font = HEADER_FONT
                hc.fill = HEADER_FILL
            except Exception:  # noqa: BLE001
                log.debug("non-fatal report step failed", exc_info=True)
            r += 1
            if count is not None:
                dst.cell(row=r, column=1, value=f"{label}: {count}")
                r += 1

        def _row(values):
            nonlocal r
            for c, v in enumerate(values, 1):
                if v not in (None, ""):
                    dst.cell(row=r, column=c, value=v)
            r += 1

        # full-domain banner (tab name may be truncated to 31 chars)
        bc = dst.cell(row=r, column=1, value=f"PartyOn (DeHashed) — {domain}")
        try:
            bc.font = HEADER_FONT
        except Exception:  # noqa: BLE001
            log.debug("non-fatal report step failed", exc_info=True)
        r += 2

        # 1) Valid Accounts (emails), no count — from the sidecar txt
        va = []
        for p in (list(_glob(outdir, f"{domain}_valid_usernames.txt")) +
                  sorted(Path(outdir).rglob(f"{domain}_valid_usernames.txt"))):
            try:
                va = [ln.strip() for ln in p.read_text(errors="replace").splitlines()
                      if ln.strip()]
            except OSError:
                va = []
            if va:
                break
        _section("Valid Accounts")
        for e in va:
            _row([e])
        if not va:
            _row(["(none)"])
        r += 1

        # 1b) Locked Accounts (with count) — plain one-per-line sidecar txt
        la = []
        for p in (list(_glob(outdir, f"{domain}_locked_accounts.txt")) +
                  sorted(Path(outdir).rglob(f"{domain}_locked_accounts.txt"))):
            try:
                la = [ln.strip() for ln in p.read_text(errors="replace").splitlines()
                      if ln.strip()]
            except OSError:
                la = []
            if la:
                break
        _section("Locked Accounts", count=len(la))
        for e in la:
            _row([e])
        r += 1

        # 2) Combo Lists — split "<email>\t<password>" into two columns, with count
        combo = _find("combo lists", "combo list")
        combo_rows = []
        if combo is not None:
            for row in combo.iter_rows(values_only=True):
                cell = next((c for c in row if c not in (None, "")), None)
                if cell is None:
                    continue
                txt = str(cell)
                if "\t" in txt:
                    email, pw = txt.split("\t", 1)
                else:
                    email, pw = txt, ""
                combo_rows.append([email.strip(), pw.strip()])
        _section("Combo Lists", count=sum(1 for cr in combo_rows if "@" in cr[0]))
        _row(["email", "password"])
        for cr in combo_rows:
            _row(cr)
        r += 1

        # 3) Unique Emails — verbatim, with count
        uniq = _find("unique emails", "unique email")
        uniq_rows = []
        if uniq is not None:
            for row in uniq.iter_rows(values_only=True):
                vals = [("" if v is None else v) for v in row]
                if any(str(v) != "" for v in vals):
                    uniq_rows.append(vals)
        # count actual email rows (contain '@'), so a header row — if the source
        # sheet has one — doesn't get counted and a missing header doesn't undercount
        u_count = sum(1 for row in uniq_rows if any("@" in str(c) for c in row))
        _section("Unique Emails", count=u_count)
        for ur in uniq_rows:
            _row(ur)
        r += 1

        # 4) Omitted Backups — 16 cols, skin-stripped
        omit = _find("omitted backups", "omitted backup")
        _section("Omitted Backups")
        _row(_DEHASHED_16)
        if omit is not None:
            first = True
            for row in omit.iter_rows(values_only=True):
                if first:            # skip the source header row
                    first = False
                    continue
                if any(v not in (None, "") for v in row):
                    _row([_dewrap_list_cell(v) for v in row])
        r += 1

        # 5) Breach Records — 16 cols, skin-stripped (LAST)
        breach = _find("breach records", "breach record", "dehashed results")
        _section("Breach Records")
        _row(_DEHASHED_16)
        if breach is not None:
            first = True
            for row in breach.iter_rows(values_only=True):
                if first:
                    first = False
                    continue
                if any(v not in (None, "") for v in row):
                    _row([_dewrap_list_cell(v) for v in row])

        dst.column_dimensions["A"].width = 42
        try:
            ext.close()
        except Exception:  # noqa: BLE001
            log.debug("non-fatal report step failed", exc_info=True)
        made += 1

        # ---- separate raw-JSON tab (best-effort, pretty-printed) ----
        _add_dehashed_raw_tab(wb, outdir, domain, multi)

    if made:
        print(f"[report] built {made} PartyOn (DeHashed) tab(s)")
    return made


def _add_dehashed_raw_tab(wb, outdir: Path, domain: str, multi: bool) -> None:
    """Pretty-print <domain>_raw_api_dump.json into a back-of-book tab. Best-effort:
    raw API dumps don't map to a grid, so we render readable indented text."""
    import json as _json
    src = None
    for p in (list(_glob(outdir, f"{domain}_raw_api_dump.json")) +
              sorted(Path(outdir).rglob(f"{domain}_raw_api_dump.json"))):
        src = p
        break
    if src is None:
        return
    try:
        raw = src.read_text(errors="replace")
    except OSError:
        return
    try:
        text = _json.dumps(_json.loads(raw), indent=2, ensure_ascii=False)
    except ValueError:
        text = raw   # not valid JSON — dump as-is
    title = "DeHashed Raw Results" if not multi else f"DeHashed Raw {domain}"
    ws = wb.create_sheet(_safe_sheet_title(title, wb))
    ws.cell(row=1, column=1, value=f"Raw DeHashed API dump — {domain}").font = HEADER_FONT
    _CAP = 50_000
    lines = text.splitlines()
    for i, ln in enumerate(lines[:_CAP], start=3):
        ws.cell(row=i, column=1, value=ln)
    if len(lines) > _CAP:
        ws.cell(row=_CAP + 4, column=1,
                value=f"[truncated — {len(lines) - _CAP} more line(s); "
                      f"see {src.name} on disk]")
    ws.column_dimensions["A"].width = 100


def add_testssl_sheet(wb, outdir: Path) -> int:
    """Stack every testssl_<host>_<port>.json (--jsonfile-pretty) into one readable
    'testssl' tab, each endpoint led by a ===== host:port ===== break. Raw-ish: we
    render testssl's own findings (id | severity | finding); if a file's shape is
    unexpected we fall back to pretty-printed JSON text so nothing is invisible.
    Returns 1 if the tab was created, else 0."""
    import json as _json
    outdir = Path(outdir)
    files = sorted(_glob(outdir, "testssl_*.json")) or \
        sorted(Path(outdir).rglob("testssl_*.json"))
    if not files:
        return 0
    ws = wb.create_sheet(_safe_sheet_title("testssl", wb))
    r = 1
    _CAP = 50_000

    def _hostport(path: Path) -> str:
        stem = path.stem[len("testssl_"):] if path.stem.startswith("testssl_") else path.stem
        host, _, port = stem.rpartition("_")
        return f"{host}:{port}" if host else stem

    for f in files:
        if r > _CAP:
            ws.cell(row=r, column=1, value="[truncated — testssl output exceeded cap]")
            break
        hp = _hostport(f)
        hc = ws.cell(row=r, column=1, value=f"===== {hp} =====")
        try:
            hc.font = HEADER_FONT
            hc.fill = HEADER_FILL
        except Exception:  # noqa: BLE001
            log.debug("non-fatal report step failed", exc_info=True)
        r += 1
        try:
            data = _json.loads(f.read_text(errors="replace"))
        except (ValueError, OSError) as e:
            ws.cell(row=r, column=1, value=f"(unreadable: {e})")
            r += 2
            continue
        # testssl --jsonfile-pretty: a list of finding dicts, or a wrapper dict
        findings = data if isinstance(data, list) else \
            (data.get("scanResult") or data.get("findings") or [])
        if isinstance(findings, list) and findings and isinstance(findings[0], dict) \
                and ("finding" in findings[0] or "severity" in findings[0] or "id" in findings[0]):
            ws.cell(row=r, column=1, value="id")
            ws.cell(row=r, column=2, value="severity")
            ws.cell(row=r, column=3, value="finding")
            r += 1
            for item in findings:
                if not isinstance(item, dict):
                    continue
                ws.cell(row=r, column=1, value=str(item.get("id", "")))
                ws.cell(row=r, column=2, value=str(item.get("severity", "")))
                ws.cell(row=r, column=3, value=str(item.get("finding", ""))[:1000])
                r += 1
                if r > _CAP:
                    break
        else:
            # unexpected shape -> pretty-print raw so it's still visible
            try:
                text = _json.dumps(data, indent=2, ensure_ascii=False)
            except ValueError:
                text = f.read_text(errors="replace")
            for ln in text.splitlines():
                ws.cell(row=r, column=1, value=ln)
                r += 1
                if r > _CAP:
                    break
        r += 1  # blank spacer between endpoints
    ws.column_dimensions["A"].width = 40
    ws.column_dimensions["B"].width = 12
    ws.column_dimensions["C"].width = 100
    print("[report] built testssl tab")
    return 1


def _collect_other_quickwins(outdir: Path) -> list[list[str]]:
    """Non-CVSS 'quick win' leads for the lower zone of the Findings tab:
    CONFIRMED subdomain takeovers (from parse_takeover — nuclei-confirmed, not the
    candidate list), login portals, and 403 bypasses. 6-col shape to match the
    scored zone: [Severity, CVSS, Source, Target, Finding, Detail]."""
    rows: list[list[str]] = []
    # confirmed subdomain takeovers (nuclei-confirmed only)
    try:
        from .takeover import parse_takeover
        for f in parse_takeover(outdir):
            row = f.as_row()  # [subdomain, service, template, severity, matched]
            sub = row[0] if len(row) > 0 else ""
            svc = row[1] if len(row) > 1 else ""
            tmpl = row[2] if len(row) > 2 else ""
            rows.append(["", "", "takeover", sub,
                         "Subdomain Takeover (confirmed)",
                         f"{svc} / {tmpl}".strip(" /")])
    except Exception:  # noqa: BLE001
        # data-carrying: this can silently drop CONFIRMED subdomain takeovers
        # from the findings tab, so warn (with traceback under NIGREDO_DEBUG).
        log.warning("subdomain takeover rows skipped — findings may be incomplete",
                    exc_info=True)
    # login portals (FunnelWeb report.csv), deduped by URL
    seen = set()
    for p in sorted(Path(outdir).glob("*/report.csv")):
        try:
            _, rrows = _read_csv(p)
        except OSError:
            continue
        for r in rrows:
            if r and len(r) >= 2 and r[0].strip().lower() == "login portal":
                url = r[1].strip()
                k = url.rstrip("/").lower()
                if url and k not in seen:
                    seen.add(k)
                    rows.append(["", "", "funnelweb", url, "Login Portal",
                                 "auth surface — cred testing"])
    # 403 bypasses (nomore403)
    for p in sorted(Path(outdir).glob("nomore403*.jsonl")):
        try:
            for ln in p.read_text(errors="replace").splitlines():
                low = ln.lower()
                if '"bypass"' in low or '"200"' in ln:
                    rows.append(["", "", "nomore403", ln.strip()[:120],
                                 "403 Bypass", "possible protection bypass"])
        except OSError:
            pass
    return rows


def collect_files(outdir: Path) -> tuple[list[str], list[list[str]]]:
    """Merge fileenum cleaned rows + funnelweb document rows into one schema,
    DEDUPED BY SOURCE URL. fileenum and FunnelWeb can each independently find the
    same file; we keep the first occurrence of each URL so every unique file
    appears exactly once (no copies), while different URLs are all preserved."""
    headers = ["URL", "FileName", "FileType", "Platform",
               "Author", "Creator", "CreatorTool", "Producer", "LastModifiedBy",
               "Company", "Software", "Template", "Created", "Modified", "Source"]
    out: list[list[str]] = []
    seen_urls: set[str] = set()
    _NCOLS = 14   # columns before Source

    def _norm_url(u: str) -> str:
        return (u or "").strip().rstrip("/").lower()

    for p in _glob(outdir, "fileenum_*.clean.csv"):
        header, rows = _read_csv(p)
        # map by header name so column order changes don't misalign
        hlow = [h.strip().lower() for h in (header or [])]
        want = ["url", "filename", "filetype", "platform", "author", "creator",
                "creatortool", "producer", "lastmodifiedby", "company",
                "software", "template", "created", "modified"]
        idx = {w: hlow.index(w) for w in want if w in hlow}
        for r in rows:
            vals = [r[idx[w]] if w in idx and idx[w] < len(r) else "" for w in want]
            key = _norm_url(vals[0])
            if key and key in seen_urls:
                continue
            if key:
                seen_urls.add(key)
            out.append(vals + ["fileenum"])

    # funnelweb document rows: Category in (Document, CDN Document)
    for p in _glob(outdir, "*/report.csv"):
        header, rows = _read_csv(p)
        low = [h.lower() for h in header]
        if "category" not in low:
            continue
        ci = low.index("category")
        di = low.index("detail") if "detail" in low else 1
        si = low.index("source url") if "source url" in low else 2
        for r in rows:
            if len(r) <= max(ci, di, si):
                continue
            if r[ci].strip() in ("Document", "CDN Document"):
                fname = r[di]
                url = r[si]
                key = _norm_url(url)
                if key and key in seen_urls:
                    continue      # already have this file from fileenum (or dup)
                if key:
                    seen_urls.add(key)
                ext = os.path.splitext(fname)[1].lstrip(".").lower()
                # url, filename, filetype, then blanks for the 10 metadata cols
                row = [url, fname, ext] + [""] * (_NCOLS - 3)
                out.append(row + ["funnelweb"])

    return (headers, out)


def collect_dnstwist(outdir: Path) -> tuple[list[str], list[list[str]]]:
    headers = ["type", "domain", "registrar", "ns_records", "source_domain"]
    out: list[list[str]] = []
    for p in _glob(outdir, "dnstwist_*.csv"):
        src = p.stem.replace("dnstwist_", "")
        _, rows = _read_csv(p)
        for r in rows:
            r = (r + [""] * 4)[:4]
            out.append(r + [src])
    return (headers, out)


def collect_subdomains(outdir: Path) -> tuple[list[str], list[list[str]]]:
    headers = ["subdomain", "type", "value", "source_domain"]
    out: list[list[str]] = []
    for p in _glob(outdir, "subdomains_*.clean.csv"):
        src = p.stem.replace("subdomains_", "").replace(".clean", "")
        _, rows = _read_csv(p)
        for r in rows:
            r = (r + [""] * 3)[:3]
            out.append(r + [src])
    return (headers, out)


def collect_text_reports(outdir: Path, pattern: str) -> list[tuple[str, str]]:
    """Return (domain, text) for each matching .txt report (dnsrecon, dkim)."""
    out = []
    for p in _glob(outdir, pattern):
        out.append((p.stem, p.read_text(errors="replace")))
    return out


# ---------- workbook assembly ----------

def _style_sheet(ws, headers: list[str]):
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "A2"


def _client_header_row(ws, client_domain: str, ncols: int):
    """Insert a client-primary-domain header row spanning the tool's columns.

    Tool tabs are client-SECTIONED: each client's data sits under a banner row
    naming that client's primary domain. Today that's one section per tab, but
    the structure is multi-client-ready — a holding-firm engagement with several
    sibling domains just gets additional '=== <domain> ===' banner blocks stacked
    down the same tab (same tool, same columns, more rows), no new tabs.
    """
    from openpyxl.styles import Font, PatternFill, Alignment
    r = ws.max_row + 1 if ws.max_row > 1 else 1
    cell = ws.cell(row=r, column=1, value=f"◆ CLIENT: {client_domain}")
    cell.font = Font(name=FONT, size=FONT_SIZE + 1, bold=True, color="FFFFFF")
    cell.fill = PatternFill("solid", fgColor="404040")
    cell.alignment = Alignment(horizontal="left")
    # merge across the tool's columns so it reads as a full-width banner
    if ncols > 1:
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=ncols)
    return r


def _add_table_sheet(wb, title: str, headers: list[str], rows: list[list[str]],
                     note: str = "", client_domain: str = ""):
    ws = wb.create_sheet(_safe_sheet_title(title, wb))
    # optional client-domain banner above the column headers (multi-client-ready)
    if client_domain:
        _client_header_row(ws, client_domain, len(headers))
        # column headers go on the NEXT row after the banner
        hrow = ws.max_row + 1
        for c, h in enumerate(headers, 1):
            cell = ws.cell(row=hrow, column=c, value=h)
            cell.font = HEADER_FONT
            cell.fill = HEADER_FILL
        for r in rows:
            ws.append(r)
        for row in ws.iter_rows(min_row=hrow + 1):
            for cell in row:
                cell.font = BODY_FONT
    else:
        _style_sheet(ws, headers)
        for r in rows:
            ws.append(r)
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                cell.font = BODY_FONT
    # column widths (use openpyxl's letter helper, not a possibly-merged row-1 cell)
    from openpyxl.utils import get_column_letter
    for c in range(1, len(headers) + 1):
        maxlen = len(headers[c - 1])
        for r in rows[:200]:
            if c - 1 < len(r):
                maxlen = max(maxlen, len(str(r[c - 1])))
        ws.column_dimensions[get_column_letter(c)].width = min(maxlen + 2, 60)
    # optional caveat/note row appended below the table (e.g. the PoC malware warning)
    if note:
        ws.append([])
        ws.append([note])
    return ws


def _add_tool_scribe_sheet(wb, cl, _wbk):
    """One sheet per tool with four columns SIDE BY SIDE:
        A: Concise (blank for now — built later)
        B: Raw report (every file the tool wrote, concatenated)
        C: Error log (the tool's *_errors.txt + FAILED lines)
        D: Target + Command (from commands.log, target+command together)
    Each column is filled top-to-bottom independently; a column with no data is
    left blank. Additive — removes nothing from the workbook.
    """
    disp = cl.get("display") or cl.get("tool") or "tool"
    # Label every scribe tab "(Raw)" — it's the raw-output audit tab, and this
    # keeps it distinct from any dedicated formatted tab of the same tool
    # (e.g. "DKIM" formatted vs "DKIM (Raw)" scribe) instead of colliding.
    # _safe_sheet_title(..., wb) guarantees a unique name case-insensitively, so a
    # scribe "subdomains (Raw)" can't silently collide with "Subdomains (Raw)".
    title = _safe_sheet_title(f"{disp[:22]} (Raw)", wb)
    ws = wb.create_sheet(title)

    # header row
    headers = ["Concise", "Raw report", "Error log", "Target + Command"]
    for c, h in enumerate(headers, 1):
        ws.cell(row=1, column=c, value=h)

    # build each column's lines
    concise_lines: list[str] = []          # intentionally blank for now

    raw_lines: list[str] = []
    for f in cl.get("raw_files", []):
        raw_lines.append(f"=== {f.name} ===")
        raw_lines.extend(_wbk._read_text(f, limit_lines=5000))
        raw_lines.append("")

    err_lines = list(cl.get("errors", []) or [])
    cmd_lines = list(cl.get("commands", []) or [])

    # write columns side by side, each starting at row 2
    for col, lines in enumerate(
            (concise_lines, raw_lines, err_lines, cmd_lines), start=1):
        r = 2
        for line in lines:
            ws.cell(row=r, column=col, value=str(line)[:32000])
            r += 1

    # reasonable column widths
    ws.column_dimensions["A"].width = 40
    ws.column_dimensions["B"].width = 100
    ws.column_dimensions["C"].width = 60
    ws.column_dimensions["D"].width = 80
    return ws


def _add_text_sheet(wb, title: str, sections: list[tuple[str, str]]):
    ws = wb.create_sheet(_safe_sheet_title(title, wb))
    ws.cell(row=1, column=1, value=f"{title} (per-domain reports)").font = HEADER_FONT
    ws.cell(row=1, column=1).fill = HEADER_FILL
    row = 3
    for name, text in sections:
        ws.cell(row=row, column=1, value=name).font = BOLD_FONT
        row += 1
        for line in text.splitlines():
            ws.cell(row=row, column=1, value=line).font = BODY_FONT
            row += 1
        row += 2
    ws.column_dimensions["A"].width = 100
    return ws


def collect_buckets(outdir: Path) -> tuple[list[str], list[list[str]]]:
    """Merge GrayHatWarfare bucket CSVs across domains."""
    headers = ["Provider", "Bucket URL", "Status", "File Count",
               "First Discovered", "source_domain"]
    out: list[list[str]] = []
    for p in _glob(outdir, "grayhat_*.buckets.csv"):
        src = p.stem.replace("grayhat_", "").replace(".buckets", "")
        _, rows = _read_csv(p)
        for r in rows:
            r = (r + [""] * 5)[:5]
            out.append(r + [src])
    return (headers, out)


def collect_bucket_files(outdir: Path) -> tuple[list[str], list[list[str]]]:
    """Merge GrayHatWarfare file CSVs across domains."""
    headers = ["Provider", "Bucket URL", "Filename", "Full Path", "File URL",
               "Size", "Sensitive", "source_domain"]
    out: list[list[str]] = []
    for p in _glob(outdir, "grayhat_*.files.csv"):
        src = p.stem.replace("grayhat_", "").replace(".files", "")
        _, rows = _read_csv(p)
        for r in rows:
            r = (r + [""] * 7)[:7]
            out.append(r + [src])
    # sort sensitive files to the top for triage
    out.sort(key=lambda r: (r[6] != "Y", r[1], r[2]))
    return (headers, out)


def collect_funnelweb_findings(outdir):
    """Ingest ALL of FunnelWeb's report.csv categories that the main report
    doesn't already pull (Email + Document are handled elsewhere). This captures
    JS Endpoints (from jsluice), Skipped Links, login/auth findings, and anything
    else FunnelWeb recorded — which otherwise stays stranded in FunnelWeb's own
    CSV and never reaches the workbook. Returns (header, rows) for a table sheet.

    Also folds in jsluice_secrets.txt (raw jsluice secret hits) which were
    previously only flagged Y/N and left in a file nobody was told to read."""
    header = ["Category", "Detail", "Source URL", "Extra"]
    rows = []
    # Categories that ALREADY have their own dedicated sheets elsewhere in the
    # report — exclude them here so findings aren't duplicated across two sheets:
    #   Email/Document       -> Emails + Files sheets
    #   Login Portal         -> Login Portals sheet
    # We keep the genuinely-orphaned categories (JS Endpoint, Secret, Skipped
    # Link, JS Secret, etc.) that otherwise never reach the workbook.
    already_handled = {"email", "document", "cdn document", "login portal"}
    for p in _glob(outdir, "*/report.csv"):
        h, rr = _read_csv(p)
        low = [x.lower() for x in h]
        if "category" not in low:
            continue
        ci = low.index("category")
        di = low.index("detail") if "detail" in low else 1
        si = low.index("source url") if "source url" in low else 2
        for r in rr:
            if len(r) <= max(ci, di, si):
                continue
            cat = r[ci].strip()
            if cat.lower() in already_handled:
                continue     # emails + docs already have dedicated sheets
            extra = ""
            if len(r) > max(ci, di, si) + 1:
                extra = " | ".join(c for c in r[max(ci, di, si) + 1:] if c)
            rows.append([cat, r[di], r[si], extra])

    # jsluice secrets — surface the raw file content (was only a Y/N flag before)
    for p in _glob(outdir, "*/js/jsluice_secrets.txt"):
        try:
            body = Path(p).read_text(errors="replace").strip()
        except OSError:
            continue
        if body:
            for line in body.splitlines():
                if line.strip():
                    rows.append(["JS Secret (jsluice)", line.strip(), str(p), ""])

    return header, rows


def _dns_pipe_rows(outdir):
    """Build DNS rows as 3 fields (col1|type|col3) from dnsrecon JSON, grouped by
    record type. col1 = address/IP when the record has one, else the domain;
    col3 = the target/name/value. Skips the useless Version/header element."""
    import json as _json
    from pathlib import Path
    _ORDER = ["SOA", "NS", "MX", "A", "AAAA", "CNAME", "CAA", "SRV", "TXT", "SPF", "PTR"]
    by_type = {}
    for jp in Path(outdir).glob("dnsrecon_*.json"):
        try:
            data = _json.loads(jp.read_text(errors="replace"))
        except (ValueError, OSError):
            continue
        recs = data if isinstance(data, list) else data.get("records", data)
        if not isinstance(recs, list):
            continue
        for rec in recs:
            if not isinstance(rec, dict):
                continue
            rtype = str(rec.get("type", "")).upper()
            if not rtype or "Version" in rec:      # skip header/version element
                continue
            addr = rec.get("address", "")
            name = rec.get("name", "") or rec.get("domain", "")
            target = (rec.get("target") or rec.get("exchange") or rec.get("mname")
                      or rec.get("strings") or rec.get("address") or "")
            # col1 preference: address (IP) if present, else the domain/name
            if rtype in ("A", "AAAA", "NS", "MX", "PTR", "SRV") and addr:
                c1, c3 = addr, (name or target)
                if rtype in ("NS", "MX", "SRV"):
                    c1, c3 = addr, target
            else:
                c1, c3 = (name or rec.get("domain", "")), target
            by_type.setdefault(rtype, []).append((str(c1), rtype, str(c3)))
    # emit grouped in display order, then any leftover types
    ordered = []
    for t in _ORDER:
        if t in by_type:
            ordered.extend(sorted(by_type[t]))
    for t in sorted(by_type):
        if t not in _ORDER:
            ordered.extend(sorted(by_type[t]))
    return ordered


def _dkim_pipe_rows(outdir):
    """DKIM as (record name, record) pairs for the DNS tab. dkim_*.txt is a
    STRUCTURED block per selector (selector:/name:/status:/record:), NOT a
    pipe-delimited list. B9: use the `name:` value (the fqdn) as the record name,
    paired with the `record:` value — not the literal field labels."""
    from pathlib import Path
    rows = []
    for fp in Path(outdir).glob("dkim_*.txt"):
        try:
            lines = fp.read_text(errors="replace").splitlines()
        except OSError:
            continue
        cur_name = ""
        for ln in lines:
            t = ln.strip()
            low = t.lower()
            if low.startswith("name:"):
                cur_name = t.split(":", 1)[1].strip()
            elif low.startswith("record:"):
                rec = t.split(":", 1)[1].strip()
                if cur_name:
                    rows.append((cur_name, rec))
    return rows


def add_dns_records_sheet(wb, outdir):
    """DNS records tab: pipe-split into cells, grouped by type, DKIM at the bottom.
    Falls back to nothing if no dnsrecon json (caller still adds the text DNS)."""
    from openpyxl.styles import Font
    rows = _dns_pipe_rows(outdir)
    dkim = _dkim_pipe_rows(outdir)
    if not rows and not dkim:
        return False
    ws = wb.create_sheet("DNS")
    ws.cell(row=1, column=1, value="Value / Host")
    ws.cell(row=1, column=2, value="Type")
    ws.cell(row=1, column=3, value="Target / Record")
    for c in (1, 2, 3):
        ws.cell(row=1, column=c).font = Font(bold=True)
    # B10: sort by record type (canonical order) then numerically by the IP in
    # the left column (A/AAAA/CNAME/NS/MX carry it; TXT/SOA don't -> sort after).
    _type_rank = {"A": 0, "AAAA": 1, "CNAME": 2, "MX": 3, "NS": 4, "SOA": 5,
                  "TXT": 6, "PTR": 7, "SRV": 8, "CAA": 9}
    def _ip_key(v):
        import ipaddress
        try:
            return (0, int(ipaddress.ip_address(str(v).strip())))
        except ValueError:
            return (1, str(v).strip().lower())
    rows = sorted(rows, key=lambda t: (_type_rank.get(str(t[1]).upper(), 99),
                                       _ip_key(t[0]), str(t[2]).lower()))
    r = 2
    last_type = None
    for c1, rtype, c3 in rows:
        if last_type is not None and rtype != last_type:
            r += 1   # blank row between record-type sections
        ws.cell(row=r, column=1, value=c1)
        ws.cell(row=r, column=2, value=rtype)
        ws.cell(row=r, column=3, value=c3)
        last_type = rtype
        r += 1
    if dkim:
        r += 2
        h = ws.cell(row=r, column=1, value="DKIM")
        h.font = Font(bold=True)
        r += 1
        for name, rec in dkim:
            ws.cell(row=r, column=1, value=name)
            ws.cell(row=r, column=2, value="DKIM")
            ws.cell(row=r, column=3, value=rec)
            r += 1
    ws.column_dimensions["A"].width = 40
    ws.column_dimensions["B"].width = 10
    ws.column_dimensions["C"].width = 90
    return True


def merge_external_workbooks(wb, outdir):
    """Fold other tools' own .xlsx workbooks into the final report. FunnelWeb's
    workbook (all its sheets) is STACKED into a single "FunnelWeb Raw" tab, read
    top-to-bottom like a feed (each source sheet gets a header, then its rows,
    then blank spacer). Other tools' workbooks get one tab per sheet, tool-titled."""
    from pathlib import Path
    from openpyxl import load_workbook
    outdir = Path(outdir)
    existing = {s.lower() for s in wb.sheetnames}

    # ---- FunnelWeb: stack ALL its sheets into ONE "FunnelWeb Raw" tab ----
    # Exclude PartyOn's workbook: it's named <domain>_dehashed_report.xlsx, which
    # also matches *_report.xlsx but is handled by the dedicated PartyOn stacker.
    fw_files = [p for p in sorted(outdir.rglob("*_report.xlsx"))
                if not p.name.lower().endswith("_dehashed_report.xlsx")]
    fw_stacked = 0
    if fw_files:
        title = "FunnelWeb Raw"
        if title.lower() not in existing:
            dst = wb.create_sheet(title)
            existing.add(title.lower())
            r = 1
            for path in fw_files:
                try:
                    ext = load_workbook(path, data_only=True, read_only=True)
                except Exception:  # noqa: BLE001
                    continue
                for sname in ext.sheetnames:
                    src = ext[sname]
                    # section header for this source sheet (feed-style)
                    hc = dst.cell(row=r, column=1, value=f"===== {sname} =====")
                    try:
                        hc.font = HEADER_FONT
                        hc.fill = HEADER_FILL
                    except Exception:  # noqa: BLE001
                        log.debug("non-fatal report step failed", exc_info=True)
                    r += 1
                    for row in src.iter_rows(values_only=True):
                        if any(v is not None for v in row):
                            for c, v in enumerate(row, 1):
                                if v is not None:
                                    dst.cell(row=r, column=c, value=v)
                            r += 1
                    r += 2   # blank spacer between source sheets (feed break)
                    fw_stacked += 1
                try:
                    ext.close()
                except Exception:  # noqa: BLE001
                    log.debug("non-fatal report step failed", exc_info=True)
            dst.column_dimensions["A"].width = 60
        if fw_stacked:
            print(f"[report] stacked {fw_stacked} FunnelWeb sheet(s) into "
                  f"'FunnelWeb Raw'")

    # ---- other tools' workbooks: one tab per sheet, tool-titled ----
    merged = 0
    for path in outdir.glob("*.xlsx"):
        nm = path.name.lower()
        if nm in ("final_report.xlsx", "scan_summary.xlsx"):
            continue
        tool = path.stem
        try:
            ext = load_workbook(path, data_only=True, read_only=True)
        except Exception:  # noqa: BLE001
            continue
        for sname in ext.sheetnames:
            src = ext[sname]
            title = f"{tool} - {sname}"[:31].replace(":", "-")
            base, n = title, 2
            while title.lower() in existing:
                suf = f"_{n}"
                title = base[:31 - len(suf)] + suf
                n += 1
            existing.add(title.lower())
            dst = wb.create_sheet(title)
            for row in src.iter_rows(values_only=True):
                dst.append(list(row))
            merged += 1
        try:
            ext.close()
        except Exception:  # noqa: BLE001
            log.debug("non-fatal report step failed", exc_info=True)
    if merged:
        print(f"[report] merged {merged} other external workbook sheet(s)")
    return fw_stacked + merged


def add_spray_list_sheet(wb, outdir, spray_domains=None):
    """B8: consolidated password-spray list. Every email source (snov, LinkThief,
    fileenum, funnelweb, PartyOn valid) -> lowercase -> filter to client
    domain(s) -> dedup -> sort alphabetically. One column."""
    from openpyxl.styles import Font, PatternFill
    outdir = Path(outdir)
    doms = [d.strip().lstrip("@").lower() for d in (spray_domains or []) if d and d.strip()]
    emails = set()
    try:
        _hdr, rows = collect_emails(outdir)
        for r in rows:
            if r and "@" in str(r[0]):
                emails.add(str(r[0]).strip().lower())
    except Exception:  # noqa: BLE001
        # data-carrying: swallowing here silently drops harvested emails from
        # the spray list, so warn rather than pass.
        log.warning("email collection failed — spray list may be incomplete",
                    exc_info=True)
    for p in list(_glob(outdir, "*_valid_usernames.txt")) + \
            sorted(outdir.rglob("*_valid_usernames.txt")):
        try:
            for ln in p.read_text(errors="replace").splitlines():
                e = ln.strip().lower()
                if "@" in e:
                    emails.add(e)
        except OSError:
            continue
    if doms:
        emails = {e for e in emails if e.rsplit("@", 1)[-1] in doms}
    if not emails:
        return False
    final = sorted(emails)
    ws = wb.create_sheet("Spray List")
    hc = ws.cell(row=1, column=1, value=f"Spray List ({len(final)} addresses)")
    hc.font = Font(bold=True)
    for i, e in enumerate(final, 2):
        ws.cell(row=i, column=1, value=e)
    ws.column_dimensions["A"].width = 44
    return True


def build_report(outdir, report_path=None, funnelweb_summaries=None,
                 spray_domains=None, ledger=None) -> Path:
    outdir = Path(outdir)
    report_path = Path(report_path) if report_path else outdir / "final_report.xlsx"

    wb = Workbook()
    wb.remove(wb.active)  # drop default sheet

    # ---- GUARANTEED SAVE ----------------------------------------------------
    # Every sheet-builder below is best-effort. Historically, if ANY unwrapped
    # collector threw on real data, execution never reached wb.save() and the
    # ENTIRE report was lost — the run "completed" but wrote no xlsx (silent).
    # We now wrap the whole body so a single sheet's failure can't sink the
    # deliverable: whatever sheets succeeded still get saved, and the failure is
    # announced loudly (furnace alert) instead of vanishing. Partial > nothing.
    _build_ok = True
    try:
        _build_report_body(wb, outdir, report_path, funnelweb_summaries,
                           spray_domains, ledger)
    except Exception as e:  # noqa: BLE001
        _build_ok = False
        log.error("*** a sheet-builder crashed mid-report: %s — saving the "
                  "partial report with whatever completed ***", e, exc_info=True)
        try:
            from . import audit as _audit
            _audit._furnace_alert("report", f"failed to build report body: {e}")
        except Exception:  # noqa: BLE001
            log.debug("furnace alert failed", exc_info=True)

    if not wb.sheetnames:
        ws = wb.create_sheet("Report")
        ws.cell(row=1, column=1,
                value="Report generation failed before any sheet was built — "
                      "run the Adjudicator to rebuild from files on disk.")
    try:
        wb.save(report_path)
        print(f"[report] wrote {report_path}" if _build_ok
              else f"[report] wrote PARTIAL report to {report_path} "
                   f"(some sheets missing — see errors above)")
    except Exception as e:  # noqa: BLE001
        log.error("*** FAILED TO SAVE REPORT to %s: %s ***", report_path, e, exc_info=True)
        try:
            from . import audit as _audit
            _audit._furnace_alert("report", f"failed to save {report_path}: {e}")
        except Exception:  # noqa: BLE001
            log.debug("furnace alert failed", exc_info=True)
        return report_path

    # --- Embed original files INTO the .xlsx archive (travelling backup) ---
    try:
        from . import workbook as _wbk
        rd_files = _wbk.run_data_files(outdir)
        n = _wbk.embed_files_in_xlsx(report_path, rd_files)
        if n:
            print(f"[report] embedded {n} log/data file(s) into the workbook "
                  f"archive as a backup (extract with any unzip tool)")
    except Exception as e:  # noqa: BLE001
        log.warning("file embedding skipped: %s", e, exc_info=True)
    return report_path


def _restyle_all_sheets(wb, outdir, funnelweb_summaries):
    """One uniform pass over every sheet so the workbook reads like one product.

    - Cuts the redundant raw FunnelWeb dumps (the big 'At a Glance' rollup and
      the curated 'FunnelWeb Findings' tab already carry that data cleanly; the
      per-target RAW dumps and the metadata stub are JSON-ugly and redundant).
    - Adds a dark banner row (client · date · time) at the top of every sheet.
    - Applies uniform header/zebra/auto-fit styling.
    - Marks header-only sheets with a clean 'no findings' notice.
    """
    import time as _time
    from . import sheetstyle as S
    from openpyxl.styles import Font as _Font, PatternFill as _Fill, Alignment as _Al

    # resolve client = first domain entered (the one fed through email/file-enum),
    # else the engagement folder name for IP-only jobs.
    client = None
    dfile = outdir / "domains.txt"
    try:
        if dfile.is_file():
            first = [l.strip() for l in dfile.read_text().splitlines()
                     if l.strip() and not l.startswith("#")]
            client = first[0] if first else None
    except OSError:
        pass
    if not client:
        client = outdir.name
    ran_at = _time.strftime("%Y-%m-%d %H:%M")

    # 1) cut the redundant raw funnelweb tabs (keep 'At a Glance' + 'FunnelWeb Findings')
    _cut = []
    for ws in wb.worksheets:
        t = ws.title.lower()
        if t.startswith("fw - ") and "raw" in t:          # 'FW - <target> (RAW)'
            _cut.append(ws)
        elif t == "funnelweb (raw)":                      # metadata stub
            _cut.append(ws)
    for ws in _cut:
        del wb[ws.title]

    # 2) banner + styling on every remaining sheet
    banner_fill = _Fill("solid", fgColor="111827")
    banner_font = _Font(name=S.FONT, size=S.FONT_SIZE, bold=True, color="FFFFFF")
    for ws in wb.worksheets:
        ncols = max(ws.max_column, 1)
        # insert a banner row at the very top
        ws.insert_rows(1)
        b = ws.cell(row=1, column=1,
                    value=f"{client}   ·   scanned {ran_at}")
        b.font = banner_font
        b.fill = banner_fill
        b.alignment = _Al(horizontal="left", vertical="center")
        if ncols > 1:
            ws.merge_cells(start_row=1, start_column=1, end_row=1, end_column=ncols)
        for c in range(1, ncols + 1):
            ws.cell(row=1, column=c).fill = banner_fill
        # the real header is now on row 2; style from there
        try:
            S.style_header(ws, ncols, row=2)
            S.band_rows(ws, ncols, start=3)
            S.autofit(ws, ncols)
        except Exception:  # noqa: BLE001
            log.debug("style pass failed on %s", ws.title, exc_info=True)
        # header-only sheet? (banner + header + nothing) -> intentional notice
        if ws.max_row <= 2:
            ws.cell(row=3, column=1, value="No findings for this target.").font = \
                _Font(name=S.FONT, size=S.FONT_SIZE, italic=True, color="6B7280")


def _build_report_body(wb, outdir, report_path, funnelweb_summaries,
                       spray_domains, ledger):
    """All sheet-building. Split out so build_report() guarantees a save even if
    something here throws (see GUARANTEED SAVE)."""
    outdir = Path(outdir)

    # Client primary domain(s) for the tool-tab section banners. Today this is
    # one client (one banner per tool tab); a holding-firm engagement with several
    # sibling domains would stack more banner blocks down the same tabs later.
    _client = ""
    if spray_domains:
        doms = [d.strip().lstrip("@") for d in spray_domains if d and d.strip()]
        if doms:
            _client = doms[0] if len(doms) == 1 else ", ".join(doms[:3])
    # fall back to the engagement folder name if no domain was given (IP-only job)
    if not _client:
        _client = outdir.name

    # At a Glance — the single actionable-intelligence rollup from FunnelWeb.
    # Added first so it's the leftmost/priority tab.
    if funnelweb_summaries:
        try:
            from .scan_summary import add_at_a_glance_sheet
            add_at_a_glance_sheet(wb, funnelweb_summaries, outdir=outdir,
                                  spray_domains=spray_domains)
        except Exception as e:  # noqa: BLE001
            log.warning("At a Glance tab skipped: %s", e, exc_info=True)
        # Per-host raw tabs: 'FW - <host> (RAW)', one per crawled target, so each
        # host's findings are attributable (complements the merged At a Glance).
        try:
            from .scan_summary import add_funnelweb_raw_sheets
            add_funnelweb_raw_sheets(wb, funnelweb_summaries)
        except Exception as e:  # noqa: BLE001
            log.warning("FunnelWeb raw tabs skipped: %s", e, exc_info=True)

    # Phase-0 scan-summary sheets, FOLDED INTO the main report (they used to be a
    # SEPARATE scan_summary.xlsx workbook). Combining them here means one
    # consolidated deliverable instead of two files the operator has to cross-
    # reference. Each is guarded so a missing input just skips that sheet.
    # (web-hosts + metrics need live run-state not available at report time, so
    # they stay in phase-0's own build; everything outdir-derived folds in here.)
    try:
        from . import scan_summary as _ss
    except Exception:  # noqa: BLE001
        _ss = None
    if _ss is not None:
        for _name, _fn in (
            ("targets grid", lambda: _ss.add_targets_grid_sheet(wb, outdir)),
            ("analyst synthesis", lambda: _ss.add_analyst_synthesis_sheets(wb, outdir)),
            ("nuclei by host", lambda: _ss.add_nuclei_by_host_sheet(wb, outdir)),
            ("manual retest", lambda: _ss.add_manual_retest_sheet(wb, outdir)),
            ("hosts by port", lambda: _ss.add_hosts_by_port_sheet(wb, outdir)),
            ("takeover", lambda: _ss.add_takeover_sheet(wb, outdir)),
            ("shodan", lambda: _ss.add_shodan_sheet(wb, outdir)),
            ("httpx", lambda: _ss.add_httpx_sheet(wb, outdir)),
            ("katana", lambda: _ss.add_katana_sheet(wb, outdir)),
            ("gau", lambda: _ss.add_gau_sheet(wb, outdir)),
            ("ssh-audit", lambda: _ss.add_sshaudit_sheet(wb, outdir)),
            ("subdomain inventory",
             lambda: _ss.add_subdomain_inventory_sheet(wb, outdir)),
            # C2: previously scan_summary.xlsx-only tabs, now folded in.
            ("feroxbuster", lambda: _ss.add_feroxbuster_sheet(wb, outdir)),
            ("feroxbuster 200s", lambda: _ss.add_feroxbuster_concise_sheet(wb, outdir)),
            ("403 hotspots", lambda: _ss.add_feroxbuster_403_hotspots_sheet(wb, outdir)),
            ("403 bypasses", lambda: _ss.add_nomore403_sheet(wb, outdir)),
            ("ffuf raw", lambda: _ss.add_ffuf_raw_sheet(wb, outdir)),
            ("feroxbuster raw", lambda: _ss.add_feroxbuster_raw_sheet(wb, outdir)),
            ("scan summary", lambda: _ss.add_scan_summary_sheet(wb, outdir)),
            ("severity matrix",
             lambda: _ss.add_severity_matrix_sheet_from_disk(wb, outdir)),
            ("nessus vs nmap",
             lambda: _ss.add_nessus_vs_nmap_sheet_from_disk(wb, outdir)),
            ("cloud assets", lambda: _ss.add_cloud_assets_sheet(wb, outdir)),
            ("live urls", lambda: _ss.add_live_urls_sheet_from_disk(wb, outdir)),
            ("secrets", lambda: _ss.add_secrets_sheet(wb, outdir)),
            ("linkthief emails", lambda: _ss.add_linkthief_emails_sheet(wb, outdir, spray_domains)),
        ):
            try:
                _fn()
            except Exception as e:  # noqa: BLE001
                log.warning("phase-0 '%s' sheet skipped: %s", _name, e, exc_info=True)
        try:
            add_spray_list_sheet(wb, outdir, spray_domains)   # B8
        except Exception as e:  # noqa: BLE001
            log.warning("spray list skipped: %s", e, exc_info=True)

    # Emails (merged: snov + linkedin/emailenum + fileenum + funnelweb, non-DeHashed)
    eh, er = collect_emails(outdir)
    _add_table_sheet(wb, "Emails", eh, er, client_domain=_client)

    # Spray: TOTAL unique list (all sources incl DeHashed), filtered to the
    # user-defined primary domain(s) + spray_emails.txt
    sh, sr = collect_spray(outdir, spray_domains=spray_domains)
    _add_table_sheet(wb, "Spray", sh, sr, client_domain=_client)

    # DeHashed: superseded by add_partyon_sheets below. R-6 removed the old
    # collect_dehashed path (it read the dehashed_*.emails.txt convention that
    # nothing writes anymore, producing two permanently-empty tabs).

    # PartyOn (DeHashed): one stacked tab per domain from PartyOn's own workbook,
    # plus a back-of-book raw-JSON tab. Kept separate from the legacy tabs above.
    try:
        add_partyon_sheets(wb, outdir, client_domain=_client)
    except Exception as e:  # noqa: BLE001
        log.warning("PartyOn ingest skipped: %s", e, exc_info=True)

    # testssl: stack every endpoint's JSON into one readable 'testssl' tab
    try:
        add_testssl_sheet(wb, outdir)
    except Exception as e:  # noqa: BLE001
        log.warning("testssl ingest skipped: %s", e, exc_info=True)

    # Files (fileenum + funnelweb docs)
    fh, fr = collect_files(outdir)
    _add_table_sheet(wb, "Files", fh, fr, client_domain=_client)

    # Lookalikes (dnstwist)
    th, tr = collect_dnstwist(outdir)
    _add_table_sheet(wb, "Domain Squatting", th, tr, client_domain=_client)

    # Subdomains
    sh, sr = collect_subdomains(outdir)
    _add_table_sheet(wb, "Subdomains", sh, sr, client_domain=_client)

    # Cloud storage (GrayHatWarfare) — buckets + files
    bh, br = collect_buckets(outdir)
    _add_table_sheet(wb, "Cloud Buckets", bh, br, client_domain=_client)
    bfh, bfr = collect_bucket_files(outdir)
    _add_table_sheet(wb, "Cloud Files", bfh, bfr, client_domain=_client)

    # DNS = the concise/organized pipe-split, type-grouped view WITH DKIM folded
    # in at the bottom (this is the report view). DKIM = the raw DKIM list only.
    # (The old separate "DNS Records" tab is removed — this IS that view, named
    # "DNS".) The raw dnsrecon text still travels via the per-tool (Raw) scribe.
    try:
        add_dns_records_sheet(wb, outdir)   # creates the "DNS" tab now
    except Exception as e:  # noqa: BLE001
        log.warning("DNS tab skipped: %s", e, exc_info=True)
    _add_text_sheet(wb, "DKIM", collect_text_reports(outdir, "dkim_*.txt"))

    # Fold other tools' own .xlsx workbooks (FunnelWeb's At-a-Glance/Raw Data)
    # into the final report, each sheet prefixed by the producing tool.
    try:
        merge_external_workbooks(wb, outdir)
    except Exception as e:  # noqa: BLE001
        log.warning("external workbook merge skipped: %s", e, exc_info=True)

    # Burp Suite export: scope JSON (import via Burp UI) + consolidated URL feed,
    # and the "Burp Target URLs" tab so the list lives in the workbook too.
    try:
        from . import burp_export
        _primary = []
        try:
            from . import runmode
            _primary = list(runmode.answer("_domains", []) or [])
        except Exception:  # noqa: BLE001
            _primary = []
        if not _primary and _client:
            _primary = [_client]
        burp_export.build_scope_json(outdir, _primary)
        _bpath, _burls = burp_export.build_url_feed(outdir)
        if _burls:
            ws_b = wb.create_sheet("Burp Target URLs")
            hb = ws_b.cell(row=1, column=1, value="Discovered URL (Burp feed)")
            hb.font = HEADER_FONT
            hb.fill = HEADER_FILL
            for i, u in enumerate(_burls, start=2):
                ws_b.cell(row=i, column=1, value=u).font = BODY_FONT
            ws_b.column_dimensions["A"].width = 90
            ws_b.freeze_panes = "A2"
    except Exception as e:  # noqa: BLE001
        log.warning("Burp export skipped: %s", e, exc_info=True)

    # FunnelWeb findings the main report doesn't otherwise pull: JS Endpoints
    # (jsluice), Skipped Links, login/auth findings, jsluice secrets. Previously
    # stranded in FunnelWeb's own report.csv / raw files.
    fwh, fwr = collect_funnelweb_findings(outdir)
    if fwr:
        _add_table_sheet(wb, "FunnelWeb Findings", fwh, fwr, client_domain=_client)

    # cvemap — CVEs for discovered technologies (from cvemap_findings.csv)
    cvemap_csv = Path(outdir) / "cvemap_findings.csv"
    if cvemap_csv.is_file():
        ch, cr = _read_csv(cvemap_csv)
        _add_table_sheet(wb, "CVEs (tech)", ch, cr, client_domain=_client)

    # IIS recon — internal-IP disclosure, shortnames, exposed high-value paths
    iis_rows = []
    for p in sorted(Path(outdir).glob("iis_*.txt")):
        for line in p.read_text(errors="replace").splitlines():
            parts = [x.strip() for x in line.split("|")]
            if len(parts) >= 3:
                iis_rows.append(parts[:3])
    if iis_rows:
        _add_table_sheet(wb, "IIS Recon", ["Type", "URL", "Detail"], iis_rows)

    # retire.js JS-component vulns, enriched with Snyk reference URLs (SerpAPI)
    try:
        from . import snyk_enrich
        import os as _os
        serp_key = _os.getenv("SERPAPI_KEY", "")
        retire_rows = snyk_enrich.enrich(outdir, api_key=serp_key)
        if retire_rows:
            _add_table_sheet(wb, "JS Vulns (retire.js)",
                             ["Component", "Version", "Severity", "CVE", "GHSA",
                              "Snyk URL", "Source File"], retire_rows)
    except Exception as e:  # noqa: BLE001
        log.warning("retire.js/Snyk tab skipped: %s", e, exc_info=True)

    # Master login-portal list (FunnelWeb detection folded across domains)
    login_rows = []
    for p in sorted(Path(outdir).glob("*/report.csv")):
        try:
            _, rows = _read_csv(p)
            for r in rows:
                if r and len(r) >= 2 and r[0].strip() == "Login Portal":
                    login_rows.append([r[1], r[-1] if len(r) > 4 else ""])
        except OSError:
            pass
    if login_rows:
        # dedupe by URL
        seen_l, uniq = set(), []
        for lr in login_rows:
            k = lr[0].rstrip("/").lower()
            if k not in seen_l:
                seen_l.add(k)
                uniq.append(lr)
        _add_table_sheet(wb, "Login Portals", ["URL", "Details"], uniq)

    # Run Notes — caveats recorded during the run (e.g. unverified company name)
    try:
        from .runmode import get_notes
        notes = get_notes()
    except Exception:  # noqa: BLE001
        notes = []
    if notes:
        ws = wb.create_sheet("Run Notes")
        ws.cell(row=1, column=1, value="Run Notes / Caveats").font = Font(bold=True)
        for i, note in enumerate(notes, start=2):
            ws.cell(row=i, column=1, value=f"• {note}")
        ws.column_dimensions["A"].width = 100

    # --- API Credits sheet: transparent per-tool credit spend for the run ---
    try:
        rows = []
        if ledger is not None:
            rows = ledger.summary_rows()
        if not rows:
            # fall back to reading the persisted ledger file if no live ledger
            led_file = outdir / ".api_credits.json"
            if led_file.is_file():
                from .api_budget import CreditLedger
                rows = CreditLedger(outdir).summary_rows()
        if rows:
            _add_table_sheet(wb, "API Credits",
                             ["Tool", "Credits", "Source"], rows)
    except Exception as e:  # noqa: BLE001
        log.warning("API Credits tab skipped: %s", e, exc_info=True)

    # --- Forks sheet: GitHub forks catalogued but NOT scanned (recorded only) ---
    try:
        fork_rows = []
        for ff in sorted(outdir.glob("gitleaks_*_forks.txt")):
            for line in ff.read_text(errors="replace").splitlines():
                line = line.strip()
                if not line:
                    continue
                parts = line.split("\t")
                name = parts[0] if parts else line
                url = parts[1] if len(parts) > 1 else ""
                fork_rows.append([name, url, "catalogued (not scanned)"])
        if fork_rows:
            _add_table_sheet(wb, "Forks (not scanned)",
                             ["Fork (owner/repo)", "URL", "Status"], fork_rows)
    except Exception as e:  # noqa: BLE001
        log.warning("Forks tab skipped: %s", e, exc_info=True)

    # --- FQDN<->IP pairs sheet: WebGet's per-IP FQDN assignment (its "first tab").
    # PRIMARY: results.tsv (ip -> all its FQDNs; WebGet does this best). FALLBACK:
    # fqdn_resolve's fqdn_pairs.json tiered audit (legacy / when WebGet didn't run).
    try:
        results_tsv = outdir / "results.tsv"
        pairs_file = outdir / "fqdn_pairs.json"
        if results_tsv.is_file():
            fqdn_rows = []
            for _ln in results_tsv.read_text(errors="replace").splitlines():
                _cols = [c.strip() for c in _ln.split("\t") if c.strip()]
                if len(_cols) < 2:
                    continue
                _ip = _cols[0]
                _names = []
                for _name in _cols[1:]:
                    _n = _name.split("=", 1)[1] if _name.startswith(("ptr=", "sub=")) else _name
                    if _n and _n != "NO_PTR":
                        _names.append(_n)
                if _names:
                    fqdn_rows.append([_ip, ", ".join(sorted(set(_names))),
                                      "WebGet (resolve+scope-confirm)"])
            if fqdn_rows:
                _add_table_sheet(wb, "FQDN Pairs",
                                 ["IP", "FQDN(s)", "Source"],
                                 fqdn_rows)
        elif pairs_file.is_file():
            import json as _json
            data = _json.loads(pairs_file.read_text())
            fqdn_rows = []
            for tier, label in (("confirmed_1to1", "1:1 confirmed (full scan)"),
                                ("confirmed_multi", "multi (harvest-only)"),
                                ("unconfirmed", "unconfirmed (report-only)")):
                for p in data.get(tier, []):
                    fqdn_rows.append([
                        p.get("ip", ""), p.get("fqdn", ""),
                        ", ".join(p.get("sources", [])),
                        str(len(set(p.get("sources", [])))), label,
                    ])
            if fqdn_rows:
                _add_table_sheet(wb, "FQDN Pairs",
                                 ["IP", "FQDN", "Confirmed by", "Votes", "Tier"],
                                 fqdn_rows)
    except Exception as e:  # noqa: BLE001
        log.warning("FQDN Pairs tab skipped: %s", e, exc_info=True)

    # --- Cache (Stockpiler Exp): public PoC exploits for the client's CVEs ---
    try:
        cache_file = outdir / "cache_pocs.json"
        if cache_file.is_file():
            import json as _json
            data = _json.loads(cache_file.read_text())
            cache_rows = []
            # CVE results first (primary), tech results after (noisy) — each PoC
            # grouped under the query that found it.
            for kind_filter in ("cve", "tech"):
                for entry in data:
                    if entry.get("kind") != kind_filter:
                        continue
                    for p in entry.get("pocs", []):
                        cache_rows.append([
                            entry.get("query", ""),
                            entry.get("kind", ""),
                            p.get("url", ""),
                            str(p.get("stars", 0)),
                            (p.get("description", "") or "")[:200],
                        ])
            if cache_rows:
                _add_table_sheet(
                    wb, "Cache",
                    ["Query (CVE/Tech)", "Type", "PoC URL", "Stars", "Description"],
                    cache_rows,
                    note=("PoCs are third-party. Some may be FAKE or MALWARE. "
                          "Review the source before executing. CVE results are "
                          "precise; tech-name results (bottom) are best-effort."))
    except Exception as e:  # noqa: BLE001
        log.warning("Cache tab skipped: %s", e, exc_info=True)

    # --- cloud_enum: active multi-cloud bucket brute-force findings ---
    try:
        from . import cloud_enum as _ce
        ce_rows = _ce.parse_findings(outdir)
        if ce_rows:
            _add_table_sheet(
                wb, "Cloud Enum",
                ["Provider", "Status", "Resource URL"],
                ce_rows,
                note="Active brute-force discoveries (AWS/Azure/GCP). OPEN/PUBLIC "
                     "resources may expose data — verify access scope manually.")
    except Exception as e:  # noqa: BLE001
        log.warning("Cloud Enum tab skipped: %s", e, exc_info=True)

    # --- LinkThief: full tiered LinkedIn worklist (the augmentation view) ---
    # The confident guesses (clean) first, then altered, then rejected/anomalies —
    # each WITH its source LinkedIn URL, so the analyst can manually verify the
    # confident ones and resolve the rejects by visiting the URLs. This is the
    # 20-30 min human-in-the-loop worklist, distinct from the merged Emails tab.
    try:
        lt_rows = []
        for pattern in ("linkthief_*.csv", "emails_*.csv"):
            for p in _glob(outdir, pattern):
                header, rows = _read_csv(p)
                hl = [h.lower() for h in header]
                def _col(name):
                    return hl.index(name) if name in hl else -1
                ci, ui = _col("category"), _col("linkedin_url")
                fi, li = _col("parsed_first"), _col("parsed_last")
                ei, ri = _col("attempted_email"), _col("reason")
                for r in rows:
                    def g(i):
                        return r[i] if 0 <= i < len(r) else ""
                    lt_rows.append([g(ci), g(fi), g(li), g(ei), g(ui), g(ri)])
        if lt_rows:
            _add_table_sheet(
                wb, "LinkThief",
                ["Category", "First", "Last", "Attempted Email",
                 "LinkedIn URL", "Reason"],
                lt_rows,
                note="Confident guesses (clean) first, then altered, then rejected. "
                     "Verify confident ones and resolve rejects by visiting the URLs "
                     "— confident guesses can still be wrong. This is the manual "
                     "augmentation worklist for building the true master list.")
    except Exception as e:  # noqa: BLE001
        log.warning("LinkThief tab skipped: %s", e, exc_info=True)

    # ============================================================
    # WORKBOOK STRUCTURE (inverted pyramid: concise -> raw)
    # Add the master/analytics/at-a-glance/run-data tabs, then reorder so the
    # actionable pages are at the front and the raw audit material is at the back.
    # ============================================================
    try:
        from . import workbook as _wbk

        # --- Aggregated error log (all tools -> one file at engagement root) ---
        try:
            elog = _wbk.write_aggregated_error_log(outdir)
            if elog:
                print(f"[report] aggregated error log -> {elog.name}")
        except Exception:  # noqa: BLE001
            log.debug("non-fatal report step failed", exc_info=True)

        # --- Findings: CVSS-scored vuln findings (Low->Critical, worst first),
        #     then a divider, then the non-CVSS 'other quick wins' below ---
        findings = _wbk.collect_severity_findings(outdir)
        scored = [f for f in findings
                  if f.get("severity") in ("Critical", "High", "Medium", "Low")]
        other = _collect_other_quickwins(outdir)
        if scored or other:
            fw = wb.create_sheet(_safe_sheet_title("Findings", wb))
            hdr = ["Severity", "CVSS", "Source", "Target", "Finding", "Detail"]
            for c, h in enumerate(hdr, 1):
                cell = fw.cell(row=1, column=c, value=h)
                cell.font = HEADER_FONT
                cell.fill = HEADER_FILL
            rr = 2
            for f in scored:   # already sorted Critical->Low by collect_severity_findings
                for c, v in enumerate([f["severity"], str(f["score"]), f["source"],
                                       f["target"], f["name"], f["detail"]], 1):
                    fw.cell(row=rr, column=c, value=v)
                rr += 1
            if other:
                dv = fw.cell(row=rr + 1, column=1,
                             value="── Other Quick Wins (no CVSS score) ──")
                dv.font = HEADER_FONT
                dv.fill = HEADER_FILL
                rr += 2
                for row in other:
                    for c, v in enumerate(row, 1):
                        if v:
                            fw.cell(row=rr, column=c, value=v)
                    rr += 1
            for col, w in zip("ABCDEF", (12, 8, 12, 40, 34, 60)):
                fw.column_dimensions[col].width = w
            fw.freeze_panes = "A2"
            # severity summary block (unchanged)
            summ = _wbk.severity_summary(findings)
            sev_rows = [[k, str(v)] for k, v in summ.items() if v]
            _add_table_sheet(wb, "At a Glance Summary",
                             ["Severity", "Count"], sev_rows)

        # --- Master Target list ---
        mt = _wbk.collect_master_targets(outdir)
        if mt:
            _add_table_sheet(wb, "Master Targets", ["Tool", "Target"], mt)

        # --- Master Error log (sorted by tool) ---
        me = _wbk.collect_master_errors(outdir)
        if me:
            _add_table_sheet(wb, "Master Errors", ["Tool", "Error"], me)

        # --- Analytics: runtime, API cost, per-tool status ---
        an_rows = []
        if ledger is not None:
            try:
                for row in (ledger.summary_rows() or []):
                    # summary_rows returns [tool, ...cost fields]; prefix as API cost
                    an_rows.append(["API cost"] + [str(x) for x in row][:2])
            except Exception:  # noqa: BLE001
                log.debug("non-fatal report step failed", exc_info=True)
        # runtime + tool status from the audit markers / command log
        rl = outdir / "resource_log.txt"
        if rl.is_file():
            an_rows.append(["resource_log", "see Run Data tab", "CPU/RAM samples"])
        for done in _glob(outdir, "*.done"):
            an_rows.append(["completed", done.stem, "ok"])
        if an_rows:
            _add_table_sheet(wb, "Analytics",
                             ["Metric", "Item", "Value"], an_rows)

        # --- Run Data tab: viewable copies of the log/data files ---
        rd_files = _wbk.run_data_files(outdir)
        if rd_files:
            sections = []
            for f in rd_files:
                text = "\n".join(_wbk._read_text(f, limit_lines=2000))
                sections.append((f.name, text))
            _add_text_sheet(wb, "Run Data", sections)

        # --- Per-tool audit clusters: ONE sheet per tool, four columns SIDE BY
        # SIDE: Concise | Raw report | Error log | Target + Command. Everything a
        # tool produced lives together in one place. Concise is left blank for now
        # (to be built later); the other three are filled from the tool's output.
        # Nothing is removed — this is purely additive.
        clusters = _wbk.per_tool_clusters(outdir)
        for cl in clusters:
            try:
                _add_tool_scribe_sheet(wb, cl, _wbk)
            except Exception as e:  # noqa: BLE001
                print(f"[report] scribe sheet for {cl.get('tool','?')} "
                      f"skipped: {e}")
    except Exception as e:  # noqa: BLE001
        log.warning("workbook structure tabs skipped: %s", e, exc_info=True)

    # --- Uniform styling + client/date/time banner on every sheet ------------
    # One pass over every tab so the whole workbook reads like one product:
    # a dark banner row (client · date · time), uniform header, zebra bands,
    # auto-fit widths. Also drops the redundant raw FunnelWeb dumps here.
    try:
        _restyle_all_sheets(wb, outdir, funnelweb_summaries)
    except Exception as e:  # noqa: BLE001
        log.warning("workbook restyle skipped: %s", e, exc_info=True)

    # --- Reorder: fixed priority pages first, then everything else A→Z ---
    # Library-style: a defined front section (the pages an analyst opens first),
    # then all remaining tabs alphabetical, with Run Data pinned last.
    #   1 At a Glance  2 Findings  3 Targets  4 metrics (cost/runtime/errors)
    try:
        # Names here MUST match tabs that actually get created in this workbook,
        # or they silently do nothing. (The FunnelWeb rollup tab is "At a Glance";
        # the CVSS rollup is "Severity Findings".)
        _front = ["At a Glance", "At a Glance Summary", "Findings",
                  "Targets", "Master Targets", "Burp Target URLs",
                  "API Credits", "Master Errors", "Analytics"]
        front_order = {name: i for i, name in enumerate(_front)}
        BIG = 10_000

        def _key(ws):
            t = ws.title
            tl = t.lower()
            if t == "Run Data":
                return (3, "")           # always dead last
            if tl.startswith("dehashed raw"):
                # raw API dump -> pinned to the very back (after Run Data)
                return (4, tl)
            if t in front_order:
                return (0, f"{front_order[t]:04d}")   # fixed front block
            if tl.startswith("partyon (dehashed)"):
                # group the PartyOn tab(s) under "DeHashed", AHEAD of the legacy
                # DeHashed Emails / DeHashed CredStuff tabs (two spaces sort before
                # 'dehashed c…'/'dehashed e…').
                return (1, "dehashed  " + tl)
            return (1, tl)               # everyone else alphabetical
        wb._sheets.sort(key=_key)
    except Exception as e:  # noqa: BLE001
        log.warning("tab reorder skipped: %s", e, exc_info=True)
    # NOTE: saving + file-embedding happen in build_report() (the GUARANTEED SAVE
    # wrapper), NOT here — the body only builds sheets so a crash can't skip save.
