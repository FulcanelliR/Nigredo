"""Live campaign dashboard.

Renders a single in-place panel while a `campaign run` is in flight, so the
operator sees per-client progress instead of a blank prompt. It is a READ-ONLY
view: it polls each client's results/<client>/recon_state.json on a timer and
redraws. It never touches the running subprocesses — the run owns those; this
just reflects what they've checkpointed to disk.

Layout (locked spec):

    NIGREDO CAMPAIGN — 3 clients running                     elapsed 00:42:15

      acme-corp     [==============....]  12/18  partyon         +38m
      globex-inc    [=====.............]   5/18  subdomains      +12m
      initech       [==================]  18/18  done            45m

      live logs -> results/<client>/campaign_run.log      [q] quit
"""
from __future__ import annotations

import json
import time
from pathlib import Path

# Canonical stage order = the order tools actually run, so "current stage" is the
# furthest-along not-yet-done tool. Imported lazily to avoid a hard dependency at
# module import time (keeps this usable even if preflight moves).
def _stage_order() -> list[str]:
    try:
        from . import preflight
        return list(preflight.PHASE1_TOOLS) + list(preflight.PHASE2_TOOLS)
    except Exception:
        return []


def _enabled_stages(cfg, order: list[str]) -> list[str]:
    """The stages that will actually run for this client (respects run_* flags).
    This is the progress DENOMINATOR — a client with tools disabled has fewer
    total stages, so its bar reflects its own plan, not a fixed 16."""
    if cfg is None:
        return list(order)
    enabled = [t for t in order if getattr(cfg, f"run_{t}", True)]
    return enabled or list(order)


def _read_state(client_dir: Path) -> dict:
    f = client_dir / "recon_state.json"
    try:
        d = json.loads(f.read_text())
        if isinstance(d, dict):
            d.setdefault("done", {})
            d.setdefault("completed", False)
            return d
    except (ValueError, OSError):
        pass
    return {"done": {}, "completed": False}


def _read_phase0(client_dir: Path) -> dict:
    """Phase-0 (nmap + web fuzzers) live progress, written by RunMetrics to
    phase0_state.json. Empty dict if absent/unreadable. Keys: current, step_index,
    total, completed, ts."""
    f = client_dir / "phase0_state.json"
    try:
        d = json.loads(f.read_text())
        if isinstance(d, dict):
            return d
    except (ValueError, OSError):
        pass
    return {}


def _read_hearthbeat(client_dir: Path) -> dict:
    """Parse the child's hearthbeat.log for this client's own elapsed time and the
    last tool it reported. Lines look like:

        [hearthbeat] [15:42:03] +38m12s into run | subdomains took 4m03s

    We pull the most recent '+<elapsed> into run' and the last 'X took Y' tool.
    Returns {'elapsed': str|None, 'last_tool': str|None}. Never raises — the
    panel must survive a missing/partial log (heartbeat writes are best-effort)."""
    f = client_dir / "hearthbeat.log"
    out = {"elapsed": None, "last_tool": None}
    try:
        lines = f.read_text().splitlines()
    except OSError:
        return out
    for line in reversed(lines):
        if "into run" not in line:
            continue
        # elapsed: text between '+' and ' into run'
        try:
            seg = line.split("+", 1)[1]
            out["elapsed"] = seg.split(" into run", 1)[0].strip()
        except (IndexError, ValueError):
            pass
        # last finished tool: '... | <tool> took <dur>'
        if "|" in line and " took " in line:
            try:
                tail = line.split("|", 1)[1].strip()
                out["last_tool"] = tail.split(" took ", 1)[0].strip()
            except (IndexError, ValueError):
                pass
        break   # most recent qualifying line only
    return out


def _done_count(state: dict, enabled: list[str]) -> int:
    """How many ENABLED stages are done, across all domains for this client.
    A tool counts as done once it's done for every domain that reached it; we
    keep it simple and count a stage done if it's marked done for any domain,
    since the orchestrator marks per (domain, tool) and advances in lockstep."""
    done_tools: set[str] = set()
    for _domain, tools in (state.get("done") or {}).items():
        for t in tools:
            done_tools.add(t)
    return sum(1 for t in enabled if t in done_tools)


def _current_stage(state: dict, enabled: list[str]) -> str:
    """First enabled stage not yet done = what it's working on now. If all done,
    'done'. If nothing done yet, the first enabled stage (about to start)."""
    done_tools: set[str] = set()
    for _domain, tools in (state.get("done") or {}).items():
        done_tools.update(tools)
    for t in enabled:
        if t not in done_tools:
            return t
    return "done"


def _bar(done: int, total: int, width: int = 18) -> str:
    if total <= 0:
        return "░" * width
    filled = int(round(width * done / total))
    filled = max(0, min(width, filled))
    return "█" * filled + "░" * (width - filled)


def _fmt_elapsed(seconds: float) -> str:
    s = int(seconds)
    h, rem = divmod(s, 3600)
    m, sec = divmod(rem, 60)
    return f"{h:02d}:{m:02d}:{sec:02d}"


def _fmt_since(seconds: float) -> str:
    """Compact per-client age, like +38m or 45m (spec uses a short form)."""
    m = int(seconds // 60)
    if m < 60:
        return f"{m}m"
    h, mm = divmod(m, 60)
    return f"{h}h{mm:02d}m"


class CampaignDashboard:
    """Poll-and-redraw dashboard. Feed it the results root and the client list;
    call .render_once() on a timer, or .run_until(is_done) to block until the
    run finishes or the user quits with 'q'.

    configs: optional {client: ReconConfig} so the denominator respects each
    client's enabled tools. Without it, all stages count (fixed total)."""

    def __init__(self, results_root: Path, clients: list[str],
                 configs: dict | None = None):
        self.results_root = Path(results_root)
        self.clients = list(clients)
        self.configs = configs or {}
        self.started = time.time()
        self._start_per_client: dict[str, float] = {}
        self._order = _stage_order()
        self._last_line_count = 0   # for in-place redraw (see render_once)

    def _client_dir(self, client: str) -> Path:
        return self.results_root / client

    def _lines(self) -> list[str]:
        running = sum(1 for c in self.clients
                      if not _read_state(self._client_dir(c)).get("completed"))
        head = (f"NIGREDO CAMPAIGN — {running} client(s) running"
                f"{'':>8}elapsed {_fmt_elapsed(time.time() - self.started)}")
        out = [head, ""]
        namew = max((len(c) for c in self.clients), default=8) + 2
        now = time.time()
        for c in self.clients:
            cdir = self._client_dir(c)
            state = _read_state(cdir)
            hb = _read_hearthbeat(cdir)
            enabled = _enabled_stages(self.configs.get(c), self._order)
            total = len(enabled)
            done = _done_count(state, enabled)
            completed = bool(state.get("completed")) or (total and done >= total)
            # Per-client elapsed: prefer the child's own hearthbeat clock (spec
            # data source). Fall back to wall-time since we first saw the client
            # if the heartbeat hasn't written a line yet.
            self._start_per_client.setdefault(c, now)
            age = hb["elapsed"] or _fmt_since(now - self._start_per_client[c])
            # Phase 0 (nmap + web fuzzers) runs BEFORE the recon engine and writes its
            # own live progress. While it's in flight (not completed, recon not yet
            # writing recon_state.json), show the phase-0 bar so the operator sees
            # movement instead of a stuck 0/N recon bar.
            p0 = _read_phase0(cdir)
            recon_started = bool(state.get("done"))
            if (p0 and not p0.get("completed") and not recon_started
                    and not completed):
                pidx = int(p0.get("step_index", 0) or 0)
                ptot = int(p0.get("total") or len(_stage_order()) or 11)
                cur = p0.get("current") or "starting"
                out.append(f"  {c:<{namew}}[{_bar(pidx, ptot)}] {pidx:>3}/{ptot:<3} "
                           f"{('scan·' + cur):<14} {('+' + age):>6}")
                continue
            if completed:
                stage = "✓ done"
                bar = _bar(total, total)
                done = total
                # spec: "18/18  ✓ done           45m"  (age plain, no + prefix)
                out.append(f"  {c:<{namew}}[{bar}] {done:>3}/{total:<3} "
                           f"{stage:<14} {age:>6}")
            else:
                stage = _current_stage(state, enabled)
                bar = _bar(done, total)
                # spec: "12/18  partyon         +38m"  (+ prefix while running)
                out.append(f"  {c:<{namew}}[{bar}] {done:>3}/{total:<3} "
                           f"{stage:<14} {('+'+age):>6}")
        out.append("")
        out.append("  live logs → results/<client>/campaign_run.log"
                   "      [q] quit")
        return out

    def render_once(self, clear: bool = True) -> None:
        # In-place redraw: after the first frame, move the cursor back up over the
        # lines we printed last time and overwrite them, clearing each line first.
        # The panel updates in place — bars move, nothing scrolls, no new lines are
        # pushed down the terminal. Falls back to a plain print if not a TTY.
        import sys
        lines = self._lines()
        out = sys.stdout
        if clear and out.isatty() and getattr(self, "_last_line_count", 0):
            # go up N lines to the top of the previous panel
            out.write(f"\033[{self._last_line_count}A")
        if out.isatty():
            # write each line, clearing to end-of-line so shorter new content
            # doesn't leave stale characters from the previous frame
            for ln in lines:
                out.write("\033[2K" + ln + "\n")
            self._last_line_count = len(lines)
        else:
            out.write("\n".join(lines) + "\n")
        out.flush()

    def run_until(self, is_done, interval: float = 2.0) -> None:
        """Redraw every `interval` seconds until is_done() is True. If stdin is a
        TTY, 'q' + Enter quits the VIEW (not the run). Falls back to plain
        periodic redraws when no TTY (e.g. piped/automated)."""
        import sys
        import select

        tty = sys.stdin.isatty()
        try:
            while not is_done():
                self.render_once()
                if tty:
                    # wait up to `interval` for a keypress; redraw otherwise
                    r, _, _ = select.select([sys.stdin], [], [], interval)
                    if r:
                        line = sys.stdin.readline().strip().lower()
                        if line == "q":
                            print("\n[dashboard] detached — run continues in the "
                                  "background. `campaign status` to check in.")
                            return
                else:
                    time.sleep(interval)
            # final frame so the last state (all done) is visible
            self.render_once()
        except KeyboardInterrupt:
            print("\n[dashboard] detached — run continues in the background.")
