"""Preflight checks for phase 1 (passive recon) and phase 2 (email) tools.

Reports which external binaries, Python libraries, API keys, and helper scripts
are present before a run starts, so a missing dependency is surfaced up front
rather than failing mid-run. Nothing here fails hard: it returns a structured
report and the orchestrator decides what to skip.
"""
from __future__ import annotations

import os
import shutil
from dataclasses import dataclass, field


# tool -> external binaries it needs on PATH
BINARY_REQUIREMENTS = {
    "dnsrecon": ["dnsrecon"],
    "dnstwist": ["dnstwist"],
    "subdomains": ["subfinder", "shuffledns", "dnsx"],
    "takeover": ["nuclei"],   # dedicated nuclei takeover-template pass
    "submutate": ["dnsx"],    # shuffledns + httpx + wordsegment all optional
    "cvemap": ["cvemap"],      # CVE lookup on discovered tech (optional)
    "trufflehog": ["trufflehog"],
    "gitleaks": ["gitleaks", "git"],   # git needed to clone org repos
}

# tool -> python modules it needs importable
PYLIB_REQUIREMENTS = {
    "dkim": ["dns"],                      # dnspython
    "fileenum": ["requests", "serpapi"],  # bs4/pypdf/etc are optional, degrade
    "emailenum": ["serpapi"],
    "snov": ["requests"],
    "buckets": ["requests"],
    "trufflehog": ["requests"],
    "gitleaks": ["requests"],
    "funnelweb": ["patchright", "aiohttp", "aiofiles", "magic"],  # heavy deps
}

# tool -> (env var, human label) credentials it needs
CREDENTIAL_REQUIREMENTS = {
    "fileenum": [("SERPAPI_KEY", "SerpAPI key")],
    "emailenum": [("SERPAPI_KEY", "SerpAPI key")],
    "snov": [("SNOV_CLIENT_ID", "Snov client id"),
             ("SNOV_CLIENT_SECRET", "Snov client secret")],
    "buckets": [("GRAYHAT_API_KEY", "GrayHatWarfare API key")],
}


@dataclass
class ToolStatus:
    name: str
    ready: bool
    missing_binaries: list[str] = field(default_factory=list)
    missing_pylibs: list[str] = field(default_factory=list)
    missing_creds: list[str] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)


def _module_importable(mod: str) -> bool:
    import importlib.util
    try:
        return importlib.util.find_spec(mod) is not None
    except (ImportError, ValueError, ModuleNotFoundError):
        return False


def check_tool(name: str,
               config_keys: dict | None = None) -> ToolStatus:
    config_keys = config_keys or {}
    missing_bin = [b for b in BINARY_REQUIREMENTS.get(name, [])
                   if shutil.which(b) is None]
    missing_lib = [m for m in PYLIB_REQUIREMENTS.get(name, [])
                   if not _module_importable(m)]
    missing_cred = []
    for env_var, label in CREDENTIAL_REQUIREMENTS.get(name, []):
        # satisfied by env var or by an explicit config entry
        if not os.getenv(env_var) and not config_keys.get(env_var):
            missing_cred.append(label)

    notes = []
    soft_notes = []
    if name == "partyon":
        po_script = (config_keys or {}).get("partyon_script", "PartyOn.py")
        if shutil.which(po_script) is None and not os.path.isfile(po_script):
            notes.append(f"PartyOn script '{po_script}' not found on PATH or cwd")
    if name == "cloud_enum":
        ce_script = (config_keys or {}).get("cloud_enum_script", "cloud_enum.py")
        if (shutil.which(ce_script) is None and shutil.which("cloud_enum") is None
                and not os.path.isfile(ce_script)):
            notes.append(f"cloud_enum script '{ce_script}' not found on PATH or cwd")
    if name == "funnelweb":
        fw_script = (config_keys or {}).get("funnelweb_script", "FunnelWeb.py")
        if shutil.which(fw_script) is None and not os.path.isfile(fw_script):
            notes.append(f"crawler script '{fw_script}' not found on PATH or cwd")
        if _module_importable("magic"):
            try:
                import magic  # noqa: F401
                magic.Magic(mime=True)
            except Exception:
                notes.append("python-magic present but libmagic system lib missing")
        if shutil.which("exiftool") is None:
            # soft: crawler runs without it, just skips metadata extraction
            soft_notes.append("exiftool not on PATH (metadata scan will be skipped)")

    ready = not (missing_bin or missing_lib or missing_cred or notes)
    notes = notes + soft_notes
    return ToolStatus(name=name, ready=ready, missing_binaries=missing_bin,
                      missing_pylibs=missing_lib, missing_creds=missing_cred,
                      notes=notes)


PHASE1_TOOLS = ["dnsrecon", "dnstwist", "subdomains", "takeover", "submutate", "cvemap", "dkim", "fileenum", "buckets", "cloud_enum", "trufflehog", "gitleaks", "funnelweb"]
PHASE2_TOOLS = ["emailenum", "partyon", "snov"]


def run_preflight(tools: list[str],
                  config_keys: dict | None = None) -> dict[str, ToolStatus]:
    return {t: check_tool(t,
                          config_keys=config_keys) for t in tools}


def format_preflight(statuses: dict[str, "ToolStatus"]) -> str:
    lines = ["Preflight check:"]
    for name, st in statuses.items():
        if st.ready:
            lines.append(f"  [ready]   {name}")
        else:
            bits = []
            if st.missing_binaries:
                bits.append(f"missing binaries: {', '.join(st.missing_binaries)}")
            if st.missing_pylibs:
                bits.append(f"missing python libs: {', '.join(st.missing_pylibs)}")
            if st.missing_creds:
                bits.append(f"missing creds: {', '.join(st.missing_creds)}")
            if st.notes:
                bits.append("; ".join(st.notes))
            lines.append(f"  [SKIP]    {name}  ({'; '.join(bits)})")
    return "\n".join(lines)
