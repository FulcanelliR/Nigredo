"""Audit completeness — every tool records what it did, so a run is fully
legible and a finding can be traced back to tool -> command -> targets -> scope.

WHY THIS EXISTS
  Before this, some tools (especially API-based ones like the LinkedIn/email
  enum and snov) ran WITHOUT logging anything — so a silent skip or an empty
  result was indistinguishable from a bug. If a tool doesn't say "I ran, against
  these targets, and here's what I did", you can't tell "found nothing" from
  "never ran". This module gives every tool a uniform way to record:
    1. its ACTION to the unified commands.log (a shell command OR an API call)
    2. its TARGET LIST to <tool>_targets.txt in the engagement folder
    3. a COMPLETION MARKER (<tool>.done) once it finished cleanly, so resume can
       tell a finished tool from one that stalled mid-write.

  These are deliberately tiny, dependency-free helpers so ANY module (including
  the API tools that don't shell out) can call them.
"""
from __future__ import annotations

import time
from pathlib import Path


def log_action(command_log: Path, tool: str, action: str) -> None:
    """Append one line to the unified commands.log describing what a tool did.

    For shell tools this is the command string. For API tools it's the call,
    e.g. log_action(cl, "LinkThief", "serpapi q='site:linkedin.com/in acme'").
    Every tool should call this BEFORE acting, so the log reflects intent even
    if the tool then errors.
    """
    try:
        ts = time.strftime("%Y-%m-%dT%H:%M:%S")
        with open(command_log, "a") as f:
            f.write(f"[{ts}] [{tool}] {action}\n")
    except OSError:
        pass  # logging must never break a run


def append_error(outdir: Path, tool: str, detail: str,
                 exit_code=None, completed: bool = False) -> Path | None:
    """Append a structured error record to <tool>_errors.txt.

    This is the per-tool error file the workbook's collect_master_errors() and
    write_aggregated_error_log() already look for. Writing it here (from the
    central dispatch) means EVERY tool that errors produces a consistent,
    tool-separated record with full detail.

    `detail`     the error text (exception message, stderr tail, etc.).
    `exit_code`  process exit code if known (distinguishes crash vs clean-exit).
    `completed`  True if the tool RAN TO COMPLETION but produced nothing/failed
                 internally, False if it crashed/raised. This is the key
                 completed-but-empty vs silently-failed distinction: an analyst
                 needs to know whether to re-run, call the client, or accept the
                 result.
    """
    try:
        safe = _safe(tool)
        p = Path(outdir) / f"{safe}_errors.txt"
        ts = time.strftime("%Y-%m-%dT%H:%M:%S")
        status = ("completed-with-error" if completed else "did-not-complete")
        ec = "" if exit_code is None else f" exit={exit_code}"
        with open(p, "a") as f:
            f.write(f"{'-' * 60}\n")
            f.write(f"[{ts}] [{tool}] status={status}{ec}\n")
            f.write(f"{detail.rstrip()}\n")
        # FURNACE ALERT: for the basic, loud-worthy tool failures (write / save /
        # connect), announce it prominently to the terminal so a silent failure
        # (like ffuf not writing its output) can't slip by unnoticed. The XXXX is
        # the actual error condition.
        _furnace_alert(tool, detail)
        return p
    except OSError:
        return None  # error logging must never break a run


_FURNACE_TRIGGERS = (
    ("failed to write", "failed to write"),
    ("failed to save", "failed to save"),
    ("failed to connect", "failed to connect"),
    ("permission denied", "failed to write (permission denied)"),
    ("connection refused", "failed to connect (connection refused)"),
    ("connection reset", "failed to connect (connection reset)"),
    ("no such file", "failed to write (no such file/dir)"),
    ("disk quota", "failed to write (disk full)"),
    ("no space left", "failed to write (disk full)"),
    ("timed out", "failed to connect (timed out)"),
    ("could not write", "failed to write"),
    ("cannot write", "failed to write"),
)


def _furnace_alert(tool: str, detail: str) -> None:
    """Loud terminal alert for basic write/save/connect failures.
    'The fire sparks inside the furnace - Error - <what happened>'."""
    low = (detail or "").lower()
    reason = ""
    for needle, label in _FURNACE_TRIGGERS:
        if needle in low:
            reason = label
            break
    if not reason:
        return  # only the loud-worthy basic errors get the furnace alarm
    try:
        print("\n" + "=" * 60)
        print(f"  \U0001f525 The fire sparks inside the furnace - Error - "
              f"{reason} [{tool}]")
        print("=" * 60 + "\n", flush=True)
    except Exception:  # noqa: BLE001
        pass


def save_targets(outdir: Path, tool: str, targets) -> Path | None:
    """Write the exact target list a tool ran against to <tool>_targets.txt.

    `targets` may be a list/set/tuple or a single string. Returns the path, or
    None if there was nothing to write. This is the per-tool target record that
    feeds the report's per-tool target tabs and the finding->target audit chain.
    """
    if targets is None:
        return None
    if isinstance(targets, (str, bytes)):
        items = [targets if isinstance(targets, str) else targets.decode("utf-8", "replace")]
    else:
        items = [str(t).strip() for t in targets if str(t).strip()]
    if not items:
        return None
    safe = _safe(tool)
    p = Path(outdir) / f"{safe}_targets.txt"
    try:
        p.write_text("\n".join(items) + "\n")
        return p
    except OSError:
        return None


def mark_complete(outdir: Path, tool: str, domain: str = "") -> Path | None:
    """Drop a completion marker (<tool>[_<domain>].done) once a tool finishes
    cleanly. Resume checks THIS (not just the output file) so a tool that
    stalled/crashed mid-write — leaving a partial output file — is re-run rather
    than mistaken for complete."""
    safe = _safe(tool)
    name = f"{safe}_{_safe(domain)}.done" if domain else f"{safe}.done"
    p = Path(outdir) / name
    try:
        p.write_text(time.strftime("%Y-%m-%dT%H:%M:%S") + "\n")
        return p
    except OSError:
        return None


def is_complete(outdir: Path, tool: str, domain: str = "") -> bool:
    """True if a completion marker exists for this tool (+domain). Used by resume
    to skip a stage whose output is known-good, and to re-run one that isn't."""
    safe = _safe(tool)
    name = f"{safe}_{_safe(domain)}.done" if domain else f"{safe}.done"
    return (Path(outdir) / name).is_file()


def output_nonempty(path: Path) -> bool:
    """True if an output file exists AND has real content — the 'did this tool
    produce anything' check. A file that exists but is blank means the tool ran
    and found nothing (or stalled); callers decide which. Combined with a
    completion marker, this distinguishes 'complete + empty' (skip, found
    nothing) from 'incomplete' (re-run)."""
    try:
        p = Path(path)
        return p.is_file() and p.stat().st_size > 0
    except OSError:
        return False


def _safe(name: str) -> str:
    """Filesystem-safe token from a tool/domain name."""
    return "".join(c if (c.isalnum() or c in "-._") else "_" for c in str(name))
