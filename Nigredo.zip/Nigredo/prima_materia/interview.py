#!/usr/bin/env python3
"""Startup interview for unattended runs — the human prep checkpoint.

nigredo runs unattended by default, so BEFORE it goes autonomous it collects
every piece of human-required input up front. This is the deliberate safeguard:
the operator prepares the run, answers all the questions consciously, and only
then does it run hands-off against the target. There is no bypass — you must
answer the interview.

It only asks for what THIS run actually needs: each tool is checked for whether
it's enabled (run_* flag) and whether its value is already set (config/env). It
never asks for something that's disabled or already provided.

Collected values are stashed in runmode for the tools to read; the DeHashed key,
if newly entered, is saved back to the config for next time.

--manual skips this entirely (tools prompt as they're reached).
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from . import runmode


def _sanitize_text(s: str) -> str:
    """Light cleanup for free-text fields (org/business names) so stray control
    characters or quotes can't break downstream file/sheet handling. Keeps spaces
    and normal punctuation so the value is still useful for searching."""
    if not s:
        return s
    # strip ASCII control chars; collapse whitespace; drop characters that break
    # Excel sheet names or shell/file handling if the value flows there.
    s = "".join(ch for ch in s if ch == "\t" or ord(ch) >= 32)
    s = s.replace("\t", " ").strip()
    return s


def _ask(prompt: str, default: str = "") -> str:
    suffix = f" [{default}]" if default else ""
    try:
        ans = input(f"  {prompt}{suffix}: ").strip()
    except EOFError:
        return default
    return ans or default


def _ask_secret(prompt: str) -> str:
    # Visible WHILE typing (so you can see/verify what you paste), but once you
    # press Enter the entered value is wiped from the terminal line and replaced
    # with a masked marker — so the key isn't left sitting on screen (or in a
    # scrollback/screen-share) after entry. Falls back gracefully if the terminal
    # doesn't support cursor control.
    import sys
    try:
        val = input(f"  {prompt}: ").strip()
    except EOFError:
        return ""
    if val and sys.stdout.isatty():
        # move cursor up one line, clear it, reprint the prompt with a mask
        try:
            sys.stdout.write("\033[1A\033[2K")
            sys.stdout.write(f"  {prompt}: {'*' * 8}\n")
            sys.stdout.flush()
        except Exception:
            pass
    return val


def _ask_choice(prompt: str, options: dict, default: str) -> str:
    opt = "  ".join(f"[{k}] {v}" for k, v in options.items())
    try:
        ans = input(f"  {prompt}\n    {opt}\n    choice [{default}]: ").strip().lower()
    except EOFError:
        return default
    return ans if ans in options else default


def _invoking_user_home() -> Path:
    """The home dir of the user who invoked us — the REAL user's home under
    sudo (via $SUDO_USER), not root's. Matches the pathfix.py approach so the
    subfinder-config guidance points at the right place."""
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user:
        try:
            import pwd
            return Path(pwd.getpwnam(sudo_user).pw_dir)
        except (KeyError, ImportError):
            pass
    return Path.home()


def _subfinder_config_notice() -> None:
    """One-time awareness notice about subfinder's provider-config.yaml. We do
    NOT manage that file (subfinder owns its own config by design) — we just
    make sure the user knows to populate it, and where, given sudo context.

    subfinder runs fine WITHOUT keys; source keys only improve results, so this
    never blocks the run."""
    running_as_root = hasattr(os, "geteuid") and os.geteuid() == 0
    # under sudo, subfinder reads ROOT's config (the effective user), not the
    # invoking user's — this is the wrinkle that trips people up.
    root_cfg = Path("/root/.config/subfinder/provider-config.yaml")
    user_cfg = _invoking_user_home() / ".config/subfinder/provider-config.yaml"
    # the config subfinder will ACTUALLY read depends on who it runs as
    effective_cfg = root_cfg if running_as_root else user_cfg

    if effective_cfg.exists():
        return   # already set up where subfinder will look — nothing to say

    print("\n  " + "-" * 60)
    print("  [subfinder] NOTE — passive subdomain source keys")
    print("  " + "-" * 60)
    print("  subfinder runs fine with NO keys, but source keys (VirusTotal,")
    print("  Censys, SecurityTrails, Chaos, GitHub, Shodan, etc.) greatly")
    print("  improve results. These live in subfinder's OWN config file,")
    print("  which Nigredo does not manage. To set them up:")
    print()
    print("    1) generate the template:  subfinder")
    print(f"    2) edit the file:          {effective_cfg}")
    print("    3) add the API keys you have under each source name")
    print()
    if running_as_root:
        print("  IMPORTANT: because Nigredo runs under sudo/root, subfinder reads")
        print(f"  ROOT's config ({root_cfg}),")
        print("  NOT your user's. Set the keys up there, or run the generate")
        print("  step with the same sudo/root context so the paths match.")
        if user_cfg.exists():
            print(f"  (You DO have a config at {user_cfg} —")
            print("   but root won't read it. Copy it to root's path if needed.)")
    print("  " + "-" * 60)


def _save_config_key(config_path, key, value) -> None:
    if not config_path:
        return
    try:
        p = Path(config_path)
        cfg = json.loads(p.read_text()) if p.exists() else {}
        cfg[key] = value
        p.write_text(json.dumps(cfg, indent=2))
        print(f"    saved {key} to {p.name}")
    except Exception as e:  # noqa: BLE001
        print(f"    could not save {key}: {e}")


def run_interview(cfg=None, domains=None, config_path=None) -> None:
    """Collect all upfront answers for an unattended run and stash them.

    cfg: the ReconConfig (to check run_* flags and existing keys).
    domains: the domains the run will cover (primary = domains[0]).
    config_path: where to persist newly-entered keys (e.g. DeHashed).
    """
    domains = domains or []
    primary = domains[0] if domains else ""
    base = primary.split(".")[0] if primary else ""

    print("\n" + "=" * 62)
    print(" UNATTENDED SETUP — answer everything now, then it runs hands-off")
    print(" (this is the prep checkpoint; run with --manual for step-by-step)")
    print("=" * 62)

    # ---- missing-tools gate: surface skipped tools BEFORE the run goes hands-off ----
    try:
        from .toolsetup import missing_tools, install_command, load_skips
        miss = [t for t in missing_tools() if t not in load_skips()]
        if miss:
            print("\n  [!] Some external tools are NOT installed. The run will")
            print("      SKIP the features that need them. To install: run")
            print("      'sudo python3 run.py install-missing'. Missing:")
            for t in miss:
                print(f"        - {t:14} {install_command(t)}")
            from .runmode import prompt_choice
            # blank -> N (the [y/N] default); re-prompts on anything unrecognized
            # so a typo can't silently abort (or silently proceed) the run.
            proceed = prompt_choice(
                "\n  Proceed anyway with these SKIPPED? [y/N]: ",
                {"y": True, "yes": True, "n": False, "no": False},
                default=False)
            if not proceed:
                print("  Aborting so you can install the missing tools first.")
                raise SystemExit(0)
            print("  Proceeding with a partial toolset (you acknowledged the skips).")
    except SystemExit:
        raise
    except Exception as e:  # noqa: BLE001
        print(f"  [tools] check skipped: {e}")

    # ---- Nessus seed (nmap ALWAYS runs; Nessus adds cross-validation) ----
    # If .nessus file(s) are ALREADY present in the working dir, they were placed
    # there ahead of time (the campaign flow copies each client's Nessus files into
    # the client folder at init). In that case, auto-discover them and DON'T
    # re-prompt — asking again is the double-handling that made you redo setup.
    # Only prompt for a directory when none are present (the single-engagement
    # flow, where nothing pre-seeded them).
    from pathlib import Path as _P
    # Look for pre-placed .nessus in the client's folder (the dir holding this
    # client's recon_config.json) AND the cwd. The campaign copies each client's
    # files into results/<client>/ at init, and configure runs from the campaign
    # cwd, so we must check the config's own directory to see them.
    _nessus_search_dirs = [_P(".")]
    if config_path:
        _nessus_search_dirs.insert(0, _P(config_path).resolve().parent)
    nessus_files = []
    for _d in _nessus_search_dirs:
        nessus_files = [str(p) for p in _d.rglob("*.nessus")]
        if nessus_files:
            break
    if nessus_files:
        print(f"\n  [nessus] found {len(nessus_files)} .nessus file(s) already "
              f"in place — using them (no need to re-enter a folder).")
    else:
        print("\n  nmap always runs. You can ALSO seed from Nessus .nessus file(s)")
        print("  so the two sources cross-validate the target map. Point to a")
        print("  DIRECTORY and every .nessus file in it (top level) will be merged.")
        try:
            ndir = input("  Directory containing .nessus files "
                         "(blank to skip): ").strip()
        except EOFError:
            ndir = ""
        if ndir:
            ndp = _P(ndir).expanduser()
            if ndp.is_dir():
                # top level only (no recursion), case-insensitive extension
                found = sorted(p for p in ndp.iterdir()
                               if p.is_file() and p.suffix.lower() == ".nessus")
                nessus_files = [str(p) for p in found]
                if nessus_files:
                    print(f"  [nessus] merged {len(nessus_files)} Nessus file(s):")
                    for p in found:
                        print(f"           - {p.name}")
                else:
                    print(f"  [nessus] no .nessus files found in {ndp}")
            else:
                print(f"  [nessus] not a directory: {ndp} — skipping")
    if nessus_files:
        runmode.stash("nessus_files", nessus_files)
        # Nessus-only scope seeding: if no targets.txt (or it's empty) but Nessus
        # file(s) are present, offer to derive scope from the Nessus hosts (with a
        # confirmation echo). If targets.txt already has content, it wins — Nessus
        # is merged separately in the pipeline; we don't override explicit targets.
        try:
            from pathlib import Path as _P
            tpath = _P("targets.txt")
            has_targets = tpath.exists() and bool(
                [ln for ln in tpath.read_text().splitlines()
                 if ln.strip() and not ln.strip().startswith("#")])
            if not has_targets:
                from . import nessus_import
                nessus_import.seed_scope_from_nessus(nessus_files, "targets.txt")
        except Exception as _e:  # noqa: BLE001
            print(f"  [scope] Nessus seeding skipped: {_e}")

    def enabled(flag: str) -> bool:
        # everything is on by default unless the config explicitly disables it
        return bool(getattr(cfg, flag, True)) if cfg else True

    # ---- content discovery wordlist modes ----
    # ffuf runs DIRECTORIES-ONLY by default (fast broad map for feroxbuster to
    # recurse into), so it needs no mode question. feroxbuster does the deep
    # file+dir digging, so ask its mode.
    mode_opts = {"w": "words + extensions", "f": "files only",
                 "b": "both", "c": "custom path"}
    if enabled("feroxbuster_enabled"):
        m = _ask_choice("feroxbuster wordlist mode? (files+dirs recursion)",
                        mode_opts, "b")
        runmode.stash("ferox_mode", m)
        _save_config_key(config_path, "ferox_mode", m)
        if m == "c":
            # Custom-wordlist path: stashed for this session AND persisted to the
            # client's config so it survives into the unattended campaign child
            # (the read site in tools.py falls back to cfg.ferox_custom_wordlist
            # when there's no interview stash).
            _cwl = _ask("feroxbuster custom wordlist path")
            runmode.stash("ferox_custom_wordlist", _cwl)
            _save_config_key(config_path, "ferox_custom_wordlist", _cwl)
        else:
            # Wordlist size, mirroring ffuf's small/medium/large exactly (same
            # raft list family, same s/m/l codes the run-side sizer speaks). Large
            # is far more thorough but much slower — big lists across recursive
            # dirs are what make runs take hours on large sites.
            size = _ask_choice(
                "feroxbuster wordlist size?",
                {"s": "small  (raft-small, fastest)",
                 "m": "medium (raft-medium, balanced)",
                 "l": "large  (raft-large, thorough but slow)"}, "m")
            runmode.stash("ferox_wordlist_size", size)
            _save_config_key(config_path, "ferox_wordlist_size", size)

    # ffuf directory wordlist size — asked UP FRONT here (like feroxbuster) and
    # persisted, so it works in fire-and-forget/unattended mode. ffuf reads the
    # value at run time instead of prompting mid-run (which the unattended default
    # silently skips — that's why it never asked before). Gate on ffuf_enabled,
    # the flag the pipeline actually honors (the old 'run_ffuf' name was a
    # leftover from the phase move and never existed as a config field).
    if enabled("ffuf_enabled"):
        fsz = _ask_choice(
            "ffuf directory wordlist size?",
            {"s": "small  (raft-small-directories, fastest)",
             "m": "medium (raft-medium-directories, balanced)",
             "l": "large  (raft-large-directories, thorough but slow)"}, "m")
        runmode.stash("ffuf_wordlist_size", fsz)
        _save_config_key(config_path, "ffuf_wordlist_size", fsz)

    # ---- cloud_enum brute-force depth ----
    # Active multi-cloud bucket brute-force. Two levels offered (a third,
    # "quick"/-qs, stays available via cloud_enum_depth in config but isn't
    # prompted, to keep the choice simple):
    #   normal -> curated ~149-name mutations list (fast, high signal) [DEFAULT]
    #   full   -> stock ~306-name fuzz.txt (thorough, slower, more requests)
    # Stashed so unattended/fire-and-forget runs honor the choice; the
    # orchestrator reads it via runmode.answer("cloud_enum_depth", cfg default).
    if enabled("run_cloud_enum") if hasattr(cfg, "run_cloud_enum") else True:
        cdepth = _ask_choice(
            "cloud_enum depth? (active bucket brute-force)",
            {"normal": "normal (curated ~149 names, recommended)",
             "full": "full   (stock ~306 fuzz.txt, thorough but slower)"},
            "normal")
        runmode.stash("cloud_enum_depth", cdepth)
        _save_config_key(config_path, "cloud_enum_depth", cdepth)

    # ---- FunnelWeb crawler (RV5 = the only supported branch) ----
    # RV4 is a DEAD BRANCH. RV5 is the maintained crawler + full Phase A/B audit
    # pipeline (JS/PHP harvest, secret_scan, jsluice, semgrep, retire.js, login
    # detection). No version prompt — RV5 always.
    if enabled("run_funnelweb") if hasattr(cfg, "run_funnelweb") else True:
        script = "FunnelWeb.py"
        runmode.stash("funnelweb_script", script)
        _save_config_key(config_path, "funnelweb_script", script)

    # ---- company name (buckets, cloud_enum) — reused; note if unverified ----
    if enabled("run_buckets") or enabled("run_cloud_enum"):
        company = _sanitize_text(_ask(f"Company/org name (for bucket & cloud search)", base))
        runmode.stash("company", company)
        if company:
            _save_config_key(config_path, "company", company)   # survive into child
        if not company or company == base:
            runmode.stash("company_unverified", True)
            runmode.add_note(
                f"Company name for bucket/cloud search was not explicitly set; "
                f"used domain-derived '{company or base}'. Bucket/cloud_enum "
                f"results may be incomplete or inaccurate — verify the real "
                f"company name and re-run those tools if needed.")
            print("    (note: using domain-derived name; report will flag it "
                  "as possibly inaccurate)")

    # ---- GrayHatWarfare API tier (buckets) — gates regex/results/sort ----
    if enabled("run_buckets"):
        tier = _ask_choice(
            "GrayHatWarfare API tier? (higher unlocks regex + more results)",
            {"l": "low (free — keyword only, capped)",
             "m": "medium (base — more keywords/results)",
             "h": "high (premium — regex sensitive-file search, full results, sort)",
             "x": "max (enterprise — unlimited paging)"}, "l")
        tier_map = {"l": "low", "m": "medium", "h": "high", "x": "max"}
        runmode.stash("grayhat_tier", tier_map.get(tier, "low"))
        _save_config_key(config_path, "grayhat_tier", tier_map.get(tier, "low"))

    # ---- GitHub org (trufflehog, gitleaks) ----
    if enabled("run_trufflehog") or enabled("run_gitleaks"):
        org = _sanitize_text(_ask("GitHub org / handle (blank = derive from domain)", base))
        runmode.stash("github_org", org)
        if org:
            _save_config_key(config_path, "github_org", org)   # survive into child
        if not org or org == base:
            runmode.stash("github_org_unverified", True)

    # ---- email enumeration: business name + format + note source url ----
    if enabled("run_emailenum"):
        biz = _sanitize_text(_ask("Business name as it appears on LinkedIn", base))
        runmode.stash("email_business", biz)
        if biz:
            _save_config_key(config_path, "email_business", biz)   # survive into child
        fmt = _ask("Email format (tokens {first} {last} {f} {l})", "{first}.{last}")
        runmode.stash("email_format", fmt)
        if fmt:
            _save_config_key(config_path, "email_format", fmt)

    # ---- forwarding proxy for target-hitting HTTP tools ----
    # One proxy URL, applied to web probe + ffuf + feroxbuster via their native
    # proxy flags. Blank = connect direct. (Nuclei and PartyOn use their own;
    # DNS/OSINT tools are excluded — different mechanism / not target-facing.)
    print("\n  Forwarding proxy (optional) — routes the target-hitting HTTP")
    print("  tools (web probe, ffuf, feroxbuster) through one proxy so the")
    print("  target sees the proxy's address. Blank = connect direct.")
    fp = _ask("Forwarding proxy URL (e.g. http://host:port, blank = none)")
    runmode.stash("forward_proxy", fp)
    _save_config_key(config_path, "forward_proxy", fp)

    # ---- same-host redirect following (scope-check quirk) ----
    print("\n  Same-host redirects: when an in-scope target redirects to the")
    print("  SAME host on a different path (e.g. https://site.com -> ")
    print("  https://site.com/login/), following it keeps the useful landing")
    print("  page instead of dropping it. Cross-host redirects (to Okta, MSO,")
    print("  etc.) are NEVER followed either way — that off-scope protection")
    print("  stays. Recommended: Y.")
    follow = _ask("Follow same-host redirects? [Y/n]", "Y").strip().lower()
    runmode.stash("follow_same_host_redirects", follow not in ("n", "no"))
    _save_config_key(config_path, "follow_same_host_redirects", follow not in ("n", "no"))

    # ---- API keys for Nigredo's own tools ----
    # Ask for every key a tool needs, but only when that tool is enabled AND the
    # key isn't already set (config or env). Entered keys are saved so future
    # runs don't re-prompt. Blank = skip that tool's key-gated features.
    # (subfinder's OWN source keys are NOT handled here — see the notice below;
    # those live in subfinder's provider-config.yaml by design.)
    def _key_prompt(field, env_name, prompt, needed_when):
        if not needed_when:
            return
        # Already provided this session (stash) or via env? Then don't re-ask —
        # but DO still write it into THIS client's config so every client's
        # recon_config.json ends up with the key, not just the first one that was
        # asked. (Without this, a key entered for client 1 was recognized for
        # clients 2+ but never saved to their config files.)
        stashed = runmode.answer(field, "")
        if bool(getattr(cfg, field, "") if cfg else ""):
            return                                  # already in this client's config
        if stashed:
            _save_config_key(config_path, field, stashed)
            return
        if bool(os.getenv(env_name, "")):
            return                                  # env-provided; no need to store
        val = _ask_secret(prompt)
        if val:
            runmode.stash(field, val)
            _save_config_key(config_path, field, val)

    print("\n  API keys — to SKIP a tool for this client, leave its key blank:")
    _key_prompt("serpapi_key", "SERPAPI_KEY",
                "SerpAPI key (file + email enumeration) — blank to skip",
                enabled("run_fileenum") or enabled("run_emailenum"))
    # fileenum scope: basic (metadata files only, ~8 SerpAPI credits) vs full
    # (everything + secret dorks, ~60 credits — brutal on a free account).
    if enabled("run_fileenum"):
        from .runmode import prompt_choice
        print("    fileenum file search: BASIC = metadata files only")
        print("    (pdf/doc(x)/xls(x)/ppt(x)/csv, ~8 credits). FULL = every file")
        print("    type + secret dorks (~60 credits).")
        _fe = prompt_choice(
            "    fileenum — [B]asic (default) / [F]ull? [B/f]: ",
            {"b": "basic", "basic": "basic", "f": "full", "full": "full"},
            default="basic")
        runmode.stash("fileenum_mode", _fe)
        _save_config_key(config_path, "fileenum_mode", _fe)
    _key_prompt("snov_client_id", "SNOV_CLIENT_ID",
                "Snov.io client ID (email discovery) — blank to skip", enabled("run_snov"))
    _key_prompt("snov_client_secret", "SNOV_CLIENT_SECRET",
                "Snov.io client secret (email discovery) — blank to skip", enabled("run_snov"))
    _key_prompt("grayhat_api_key", "GRAYHAT_API_KEY",
                "GrayHatWarfare key (bucket search) — blank to skip", enabled("run_buckets"))
    _key_prompt("cvemap_api_key", "PDCP_API_KEY",
                "ProjectDiscovery PDCP key for cvemap CVE lookup — a FREE account "
                "raises the rate limit and makes the cvemap stage much faster; "
                "blank = free/anonymous tier (works, just slower)",
                enabled("run_cvemap"))
    _key_prompt("shodan_api_key", "SHODAN_API_KEY",
                "Shodan key (host lookup + optional on-demand scan; free "
                "InternetDB works without it) — blank to skip the key-gated parts",
                enabled("run_shodan"))
    # If a Shodan key is present, offer the ACTIVE on-demand scan (validation of
    # nmap/Nessus-discovered IPs). This is an active 3rd-party scan, so it's
    # explicitly opt-in with a clear warning.
    if enabled("run_shodan"):
        _have_shodan = bool(getattr(cfg, "shodan_api_key", "") if cfg else "") \
            or bool(os.getenv("SHODAN_API_KEY", "")) \
            or bool(runmode.answer("shodan_api_key", ""))
        if _have_shodan:
            print("\n  ⚠ WARNING: Shodan on-demand scan will have SHODAN (a 3rd "
                  "party) ACTIVELY SCAN the target hosts from their infrastructure.")
            ans = _ask("Run Shodan on-demand scan on discovered IPs? [y/N]", "N").strip().lower()
            want = ans in ("y", "yes")
            runmode.stash("shodan_ondemand_scan", want)
            _save_config_key(config_path, "shodan_ondemand_scan", want)
    _key_prompt("github_token", "GITHUB_TOKEN",
                "GitHub token (repo enumeration + secret scanning) — blank to skip",
                enabled("run_trufflehog") or enabled("run_gitleaks"))

    # ---- subfinder config notice (one-time awareness, not management) ----
    # subfinder works WITHOUT keys, but source keys (VirusTotal, Censys,
    # SecurityTrails, Chaos, etc.) greatly improve results. Those live in
    # subfinder's OWN config by design — we don't manage that file, we just make
    # sure the user knows to set it up (and where, given sudo).
    if enabled("run_subdomains"):
        _subfinder_config_notice()

    # ---- PartyOn (breach/credential): DeHashed key + mode (results vs spray) ----
    if enabled("run_partyon"):
        print("\n  PartyOn (breach/credential lookup):")
        # DeHashed key: only ask if not already set. Check config, env, AND the
        # in-session stash — the stash check is what stops it re-asking on every
        # client in a 'configure --mode each' session (same behavior as the other
        # API keys via _key_prompt). Without it, a key entered for client 1 isn't
        # recognized for clients 2+, so it re-prompted every time.
        _dh_stashed = runmode.answer("dehashed_api_key", "")
        if bool(getattr(cfg, "dehashed_api_key", "") if cfg else ""):
            pass                                    # already in this client's config
        elif _dh_stashed:
            _save_config_key(config_path, "dehashed_api_key", _dh_stashed)  # propagate
        elif not bool(os.getenv("DEHASHED_API_KEY", "")):
            key = _ask_secret("DeHashed API key (blank = skip PartyOn)")
            if key:
                runmode.stash("dehashed_api_key", key)
                _save_config_key(config_path, "dehashed_api_key", key)
        # Mode: DeHashed results only (default, safe) vs full harvest + credential
        # spray. The spray FIRES credential stuffing at the client, so it is an
        # explicit opt-in and never the default.
        from .runmode import prompt_choice
        print("    PartyOn can pull DeHashed results only, or also run the credential-")
        print("    spray engine (this FIRES credential stuffing at the client).")
        spray = prompt_choice(
            "    Mode — [R]esults only (default) / [F]ull harvest+spray? [R/f]: ",
            {"r": False, "results": False, "n": False,
             "f": True, "full": True, "spray": True, "y": True},
            default=False)
        runmode.stash("partyon_spray", spray)
        _save_config_key(config_path, "partyon_spray", spray)
        if spray:
            # proxy/--url is only used by the spray engine (blank = run without --url)
            proxy = _ask("PartyOn proxy URL for spray (blank = no --url)")
            runmode.stash("partyon_proxy", proxy)
            _save_config_key(config_path, "partyon_proxy", proxy)
            if proxy:
                secs = _ask("PartyOn delay seconds (min 3)", "3")
                runmode.stash("partyon_seconds", secs)
                try:
                    _save_config_key(config_path, "partyon_seconds", int(secs))
                except (TypeError, ValueError):
                    _save_config_key(config_path, "partyon_seconds", 3)
        runmode.stash("partyon_domain", primary)

    print("\n[interview] all answers recorded — starting unattended run.\n")
