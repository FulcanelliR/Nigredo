#!/usr/bin/env python3
"""Global run-mode state: unattended (default) vs manual.

nigredo runs UNATTENDED by default — it can scan for hours or days, so it must
never block waiting for input partway through. Every interactive prompt helper
checks `is_unattended()` and returns its default instead of blocking.

`--manual` flips this to interactive, restoring the step-by-step prompting where
the operator answers each question as tools reach them.

A small set of values that genuinely must be known to run (and have no safe
default) are collected ONCE at startup by the "setup interview" (see
interview.py) and stashed here, so even unattended runs have them ready.
"""
from __future__ import annotations

_UNATTENDED = True          # default: fire-and-forget
_ANSWERS: dict = {}         # pre-collected answers from the startup interview
_NOTES: list = []           # caveats to surface in the final report/output


def add_note(note: str) -> None:
    """Record a caveat (e.g. a value was derived/unverified) to surface at the
    end of the run and in the report."""
    if note not in _NOTES:
        _NOTES.append(note)


def get_notes() -> list:
    return list(_NOTES)


def set_manual(manual: bool) -> None:
    global _UNATTENDED
    _UNATTENDED = not manual


_VERBOSE = False


def set_verbose(v: bool) -> None:
    """Quiet by default: only HEARTHBEAT + current tool name print. --verbose
    turns on the detailed per-tool output."""
    global _VERBOSE
    _VERBOSE = bool(v)


def is_verbose() -> bool:
    return _VERBOSE


def is_unattended() -> bool:
    return _UNATTENDED


def stash(key: str, value) -> None:
    _ANSWERS[key] = value


def answer(key: str, default=None):
    """Return a pre-collected answer, or the given default if none was set."""
    return _ANSWERS.get(key, default)


def has_answer(key: str) -> bool:
    return key in _ANSWERS


def prompt_choice(prompt: str, valid, default=None, *,
                  quit_tokens=("q", "quit")):
    """Prompt the operator until they enter a RECOGNIZED option, re-asking on
    anything unrecognized instead of silently falling back to a default.

    - `valid`: either a mapping {accepted_token: canonical_value} or an iterable
      of accepted tokens (then each token maps to itself). Tokens are matched
      case-insensitively after strip().
    - blank input selects `default` when `default is not None`; if `default` is
      None, blank is NOT accepted and the prompt repeats.
    - EOF (piped/closed stdin) returns `default` immediately — never loops, so a
      non-interactive run can't hang here.
    - a token in `quit_tokens` (and not overridden by `valid`) raises
      KeyboardInterrupt so callers can treat it as an operator quit.

    NOTE: this helper does NOT itself check is_unattended() — callers that should
    auto-proceed when unattended must gate on that BEFORE calling (as _gate does),
    while the startup interview intentionally prompts even in unattended mode.

    Returns the canonical value for the chosen token (or `default`).
    """
    if isinstance(valid, dict):
        table = {str(k).strip().lower(): v for k, v in valid.items()}
    else:
        table = {str(t).strip().lower(): str(t).strip().lower() for t in valid}
    quitset = {str(q).strip().lower() for q in quit_tokens
               if str(q).strip().lower() not in table}
    shown = "/".join(table.keys()) or "(no options)"
    while True:
        try:
            ans = input(prompt).strip().lower()
        except EOFError:
            return default
        if ans == "" and default is not None:
            return default
        if ans in table:
            return table[ans]
        if ans in quitset:
            raise KeyboardInterrupt("operator quit")
        hint = f"    please enter one of: {shown}"
        if quitset:
            hint += "  (or " + "/".join(sorted(quitset)) + " to quit)"
        print(hint)
