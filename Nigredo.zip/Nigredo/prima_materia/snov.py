#!/usr/bin/env python3
"""Snov.io domain email enumeration (phase 2 email).

Pulls email addresses for a domain via the Snov.io v2 Domain Search API and
enforces that every returned address is actually on the target domain (the API
occasionally returns off-domain stragglers; we drop those and log them).

Flow:
  1. Auth:  POST /v1/oauth/access_token  (client_credentials) -> access_token
  2. Start: POST /v2/domain-search/start {domain} -> task_hash
  3. Result: GET /v2/domain-search/result/{task_hash} -> company info + links
            (links.domain_emails is the URL for on-domain addresses)
  4. Follow the domain_emails link, paginating, to collect addresses.

Credentials come from --client-id/--client-secret or the SNOV_CLIENT_ID /
SNOV_CLIENT_SECRET environment variables. Nothing is hardcoded.

Discovery only: returns addresses; does not send mail or validate credentials.
"""
from __future__ import annotations

import os
import time
from pathlib import Path

import requests

API = "https://api.snov.io"
AUTH_URL = f"{API}/v1/oauth/access_token"
START_URL = f"{API}/v2/domain-search/start"
RESULT_URL = f"{API}/v2/domain-search/result/{{task_hash}}"
# free (0-credit) endpoint: how many domain emails Snov has, for cost estimation
EMAIL_COUNT_URL = f"{API}/v1/get-domain-emails-count"
EMAILS_PER_PAGE = 50   # snov bills 1 credit per page of up to 50 domain emails


def get_free_email_count(domain: str, token: str, timeout: int = 30):
    """FREE (0-credit) endpoint: number of domain emails Snov has. Returns an int,
    or None for webmail/unavailable. Used to estimate cost before spending."""
    try:
        resp = requests.post(EMAIL_COUNT_URL,
                             data={"access_token": token, "domain": domain},
                             timeout=timeout)
        if resp.status_code != 200:
            return None
        body = resp.json()
        if not body.get("success") or body.get("webmail"):
            return None
        return int(body.get("result", 0) or 0)
    except (requests.RequestException, ValueError, TypeError):
        return None


def estimate_all_emails_credits(email_count: int) -> int:
    """1 credit per page of up to 50 domain emails (snov's 'all emails' model)."""
    import math
    return math.ceil(email_count / EMAILS_PER_PAGE) if email_count > 0 else 0


class SnovError(RuntimeError):
    pass


def get_access_token(client_id: str, client_secret: str, timeout: int = 30) -> str:
    resp = requests.post(AUTH_URL, data={
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
    }, timeout=timeout)
    resp.raise_for_status()
    tok = resp.json().get("access_token")
    if not tok:
        raise SnovError("no access_token in auth response")
    return tok


def _auth_headers(token: str) -> dict:
    return {"Authorization": f"Bearer {token}"}


def start_domain_search(token: str, domain: str, timeout: int = 30) -> str:
    """Kick off the async domain search; return the task_hash."""
    resp = requests.post(START_URL, headers=_auth_headers(token),
                         data={"domain": domain}, timeout=timeout)
    resp.raise_for_status()
    body = resp.json()
    task_hash = (body.get("meta") or {}).get("task_hash") or body.get("task_hash")
    if not task_hash:
        raise SnovError(f"no task_hash in start response: {body}")
    return task_hash


def get_result(token: str, task_hash: str, timeout: int = 30,
               poll_interval: float = 2.0, max_polls: int = 30) -> dict:
    """Poll the result endpoint until data is ready; return the parsed body.
    The body's links.domain_emails is the URL to fetch on-domain addresses."""
    url = RESULT_URL.format(task_hash=task_hash)
    for _ in range(max_polls):
        resp = requests.get(url, headers=_auth_headers(token), timeout=timeout)
        resp.raise_for_status()
        body = resp.json()
        # When still processing, the data/links may be absent; keep polling.
        if body.get("data") or (body.get("links") or {}).get("domain_emails"):
            return body
        time.sleep(poll_interval)
    return {}


def _emails_from_payload(payload) -> list[str]:
    """Pull email strings out of a Snov payload that may nest them under
    common keys. Tolerant of shape changes across API versions."""
    found: list[str] = []

    def walk(obj):
        if isinstance(obj, dict):
            # direct email field
            for key in ("email", "emails", "value"):
                v = obj.get(key)
                if isinstance(v, str) and "@" in v:
                    found.append(v)
                elif isinstance(v, list):
                    for item in v:
                        walk(item)
            for v in obj.values():
                if isinstance(v, (dict, list)):
                    walk(v)
        elif isinstance(obj, list):
            for item in obj:
                walk(item)
        elif isinstance(obj, str) and "@" in obj:
            found.append(obj)

    walk(payload)
    return found


def fetch_domain_emails(token: str, domain_emails_url: str, timeout: int = 30,
                        max_pages: int = 50, poll_interval: float = 1.0) -> list[str]:
    """Follow the domain_emails link, paginating, returning all email strings."""
    emails: list[str] = []
    page = 1
    while page <= max_pages:
        sep = "&" if "?" in domain_emails_url else "?"
        url = f"{domain_emails_url}{sep}page={page}"
        resp = requests.get(url, headers=_auth_headers(token), timeout=timeout)
        resp.raise_for_status()
        body = resp.json()
        page_emails = _emails_from_payload(body.get("data", body))
        if not page_emails:
            break
        emails.extend(page_emails)
        # stop if there's no next page indicated
        meta = body.get("meta") or {}
        last_page = meta.get("last_page") or meta.get("total_pages")
        if last_page and page >= int(last_page):
            break
        page += 1
        time.sleep(poll_interval)
    return emails


def filter_on_domain(emails, domain: str) -> tuple[list[str], list[str]]:
    """Lowercase, then split into (on_domain, off_domain) unique sorted lists.
    On-domain = address ends with @<domain> exactly."""
    suffix = "@" + domain.lower()
    on_set, off_set = set(), set()
    for e in emails:
        e = e.strip().lower()
        if not e or "@" not in e:
            continue
        if e.endswith(suffix):
            on_set.add(e)
        else:
            off_set.add(e)
    return (sorted(on_set), sorted(off_set))


def process(domain: str, outdir, command_log,
            client_id: str = "", client_secret: str = "",
            ledger=None, dry_run: bool = False) -> Path | None:
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    safe = domain.replace("/", "_")

    client_id = client_id or os.getenv("SNOV_CLIENT_ID", "")
    client_secret = client_secret or os.getenv("SNOV_CLIENT_SECRET", "")

    with open(command_log, "a") as log:
        log.write(f"snov.io domain-search domain={domain}\n")
    if dry_run:
        print(f"[dry-run] snov.io domain-search for {domain}")
        return None
    if not client_id or not client_secret:
        print("[snov] missing credentials (SNOV_CLIENT_ID / SNOV_CLIENT_SECRET) — skipping")
        return None

    try:
        token = get_access_token(client_id, client_secret)

        # FREE (0-credit) cost estimate first, so we know+report the cost before
        # spending anything. All-emails mode: 1 credit per 50-email page.
        est_count = get_free_email_count(domain, token)
        est_credits = estimate_all_emails_credits(est_count) if est_count else 0
        if est_count is not None:
            print(f"[snov] {domain}: ~{est_count} emails available, "
                  f"est. ~{est_credits} credit(s) (all-emails mode)")
            # optional cap check BEFORE spending (only if user set one)
            if ledger is not None and ledger.would_exceed("snov", est_credits):
                print(f"[snov] estimated {est_credits} credits would exceed the "
                      f"snov cap — skipping snov for {domain}")
                return None

        task_hash = start_domain_search(token, domain)
        result = get_result(token, task_hash)
        links = result.get("links") or {}
        domain_emails_url = links.get("domain_emails")

        if domain_emails_url:
            raw_emails = fetch_domain_emails(token, domain_emails_url)
        else:
            # fall back to any emails embedded directly in the result payload
            raw_emails = _emails_from_payload(result.get("data", result))
    except requests.HTTPError as e:
        status = getattr(e.response, "status_code", None)
        if status in (401, 403):
            print(f"[snov] API returned {status} (auth/credits/plan) — skipping "
                  f"snov for {domain}. Check the Snov key, remaining API limits, "
                  f"and that domain-search is enabled on your plan.")
        elif status == 429:
            print(f"[snov] rate-limited (429) — skipping snov for {domain}")
        else:
            print(f"[snov] API error ({status or 'network'}) — skipping snov for "
                  f"{domain}: {e}")
        return None
    except (requests.RequestException, ValueError, KeyError) as e:
        # network failure, bad JSON, unexpected payload shape — skip, don't crash
        print(f"[snov] failed for {domain} ({type(e).__name__}) — skipping: {e}")
        return None

    on_domain, off_domain = filter_on_domain(raw_emails, domain)

    # record credit spend: 1 credit per 50-email page actually retrieved.
    # (estimated — snov's API doesn't return an exact per-call credit figure.)
    if ledger is not None:
        import math
        pages = math.ceil(len(raw_emails) / EMAILS_PER_PAGE) if raw_emails else 0
        if pages:
            try:
                ledger.record("snov", pages, kind="estimated",
                              note=f"{len(raw_emails)} emails / {domain}")
            except Exception as e:  # noqa: BLE001 (BudgetExceeded etc.)
                print(f"[snov] {e}")

    emails_path = outdir / f"snov_{safe}.emails.txt"
    offdomain_path = outdir / f"snov_{safe}.offdomain.txt"
    emails_path.write_text("\n".join(on_domain) + ("\n" if on_domain else ""))
    offdomain_path.write_text("\n".join(off_domain) + ("\n" if off_domain else ""))

    print(f"[\u2713] snov on-domain emails: {len(on_domain)} -> {emails_path}")
    if off_domain:
        print(f"[i] off-domain dropped (review): {len(off_domain)} -> {offdomain_path}")
    return emails_path
