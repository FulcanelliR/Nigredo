#!/usr/bin/env python3
"""Parse a Nessus .nessus (XML) export for the nigredo discovery layer.

nmap and Nessus together form the discovery layer: two independent sources that
cross-validate to map all potential targets with high confidence. This parser
pulls, per host, the port/service data AND the findings so the workbook can show
Nessus and nmap side by side for validation, while a merged union of both feeds
the downstream tools.

Conventions follow the user's proven n2csv.py:
  - Port/service list comes from these plugin families only:
    Port scanners, Service detection, DNS, SNMP, Windows
  - Findings come from ANY plugin with severity > 0 (Low..Critical), formatted
    [PROTO PORT] -Severity- pluginID pluginName
  - port == 0 items are host-level, skipped for the port list

Also pulled: plugin_output (full), OS (operating-system), CVE(s), CVSS v3.1 base
score (cvss3_base_score).
"""
from __future__ import annotations

import defusedxml.ElementTree as ET
from pathlib import Path

PORT_FAMILIES = {"Port scanners", "Service detection", "DNS", "SNMP", "Windows"}
_SEV = {0: "Informational", 1: "Low", 2: "Medium", 3: "High", 4: "Critical"}

# ---- detection-method provenance: which plugin found a port, and how ----
# Maps well-known Nessus discovery pluginIDs to a human method label. This tells
# us HOW Nessus knew a port was open — a credentialed netstat/WMI enumeration is
# authoritative; a remote SYN/service probe is reliable but can miss/guess (the
# '?' cases). Optional: unknown pluginIDs simply aren't tagged.
_DETECTION_PLUGINS = {
    "11219": "SYN scan",              # Nessus SYN scanner
    "10335": "nmap portscan",         # Nessus nmap wrapper
    "14272": "netstat portscan",      # netstat (credentialed)
    "34220": "netstat portscan",      # netstat portscanner
    "25221": "netstat portscan",      # remote-registry netstat
    "22964": "service detection",     # Service Detection (fingerprint)
    "10884": "ping/host-alive",
    "34277": "nmap (xml import)",
}
# which of those imply the scan had CREDENTIALS (authoritative results)
_DETECTION_IS_CREDENTIALED = {
    "14272": True, "34220": True, "25221": True,
}

# exploit-framework tags Nessus emits (all optional per plugin/version)
_EXPLOIT_FRAMEWORKS = [
    ("exploit_framework_metasploit", "Metasploit"),
    ("exploit_framework_canvas", "CANVAS"),
    ("exploit_framework_core", "Core Impact"),
    ("exploit_framework_d2_elliot", "D2 Elliot"),
]


def _truthy(v: str) -> bool:
    return (v or "").strip().lower() in ("true", "yes", "1")


def _new_port_detail(svc: str, proto: str) -> dict:
    """A fresh per-port record with all fields the expanded parser populates.
    Everything beyond the core is optional and stays empty if Nessus didn't emit
    it, so this is safe across Nessus versions."""
    return {
        "service": svc, "protocol": proto.upper(),
        "findings": [], "outputs": [], "cves": [], "cvss3": [],
        # --- expanded provenance / exploitability (all optional) ---
        "cvss3_vectors": [],
        "detected_by": [],          # e.g. ['SYN scan', 'service detection']
        "credentialed": False,      # True if a credentialed plugin saw it
        "exploit_available": False,
        "metasploit": [],
        "exploit_frameworks": [],
        "exploit_ease": "",
        "plugin_types": [],         # 'remote' / 'local'
        "solution": "",
        "synopsis": "",
    }


def _host_props(rh) -> dict:
    props = {}
    hp = rh.find("HostProperties")
    if hp is not None:
        for tag in hp.findall("tag"):
            name = tag.get("name", "")
            if name:
                props[name] = (tag.text or "").strip()
    return props


def parse_nessus(path) -> dict:
    """Return {ip: host_dict}. Each host_dict has:
        address, hostnames[], os, open_ports (csv),
        ports: {("tcp",443): {service, protocol, findings[], outputs[],
                              cves[], cvss3[]}},
        findings_by_plugin: {pluginName: [(ip,proto,port,severity), ...]}
    """
    path = Path(path)
    root = ET.parse(path).getroot()
    results: dict[str, dict] = {}

    report = root.find("Report")
    if report is None:
        return results

    for rh in report.findall("ReportHost"):
        props = _host_props(rh)
        ip = props.get("host-ip") or rh.get("name", "")
        if not ip:
            continue
        fqdn = props.get("host-fqdn", "")
        host = results.setdefault(ip, {
            "address": ip,
            "hostnames": [fqdn] if fqdn else [],
            "os": props.get("operating-system", ""),
            "open_ports": "",
            "ports": {},           # (proto, port) -> details
            "findings_by_plugin": {},
        })

        port_set: set[int] = set()

        for item in rh.findall("ReportItem"):
            proto = (item.get("protocol", "tcp") or "tcp").lower()
            try:
                port = int(item.get("port", "0"))
            except ValueError:
                continue
            family = item.get("pluginFamily", "")
            svc = item.get("svc_name", "")
            sev = int(item.get("severity", "0") or 0)
            pid = item.get("pluginID", "")
            pname = item.get("pluginName", "")

            # ---- port/service list: only the port-ish families, tcp, port>0 ----
            if port != 0 and proto == "tcp" and family in PORT_FAMILIES:
                port_set.add(port)
                key = (proto, port)
                pd = host["ports"].setdefault(key, _new_port_detail(svc, proto))
                # DETECTION METHOD / PROVENANCE — which plugin found this port, and
                # was it credentialed? This tells us HOW reliable the finding is.
                if pid in _DETECTION_PLUGINS:
                    method = _DETECTION_PLUGINS[pid]
                    if method not in pd["detected_by"]:
                        pd["detected_by"].append(method)
                    if _DETECTION_IS_CREDENTIALED.get(pid):
                        pd["credentialed"] = True

            # ---- findings: ANY plugin with severity > 0, attach to its port ----
            if sev > 0 and port != 0:
                key = (proto, port)
                pd = host["ports"].setdefault(key, _new_port_detail(svc, proto))
                pd["findings"].append(
                    f"[{proto.upper()} {port}] -{_SEV.get(sev,'')}- {pid} {pname}")
                out = (item.findtext("plugin_output", "") or "").strip()
                if out:
                    pd["outputs"].append(out)
                # CVEs (can be multiple)
                for cve in item.findall("cve"):
                    if cve.text:
                        pd["cves"].append(cve.text.strip())
                # CVSS v3.1 base score + vector (vector shows attack characteristics)
                c3 = item.findtext("cvss3_base_score", "")
                if c3:
                    pd["cvss3"].append(c3.strip())
                v3 = item.findtext("cvss3_vector", "") or item.findtext("cvss3_base_vector", "")
                if v3 and v3.strip() not in pd["cvss3_vectors"]:
                    pd["cvss3_vectors"].append(v3.strip())

                # ---- EXPLOITABILITY — feeds Cache/PoC + prioritization ----
                # All optional; absent on Nessus versions/plugins that don't emit them.
                if _truthy(item.findtext("exploit_available", "")):
                    pd["exploit_available"] = True
                ms = (item.findtext("metasploit_name", "") or "").strip()
                if ms and ms not in pd["metasploit"]:
                    pd["metasploit"].append(ms)
                for fw_tag, fw_label in _EXPLOIT_FRAMEWORKS:
                    if _truthy(item.findtext(fw_tag, "")):
                        if fw_label not in pd["exploit_frameworks"]:
                            pd["exploit_frameworks"].append(fw_label)
                ease = (item.findtext("exploitability_ease", "") or "").strip()
                if ease and not pd["exploit_ease"]:
                    pd["exploit_ease"] = ease

                # ---- plugin_type: 'remote' (network-observable) vs 'local'
                # (needs credentials). A local finding implies a credentialed scan. ----
                ptype = (item.findtext("plugin_type", "") or "").strip().lower()
                if ptype:
                    if ptype not in pd["plugin_types"]:
                        pd["plugin_types"].append(ptype)
                    if ptype == "local":
                        pd["credentialed"] = True

                # ---- remediation context for the report (optional) ----
                for tag in ("solution", "synopsis"):
                    val = (item.findtext(tag, "") or "").strip()
                    if val and not pd[tag]:
                        pd[tag] = val

                # vuln matrix
                host["findings_by_plugin"].setdefault(pname, []).append(
                    (ip, proto.upper(), port, _SEV.get(sev, "")))

        host["open_ports"] = ",".join(str(p) for p in sorted(port_set))

    return results


def derive_scope_hosts(paths: list[str]) -> list[str]:
    """Extract the host IPs (that have open ports) from one or more .nessus files,
    for use as scope when no targets.txt was provided. Sorted, deduped."""
    if not paths:
        return []
    rich = load_multi(paths) if len(paths) > 1 else load(paths[0])
    tgt = to_target_dict(rich)
    hosts = sorted(tgt.keys(), key=lambda ip: [int(o) for o in ip.split(".")]
                   if ip.count(".") == 3 and all(o.isdigit() for o in ip.split("."))
                   else [0, 0, 0, 0])
    return hosts


def seed_scope_from_nessus(paths: list[str], targets_path="targets.txt",
                           assume_yes: bool = False) -> list[str]:
    """Nessus-only scope seeding: when no targets.txt was provided but .nessus
    file(s) are present, derive the scope from the Nessus hosts. Echoes the
    derived hosts for CONFIRMATION before writing them (guards over-scoping — the
    analyst sees exactly what will be scanned and approves). Returns the seeded
    host list (empty if declined or none found).

    If both a targets.txt AND Nessus exist, this is NOT called — the explicit
    targets.txt wins; Nessus is merged separately in the pipeline."""
    hosts = derive_scope_hosts(paths)
    if not hosts:
        print("[scope] no Nessus hosts with open ports to seed scope from.")
        return []
    print(f"\n[scope] No targets.txt provided, but {len(paths)} Nessus file(s) "
          f"present. Derived {len(hosts)} host(s) with open ports:")
    for h in hosts:
        print(f"    {h}")
    if not assume_yes:
        try:
            from .runmode import is_unattended
            if is_unattended():
                # headless/automated run: don't hang on input(). Auto-SKIP seeding
                # (safer than auto-seeding scope without a human confirming).
                print("[scope] unattended run — Nessus seeding skipped "
                      "(no operator to confirm scope).")
                return []
        except Exception:  # noqa: BLE001
            pass
        try:
            ans = input(f"  Seed scope with these {len(hosts)} host(s)? [y/N]: "
                        ).strip().lower()
        except EOFError:
            ans = "n"
        if ans not in ("y", "yes"):
            print("[scope] Nessus seeding declined — no targets seeded.")
            return []
    try:
        from pathlib import Path as _P
        _P(targets_path).write_text("\n".join(hosts) + "\n")
        print(f"[scope] seeded {len(hosts)} host(s) into {targets_path}")
    except OSError as e:
        print(f"[scope] could not write {targets_path}: {e}")
        return []
    return hosts


def to_target_dict(results: dict) -> dict:
    """Reduce the rich parse to the simple {ip: {address, hostnames, open_ports,
    filtered_count}} shape the pipeline uses to seed/merge the target list."""
    out = {}
    for ip, h in results.items():
        if not h["open_ports"]:
            continue
        out[ip] = {
            "address": ip,
            "hostnames": list(h["hostnames"]),
            "open_ports": h["open_ports"],
            "filtered_count": 0,
        }
    return out


def load(path) -> dict:
    """Parse and return the RICH results (for the workbook + target seeding)."""
    results = parse_nessus(path)
    total_ports = sum(len(h["ports"]) for h in results.values())
    total_find = sum(sum(len(p["findings"]) for p in h["ports"].values())
                     for h in results.values())
    print(f"[nessus] parsed {len(results)} host(s), {total_ports} port(s), "
          f"{total_find} finding(s) from {Path(path).name}")
    return results


def load_multi(paths: list[str]) -> dict:
    """Parse several .nessus files and merge them into one rich result set.

    Files are merged by IP; ports/findings union together. Each host records
    which source file(s) it came from (host['sources']) so provenance can be
    surfaced. Later files' findings are appended, not overwritten.
    """
    combined: dict = {}
    for p in paths:
        if not p:
            continue
        try:
            one = parse_nessus(p)
        except Exception as e:  # noqa: BLE001
            print(f"[nessus] could not parse {p}: {e}")
            continue
        fname = Path(p).name
        n_ports = sum(len(h["ports"]) for h in one.values())
        print(f"[nessus] {fname}: {len(one)} host(s), {n_ports} port(s)")
        for ip, h in one.items():
            if ip not in combined:
                h["sources"] = [fname]
                combined[ip] = h
                continue
            c = combined[ip]
            c.setdefault("sources", [])
            if fname not in c["sources"]:
                c["sources"].append(fname)
            # union hostnames
            for fq in h["hostnames"]:
                if fq and fq not in c["hostnames"]:
                    c["hostnames"].append(fq)
            if not c.get("os") and h.get("os"):
                c["os"] = h["os"]
            # union ports + their findings
            for key, pd in h["ports"].items():
                if key not in c["ports"]:
                    c["ports"][key] = pd
                else:
                    cp = c["ports"][key]
                    cp["findings"].extend(pd["findings"])
                    cp["outputs"].extend(pd["outputs"])
                    cp["cves"].extend(pd["cves"])
                    cp["cvss3"].extend(pd["cvss3"])
            # rebuild open_ports
            allp = {int(port) for (_pr, port) in c["ports"].keys()}
            c["open_ports"] = ",".join(str(x) for x in sorted(allp))
    total_ports = sum(len(h["ports"]) for h in combined.values())
    print(f"[nessus] combined: {len(combined)} host(s), {total_ports} port(s) "
          f"from {len([p for p in paths if p])} file(s)")
    return combined
