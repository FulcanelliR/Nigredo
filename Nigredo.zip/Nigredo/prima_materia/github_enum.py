#!/usr/bin/env python3
"""GitHub enumeration + secret scanning (phase 1).

Two independent, gated tools that look for leaked credentials in a target's
public GitHub presence. RAW OUTPUT ONLY for now — native JSON/JSONL plus stdout
saved to the engagement folder; no parsing or report integration yet.

  trufflehog  -- scans an entire GitHub ORG via the GitHub API (no cloning),
                 with live credential verification. `github --org=<org>`.
  gitleaks    -- has no native org scan, so this enumerates the org's PUBLIC
                 repos via the GitHub API, clones each to a temp dir, runs
                 `gitleaks git` over full history, saves raw JSON per repo, then
                 removes the clones.

Public repositories only — no private-repo scanning. Both skip safely if their
binary (or git) isn't on PATH.

WARNING: secret scanners surface REAL credentials in cleartext in their output.
These files live in the per-client engagement folder and must be handled with
the same care as any other sensitive engagement artifact.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

import requests

GITHUB_API = "https://api.github.com"


# ---------------------------------------------------------------- trufflehog
def run_trufflehog(org: str, outdir: Path, command_log: Path,
                   token: str = "", results: str = "verified,unknown,unverified",
                   include_members: bool = False, include_comments: bool = False,
                   dry_run: bool = False) -> Path | None:
    """Scan a whole GitHub org with TruffleHog. Raw JSONL saved."""
    if shutil.which("trufflehog") is None and not dry_run:
        print("[trufflehog] 'trufflehog' not found on PATH — skipping")
        return None

    out_jsonl = outdir / f"trufflehog_{org}.jsonl"
    stdout_file = outdir / f"trufflehog_{org}.stdout.txt"

    cmd = ["trufflehog", "github", f"--org={org}", "--json",
           f"--results={results}"]
    if token:
        cmd.append(f"--token={token}")
    if include_members:
        cmd.append("--include-members")
    if include_comments:
        cmd += ["--issue-comments", "--pr-comments", "--gist-comments"]

    # log with token redacted
    safe_cmd = [c if not c.startswith("--token=") else "--token=***" for c in cmd]
    with open(command_log, "a") as log:
        log.write(" ".join(safe_cmd) + f"  > {out_jsonl}\n")
    if dry_run:
        print("[dry-run]", " ".join(safe_cmd), ">", out_jsonl)
        return None

    print(f"[trufflehog] scanning org '{org}' (live verification)...")
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=3600)
        # trufflehog writes findings as JSON lines to stdout
        out_jsonl.write_text(res.stdout or "")
        if res.stderr:
            stdout_file.write_text(res.stderr)
        n = sum(1 for ln in (res.stdout or "").splitlines() if ln.strip())
        print(f"[\u2713] trufflehog: {n} finding line(s) -> {out_jsonl}")
    except subprocess.TimeoutExpired:
        print("[trufflehog] timed out (60m) — partial output may be saved")
    except Exception as e:  # noqa: BLE001
        stdout_file.write_text(f"trufflehog error: {e}\n")
        print(f"[trufflehog] error: {e}")
    return out_jsonl if out_jsonl.exists() else None


# ------------------------------------------------------------------ gitleaks
def parse_github_target(value: str) -> tuple[str, str]:
    """Normalize whatever the operator gave into (owner, repo_or_empty).

    Accepts:
      - a full URL:      https://github.com/owner/repo  -> ('owner', 'repo')
      - a full URL:      https://github.com/owner       -> ('owner', '')
      - 'owner/repo'     -> ('owner', 'repo')
      - 'owner'          -> ('owner', '')
      - just 'repo' (what you gave last time — the part after owner/) can't be
        resolved without the owner, so it's returned as ('repo', '') and treated
        as a handle; the caller will report if nothing's found.
    """
    v = value.strip()
    if not v:
        return ("", "")
    # strip a github URL down to the path
    for prefix in ("https://github.com/", "http://github.com/",
                   "https://www.github.com/", "github.com/"):
        if v.lower().startswith(prefix):
            v = v[len(prefix):]
            break
    v = v.strip("/")
    # drop a trailing .git and any extra path segments (/tree/main etc.)
    if v.endswith(".git"):
        v = v[:-4]
    parts = [p for p in v.split("/") if p]
    if len(parts) >= 2:
        return (parts[0], parts[1])
    if len(parts) == 1:
        return (parts[0], "")
    return ("", "")


def list_org_repos(org: str, token: str = "", timeout: int = 30,
                   include_forks: bool = False) -> tuple[list[dict], list[dict]]:
    """List public repos for a GitHub org/user/URL/owner-repo. Returns a tuple
    (repos, forks) — forks are separated so the caller can catalogue them on
    their own report page instead of scanning them. Handles a single 'owner/repo'
    or URL by fetching just that repo."""
    headers = {"Accept": "application/vnd.github+json"}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    owner, repo = parse_github_target(org)
    all_repos: list[dict] = []

    # single specific repo (owner/repo or a repo URL)
    if owner and repo:
        r = requests.get(f"{GITHUB_API}/repos/{owner}/{repo}", headers=headers,
                         timeout=timeout)
        if r.status_code == 200:
            obj = r.json()
            if not obj.get("private"):
                all_repos = [obj]
        elif r.status_code == 403:
            remaining = r.headers.get("X-RateLimit-Remaining", "?")
            print(f"[github] 403 fetching {owner}/{repo} "
                  f"(rate-limit remaining: {remaining})."
                  f"{' Set GITHUB_TOKEN.' if not token else ''}")
        else:
            print(f"[github] repo {owner}/{repo} not found ({r.status_code})")
    else:
        # a handle: list all public repos for the org or user
        handle = owner or org.strip("/")
        for base in (f"{GITHUB_API}/orgs/{handle}/repos",
                     f"{GITHUB_API}/users/{handle}/repos"):
            page = 1
            ok = False
            while True:
                r = requests.get(base, headers=headers,
                                 params={"type": "public", "per_page": 100,
                                         "page": page}, timeout=timeout)
                if r.status_code == 404:
                    break
                if r.status_code == 403:
                    remaining = r.headers.get("X-RateLimit-Remaining", "?")
                    print(f"[github] 403 listing repos for '{handle}' "
                          f"(rate-limit remaining: {remaining})."
                          f"{' Set GITHUB_TOKEN for a higher limit.' if not token else ''}")
                    break
                r.raise_for_status()
                ok = True
                batch = r.json()
                if not batch:
                    break
                all_repos.extend(batch)
                if len(batch) < 100:
                    break
                page += 1
            if ok:
                break

    # split public non-forks from forks (forks catalogued separately, not scanned)
    public = [x for x in all_repos if not x.get("private")]
    non_forks = [x for x in public if not x.get("fork")]
    forks = [x for x in public if x.get("fork")]
    return (non_forks, forks)


def run_gitleaks(org: str, outdir: Path, command_log: Path,
                 token: str = "", clone_depth: int = 0,
                 max_repos: int = 0, dry_run: bool = False) -> Path | None:
    """Clone the org's public repos and run gitleaks over each. Raw JSON per
    repo saved under a gitleaks_<org>/ subfolder."""
    if shutil.which("gitleaks") is None and not dry_run:
        print("[gitleaks] 'gitleaks' not found on PATH — skipping")
        return None
    if shutil.which("git") is None and not dry_run:
        print("[gitleaks] 'git' not found on PATH — skipping (needed to clone)")
        return None

    gl_dir = outdir / f"gitleaks_{org}"
    gl_dir.mkdir(parents=True, exist_ok=True)

    if dry_run:
        with open(command_log, "a") as log:
            log.write(f"gitleaks: enumerate + clone public repos of {org}, "
                      f"then 'gitleaks git <repo> --report-format json' each\n")
        print(f"[dry-run] gitleaks would clone {org}'s public repos and scan each")
        return gl_dir

    try:
        repos, forks = list_org_repos(org, token=token)
    except requests.HTTPError as e:
        print(f"[gitleaks] could not list repos for '{org}': {e}")
        return None

    # catalogue forks separately (recorded for the report, NOT scanned)
    if forks:
        fork_lines = [f"{r.get('full_name', '')}\t{r.get('html_url', '')}"
                      for r in forks]
        (outdir / f"gitleaks_{org}_forks.txt").write_text("\n".join(fork_lines) + "\n")
        print(f"[gitleaks] {len(forks)} fork(s) catalogued (not scanned) -> "
              f"gitleaks_{org}_forks.txt")

    if not repos:
        print(f"[gitleaks] no public non-fork repos found for '{org}'"
              f"{' (only forks, see forks file)' if forks else ''}")
        return gl_dir

    if max_repos and len(repos) > max_repos:
        print(f"[gitleaks] {len(repos)} repos found; capping at {max_repos}")
        repos = repos[:max_repos]

    print(f"[gitleaks] cloning + scanning {len(repos)} public repo(s) of '{org}'")
    scanned = 0
    with tempfile.TemporaryDirectory(prefix="rp_gitleaks_") as tmp:
        for repo in repos:
            name = repo.get("name", "")
            clone_url = repo.get("clone_url", "")
            if not clone_url:
                continue
            dest = Path(tmp) / name
            clone_cmd = ["git", "clone", "--quiet"]
            if clone_depth > 0:
                clone_cmd += ["--depth", str(clone_depth)]
            clone_cmd += [clone_url, str(dest)]
            with open(command_log, "a") as log:
                log.write(" ".join(clone_cmd) + "\n")
            try:
                subprocess.run(clone_cmd, capture_output=True, timeout=600, check=True)
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired) as e:
                print(f"[gitleaks]   clone failed for {name}: skipping")
                continue

            report = gl_dir / f"{name}.json"
            gl_cmd = ["gitleaks", "git", str(dest),
                      "--report-format", "json",
                      "--report-path", str(report),
                      "--exit-code", "0",       # don't fail the run on findings
                      "--no-banner"]
            with open(command_log, "a") as log:
                log.write(" ".join(gl_cmd) + "\n")
            try:
                subprocess.run(gl_cmd, capture_output=True, text=True, errors="replace", timeout=1800)
                scanned += 1
            except subprocess.TimeoutExpired:
                print(f"[gitleaks]   scan timed out for {name}")
            except Exception as e:  # noqa: BLE001
                print(f"[gitleaks]   scan error for {name}: {e}")

    print(f"[\u2713] gitleaks: scanned {scanned} repo(s); raw JSON in {gl_dir}/")
    return gl_dir


# ------------------------------------------------------------------- combined
def prompt_org(default: str = "") -> str:
    from .runmode import is_unattended
    if is_unattended():
        return default    # uses cached company/org; blank = skip cleanly
    try:
        ans = input("  GitHub org / handle to scan "
                    f"(blank to skip){f' [{default}]' if default else ''}: ").strip()
    except EOFError:
        ans = ""
    return ans or default
