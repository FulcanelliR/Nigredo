"""FunnelWeb crawler runner + output ingest (final, optional phase-1 step).

FunnelWeb.py is a standalone async Playwright crawler that produces its own
output tree (<domain>/report.csv, a documents/ folder, and a js/ folder from its
Phase A/B JS analysis). We launch it as a subprocess with the engagement dir as
cwd, so its <domain>/ tree lands alongside the other recon output.

After it runs, we INGEST its report.csv to contribute to the single, workbook-
level "At a Glance" tab: a deduplicated, actionable-intelligence summary. Ingest
rules (agreed with the operator):
  - HTML-decode all URLs (&amp; -> & etc.)
  - dedup emails on the address; dedup JS URLs by PATH (drop the query string so
    cache-buster/session junk doesn't inflate counts)
  - split JS endpoints/files into first-party (target domain + subdomains) vs
    third-party (trackers, CDNs, google/facebook/etc.)
  - the At a Glance page shows a COUNT dashboard for everything, plus LISTINGS
    for the high-value actionable items: unique emails, files (name + source),
    and HIGH-confidence secrets (type + value + where found). JS endpoints and
    below are count-only.
The raw report.csv is never modified — it stays complete for analytics.
"""
from __future__ import annotations

import csv
import html
import os
import shutil
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from urllib.parse import urlparse


def _confirm_seed_url(domain: str, timeout: int = 10) -> str:
    """Turn the primary domain into a CONFIRMED start URL: try https first, then
    http; return whichever responds (any HTTP status = alive). Returns "" if
    NEITHER responds — the caller then fails the run and records it, instead of
    feeding FunnelWeb a dead URL that only crawls 1 page (the in-series bug)."""
    import subprocess as _sp
    if domain.startswith(("http://", "https://")):
        return domain            # already an explicit URL — trust it
    for scheme in ("https", "http"):
        url = f"{scheme}://{domain}"
        try:
            res = _sp.run(["curl", "-s", "-k", "-o", "/dev/null", "-w",
                           "%{http_code}", "--max-time", str(timeout), url],
                          capture_output=True, text=True, errors="replace", timeout=timeout + 5)
            code = (res.stdout or "").strip()
            if code and code != "000":
                return url
        except (OSError, _sp.TimeoutExpired):
            continue
    return ""


def build_command(domain: str, script: str, workers: int = 0,
                  rate_limit: float = 0.0, proxy: str = "",
                  start_url: str = "", stealth: bool = False) -> list[str]:
    # The crawler accepts --url, --workers, --rate-limit (and --max-pages).
    # start_url, if given, is the CONFIRMED live URL; else fall back to https://.
    if not start_url:
        start_url = domain if domain.startswith(("http://", "https://")) else f"https://{domain}"
    cmd = [sys.executable, script, "--url", start_url]
    if workers and workers > 0:
        cmd += ["--workers", str(workers)]
    if rate_limit and rate_limit > 0:
        cmd += ["--rate-limit", str(rate_limit)]
    if proxy:
        cmd += ["--proxy", proxy]   # FW-3: route FunnelWeb through the same proxy
                                    # (the monolith already threads it into both the
                                    # Playwright browser and its aiohttp sessions)
    if stealth:
        cmd += ["--stealth"]        # max-stealth: real Chrome, persistent, headed
    return cmd


def run_funnelweb(domain: str, outdir: Path, command_log: Path,
                  script: str = "FunnelWeb.py", workers: int = 0,
                  rate_limit: float = 0.0, proxy: str = "",
                  stealth: bool = False,
                  dry_run: bool = False) -> bool:
    """Launch FunnelWeb against ONE target (domain or full URL), writing its output
    tree into outdir. Returns True if launched (or dry-run), False if the script is
    unavailable OR the target doesn't respond on http/https (recorded for analyst).

    This is the single-target core. For the multi-target webapp sweep (crawl every
    validated host one at a time), use run_funnelweb_multi().
    """
    script_path = shutil.which(script) or str(Path(script).resolve())

    # Confirm the seed URL FIRST (https then http). Feeding FunnelWeb a dead URL
    # is exactly what made it crawl only 1 page in series. If neither responds,
    # fail the run and record it for the analyst rather than pretend-crawl.
    # If the target is already a full URL, _confirm_seed_url handles it.
    start_url = domain if dry_run else _confirm_seed_url(domain)
    if not dry_run and not start_url:
        from . import audit
        msg = (f"target '{domain}' did not respond on https or http — "
               f"FunnelWeb not launched (no reachable seed URL)")
        print(f"[funnelweb] {msg}")
        try:
            audit.append_error(outdir, "funnelweb", msg, completed=False)
        except Exception:  # noqa: BLE001
            pass
        return False

    cmd = build_command(domain, script_path, workers=workers,
                        rate_limit=rate_limit, proxy=proxy, start_url=start_url,
                        stealth=stealth)

    with open(command_log, "a") as log:
        log.write(f"(cwd={outdir}) " + " ".join(cmd) + "\n")
    if dry_run:
        print("[dry-run] (cwd=%s)" % outdir, " ".join(cmd))
        return True

    if not Path(script_path).is_file():
        print(f"[funnelweb] script not found: {script} — skipping")
        return False

    # The crawler runs with cwd=outdir (so its <netloc>/ tree lands with the other
    # recon output), but its companion audit modules (js_harvest, php_harvest,
    # login_detect, jsluice_scan, retirejs_scan) live NEXT TO THE SCRIPT. Because
    # cwd != script dir, a bare `from js_harvest import ...` in the subprocess
    # would fail and the guarded hooks would silently no-op. Put the script's own
    # directory on PYTHONPATH so those imports resolve regardless of cwd.
    env = dict(os.environ)
    script_dir = str(Path(script_path).resolve().parent)
    existing_pp = env.get("PYTHONPATH", "")
    env["PYTHONPATH"] = (script_dir + os.pathsep + existing_pp) if existing_pp else script_dir

    print(f"[funnelweb] crawling {domain} — Ctrl-C stops it cleanly")
    subprocess.run(cmd, cwd=str(outdir), env=env, check=False)
    return True


def _target_label(target: str) -> str:
    """FunnelWeb keys its output dir on the URL's netloc INCLUDING port
    (e.g. 'app.example.com' or 'app.example.com:8080'). Return that label so we
    can locate each target's output tree and tag its workbook rows uniquely."""
    from urllib.parse import urlparse
    t = target.strip()
    if "://" not in t:
        t = "https://" + t
    netloc = urlparse(t).netloc
    return netloc or target.strip()


def run_funnelweb_multi(targets, outdir: Path, command_log: Path,
                        script: str = "FunnelWeb.py", workers: int = 0,
                        rate_limit: float = 0.0, proxy: str = "",
                        stealth: bool = False,
                        dry_run: bool = False) -> list:
    """Run FunnelWeb against MANY webapp targets, ONE AT A TIME, exhausting the
    list. Each target crawls independently and writes its own <netloc>/ output
    tree (netloc includes the port, so host:80 and host:8080 don't collide).

    Returns the list of target LABELS that were launched (for the caller to ingest
    per-target and tag 'FunnelWeb - <label>' in the workbook). De-dupes targets on
    their netloc label so we don't crawl the same endpoint twice.
    """
    launched = []
    seen = set()
    for target in targets:
        label = _target_label(target)
        if not label or label in seen:
            continue
        seen.add(label)
        print(f"[funnelweb] === target {len(launched)+1}: {label} ===")
        while True:                       # retry loop for THIS target
            try:
                ok = run_funnelweb(target, outdir, command_log, script=script,
                                   workers=workers, rate_limit=rate_limit,
                                   proxy=proxy, stealth=stealth, dry_run=dry_run)
                if ok:
                    launched.append(label)
                break                     # target done -> next target
            except KeyboardInterrupt:
                # One Ctrl+C during funnelweb: 'skip' is ambiguous (this target vs
                # the whole tool), so ask. This matches the single-target tools,
                # where one Ctrl+C skips the current target only.
                from .interrupt import _prompt_multitarget_menu
                act = _prompt_multitarget_menu("funnelweb", label)
                if act == "this":
                    print(f"[funnelweb] skipped '{label}' — next target.")
                    break                 # stop this target, continue the loop
                if act == "retry":
                    print(f"[funnelweb] retrying '{label}'…")
                    continue              # re-crawl this target
                if act == "tool":
                    print("[funnelweb] skipping the rest of funnelweb.")
                    return launched       # clean return -> dispatch moves on
                if act == "quit":
                    raise                 # bubble to dispatch -> save + quit run
    if not launched:
        print("[funnelweb] no reachable targets crawled")
    else:
        print(f"[funnelweb] crawled {len(launched)} target(s): "
              f"{', '.join(launched)}")
    return launched


# ============================ INGEST ============================

def _is_first_party(url: str, base_domains: list[str]) -> bool:
    """True if the URL's host is one of the target domains or a subdomain."""
    try:
        host = urlparse(url).netloc.lower().split(":")[0]
    except Exception:
        return False
    for b in base_domains:
        b = b.lower().split(":")[0]
        if host == b or host.endswith("." + b):
            return True
    return False


def _path_key(url: str) -> str:
    """Canonical key for dedup: scheme+host+path, DROPPING the query string so
    cache-buster/session params don't create false 'unique' endpoints."""
    try:
        p = urlparse(html.unescape(url))
        host = p.netloc.lower()
        path = p.path or "/"
        return f"{p.scheme.lower()}://{host}{path}"
    except Exception:
        return url


@dataclass
class FunnelWebSummary:
    """Deduplicated, actionable rollup of one FunnelWeb report.csv."""
    domain: str = ""
    emails: set = field(default_factory=set)
    files: dict = field(default_factory=dict)        # filename -> source url
    secrets_high: list = field(default_factory=list) # (type, value, where)
    secrets_other_count: int = 0
    js_endpoints_first: set = field(default_factory=set)
    js_endpoints_third: set = field(default_factory=set)
    js_files_first: set = field(default_factory=set)
    js_files_third: set = field(default_factory=set)
    documents: int = 0
    cdn_documents: int = 0
    external_documents: int = 0
    external_doc_list: list = field(default_factory=list)  # (url, referring_page)
    skipped_links: int = 0
    jsluice_secret_flag: bool = False
    retire_findings: list = field(default_factory=list)  # (component_ver, sev, file, advisory)
    retire_high: int = 0


def ingest_report(report_csv: Path, base_domains: list[str]) -> FunnelWebSummary:
    """Parse a FunnelWeb report.csv into a deduplicated summary."""
    s = FunnelWebSummary(domain=base_domains[0] if base_domains else "")
    if not Path(report_csv).is_file():
        return s
    with open(report_csv, newline="", encoding="utf-8", errors="replace") as f:
        reader = csv.reader(f)
        try:
            next(reader)  # header
        except StopIteration:
            return s
        for row in reader:
            if len(row) < 2:
                continue
            while len(row) < 5:
                row.append("")
            cat, detail, source, local, notes = row[:5]
            detail = html.unescape(detail)
            source = html.unescape(source)

            if cat == "Email":
                s.emails.add(detail.strip().lower())
            elif cat in ("Secret", "API Key"):
                # FunnelWeb emits secrets under both "Secret" (with a
                # "[HIGH] <type> (entropy=..)" Notes tag) and "API Key" (a plain
                # row with no Notes). Count both so the At a Glance secrets rollup
                # doesn't silently omit API-key hits.
                conf = "LOW"
                stype = "API Key" if cat == "API Key" else ""
                if notes.startswith("["):
                    conf = notes[1:notes.find("]")] if "]" in notes else "LOW"
                    after = notes[notes.find("]") + 1:].strip()
                    stype = after.split(" (entropy")[0].strip() or stype
                if conf.upper() == "HIGH":
                    s.secrets_high.append((stype, detail, local or source))
                else:
                    s.secrets_other_count += 1
            elif cat == "JS Endpoint":
                key = _path_key(detail)
                if _is_first_party(detail, base_domains):
                    s.js_endpoints_first.add(key)
                else:
                    s.js_endpoints_third.add(key)
            elif cat == "JavaScript":
                # the JS file's own URL is in Source URL for these rows
                key = _path_key(source or detail)
                if _is_first_party(source or detail, base_domains):
                    s.js_files_first.add(key)
                else:
                    s.js_files_third.add(key)
            elif cat == "Document":
                s.documents += 1
                if detail:
                    s.files[detail] = source
            elif cat == "CDN Document":
                s.cdn_documents += 1
                if detail:
                    s.files[detail] = source
            elif cat == "External Document":
                s.external_documents += 1
                s.external_doc_list.append((detail, source))
            elif cat == "Skipped Link":
                s.skipped_links += 1
            elif cat == "Retire.js Finding":
                sev = (notes[1:notes.find("]")].upper()
                       if notes.startswith("[") and "]" in notes else "")
                s.retire_findings.append((detail, sev, source, local))
                if sev in ("HIGH", "CRITICAL"):
                    s.retire_high += 1
    # jsluice secret flag: presence of a non-empty jsluice_secrets.txt
    js_secrets = Path(report_csv).parent / "js" / "jsluice_secrets.txt"
    try:
        s.jsluice_secret_flag = js_secrets.is_file() and js_secrets.stat().st_size > 0
    except OSError:
        s.jsluice_secret_flag = False
    return s


def find_report(engagement_dir: Path, target_label: str) -> Path | None:
    """Locate FunnelWeb's CSV for a target under the engagement dir.

    The current FunnelWeb writes '<netloc>/raw.csv' (netloc includes port). Older
    builds wrote '<domain>/report.csv'. Check raw.csv first, then report.csv, so
    ingest works across versions. target_label is the netloc (host or host:port).
    """
    base = Path(engagement_dir) / target_label
    for name in ("raw.csv", "report.csv"):
        cand = base / name
        if cand.is_file():
            return cand
    return None


def reconstruct_summaries_from_disk(engagement_dir: Path) -> list["FunnelWebSummary"]:
    """Rebuild the At-a-Glance summaries by scanning the engagement dir on disk.

    The normal run hands report.build_report() an in-memory list of
    FunnelWebSummary objects (one per crawled host). The standalone `report`
    subcommand has no such list — it runs against an already-finished
    engagement folder — so without this it passed funnelweb_summaries=None and
    the At a Glance tab silently never got built.

    FunnelWeb leaves one '<netloc>/raw.csv' (or legacy 'report.csv') per crawled
    host under the engagement dir. We find each of those, treat the containing
    folder name as the target label (exactly what the live path uses), and run
    the SAME ingest_report() the orchestrator runs. So a rebuilt report gets the
    identical At a Glance tab a fresh run would.
    """
    eng = Path(engagement_dir)
    summaries: list[FunnelWebSummary] = []
    seen: set[str] = set()
    # each crawled host is a direct child dir of the engagement holding raw.csv
    # (preferred) or the legacy report.csv. Sort for stable tab ordering.
    for csv_name in ("raw.csv", "report.csv"):
        for report_csv in sorted(eng.glob(f"*/{csv_name}")):
            label = report_csv.parent.name
            if label in seen:            # raw.csv wins; don't double-ingest
                continue
            seen.add(label)
            summary = ingest_report(report_csv, [label])
            try:
                summary.domain = label   # tag = the crawled target (matches live path)
            except AttributeError:
                pass
            summaries.append(summary)
    return summaries
