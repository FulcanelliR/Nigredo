"""Configuration layer for the recon pipeline.

Everything tunable per-engagement lives here so scan logic never needs editing.
Load from a JSON file; anything omitted falls back to sensible external-engagement
defaults.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class PhaseParams:
    """nmap parameters for a single scan phase."""
    min_rate: int = 300
    max_retries: int = 4
    max_rtt_timeout: str = "3000ms"
    host_timeout: str = "90m"
    timing_template: int = 3          # -T3 : more forgiving; avoids firewall throttling
    extra_args: list[str] = field(default_factory=list)


@dataclass
class Config:
    # --- Authorization / scope ---
    scope_file: str = "scope.txt"      # allowlist: CIDRs + hostnames, one per line
    targets_file: str = "targets.txt"  # hosts to actually scan, one per line

    # --- Output ---
    output_dir: str = "results"
    engagement_name: str = "engagement"

    # --- Stacked scans: extra TCP scan types (OFF by default). These were a
    # workaround for missed ports that turned out to be caused by -p- flooding;
    # the --top-ports sweep fixed that properly, so these aren't needed for a
    # normal run. Flip any to True only for a target where you specifically want
    # firewall-evasion probes. They require root (raw packets) and are slow.
    stack_ack: bool = False    # -sA firewall rule mapping
    stack_fin: bool = False    # -sF sneak past stateless SYN-only filters
    stack_null: bool = False   # -sN
    stack_xmas: bool = False   # -sX
    # --defeat-rst-ratelimit: when a firewall rate-limits RST responses, nmap
    # can mismark ports; this forces it to not throttle on RSTs. Helps find
    # ports on hardened targets that otherwise look filtered.
    defeat_rst_ratelimit: bool = True

    # --- Phase 1: full-range discovery sweep ---
    # RELENTLESS profile: patient + high retries so it finds everything Nessus
    # does instead of giving up on ports that don't answer on the first probe.
    # This is thorough, NOT fast — that's the point.
    # NOTE: sweep_ports = nmap's default top-1000 most-common ports (scattered
    # across the range by frequency, so common high ports like 8443 ARE
    # included). Full-range (-p-) floods hardened targets and gets the whole
    # scan throttled/dropped — which is why it was MISSING obvious open ports.
    # Set "-p-" only for a target that can take a full-range hammering.
    sweep_ports: str = "--top-ports 1000"
    # fold -sV -sC into the sweep so it's a single -sCV pass (matches the proven
    # working command). The deep phase still adds -O and re-runs -sV/-sC on found
    # ports for full detail.
    sweep_service_detection: bool = True
    sweep: PhaseParams = field(default_factory=lambda: PhaseParams(
        min_rate=150, max_retries=0, max_rtt_timeout="5000ms", host_timeout="0",
        timing_template=2,
    ))

    # --- Phase 2: targeted deep scan on discovered open ports ---
    deep: PhaseParams = field(default_factory=lambda: PhaseParams(
        min_rate=100, max_retries=6, max_rtt_timeout="5000ms", host_timeout="0",
        timing_template=2,
    ))
    deep_service_detection: bool = True   # -sV
    deep_default_scripts: bool = True     # -sC
    deep_os_detection: bool = False       # -O: off on deep (per-host, not per-port;
                                          # belongs on the sweep if wanted at all)
    deep_scan_type: str = "-sT"           # full connect on deep (known-open ports);
                                          # -sS available for stealth engagements

    # --- Optional phases ---
    ack_phase_enabled: bool = False       # -sA firewall fingerprint when filtered ports seen
    ack_filtered_threshold: int = 10      # run ACK only if a host shows >= this many filtered
    udp_phase_enabled: bool = False       # -sU on a curated port list
    udp_ports: str = "53,67,123,161,500"

    # --- Behavior ---
    treat_no_open_as_dead: bool = True    # hosts with zero open ports are skipped in phase 2
    pn: bool = True                       # -Pn : don't ping (external firewalls drop ICMP)

    # --- Web probe ---
    probe_connect_timeout: int = 6        # curl --connect-timeout / proto-confirm timeout
    probe_max_time: int = 15              # curl --max-time

    # --- Downstream tools ---
    nuclei_enabled: bool = True
    nuclei_rate_limit: int = 3            # -rl ; capped, see nuclei_max_rate_limit
    # --- Nessus reconciliation + honeypot detection ---
    reconcile_nessus_ports: bool = True   # directed re-probe of Nessus ports nmap missed
    reconcile_version_intensity: int = 7  # -sV intensity for the directed re-probe
    reconcile_timeout: int = 700          # per-host directed scan timeout (s)
    honeypot_qmark_threshold: int = 7     # > N '?' ports => skip host as honeypot
    nuclei_max_rate_limit: int = 3       # raise consciously; nuclei is loud
    nuclei_scan_strategy: str = ""        # -ss ; "" = nuclei native default
                                          # (template-spray). See ToolConfig note:
                                          # host-spray was hardcoded and starved the
                                          # run on some versions; opt-in only now.
    nuclei_extra: list[str] = field(default_factory=list)
    feroxbuster_enabled: bool = True
    feroxbuster_words_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-words-lowercase.txt"
    feroxbuster_files_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-files-lowercase.txt"
    feroxbuster_threads: int = 10
    feroxbuster_depth: int = 3
    feroxbuster_rate_limit: int = 20     # req/s (per directory). Lowered 50->20.
                                         # feroxbuster's FAQ ("Connection closed
                                         # before message completed") says the
                                         # 'Could not connect / error sending
                                         # request' errors are target SATURATION,
                                         # fixed by slowing down. The real pressure
                                         # is rate x scan_limit: 20/dir x 2 dirs =
                                         # ~40 req/s/host, vs the old 50x3=~150 that
                                         # over-saturated fragile enterprise/IIS
                                         # targets and made them close connections.
    feroxbuster_rate_mode: str = "auto_tune_capped"
    # How the feroxbuster request rate is governed. feroxbuster does adaptive
    # throttling natively (back off on errors, recover when clean), so we select
    # a mode rather than wrapping it:
    #   "auto_tune_capped"   -> --auto-tune --rate-limit N : adaptive, capped at N
    #                           (start at N, drop on errors, climb back, never > N).
    #                           REQUIRES feroxbuster >= 2.13.1 (older builds treat
    #                           --auto-tune and --rate-limit as mutually exclusive).
    #   "fixed"              -> --rate-limit N : hard cap, no adaptation (any version).
    #   "auto_tune_uncapped" -> --auto-tune : adaptive, no ceiling (loud; use with care).
    #   "off"                -> neither flag : feroxbuster's own default rate.
    # If your deployed binary predates 2.13.1, use "fixed".
    feroxbuster_scan_limit: int = 2      # concurrent directory scans PER HOST (NOT
                                         # hosts). Lowered 3->2. --rate-limit is
                                         # PER directory, so this MULTIPLIES:
                                         # 20/dir x 2 = ~40 req/s on a host — a
                                         # sane ceiling that avoids the connection-
                                         # pool saturation documented in ferox's FAQ
                                         # (raise cautiously if a target tolerates it)
                                         # (ffuf sits ~50-60 RPS here). Set back to 1
                                         # for sequential/lightest + clean output.
    feroxbuster_progress_interval: int = 30  # seconds between progress prints
    feroxbuster_parallel: int = 10       # value if operator opts into --parallel
    feroxbuster_extensions: str = "php,html,txt,asp,aspx,jsp,json"
    feroxbuster_status_codes: str = "200,204,301,302,307,308,401,403,405,500"
    # ^ allow-list of status codes worth attention (via -s); excludes 404 noise.
    #   Same curated set as ffuf_match_codes for consistency.
    # ffuf: brains discovery pass feeding feroxbuster
    ffuf_enabled: bool = True
    # ffuf's job is FAST, BROAD directory discovery — one flat pass across every
    # endpoint to map which directories exist. No files, no extensions (that's
    # feroxbuster's recursive job). Large directory list is affordable here
    # because it's directories-only (no extension multiplication).
    ffuf_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-directories.txt"
    ffuf_wordlist_size: str = "m"        # default size when prompting (s/m/l)
    # feroxbuster per-client intensity, carried from ReconConfig via
    # build_tool_config so an unattended run reads the configured value instead
    # of a hardcoded default. ferox_mode: w/f/b/c; ferox_wordlist_size: s/m/l.
    ferox_mode: str = "w"
    ferox_wordlist_size: str = "m"
    # custom feroxbuster wordlist path, used only when ferox_mode == "c". Carried
    # from the interview/ReconConfig via build_tool_config so an unattended child
    # honors a per-client custom wordlist instead of skipping it (was stash-only).
    ferox_custom_wordlist: str = ""
    ffuf_words_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-directories.txt"
    ffuf_files_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-files-lowercase.txt"
    ffuf_extensions: str = "php,html,txt,asp,aspx,jsp,json"
    ffuf_dirs_only: bool = True         # default: directories only, no extensions
    ffuf_progress_interval: int = 30
    # forwarding proxy for target-hitting HTTP tools (web probe, ffuf,
    # feroxbuster). Blank = no proxy, connect direct. Nuclei + PartyOn use
    # their own; DNS/OSINT tools excluded (wrong mechanism).
    forward_proxy: str = ""
    ffuf_match_codes: str = "200,204,301,302,307,308,401,403,405,500"
    ffuf_threads: int = 3                 # tight leash: ffuf is built to run VERY
                                          # fast, so cap concurrency low to stay
                                          # polite to the target (not a rate cap —
                                          # limits simultaneous connections)
    ffuf_rate: int = 0
    ffuf_extra: list[str] = field(default_factory=list)
    ffuf_feed_feroxbuster: bool = True
    # resolvers for the early subdomain correlation (shuffledns/dnsx)
    resolvers_file: str = "resolvers.txt"
    # --- discovery-before-scan (reorder): phase 0 runs full subdomain discovery
    # BEFORE the web tools so httpx/nuclei/ffuf/feroxbuster scan the discovered
    # subdomains, not just targets.txt. These mirror the ReconConfig fields so the
    # same discovery runs here; the recon engine then skips the duplicate.
    discovery_before_scan: bool = True   # run full discovery in phase 0 first
    run_subdomains: bool = True
    run_takeover: bool = True
    run_submutate: bool = True
    run_fqdn_resolve: bool = True
    # --- host validation (webget/reconx): the FQDN<->IP correlation + URL builder
    # that runs AFTER subdomain discovery and BEFORE the web fuzzers. It turns
    # targets.txt + discovered subdomains into urls.txt (the webapp-scanner pool)
    # and 403.txt (the nomore403 seed). Scope-safe: never widens past targets.txt.
    hostval_enabled: bool = True
    hostval_urls_file: str = "urls.txt"      # webapp-scanner target list it emits
    hostval_403_file: str = "403.txt"        # nomore403 seed list it emits
    hostval_no_probe: bool = False           # probe ON by default; True = correlation-only
    hostval_ports: str = ""                  # httpx -ports override ("" = tool default)
    hostval_jobs: int = 5                    # parallel DNS workers (rate-paced internally)
    # WebGet's urls.txt is now the SOLE web-tool pool (see pipeline._scan_pool).
    # The fair-game pool + fallback path were removed, so this toggle no longer does
    # anything — kept only so old saved configs still load. There is one path now.
    hostval_is_scan_authority: bool = True   # DEPRECATED / no-op (always single-pool)
    fqdn_resolve_on_scan_path: bool = False  # D1: run fqdn_resolve during phase0 discovery?
                                             # Off now (recon still runs its own copy).
                                             # Flip True to restore the old scan-path pairing.
    hostval_timeout: int = 10                # httpx per-target timeout (s)
    submutate_max_words: int = 40
    submutate_max_candidates: int = 5000
    feroxbuster_extra: list[str] = field(default_factory=list)
    testssl_enabled: bool = True
    testssl_jsonfile: bool = True
    testssl_phone_out: bool = False
    testssl_add_ca: str = ""
    testssl_extra: list[str] = field(default_factory=list)

    @classmethod
    def load(cls, path: str | Path) -> "Config":
        import dataclasses
        data = json.loads(Path(path).read_text())

        def _clean(d, klass, label):
            valid = {f.name for f in dataclasses.fields(klass)}
            # The campaign keeps ONE file (recon_config.json) for both the scan
            # (Config) and recon (ReconConfig) phases, so Config legitimately sees
            # recon-only keys here. Those are NOT errors — only warn about keys that
            # belong to NEITHER schema (genuine typos/removed options).
            cross = set()
            try:
                from .recon_config import ReconConfig as _RC
                cross = {f.name for f in dataclasses.fields(_RC)}
            except Exception:  # noqa: BLE001
                pass
            unknown = [k for k in d if k not in valid and k not in cross]
            if unknown:
                print(f"[config] ignoring {len(unknown)} unrecognized key(s) in "
                      f"{label}: {', '.join(unknown)}")
            return {k: v for k, v in d.items() if k in valid}

        sweep_d = data.pop("sweep", None)
        deep_d = data.pop("deep", None)
        sweep = PhaseParams(**_clean(sweep_d, PhaseParams, "sweep")) if sweep_d else PhaseParams()
        deep = PhaseParams(**_clean(deep_d, PhaseParams, "deep")) if deep_d else PhaseParams()
        cfg = cls(**_clean(data, cls, Path(path).name))
        cfg.sweep = sweep
        cfg.deep = deep
        return cfg

    def dump(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2))
