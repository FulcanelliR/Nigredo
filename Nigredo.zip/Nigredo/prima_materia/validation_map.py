#!/usr/bin/env python3
"""Map Nessus findings to the Nigredo tool that independently validates them.

This is the routing layer of the two-tool validation philosophy applied to
FINDINGS (not just discovery): when Nessus reports something, the corresponding
validator is forced to run against that host:port so a second, independent tool
confirms (or contradicts) it.

Matching is two-tier for accuracy:
  1. plugin ID  — exact match against known Nessus plugin IDs (most precise)
  2. keyword    — fallback on the plugin name for anything not in the ID table

Phase 1 (this module): routing + forcing the validator + capturing failures.
Phase 2 (later): parse each validator's actual output and cross-reference it
against the Nessus finding to produce a "Validated Results: Yes/No/—" verdict.
That needs real tool output to build reliably, so it's intentionally deferred.

Validators: testssl (TLS/SSL), ssh-audit (SSH), nuclei (web/other). "manual"
means no automated validator maps to this finding — a human should check it.
"""
from __future__ import annotations

# Known Nessus plugin IDs -> validator. Extend this from real Nessus output;
# IDs are stable, so this is the precise tier. (Starter set of common ones.)
PLUGIN_ID_MAP = {
    # --- TLS/SSL -> testssl ---
    "42873": "testssl",   # SSL Medium Strength Cipher Suites Supported (SWEET32-adjacent)
    "94437": "testssl",   # SSL 64-bit Block Size Cipher Suites (SWEET32)
    "157288": "testssl",  # TLS Version 1.1 Deprecated
    "104743": "testssl",  # TLS Version 1.0 Deprecated
    "20007": "testssl",   # SSL Version 2 and 3 Detection (POODLE/DROWN family)
    "78479": "testssl",   # SSLv3 Padding Oracle (POODLE)
    "83875": "testssl",   # SSL/TLS EXPORT_RSA <= 512-bit (FREAK)
    "83738": "testssl",   # SSL DROWN
    "81606": "testssl",   # SSL/TLS Logjam (weak DH)
    "58751": "testssl",   # SSL/TLS BEAST
    "65821": "testssl",   # SSL RC4 Cipher Suites Supported (Bar Mitzvah)
    "142960": "testssl",  # HSTS Missing From HTTPS Server
    "51192": "testssl",   # SSL Certificate Cannot Be Trusted
    "45411": "testssl",   # SSL Certificate with Wrong Hostname
    "15901": "testssl",   # SSL Certificate Expiry
    "10863": "testssl",   # SSL Certificate Information
    "21643": "testssl",   # SSL Cipher Suites Supported
    "62565": "testssl",   # TLS CRIME
    # --- SSH -> ssh-audit ---
    "153953": "ssh-audit", # SSH Weak Key Exchange Algorithms Enabled
    "153588": "ssh-audit", # SSH Weak MAC Algorithms Enabled
    "70658": "ssh-audit",  # SSH Server CBC Mode Ciphers Enabled
    "90317": "ssh-audit",  # SSH Weak Algorithms Supported
    "10881": "ssh-audit",  # SSH Protocol Versions Supported
    "10267": "ssh-audit",  # SSH Server Type and Version Information
}

# Keyword fallback: (substring in plugin name lowercased) -> validator.
# Order matters; first match wins. These catch the long tail not in the ID map.
KEYWORD_MAP = [
    ("sweet32", "testssl"),
    ("poodle", "testssl"),
    ("beast", "testssl"),
    ("drown", "testssl"),
    ("freak", "testssl"),
    ("logjam", "testssl"),
    ("bar mitzvah", "testssl"),
    ("barmitzvah", "testssl"),
    ("crime", "testssl"),
    ("heartbleed", "testssl"),
    ("robot attack", "testssl"),
    ("rc4", "testssl"),
    ("cipher", "testssl"),
    ("hsts", "testssl"),
    ("strict-transport", "testssl"),
    ("certificate", "testssl"),
    ("ssl", "testssl"),
    ("tls", "testssl"),
    ("ssh weak", "ssh-audit"),
    ("ssh server cbc", "ssh-audit"),
    ("ssh ", "ssh-audit"),
    ("http header", "nuclei"),
    ("http methods", "nuclei"),
    ("http trace", "nuclei"),
    ("web server", "nuclei"),
    ("clickjack", "nuclei"),
    ("x-frame", "nuclei"),
    ("cors", "nuclei"),
]


def validator_for(plugin_id: str, plugin_name: str) -> str:
    """Return the validator tool for a finding, or 'manual' if none maps.

    plugin_id is checked first (exact, precise); plugin_name keyword second.
    """
    pid = (plugin_id or "").strip()
    if pid in PLUGIN_ID_MAP:
        return PLUGIN_ID_MAP[pid]
    name = (plugin_name or "").lower()
    for kw, tool in KEYWORD_MAP:
        if kw in name:
            return tool
    return "manual"


def parse_finding_line(finding: str) -> tuple[str, str]:
    """From a formatted finding line
    '[TCP 443] -Medium- 142960 HSTS Missing From HTTPS Server'
    extract (plugin_id, plugin_name) for routing. Returns ('','') if unparsable.
    """
    # after the severity marker '-Sev- ' comes 'ID name...'
    try:
        after = finding.split("- ", 2)[-1]   # 'ID name...'
        parts = after.split(" ", 1)
        pid = parts[0].strip()
        name = parts[1].strip() if len(parts) > 1 else ""
        if pid.isdigit():
            return pid, name
    except (IndexError, ValueError):
        pass
    return "", finding


def validators_for_host(nessus_host: dict) -> dict:
    """Given a parsed Nessus host, return {(proto, port): set(validators)} for
    every port that has at least one validatable finding. Used to FORCE those
    validators to run on those host:ports."""
    out: dict = {}
    for (proto, port), pd in nessus_host.get("ports", {}).items():
        tools = set()
        for f in pd.get("findings", []):
            pid, pname = parse_finding_line(f)
            v = validator_for(pid, pname)
            if v != "manual":
                tools.add(v)
        if tools:
            out[(proto, port)] = tools
    return out
