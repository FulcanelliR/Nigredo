"""Staged nmap recon pipeline with scope enforcement."""
__version__ = "0.1.0"
