"""nomore403 runner + output parser — 403 bypass testing (phase-1 follow-up).

After feroxbuster runs, we know which directories threw a lot of 403s (the
"403 Hotspots"). nomore403 (devploit/nomore403, a Go tool) takes those forbidden
URLs and tries a broad set of access-control bypass techniques — header
injection (X-Original-URL etc.), path/verb/encoding mutations, HTTP version and
parser tricks — then scores the results, highlighting 403=>200 transitions that
are likely real bypasses.

Flow (the 3 steps agreed with the operator):
  1. feroxbuster finds 403-heavy directories -> 403 Hotspots
  2. we feed those hotspot URLs to nomore403 (via stdin)
  3. any 403->200 bypasses get surfaced as findings in the report

nomore403 specifics (from its README):
  - install:  git clone (needs its payloads/ dir; `go install` omits payloads)
  - input:    -u <url>, or read URLs from STDIN
  - output:   --jsonl -o <file>  (one JSON object per result)
  - proxy:    -x http://host:port
  - the tool needs `curl` on PATH for a few techniques (http-versions etc.)

Optional: if nomore403 isn't installed, this whole step skips gracefully.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


def nomore403_available() -> bool:
    return shutil.which("nomore403") is not None


# HTTP methods that CHANGE SERVER STATE — stripped from the httpmethods payload
# file so verb-tampering can't create/modify/delete data. Everything else
# (GET, HEAD, OPTIONS, TRACE, CONNECT, and nonsense verbs like HACK/INVENTED)
# is safe to send — a made-up verb can't map to a real write handler.
STATE_CHANGING_METHODS = {"POST", "PUT", "DELETE", "PATCH"}

# Techniques still excluded in safe mode even WITH sanitized methods:
#   method-override — makes the backend TREAT a request as another method;
#     safety can't be guaranteed by a method list (backend-dependent).
#   raw-desync / raw-duplicates / raw-authority — request SMUGGLING; the danger
#     is the malformed request structure and its effect on shared infra + OTHER
#     users, not the method. No method list makes smuggling safe.
UNSAFE_TECHNIQUES = {
    "method-override", "raw-desync", "raw-duplicates", "raw-authority",
}

# Safe technique set. verbs/verbs-case ARE included because we sanitize the
# httpmethods payload file (strip POST/PUT/DELETE/PATCH), so verb-tampering
# runs but can only send read-safe methods.
SAFE_TECHNIQUES = [
    "verbs", "verbs-case",
    "headers", "endpaths", "midpaths", "double-encoding", "http-versions",
    "path-case", "header-confusion", "host-override", "forwarded-trust",
    "proto-confusion", "ip-encoding", "hop-by-hop", "unicode",
    "path-normalization", "suffix-tricks", "http-parser", "absolute-uri",
]


def prepare_safe_payloads(src_payloads: Path, dest: Path) -> Path | None:
    """Copy nomore403's payloads folder to `dest` and strip state-changing
    methods (POST/PUT/DELETE/PATCH) from httpmethods, so verb-tampering stays
    enabled but can never send a method that writes/deletes. Returns the safe
    payloads dir, or None if the source isn't found."""
    import shutil as _sh
    src = Path(src_payloads)
    if not src.is_dir():
        return None
    dest = Path(dest)
    try:
        if dest.exists():
            _sh.rmtree(dest)
        _sh.copytree(src, dest)
    except OSError:
        return None
    methods_file = dest / "httpmethods"
    if methods_file.is_file():
        try:
            kept = []
            for ln in methods_file.read_text(errors="replace").splitlines():
                m = ln.strip()
                if not m or m.upper() in STATE_CHANGING_METHODS:
                    continue          # drop blanks + state-changing methods
                kept.append(m)
            methods_file.write_text("\n".join(kept) + "\n")
        except OSError:
            pass
    return dest


def collect_403_urls(outdir: Path, extra_403_file=None) -> list[str]:
    """Pull the 403 URLs worth testing from BOTH feroxbuster and ffuf output.
    feroxbuster writes newline-delimited JSON (type=response, status=403); ffuf
    writes a single {"results":[...]} doc (status=403). Returns unique 403 URLs
    so nomore403 can try to bypass each — from either discovery tool.

    extra_403_file: optional path to a plain newline-delimited list of 403 URLs
    from another source (the host-validation stage's 403.txt). Its URLs are
    UNIONED with the feroxbuster/ffuf-discovered set — combined, deduped — so
    nomore403 tests both the fuzzers' live 403s and the validated seed list.
    """
    import glob
    urls: list[str] = []
    seen = set()

    def _add(url: str):
        if url and url not in seen:
            seen.add(url)
            urls.append(url)

    # host-validation seed list (403.txt): plain one-URL-per-line. Added first so
    # the validated seeds lead, but order doesn't matter — the set is deduped.
    if extra_403_file:
        try:
            for line in Path(extra_403_file).read_text(errors="replace").splitlines():
                s = line.strip()
                if s and not s.startswith("#"):
                    _add(s)
        except OSError:
            pass

    # feroxbuster: newline-delimited JSON
    for jf in sorted(glob.glob(str(Path(outdir) / "feroxbuster_*.json"))):
        try:
            lines = Path(jf).read_text(errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if obj.get("type") == "response" and obj.get("status") == 403:
                _add(obj.get("url", ""))

    # ffuf: single JSON doc with a results[] array
    for jf in sorted(glob.glob(str(Path(outdir) / "ffuf_*.json"))):
        try:
            data = json.loads(Path(jf).read_text(errors="replace"))
        except (ValueError, OSError):
            continue
        for r in data.get("results", []) or []:
            if r.get("status") == 403:
                _add(r.get("url", ""))

    return urls


def _supported_flags(script: str) -> set:
    """Probe `nomore403 --help` once and return the set of long-flag names it
    supports, so we only pass flags the INSTALLED binary understands. An older
    build would REJECT unknown v2 flags and fail the whole run — this prevents
    that. Cached per process."""
    global _FLAG_CACHE
    try:
        return _FLAG_CACHE
    except NameError:
        pass
    flags = set()
    try:
        import subprocess as _sp
        out = _sp.run([script, "--help"], capture_output=True, text=True,
                      timeout=10, errors="replace")
        text = (out.stdout or "") + (out.stderr or "")
        import re as _re
        flags = set(_re.findall(r"--([a-z][a-z0-9-]+)", text))
    except Exception:
        flags = set()
    _FLAG_CACHE = flags
    return flags


def build_command(script: str, out_jsonl: Path, proxy: str = "",
                  payloads_dir: str = "", safe_mode: bool = True,
                  methods_sanitized: bool = True) -> list[str]:
    """nomore403 command reading URLs from stdin, writing JSONL.
    `script` is the binary (or path); payloads_dir points -f at the payloads
    folder. safe_mode restricts techniques via -k.

    methods_sanitized: True when we've stripped state-changing methods from the
    httpmethods payload file (so verbs/verbs-case are safe to run). If False in
    safe mode (couldn't sanitize), we drop verbs/verbs-case as a fallback so we
    never risk sending POST/PUT/DELETE/PATCH."""
    cmd = [script, "--jsonl", "-o", str(out_jsonl)]
    if safe_mode:
        techs = list(SAFE_TECHNIQUES)
        if not methods_sanitized:
            techs = [t for t in techs if t not in ("verbs", "verbs-case")]
        cmd += ["-k", ",".join(techs)]
    if proxy:
        cmd += ["-x", proxy]
    if payloads_dir:
        cmd += ["-f", payloads_dir]
    # v2 resilience flags — ONLY added if the installed binary advertises them
    # (see _supported_flags). These target the exact IIS failures seen
    # (calibration i/o timeouts, 'Could not connect', curl 'signal: killed'):
    #   --retry-count / --retry-backoff-ms : retry transient connection errors
    #     (resets/timeouts) with backoff instead of failing the target.
    #   --host-delay : space out same-host requests so a fragile target isn't
    #     over-saturated.
    # If the binary is older and lacks these, they're skipped (no rejected run).
    # Best fix is still to UPDATE: go install github.com/devploit/nomore403@latest
    # (v2.0.1+ fixes the curl 'signal: killed' hang and IIS %u002f URL parsing).
    supported = _supported_flags(script)
    if "retry-count" in supported:
        cmd += ["--retry-count", "2"]
    if "retry-backoff-ms" in supported:
        cmd += ["--retry-backoff-ms", "500"]
    if "host-delay" in supported:
        cmd += ["--host-delay", "150"]
    return cmd


def run_nomore403(outdir: Path, command_log: Path,
                  script: str = "nomore403", proxy: str = "",
                  payloads_dir: str = "",
                  safe_mode: bool = True, dry_run: bool = False,
                  extra_403_file=None) -> Path | None:
    """Run nomore403 over feroxbuster's 403 URLs. Returns the JSONL path, or
    None if skipped (tool missing / no 403s / dry-run).

    safe_mode (default True) restricts to read-only techniques — no PUT/DELETE/
    PATCH method tampering, no request-smuggling/desync. Set False only against
    targets you know can take the full set (e.g. a lab).

    extra_403_file: optional 403.txt from the host-validation stage; its URLs are
    unioned with the feroxbuster/ffuf-discovered 403s so both feed nomore403."""
    resolved = shutil.which(script) or (str(Path(script).resolve())
                                        if Path(script).is_file() else "")
    if not resolved:
        print("[nomore403] not installed — skipping 403 bypass "
              "(go install github.com/devploit/nomore403@latest, or git clone)")
        return None

    urls = collect_403_urls(outdir, extra_403_file=extra_403_file)
    if not urls:
        print("[nomore403] no 403 URLs from feroxbuster — nothing to test")
        return None

    out_jsonl = Path(outdir) / "nomore403.jsonl"
    urls_file = Path(outdir) / "nomore403_targets.txt"
    urls_file.write_text("\n".join(urls) + "\n")

    # In safe mode, build a sanitized payloads folder (POST/PUT/DELETE/PATCH
    # stripped from httpmethods) and point -f at it, so verb-tampering runs but
    # can't send a state-changing method. Find the source payloads dir from the
    # configured path, or common install locations.
    eff_payloads = payloads_dir
    methods_sanitized = False
    if safe_mode:
        src = None
        for cand in (payloads_dir, "/opt/nomore403/payloads",
                     str(Path(resolved).resolve().parent / "payloads")):
            if cand and Path(cand).is_dir():
                src = cand
                break
        if src:
            safe_dir = prepare_safe_payloads(Path(src), Path(outdir) / "nomore403_safe_payloads")
            if safe_dir:
                eff_payloads = str(safe_dir)
                methods_sanitized = True
        if not methods_sanitized:
            print("[nomore403] safe mode: couldn't find source payloads to "
                  "sanitize methods — dropping verbs/verbs-case for safety")

    cmd = build_command(resolved, out_jsonl, proxy=proxy,
                        payloads_dir=eff_payloads, safe_mode=safe_mode,
                        methods_sanitized=methods_sanitized)

    with open(command_log, "a") as log:
        log.write(f"cat {urls_file} | " + " ".join(cmd)
                  + f"   # {len(urls)} forbidden URL(s)\n")
    if dry_run:
        print(f"[dry-run] cat {urls_file} | " + " ".join(cmd))
        return None

    mode = ("SAFE mode (read-only techniques)" if safe_mode
            else "FULL mode (INCLUDES method tampering + desync — aggressive)")
    print(f"[nomore403] testing {len(urls)} forbidden URL(s) for 403 bypasses "
          f"— {mode}")
    # Capture the tool's full stdout+stderr to a log on disk. Without this,
    # nomore403's own errors (calibration failures, i/o timeouts, curl kills)
    # scroll past on the terminal and are lost, making failures impossible to
    # diagnose after the fact. The log sits next to the JSONL output.
    run_log = Path(outdir) / "nomore403.log"
    try:
        with open(urls_file) as f, open(run_log, "wb") as lf:
            lf.write(b"$ " + " ".join(cmd).encode("utf-8", "replace")
                     + f"\n# {len(urls)} forbidden URL(s)\n\n".encode())
            lf.flush()
            subprocess.run(cmd, stdin=f, stdout=lf,
                           stderr=subprocess.STDOUT, check=False)
        print(f"[nomore403] output logged -> {run_log}")
    except OSError as e:
        print(f"[nomore403] failed to run: {e}")
        return None
    return out_jsonl if out_jsonl.is_file() else None


# ---- parse results ----

@dataclass
class BypassFinding:
    url: str = ""
    technique: str = ""
    status_from: str = ""
    status_to: str = ""
    score: str = ""            # HIGH | MED | LOW (or numeric marker)
    length: str = ""
    item: str = ""             # the payload/header used
    curl: str = ""             # replayable evidence
    why: str = ""

    def as_row(self) -> list:
        transition = (f"{self.status_from}=>{self.status_to}"
                      if self.status_from or self.status_to else "")
        return [self.url, transition, self.score, self.technique,
                self.item, self.why, self.curl]


def _field(obj: dict, *names, default=""):
    for n in names:
        if n in obj and obj[n] not in (None, ""):
            return obj[n]
    return default


def parse_results(jsonl_path: Path) -> list[BypassFinding]:
    """Parse nomore403 JSONL into bypass findings. Schema keys vary a little by
    version, so we look up several likely names per field and keep only results
    that look like a real bypass (a transition to 2xx/3xx, or a HIGH score).
    Raw file is always kept for manual review regardless."""
    out: list[BypassFinding] = []
    p = Path(jsonl_path)
    if not p.is_file():
        return out
    for line in p.read_text(errors="replace").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        if not isinstance(obj, dict):
            continue
        status_to = str(_field(obj, "status", "status_to", "result_status",
                               "response_status", default=""))
        status_from = str(_field(obj, "baseline", "status_from",
                                 "baseline_status", default="403"))
        score = str(_field(obj, "score", "confidence", "severity", default=""))
        # keep likely bypasses: transition to 2xx/3xx, or HIGH score
        interesting = (status_to[:1] in ("2", "3")) or ("HIGH" in score.upper()) \
            or ("100" in score)
        if not interesting:
            continue
        out.append(BypassFinding(
            url=_field(obj, "url", "uri", "target", default=""),
            technique=_field(obj, "technique", "alias", "name", default=""),
            status_from=status_from,
            status_to=status_to,
            score=score,
            length=str(_field(obj, "length", "content_length", "size", default="")),
            item=_field(obj, "item", "payload", "header", default=""),
            curl=_field(obj, "curl", "replay", "command", default=""),
            why=_field(obj, "why", "reason", "evidence", default=""),
        ))
    # sort: HIGH/200 first
    def rank(f: BypassFinding):
        s = 0 if f.status_to[:1] == "2" else (1 if f.status_to[:1] == "3" else 2)
        h = 0 if "HIGH" in f.score.upper() or "100" in f.score else 1
        return (s, h, f.url)
    out.sort(key=rank)
    return out
