"""Subdomain takeover detection — dedicated nuclei takeover pass.

Runs nuclei with ONLY the takeover templates against the discovered subdomains,
in two tiers so the likely-vulnerable ones are checked first and nothing is
tested twice:

  Pass 1 (hotlist):   subdomains that have a CNAME (pointing off to a third-party
                      service — the classic takeover shape).
  Pass 2 (remainder): every OTHER subdomain (no CNAME) — catches A-record and
                      other cases nuclei can still fingerprint.

nuclei's takeover templates ARE the fingerprint authority (which services are
takeoverable + the dangling signature), so we don't maintain a service list — we
just decide the ORDER subdomains are fed (CNAME-bearing first). Pass 2 excludes
Pass 1's set, so each subdomain is tested exactly once.

Before each pass we print a readout:  subdomains | templates | ~total requests.

Sources the subdomain list from the subdomains step's raw CSV
(subdomains_<domain>.raw.csv: columns subdomain,type,value).
"""
from __future__ import annotations

import csv
import glob
import json
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path


def split_subdomains_by_cname(outdir: Path) -> tuple[list[str], list[str]]:
    """Read the subdomains raw CSVs and split into (has_cname, no_cname).
    has_cname = hotlist (Pass 1); no_cname = remainder (Pass 2). Deduped, and a
    subdomain with ANY CNAME record goes to the hotlist only (never both)."""
    cname_subs: set[str] = set()
    all_subs: set[str] = set()
    for csvf in sorted(glob.glob(str(Path(outdir) / "subdomains_*.raw.csv"))):
        try:
            with open(csvf, newline="", encoding="utf-8", errors="replace") as f:
                reader = csv.reader(f)
                next(reader, None)  # header: subdomain,type,value
                for row in reader:
                    if len(row) < 2:
                        continue
                    sub, rtype = row[0].strip(), row[1].strip().upper()
                    if not sub:
                        continue
                    all_subs.add(sub)
                    if rtype == "CNAME":
                        cname_subs.add(sub)
        except OSError:
            continue
    hotlist = sorted(cname_subs)
    remainder = sorted(all_subs - cname_subs)   # exclude hotlist -> no double-test
    return hotlist, remainder


def _count_takeover_templates(script: str) -> int:
    """Ask nuclei how many takeover templates the tag currently matches, so the
    readout shows a real number. Best-effort; returns 0 if it can't tell."""
    try:
        # -tags takeover -tl lists matching templates without running them
        out = subprocess.run([script, "-tags", "takeover", "-tl"],
                             capture_output=True, text=True, errors="replace", timeout=60)
        lines = [l for l in out.stdout.splitlines() if l.strip()]
        return len(lines)
    except (OSError, subprocess.SubprocessError):
        return 0


def _write_list(subs: list[str], path: Path) -> Path:
    Path(path).write_text("\n".join(subs) + ("\n" if subs else ""))
    return Path(path)


@dataclass
class TakeoverFinding:
    subdomain: str = ""
    template: str = ""
    service: str = ""
    severity: str = ""
    matched: str = ""

    def as_row(self) -> list:
        return [self.subdomain, self.service, self.template, self.severity,
                self.matched]


def _run_pass(script: str, label: str, subs: list[str], outdir: Path,
              command_log: Path, tmpl_count: int, rate_limit: int,
              proxy: str, dry_run: bool) -> Path | None:
    """Run one nuclei takeover pass over a subdomain list, with a readout."""
    if not subs:
        print(f"[takeover] {label} pass: 0 subdomains — skipped")
        return None
    est_requests = len(subs) * max(tmpl_count, 1)
    # the readout the operator asked for: subs | templates | total requests
    print(f"[takeover] {label} pass: {len(subs)} subdomains | "
          f"{tmpl_count} takeover templates | ~{est_requests:,} requests")

    list_file = _write_list(subs, Path(outdir) / f"takeover_{label}_targets.txt")
    out_json = Path(outdir) / f"takeover_{label}.json"
    cmd = [script, "-l", str(list_file), "-tags", "takeover",
           "-rl", str(rate_limit), "-jsonl", "-o", str(out_json), "-silent"]
    if proxy:
        cmd += ["-proxy", proxy]
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + f"   # takeover {label}\n")
    if dry_run:
        print(f"[dry-run] {' '.join(cmd)}")
        return None
    try:
        subprocess.run(cmd, check=False)
    except OSError as e:
        print(f"[takeover] {label} pass failed: {e}")
        return None
    return out_json if out_json.is_file() else None


def run_takeover(outdir: Path, command_log: Path, rate_limit: int = 3,
                 proxy: str = "", dry_run: bool = False) -> list[Path]:
    """Two-pass subdomain takeover detection. Returns the list of JSON result
    paths produced (hotlist, then remainder)."""
    script = shutil.which("nuclei")
    if not script:
        print("[takeover] nuclei not installed — skipping takeover pass")
        return []

    hotlist, remainder = split_subdomains_by_cname(outdir)
    if not hotlist and not remainder:
        print("[takeover] no subdomains found — skipping")
        return []

    tmpl_count = _count_takeover_templates(script) if not dry_run else 0

    print(f"[takeover] testing ALL subdomains for takeover "
          f"({len(hotlist)} with CNAME first, then {len(remainder)} others)")

    results = []
    # Pass 1: CNAME-bearing (hotlist) — the classic takeover shape, tested first
    r1 = _run_pass(script, "hotlist", hotlist, outdir, command_log,
                   tmpl_count, rate_limit, proxy, dry_run)
    if r1:
        results.append(r1)
    # Pass 2: everyone else (no CNAME) — excludes hotlist, so no double-testing
    r2 = _run_pass(script, "remainder", remainder, outdir, command_log,
                   tmpl_count, rate_limit, proxy, dry_run)
    if r2:
        results.append(r2)
    return results


def parse_takeover(outdir: Path) -> list[TakeoverFinding]:
    """Parse takeover_*.json (nuclei JSONL) into findings."""
    out: list[TakeoverFinding] = []
    seen = set()
    # match both takeover_*.json (dedicated subdomain pass) and takeover_*.jsonl
    # (the pipeline URL-pool takeover pass writes -jsonl-export .jsonl files)
    jfiles = sorted(set(glob.glob(str(Path(outdir) / "takeover_*.json")))
                    | set(glob.glob(str(Path(outdir) / "takeover_*.jsonl"))))
    for jf in jfiles:
        try:
            lines = Path(jf).read_text(errors="replace").splitlines()
        except OSError:
            continue
        for line in lines:
            line = line.strip()
            if not line:
                continue
            try:
                o = json.loads(line)
            except json.JSONDecodeError:
                continue
            info = o.get("info", {}) if isinstance(o, dict) else {}
            host = o.get("host", "") or o.get("matched-at", "") or o.get("url", "")
            tmpl = o.get("template-id", "") or o.get("templateID", "")
            key = (host, tmpl)
            if key in seen:
                continue
            seen.add(key)
            out.append(TakeoverFinding(
                subdomain=host,
                template=tmpl,
                service=info.get("name", "") if isinstance(info, dict) else "",
                severity=(info.get("severity", "") if isinstance(info, dict) else ""),
                matched=o.get("matched-at", "") or o.get("matched", ""),
            ))
    return out
