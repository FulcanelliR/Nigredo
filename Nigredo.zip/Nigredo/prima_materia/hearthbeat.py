"""HEARTHBEAT — the furnace's pulse.

The core between-tool pulse. Fires at every tool boundary (from _dispatch's exit,
the universal choke point every tool passes through) so the run has a visible,
read-back-friendly rhythm without making the run verbose.

Each beat:
  - ALWAYS prints one line to the terminal, and
  - appends the same line to hearthbeat.log in the engagement output dir.

The line carries:
  - a timestamp,
  - elapsed-since-run-start (so you can see how long the whole run's been going),
  - the last tool's name + how long IT took (so you can see per-tool duration).

This is the NEAR-TERM core. The advanced pieces (full-session buffer capture,
save-at-exit, spacebar on-demand poll) are a later capstone and live elsewhere.
"""

from __future__ import annotations

import time
from pathlib import Path


def _fmt_dur(seconds: float) -> str:
    """Human, read-back-friendly duration: 1h02m, 3m41s, 12.4s."""
    if seconds < 0:
        seconds = 0
    if seconds < 60:
        return f"{seconds:.1f}s"
    m, s = divmod(int(seconds), 60)
    if m < 60:
        return f"{m}m{s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m"


class Hearthbeat:
    """Tracks run-start + last-tool timing and emits a beat per tool boundary."""

    def __init__(self, outdir: Path):
        self.outdir = Path(outdir)
        self.run_start = time.time()
        self._last_tool_start = self.run_start
        self.log_path = self.outdir / "hearthbeat.log"
        self._last_line = ""          # most recent status line (for spacebar poll)
        self._current_tool = ""       # tool currently running
        self._spacebar_thread = None
        self._stop = False
        # Write a header so the log is self-describing on read-back.
        try:
            ts = time.strftime("%Y-%m-%dT%H:%M:%S")
            with open(self.log_path, "a") as f:
                f.write(f"# HEARTHBEAT log — run started {ts}\n")
        except OSError:
            pass  # the pulse must never break a run

    def note_output(self, line: str):
        """Record the most recent terminal output line (for the spacebar poll)."""
        if line and line.strip():
            self._last_line = line.strip()

    def set_current_tool(self, tool: str):
        self._current_tool = tool or ""

    def start_spacebar_watch(self):
        """Start a background thread: when the operator presses SPACEBAR, print a
        quick spot-check — the last output line + the timestamp of the press — so
        they can see 'here's where we are' without turning on full verbose. TTY
        only; silently no-ops if stdin isn't a terminal."""
        import sys
        import threading
        if not sys.stdin or not sys.stdin.isatty():
            return
        try:
            import termios  # noqa: F401
        except ImportError:
            return  # not a Unix TTY

        def _watch():
            import select
            import termios
            import tty
            fd = sys.stdin.fileno()
            old = termios.tcgetattr(fd)
            try:
                tty.setcbreak(fd)
                while not self._stop:
                    r, _, _ = select.select([sys.stdin], [], [], 0.5)
                    if r:
                        ch = sys.stdin.read(1)
                        if ch == " ":
                            ts = time.strftime("%H:%M:%S")
                            elapsed = _fmt_dur(time.time() - self.run_start)
                            tool = self._current_tool or "(between tools)"
                            print(f"\n\u2500\u2500 [spot-check {ts}] +{elapsed} | "
                                  f"running: {tool} | last: "
                                  f"{self._last_line or '(no output yet)'}\n",
                                  flush=True)
            except Exception:
                pass
            finally:
                try:
                    termios.tcsetattr(fd, termios.TCSADRAIN, old)
                except Exception:
                    pass

        self._spacebar_thread = threading.Thread(target=_watch, daemon=True)
        self._spacebar_thread.start()

    def stop(self):
        self._stop = True

    def tool_starting(self):
        """Call right before a tool runs, to time that tool."""
        self._last_tool_start = time.time()

    def beat(self, last_tool: str = ""):
        """Emit one pulse: called at a tool boundary (after a tool finishes).

        `last_tool` is the tool that just finished (name shown + its duration).
        Always prints AND logs. Never raises.
        """
        now = time.time()
        elapsed = now - self.run_start
        tool_dur = now - self._last_tool_start
        ts = time.strftime("%H:%M:%S")
        if last_tool:
            line = (f"\U0001f525 [{ts}] +{_fmt_dur(elapsed)} into run | "
                    f"{last_tool} took {_fmt_dur(tool_dur)}")
        else:
            line = f"\U0001f525 [{ts}] +{_fmt_dur(elapsed)} into run"
        # Always display.
        try:
            print(line)
        except Exception:
            pass
        # Always log.
        try:
            with open(self.log_path, "a") as f:
                f.write(line.replace("\U0001f525", "[hearthbeat]") + "\n")
        except OSError:
            pass
        # Next tool's clock starts now.
        self._last_tool_start = now
