#!/usr/bin/env python3
"""ffuf content discovery (phase 0) — the "brains" pass before feroxbuster.

ffuf does a smart first-pass content discovery against each web URL with
auto-calibration (which filters the soft-404 / wildcard noise automatically),
then writes two things per target:

  1. RAW ffuf JSON  (ffuf_<host>_<port>.json)      -- full audit output
  2. a TARGETED hit list (ffuf_hits.txt)           -- confirmed live paths,
     one URL per line, handed to feroxbuster to recurse into deeply.

The division of labor: ffuf is the brains (calibrated discovery, keeps 403s as
leads), feroxbuster is the workhorse that takes ffuf's confirmed hits and grinds
recursively down each one. 403s are matched, not filtered — a 403 is a protected
resource worth pivoting on, not noise.

Skips safely if ffuf isn't on PATH. TLS validation disabled (-k): target certs
are frequently self-signed / IP-based, same as feroxbuster.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from pathlib import Path
from urllib.parse import urlparse


def _fmt_elapsed(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    m, s = divmod(int(seconds), 60)
    if m < 60:
        return f"{m}m{s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m"


def _host_port_tag(url: str) -> str:
    p = urlparse(url)
    host = p.hostname or "host"
    port = p.port or ("443" if p.scheme == "https" else "80")
    return f"{host}_{port}".replace("/", "_")


def _prompt_wordlist(default: str, tool: str, dry_run: bool = False) -> str:
    """Prompt for a wordlist path, pre-filled with the configured default.
    Validates the file exists; re-prompts if not. Returns "" only if the user
    gives up (blank at an invalid default). In dry-run, returns the default.
    In unattended mode, returns the default if it exists, else "" (skip)."""
    if dry_run:
        return default
    from .runmode import is_unattended
    if is_unattended():
        return default if (default and Path(default).is_file()) else ""
    while True:
        shown = f" [{default}]" if default else ""
        try:
            ans = input(f"  {tool} wordlist{shown}: ").strip()
        except EOFError:
            ans = ""
        path = ans or default
        if not path:
            print(f"    no wordlist given for {tool}")
            try:
                again = input("    try again? [Y/n]: ").strip().lower()
            except EOFError:
                again = "n"
            if again in ("", "y", "yes"):
                continue
            return ""
        if Path(path).is_file():
            if path != default:
                print(f"    using: {path}")
            return path
        print(f"    not found: {path}")
        try:
            again = input("    enter a different path? [Y/n]: ").strip().lower()
        except EOFError:
            again = "n"
        if again in ("", "y", "yes"):
            default = ""    # clear the bad default so the prompt is clean
            continue
        return ""


def run_ffuf(tc, web_file: Path, outdir: Path, command_log: Path,
             assume_yes: bool = False, dry_run: bool = False) -> Path | None:
    """Run ffuf against each web URL; write raw JSON per target and a combined
    targeted hit list for feroxbuster. Returns the hit-list path."""
    if not getattr(tc, "ffuf_enabled", True):
        return None
    from .tools import _file_has_real_targets
    if not _file_has_real_targets(web_file):
        print(f"[ffuf] no web targets, skipping "
              f"(target file empty or blank-only: {web_file})")
        return None
    if shutil.which("ffuf") is None and not dry_run:
        print("[ffuf] 'ffuf' not found on PATH — skipping (go install ffuf)")
        return None

    # Wordlist mode. By default ffuf does a single DIRECTORIES-ONLY pass (fast,
    # broad, no extensions) — its job is to map which directories exist and hand
    # them to feroxbuster, which does the recursive file+dir digging. The w/f/b/c
    # menu is still available in --manual mode for when you want ffuf to do more.
    from .tools import _choose, _ask_text, _confirm
    from .runmode import is_unattended, answer
    from . import wordlist_select
    passes: list[tuple[str, str, bool]] = []
    if getattr(tc, "ffuf_dirs_only", True):
        # Wordlist size was chosen UP FRONT in the interview and stashed (like
        # feroxbuster), so it works in unattended/fire-and-forget mode. Read the
        # stashed size here instead of prompting mid-run — the old run-time prompt
        # got silently skipped whenever the run wasn't --manual, which is why ffuf
        # never asked. prompt_size maps the size to the raft path.
        _stashed_size = answer("ffuf_wordlist_size",
                               getattr(tc, "ffuf_wordlist_size", "m"))
        wl = wordlist_select.prompt_size("directories", "ffuf",
                                         default_size=_stashed_size,
                                         dry_run=dry_run)
        if not wl:
            # prompt_size returned "" — either SecLists rafts aren't at the
            # expected path, or the chosen raft file is missing. Don't SILENTLY
            # fall back to the config default (that's why the size prompt seemed
            # to never appear). Ask the operator directly for a wordlist so the
            # choice is always explicit and visible.
            wl = tc.ffuf_wordlist       # configured default as the pre-fill
            if not dry_run and not is_unattended():
                print("[ffuf] SecLists raft wordlists not found at the expected "
                      "path — choose a wordlist for ffuf directories:")
                wl = _prompt_wordlist(wl, "ffuf directories", dry_run)
        if not dry_run and wl and not Path(wl).is_file():
            print(f"[ffuf] directory wordlist not found: {wl}")
            wl = _prompt_wordlist(wl, "ffuf directories", dry_run)
        if wl:
            passes.append(("dirs", wl, False))
        if not passes and not dry_run:
            print("[ffuf] no valid wordlist — skipping")
            return None
        choice = "dirs-only"
    else:
        if is_unattended():
            choice = answer("ffuf_mode", "w")
        else:
            choice = _choose(
                "Wordlist mode?",
                {"w": "words + extensions",
                 "f": "files only (no extensions)",
                 "b": "both (words+ext, then files-bare)",
                 "c": "custom wordlist (you provide the path)",
                 "d": "directories only (no extensions)"},
                default="d", assume_yes=assume_yes,
            )
    # each pass: (label, wordlist_path, use_extensions)
    # (dirs-only already populated `passes` above; skip the mode-based building)
    if choice == "dirs-only":
        pass
    elif choice == "c":
        if is_unattended():
            path = answer("ffuf_custom_wordlist", "")
        else:
            path = _ask_text("Path to custom wordlist:", default="").strip()
        if not path or (not Path(path).is_file() and not dry_run):
            print(f"[ffuf] custom wordlist not found: {path or '(none)'} — skipping")
            return None
        use_ext = _confirm("Apply file extensions to the custom wordlist?",
                           assume_yes=False if not assume_yes else True)
        passes.append(("custom", path, use_ext))
    elif choice == "d":
        wl = tc.ffuf_wordlist
        if not dry_run and not Path(wl).is_file():
            wl = _prompt_wordlist(wl, "ffuf directories", dry_run)
        if wl:
            passes.append(("dirs", wl, False))
    else:
        if choice in ("w", "b"):
            wl = tc.ffuf_words_wordlist
            if not dry_run and not Path(wl).is_file():
                print(f"[ffuf] words wordlist not found: {wl}")
                wl = _prompt_wordlist(wl, "ffuf words", dry_run)
            if wl:
                passes.append(("words", wl, True))
        if choice in ("f", "b"):
            wl = tc.ffuf_files_wordlist
            if not dry_run and not Path(wl).is_file():
                print(f"[ffuf] files wordlist not found: {wl}")
                wl = _prompt_wordlist(wl, "ffuf files", dry_run)
            if wl:
                passes.append(("files", wl, False))
    if not passes and not dry_run:
        print("[ffuf] no valid wordlist — skipping")
        return None

    targets = [u.strip() for u in web_file.read_text(errors="replace").splitlines() if u.strip()]
    hits_file = outdir / "ffuf_hits.txt"
    all_hits: list[str] = []

    print(f"[ffuf] discovery over {len(targets)} target(s), "
          f"{len(passes)} pass(es) (auto-calibrated; 403s kept as leads)")

    import time as _time
    total = len(targets)
    skipped_dead = []
    rate_limited = []
    for idx, url in enumerate(targets, 1):
        base = url.rstrip("/")
        fuzz_url = f"{base}/FUZZ"
        tag = _host_port_tag(url)
        # LIVENESS GATE: verify the target actually responds BEFORE fuzzing it,
        # trying BOTH schemes. Previously ffuf fuzzed whatever was in the web_urls
        # file — including a dead http://<ip> that a scheme was blindly prepended
        # to — and would grind the full wordlist against a host that never
        # answered. Now: probe (http AND https); if neither responds, SKIP this
        # target (logged) and move on. If the OTHER scheme is the live one, fuzz
        # THAT — so a wrong upstream scheme guess (common for bare IPs with no
        # FQDN) doesn't cost us the host. Per-target skip, not whole-scan bail.
        if not dry_run:
            live = _resolve_live_url(base)
            if not live:
                print(f"[ffuf] ({idx}/{total}) SKIP {url} — no response on http "
                      f"or https (dead host or hard rate-limit); next", flush=True)
                skipped_dead.append(url)
                continue
            if live.rstrip("/") != base:
                print(f"[ffuf] ({idx}/{total}) {url} answered on the other "
                      f"scheme — fuzzing {live} instead", flush=True)
                base = live.rstrip("/")
                fuzz_url = f"{base}/FUZZ"
                tag = _host_port_tag(base)
        print(f"[ffuf] ({idx}/{total}) fuzzing {base} …", flush=True)
        started = _time.time()
        target_hits = 0

        for label, wordlist, use_ext in passes:
            raw_json = outdir / f"ffuf_{tag}_{label}.json"
            cmd = [
                "ffuf",
                "-u", fuzz_url,
                "-w", wordlist,
                "-mc", tc.ffuf_match_codes,
                "-ac", "-k",
                "-t", str(tc.ffuf_threads),
                "-rate", str(tc.ffuf_rate),
                "-o", str(raw_json),
                "-of", "json",
                # NOTE: `-or` (omit-empty-output) was REMOVED. It suppressed the
                # output file entirely on zero hits, which made ffufhits.txt
                # "empty or completely missing" and broke result capture. Without
                # it, ffuf always writes the file: present+empty = "ran, found
                # nothing"; missing = a genuine failure worth alerting on.
            ]
            if getattr(tc, "forward_proxy", ""):
                cmd += ["-x", tc.forward_proxy]   # route through forwarding proxy
            if use_ext and tc.ffuf_extensions:
                # ffuf wants extensions dotted+comma-joined: .php,.html,...
                exts = ",".join("." + e.strip().lstrip(".")
                                for e in tc.ffuf_extensions.split(",") if e.strip())
                cmd += ["-e", exts]
            cmd += list(tc.ffuf_extra)

            with open(command_log, "a") as log:
                log.write(" ".join(cmd) + "\n")
            if dry_run:
                print(f"[dry-run] {' '.join(cmd)}")
                continue
            try:
                _meter = _run_ffuf_with_meter(cmd, label, tc, target_url=base)
                if _meter and _meter.get("ratelimited"):
                    rate_limited.append(url)
                    print(f"[ffuf]   ({label}) recorded for manual re-test "
                          f"(rate-limited)")
                    # C3: salvage any hits ffuf flushed to -o before the kill.
                    try:
                        all_hits.extend(_extract_hits(raw_json))
                    except Exception:  # noqa: BLE001
                        pass
                    continue
            except KeyboardInterrupt:
                # Ctrl+C during a target -> per-target menu: skip THIS run, retry
                # THIS run, or cancel the whole ffuf tool. (Skips the exact run,
                # not the entire tool — that's the behavior that worked before.)
                print(f"\n[ffuf] interrupted on {url}. "
                      f"[s] skip this target  [r] retry this target  "
                      f"[c] cancel ffuf entirely")
                try:
                    choice = input("choice [s/r/c]: ").strip().lower()
                except (KeyboardInterrupt, EOFError):
                    choice = "c"
                if choice == "c":
                    print("[ffuf] cancelling ffuf — moving on to the next tool")
                    break
                if choice == "r":
                    print(f"[ffuf] retrying {url} …")
                    # re-run this same target once
                    try:
                        _run_ffuf_with_meter(cmd, label, tc, target_url=base)
                    except KeyboardInterrupt:
                        print(f"[ffuf] skipping {url}")
                        skipped_dead.append(url)
                        continue
                    hits = _extract_hits(raw_json)
                    all_hits.extend(hits)
                    continue
                # default: skip this target, continue to the next
                print(f"[ffuf] skipped {url} — continuing to next target")
                skipped_dead.append(url)
                continue
            except subprocess.TimeoutExpired:
                print(f"[ffuf]   ({label}) TIMED OUT, moving on")
                continue
            except Exception as e:  # noqa: BLE001
                print(f"[ffuf]   ({label}) error: {e}")
                continue
            hits = _extract_hits(raw_json)
            all_hits.extend(hits)
            target_hits += len(hits)

        if not dry_run:
            elapsed = _fmt_elapsed(_time.time() - started)
            print(f"[ffuf] ({idx}/{total}) done in {elapsed} — {target_hits} hit(s)")

    # audit trail: record which targets were skipped as dead/unresponsive so the
    # operator can see WHY a host produced nothing (skipped) vs ran-found-nothing.
    if skipped_dead:
        skip_file = outdir / "ffuf_skipped_dead.txt"
        try:
            skip_file.write_text("\n".join(skipped_dead) + "\n")
        except OSError:
            pass
        print(f"[ffuf] skipped {len(skipped_dead)} unresponsive target(s) "
              f"(see ffuf_skipped_dead.txt)")
    if rate_limited:
        rl_file = outdir / "ffuf_rate_limited.txt"
        try:
            rl_file.write_text("\n".join(rate_limited) + "\n")
        except OSError:
            pass
        print(f"[ffuf] {len(rate_limited)} target(s) rate-limited & skipped for "
              f"manual re-test (see ffuf_rate_limited.txt)")

    if dry_run:
        return hits_file

    # HANDOFF FILTER — feed feroxbuster only 1-DIRECTORY-DEEP entry points.
    #
    # Why: feroxbuster recurses (-d) from every URL it's given. If we hand it the
    # whole nested chain (/clothing, /clothing/men, /clothing/men/tshirts, ...),
    # it re-recurses the SAME branch from each starting point — massively
    # redundant, exponential work (the CPU/network hammering + hours-long spins).
    #
    # Fix: collapse each hit to its FIRST path segment (host + 1 dir), dedupe, and
    # hand feroxbuster only those top-level doors. feroxbuster then recurses DOWN
    # from /clothing on its own and discovers men/, tshirts/, small/ itself — no
    # overlap. Non-directory hits (files at the root, like /robots.txt) are kept
    # as-is so we don't lose root-level findings.
    from urllib.parse import urlsplit, urlunsplit

    def _one_deep(u: str) -> str:
        """Collapse a hit to host + its FIRST path segment. Returns "" for a
        bare-root hit (no path, or just "/") — those must NOT be handed to
        feroxbuster: a root seed makes it recurse the ENTIRE site from "/",
        which re-discovers everything ffuf already found, floods the run, and
        looks like 'it just defaults to client.com and ignores the leads'.
        This fires most when ffuf matches the root response itself (common now
        that we correctly match 403/redirect roots)."""
        try:
            parts = urlsplit(u)
        except ValueError:
            return u
        segs = [s for s in parts.path.split("/") if s]
        if len(segs) == 0:
            return ""                     # bare root — DROP (no recursion seed)
        if len(segs) == 1:
            return u                      # already 1-deep (dir or root file) keep
        new_path = "/" + segs[0]
        return urlunsplit((parts.scheme, parts.netloc, new_path, "", ""))

    seen, uniq, dropped_root = set(), [], 0
    for h in all_hits:
        collapsed = _one_deep(h)
        if not collapsed:
            dropped_root += 1
            continue                      # skip bare-root hits entirely
        if collapsed not in seen:
            seen.add(collapsed)
            uniq.append(collapsed)
    hits_file.write_text("\n".join(uniq) + ("\n" if uniq else ""))
    n_raw = len(all_hits)
    print(f"[\u2713] ffuf: {len(uniq)} unique 1-deep path(s) from {n_raw} raw hit(s) "
          f"-> {hits_file}  (feroxbuster recurses from here)")
    if dropped_root:
        print(f"    ({dropped_root} bare-root hit(s) dropped from the handoff so "
              f"feroxbuster doesn't re-recurse the whole site from /)")
    print(f"    (handed to feroxbuster for deep recursion)")
    return hits_file


def _playwright_loads(url: str, timeout: int = 30) -> bool | None:
    """Second liveness gate: does the URL actually LOAD in a headless browser?

    curl says "the server answered", but a browser enforces things curl ignores —
    a real TLS handshake it won't override, a page that actually reaches the
    'load' state, a body that isn't a browser error screen. A host can answer
    curl yet fail to load in a browser (broken TLS, connect-then-reset, hung
    server, non-HTTP service on a web port). This catches those.

    Returns:
      True  -> the page loaded in the browser (interactive; worth fuzzing)
      False -> it did NOT load (skip it)
      None  -> Playwright unavailable / can't run — caller should FAIL OPEN
               (fall back to the curl verdict, don't drop the host on our account)
    """
    try:
        from patchright.sync_api import sync_playwright, Error as _PWError, \
            TimeoutError as _PWTimeout
    except Exception:  # noqa: BLE001  (not installed / import failure)
        return None
    try:
        with sync_playwright() as pw:
            try:
                browser = pw.chromium.launch(headless=True)
            except Exception:  # noqa: BLE001  (no browser binary installed)
                return None
            try:
                ctx = browser.new_context(ignore_https_errors=False)
                page = ctx.new_page()
                try:
                    resp = page.goto(url, wait_until="domcontentloaded",
                                     timeout=timeout * 1000)
                except _PWTimeout:
                    # TIMED OUT = slow, not necessarily dead. Do NOT skip on our
                    # account — return inconclusive so the caller falls back to the
                    # curl verdict (which already said alive). 'domcontentloaded'
                    # (fires on HTML parse, not full asset load) + a generous
                    # timeout make real timeouts rare; when they happen, keep the host.
                    return None
                except _PWError:
                    # navigation genuinely failed = the browser could NOT load it
                    return False
                if resp is None:
                    return False
                # a real HTTP response reached the load state. Even 401/403/3xx
                # count as "loaded" (still interactive/worth fuzzing) — we only
                # reject the cases where the browser could not load at all.
                return True
            finally:
                browser.close()
    except Exception:  # noqa: BLE001  (any runtime failure -> fail open)
        return None


def _resolve_live_url(target_url: str, timeout: int = 10) -> str:
    """Return a URL that actually RESPONDS, trying BOTH schemes when needed, and
    that also LOADS in a headless browser (curl + Playwright, both must pass).

    Why two gates: curl confirms the server answers; Playwright confirms a real
    browser can actually load the page. A host can pass curl (something answered
    on the socket) yet fail to load in a browser — broken TLS the browser won't
    override, connect-then-reset, a hung/non-HTTP listener on a web port. Those
    are worthless to fuzz, so we require BOTH. If Playwright isn't installed we
    FAIL OPEN to the curl verdict (never drop a host just because Playwright is
    missing).

    Scheme handling: try the given scheme first, then the other, so a wrong
    upstream scheme guess on a bare IP doesn't wrongly declare a live host dead.

    Any HTTP status = alive (even 403/401 — the server is talking). 000 = the
    connection failed entirely."""
    import subprocess as _sp
    from urllib.parse import urlsplit, urlunsplit

    def _curl_ok(u: str) -> bool:
        # ALIVE = any real HTTP status code. We DELIBERATELY treat 403, 401, and
        # 3xx redirects as alive-and-worth-fuzzing — the whole point of fuzzing a
        # blocked/redirecting root is to find the path that BYPASSES the block or
        # sidesteps the redirect. Do NOT "tighten" this to 200-only; that would
        # skip exactly the hosts most worth testing. curl has no -L, so a 301/302
        # is reported as itself (not chased off-scope). Only 000 (no TCP/TLS/DNS
        # response at all) counts as dead.
        try:
            res = _sp.run(["curl", "-s", "-k", "-o", "/dev/null", "-w",
                           "%{http_code}", "--max-time", str(timeout), u],
                          capture_output=True, text=True, errors="replace", timeout=timeout + 5)
            code = (res.stdout or "").strip()
            return bool(code) and code != "000"
        except (OSError, _sp.TimeoutExpired):
            return False

    def _both_gates_ok(u: str) -> bool:
        # gate 1: curl must see a real HTTP response
        if not _curl_ok(u):
            return False
        # gate 2: a headless browser must actually load it. None = Playwright
        # unavailable -> fail open (curl verdict stands).
        loaded = _playwright_loads(u, timeout=max(timeout, 30))
        if loaded is None:
            return True                # fail open: no Playwright, trust curl
        return loaded

    # candidate order: the scheme we were given first, then the other one.
    try:
        parts = urlsplit(target_url)
        given = (parts.scheme or "http").lower()
    except ValueError:
        given = "http"
    other = "http" if given == "https" else "https"

    # first candidate = exactly what we were handed (curl + browser gates)
    if _both_gates_ok(target_url):
        return target_url

    # build the same URL under the other scheme and try that
    try:
        parts = urlsplit(target_url if "://" in target_url else f"{given}://{target_url}")
        alt = urlunsplit((other, parts.netloc or parts.path, parts.path if parts.netloc else "",
                          parts.query, parts.fragment))
        # tidy: if netloc was empty (bare host/ip), rebuild cleanly
        if not parts.netloc:
            host = parts.path.split("/")[0]
            rest = target_url.split(host, 1)[1] if host in target_url else ""
            alt = f"{other}://{host}{rest}"
        if _both_gates_ok(alt):
            return alt
    except ValueError:
        pass
    return ""


def _run_ffuf_with_meter(cmd: list[str], label: str, tc,
                         target_url: str = "") -> None:
    """Run ffuf, rendering a periodic progress meter and health-checking the way
    an operator does by hand.

    THE OPERATOR'S ACTUAL PROCESS (what this automates): errors alone are NOT a
    reason to stop — ffuf erroring often just means the target is throttling/
    blocking the fuzzer while the site itself is perfectly fine for a normal
    visitor. So when errors spike, we don't bail; we do what you'd do — fire ONE
    normal request at the target root ('pull it up in the browser'):
      - site still answers  -> it's just throttling us. KEEP GOING. (re-check
        later if errors persist, but never kill a scan against a live site.)
      - site is ALSO down   -> we may have knocked it over. THAT is the bail
        condition — stop so we don't keep hammering a target we took down.

    A stalled rate (near-zero for a sustained stretch) triggers the same health
    check rather than an automatic kill.
    """
    grace_secs = getattr(tc, "ffuf_grace_secs", 90)
    err_ratio_trigger = getattr(tc, "ffuf_error_ratio", 0.70)  # errors this high => CHECK (not bail)
    err_ratio_min_reqs = getattr(tc, "ffuf_error_min_reqs", 100)
    stall_secs = getattr(tc, "ffuf_stall_secs", 120)
    stall_rate = getattr(tc, "ffuf_stall_rate", 1)
    recheck_secs = getattr(tc, "ffuf_health_recheck_secs", 120)  # min gap between checks
    # --- per-target RATE-LIMIT SKIP (operator spec) ---------------------------
    # Their security's rate-limiting drops req/sec below 10 for most of a ~6-min
    # window and errors climb past ~85% of requests. When that's sustained across
    # the window we KILL THIS TARGET's ffuf process and move to the next — the
    # targets are legit, so we skip-and-record rather than grind or bail the whole
    # scan. Window resets at ~6 min (where this client's limiter resets).
    rl_window = getattr(tc, "ffuf_ratelimit_window_secs", 360)   # 6 minutes
    rl_rate = getattr(tc, "ffuf_ratelimit_rate", 10)             # below 10 req/sec
    rl_err_ratio = getattr(tc, "ffuf_ratelimit_err_ratio", 0.85)  # errors >= 85%
    import subprocess as _sp
    import threading, time as _time, re as _re

    interval = getattr(tc, "ffuf_progress_interval", 30)
    from . import resources
    # C3: capture BOTH streams (merge stderr into stdout) so the rate meter isn't
    # blind if this ffuf build prints its progress line to stdout rather than
    # stderr — a blind meter mis-read "0 req/s" and false-killed live targets.
    proc = _sp.Popen(cmd, stdout=_sp.PIPE, stderr=_sp.STDOUT, text=True, errors="replace",
                     **resources.popen_kwargs())
    state = {"done": 0, "total": 0, "rate": "", "errors": 0, "saw_rate": False}
    prog_re = _re.compile(r"\[(\d+)/(\d+)\].*?(\d+)\s*req/sec")
    err_re = _re.compile(r"[Ee]rrors?:\s*(\d+)")
    bail = {"flag": False, "reason": "", "ratelimited": False}

    def _reader():
        for line in proc.stdout:
            m = prog_re.search(line)
            if m:
                state["done"] = int(m.group(1))
                state["total"] = int(m.group(2))
                state["rate"] = m.group(3)
                state["saw_rate"] = True   # meter is genuinely reading a rate
            em = err_re.search(line)
            if em:
                state["errors"] = int(em.group(1))

    def _printer():
        last = ""
        _start = _time.time()
        stalled_for = 0
        last_check = 0
        # rolling 6-min window samples: (was_rate_low, err_ratio, elapsed, rate)
        rl_samples = []
        while proc.poll() is None:
            # wall-clock elapsed — do NOT depend on parsing a progress line, or a
            # target that stalls before/without emitting a total would never be
            # evaluated (that was the bug: detection sat behind `if total:` and a
            # 0-req/s hang printed no total, so it ran for 1680s+ un-skipped).
            elapsed = _time.time() - _start
            total, done = state["total"], state["done"]
            if total:
                left = max(total - done, 0)
                pct = done / total * 100 if total else 0
                errs = state["errors"]
                line = (f"[ffuf-progress] ({label}) {left:,} reqs left · "
                        f"{pct:.0f}% · {state['rate']} req/sec"
                        f"{f' · {errs} errors' if errs else ''}")
                if line != last:
                    print(line, flush=True)
                    last = line
            else:
                errs = state["errors"]

            # ---- per-target rate-limit / stall skip detection (6-min window) ----
            # (runs EVERY tick, whether or not a progress total has been seen)
            try:
                _cur_rate = int(state["rate"] or 0)
            except (ValueError, TypeError):
                _cur_rate = 0
            _er = (errs / done) if done else 0.0
            rl_samples.append((_cur_rate < rl_rate, _er, elapsed, _cur_rate))
            rl_samples = [s for s in rl_samples if elapsed - s[2] <= rl_window]
            # need the window to actually be full before judging
            _window_full = elapsed >= rl_window and rl_samples
            if _window_full:
                low_frac = sum(1 for s in rl_samples if s[0]) / len(rl_samples)
                worst_err = max(s[1] for s in rl_samples)
                # (b) pinned at ~0 req/s for the whole window = dead standstill.
                # No error ratio needed — at ~0 req/s nothing is sent to error.
                stalled_zero = all(s[3] <= 0 for s in rl_samples)
                # (a) slow AND erroring = rate-limited with errors
                trip_a = (low_frac >= 0.9 and worst_err >= rl_err_ratio
                          and done >= err_ratio_min_reqs)
                # C3: only treat a 0-rate window as a stall if the meter has
                # ACTUALLY parsed a rate at least once. If it never parsed one,
                # the meter is blind (ffuf output-format mismatch) — fail OPEN and
                # let ffuf finish rather than kill on absence of evidence.
                trip_b = stalled_zero and state.get("saw_rate", False)
                if trip_a or trip_b:
                    bail["flag"] = True
                    bail["ratelimited"] = True
                    if trip_b:
                        bail["reason"] = (f"stalled at ~0 req/s for the full "
                                          f"{rl_window}s (dead standstill / "
                                          f"hard rate-limit)")
                    else:
                        bail["reason"] = (f"rate-limited: <{rl_rate} req/s for "
                                          f"{low_frac*100:.0f}% of {rl_window}s, "
                                          f"errors {worst_err*100:.0f}%")
                    print(f"[ffuf]   ({label}) *** {bail['reason']} — "
                          f"skipping this target for manual re-test ***",
                          flush=True)
                    proc.kill()
                    break

            if total:
                if elapsed >= grace_secs and target_url:
                    # decide whether the situation WARRANTS a health check
                    trigger = None
                    if done >= err_ratio_min_reqs and errs / done >= err_ratio_trigger:
                        trigger = f"{errs}/{done} requests errored ({errs/done*100:.0f}%)"
                    try:
                        cur_rate = int(state["rate"] or 0)
                    except ValueError:
                        cur_rate = 0
                    if cur_rate <= stall_rate:
                        stalled_for += interval
                        if stalled_for >= stall_secs:
                            trigger = trigger or f"rate stalled at {cur_rate} req/sec for {stalled_for}s"
                    else:
                        stalled_for = 0

                    # only check periodically, not every tick
                    if trigger and (elapsed - last_check) >= recheck_secs:
                        last_check = elapsed
                        # NOTE: the old liveness "throttling, not an outage —
                        # continuing" branch was REMOVED. It kept ffuf grinding
                        # forever against a stalled/rate-limited-to-0 target. The
                        # combined rate-limit + 0-stall skip above (6-min window)
                        # now owns that decision: slow+erroring OR pinned at ~0
                        # req/s -> skip the target and record for manual re-test.
                        print(f"[ffuf]   ({label}) {trigger} — the 6-min "
                              f"rate/stall check will skip this target if it "
                              f"doesn't recover.", flush=True)
            _time.sleep(interval)

    rt = threading.Thread(target=_reader, daemon=True); rt.start()
    pt = threading.Thread(target=_printer, daemon=True); pt.start()
    # no wall-clock cap — run to completion, unless the printer thread bails on
    # a health check (too many errors / stalled rate), which kills proc itself.
    try:
        proc.wait()
    except KeyboardInterrupt:
        resources.kill_tree(proc)
        raise
    finally:
        if proc.poll() is None:
            resources.kill_tree(proc)
        rt.join(timeout=2)
        pt.join(timeout=2)
    if bail["flag"]:
        print(f"[ffuf]   ({label}) BAILED — {bail['reason']}")
    return {"ratelimited": bail.get("ratelimited", False),
            "reason": bail.get("reason", "")}


# Status codes worth handing to feroxbuster to RECURSE from. ffuf matches a wider
# set (incl. 301/302/307/308), but a pure redirect is a signpost, not a room —
# recursing into it just re-walks ground the redirect target already covers. So we
# pass only codes that indicate a real resource or a guarded one (200/204 content,
# 401/403 auth-guarded surface for nomore403, 405 wrong-verb-but-exists, 500
# exists-but-erroring). This trims feroxbuster's workload without losing surface.
# (ffuf's own hit list / report still records everything it matched, redirects
# included — this filter only governs the feroxbuster hand-off.)
_FEROX_RECURSE_CODES = {200, 204, 401, 403, 405, 500}


def _extract_hits(raw_json: Path) -> list[str]:
    """Pull the confirmed result URLs out of an ffuf JSON file, keeping only the
    statuses worth recursing into with feroxbuster (drops pure redirects)."""
    if not raw_json.exists() or raw_json.stat().st_size == 0:
        return []
    try:
        data = json.loads(raw_json.read_text(errors="replace"))
    except (ValueError, OSError):
        return []
    out = []
    for r in data.get("results", []) or []:
        u = r.get("url", "")
        if not u:
            continue
        try:
            code = int(r.get("status", 0))
        except (TypeError, ValueError):
            code = 0
        # keep only recurse-worthy codes; if status is missing/unparseable, keep it
        # (fail-open so a schema quirk never silently drops a real hit)
        if code == 0 or code in _FEROX_RECURSE_CODES:
            out.append(u)
    return out
