"""Shodan passive IP enrichment — InternetDB (free) + optional host lookup.

Passive: no packets to the target. Shodan/InternetDB already scanned these IPs,
so we just read what they know. Scope-safe: only enriches IPs already in the
validated target list (never expands scope).

Two layers:
  InternetDB (default, FREE, no key): GET https://internetdb.shodan.io/{ip}
      -> ports, cpes, hostnames, tags, vulns (CVEs). No key, high rate limit,
         weekly-updated. Covers the core passive picture for every target IP at
         zero cost.
  Host lookup (optional, needs membership key): api.shodan.io/shodan/host/{ip}
      -> everything InternetDB has PLUS service banners, product/version detail,
         SSL certs, org/geo. Budget-capped + cached (host lookups are the cheap
         path but still count against the ~100 query credits/month).

Both are cached so re-runs don't re-fetch (and don't re-spend credits).
Results cross-reference into the findings matrix: Shodan's passive ports/CVEs
alongside the active nmap results.
"""
from __future__ import annotations

import csv
import json
import time
from dataclasses import dataclass, field
from pathlib import Path

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None

INTERNETDB_URL = "https://internetdb.shodan.io/{ip}"
SHODAN_HOST_URL = "https://api.shodan.io/shodan/host/{ip}"


def _looks_like_ip(s: str) -> bool:
    parts = s.strip().split(".")
    if len(parts) != 4:
        return False
    try:
        return all(0 <= int(p) <= 255 for p in parts)
    except ValueError:
        return False


@dataclass
class ShodanHost:
    ip: str = ""
    ports: list = field(default_factory=list)
    vulns: list = field(default_factory=list)       # CVE ids
    cpes: list = field(default_factory=list)         # detected products
    hostnames: list = field(default_factory=list)
    tags: list = field(default_factory=list)
    # richer (host-lookup only):
    org: str = ""
    os: str = ""
    products: list = field(default_factory=list)     # product/version strings
    source: str = "internetdb"                       # internetdb | host

    def as_row(self) -> list:
        return [self.ip,
                ", ".join(str(p) for p in sorted(self.ports)),
                ", ".join(self.vulns),
                ", ".join(self.cpes),
                ", ".join(self.hostnames),
                ", ".join(self.tags),
                self.org, self.os,
                ", ".join(self.products),
                self.source]


def _cache_path(outdir: Path) -> Path:
    return Path(outdir) / ".shodan_cache.json"


def _load_cache(outdir: Path) -> dict:
    p = _cache_path(outdir)
    if p.is_file():
        try:
            return json.loads(p.read_text())
        except (ValueError, OSError):
            return {}
    return {}


def _save_cache(outdir: Path, cache: dict) -> None:
    try:
        _cache_path(outdir).write_text(json.dumps(cache))
    except OSError:
        pass


def lookup_internetdb(ip: str, timeout: int = 15) -> ShodanHost | None:
    """Free, no-key InternetDB lookup. Returns ShodanHost or None.
    A 404 means Shodan has nothing on that IP (not an error)."""
    if requests is None:
        return None
    try:
        r = requests.get(INTERNETDB_URL.format(ip=ip), timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code == 404:
        return ShodanHost(ip=ip, source="internetdb")   # known-empty
    if r.status_code != 200:
        return None
    try:
        d = r.json()
    except ValueError:
        return None
    return ShodanHost(
        ip=ip,
        ports=d.get("ports", []) or [],
        vulns=d.get("vulns", []) or [],
        cpes=d.get("cpes", []) or [],
        hostnames=d.get("hostnames", []) or [],
        tags=d.get("tags", []) or [],
        source="internetdb",
    )


def submit_ondemand_scan(ips, api_key: str, outdir: Path,
                         command_log: Path, timeout: int = 30) -> dict:
    """Submit an ACTIVE Shodan on-demand scan for the given discovered IPs.
    Shodan scans them from its own infrastructure (asynchronous). Returns a dict
    {scan_id, ips, submitted_at} stashed to disk so the final stage can collect
    results later. Graceful: on any failure (no key, out of scan credits, network)
    it logs and returns {} so nothing downstream breaks.

    Scan submission spends 1 scan credit per IP. We do NOT cap — Shodan tracks
    usage and the run's credit ledger surfaces spend; if credits run out Shodan
    returns an error which we handle gracefully.
    """
    if requests is None or not api_key:
        return {}
    ip_list = [ip for ip in (ips or []) if _looks_like_ip(ip)]
    if not ip_list:
        return {}
    try:
        # Shodan scan submit: POST /shodan/scan  (ips=comma-separated)
        r = requests.post(
            "https://api.shodan.io/shodan/scan",
            params={"key": api_key},
            data={"ips": ",".join(ip_list)},
            timeout=timeout,
        )
    except requests.RequestException as e:
        _log_scan(command_log, f"submit failed (network): {e}")
        return {}
    if r.status_code == 403:
        _log_scan(command_log, "submit rejected 403 (auth/out of scan credits) "
                               "— skipping on-demand scan gracefully")
        print("[shodan] on-demand scan skipped: 403 (check key / scan credits)")
        return {}
    if r.status_code != 200:
        _log_scan(command_log, f"submit non-200: {r.status_code}")
        return {}
    try:
        d = r.json()
    except ValueError:
        return {}
    scan_id = d.get("id", "")
    if not scan_id:
        return {}
    import json as _json
    import time as _time
    record = {"scan_id": scan_id, "ips": ip_list,
              "count": d.get("count", len(ip_list)),
              "credits_left": d.get("credits_left"),
              "submitted_at": _time.time()}
    try:
        (Path(outdir) / "shodan_scan_pending.json").write_text(_json.dumps(record))
    except OSError:
        pass
    print(f"[shodan] on-demand scan submitted: {record['count']} IP(s), "
          f"scan id {scan_id} (results collected at end of run)")
    _log_scan(command_log, f"submitted scan {scan_id} for {len(ip_list)} IP(s)")
    return record


def collect_ondemand_scan(outdir: Path, api_key: str, client: str = "",
                          command_log: Path = None, timeout: int = 30) -> int:
    """Collect a previously-submitted on-demand scan's results in the FINAL stage.
    Reads shodan_scan_pending.json, host-looks-up each scanned IP (results are in
    Shodan's DB once the async scan finished), and saves each as
    <client>-<ip>-shodan.json. Returns the count saved. Fully graceful."""
    import json as _json
    pending_f = Path(outdir) / "shodan_scan_pending.json"
    if not pending_f.is_file() or requests is None or not api_key:
        return 0
    try:
        rec = _json.loads(pending_f.read_text())
    except (OSError, ValueError):
        return 0
    ips = rec.get("ips", []) or []
    if not ips:
        return 0
    safe_client = _safe_name(client) if client else "client"
    saved = 0
    for ip in ips:
        try:
            r = requests.get(SHODAN_HOST_URL.format(ip=ip),
                             params={"key": api_key}, timeout=timeout)
            if r.status_code != 200:
                continue
            data = r.json()
        except (requests.RequestException, ValueError):
            continue
        fname = f"{safe_client}-{ip}-shodan.json"
        try:
            (Path(outdir) / fname).write_text(_json.dumps(data, indent=2))
            saved += 1
        except OSError:
            continue
    if saved and command_log:
        _log_scan(command_log, f"collected {saved} on-demand scan result(s)")
    if saved:
        print(f"[final:shodan-scan] collected {saved} on-demand scan result(s) "
              f"-> {safe_client}-<ip>-shodan.json")
    return saved


def _safe_name(s: str) -> str:
    """Filesystem-safe token for filenames."""
    import re as _re
    return _re.sub(r"[^A-Za-z0-9._-]", "_", str(s)).strip("_") or "client"


def _log_scan(command_log, msg: str) -> None:
    if not command_log:
        return
    try:
        with open(command_log, "a") as f:
            f.write(f"[shodan-scan] {msg}\n")
    except OSError:
        pass


def lookup_host(ip: str, api_key: str, timeout: int = 30) -> ShodanHost | None:
    """Full Shodan host lookup (needs membership key; costs a query credit).
    Returns richer data: banners, product/version, org, os."""
    if requests is None or not api_key:
        return None
    try:
        r = requests.get(SHODAN_HOST_URL.format(ip=ip),
                         params={"key": api_key}, timeout=timeout)
    except requests.RequestException:
        return None
    if r.status_code != 200:
        return None
    try:
        d = r.json()
    except ValueError:
        return None
    products = []
    for banner in d.get("data", []) or []:
        prod = banner.get("product", "")
        ver = banner.get("version", "")
        if prod:
            products.append(f"{prod} {ver}".strip())
    return ShodanHost(
        ip=ip,
        ports=d.get("ports", []) or [],
        vulns=list((d.get("vulns", {}) or {}).keys()) if isinstance(d.get("vulns"), dict)
              else (d.get("vulns", []) or []),
        cpes=d.get("cpes", []) or [],
        hostnames=d.get("hostnames", []) or [],
        tags=d.get("tags", []) or [],
        org=d.get("org", "") or "",
        os=d.get("os", "") or "",
        products=products,
        source="host",
    )


def enrich(target_ips, outdir: Path, command_log: Path,
           use_host_lookup: bool = False, api_key: str = "",
           host_lookup_cap: int = 50, rate_delay: float = 1.0,
           ledger=None, dry_run: bool = False) -> list[ShodanHost]:
    """Enrich the (scope-safe) target IPs with Shodan passive data.

    Default path: InternetDB (free) for every IP. If use_host_lookup and a key
    are given, ALSO do the richer host lookup for up to host_lookup_cap IPs
    (budget guard). Cached so re-runs don't re-fetch/re-spend.
    """
    outdir = Path(outdir)
    ips = sorted({ip.strip() for ip in target_ips if _looks_like_ip(ip.strip())})
    if not ips:
        print("[shodan] no target IPs to enrich — skipping")
        return []

    with open(command_log, "a") as log:
        log.write(f"shodan enrich {len(ips)} IP(s) "
                  f"(internetdb{' + host-lookup' if use_host_lookup else ''})\n")
    if dry_run:
        print(f"[dry-run] shodan enrich {len(ips)} IP(s)")
        return []

    cache = _load_cache(outdir)
    results: list[ShodanHost] = []
    host_lookups_done = 0

    print(f"[shodan] enriching {len(ips)} target IP(s) via InternetDB (free)"
          + (f" + host lookup (cap {host_lookup_cap})" if use_host_lookup else ""))

    for ip in ips:
        ckey_idb = f"idb:{ip}"
        host = None
        # free InternetDB first (cached)
        if ckey_idb in cache:
            host = ShodanHost(**cache[ckey_idb])
        else:
            host = lookup_internetdb(ip)
            if host:
                cache[ckey_idb] = host.__dict__
                time.sleep(rate_delay)

        # optional richer host lookup (key + budget-capped + cached)
        if use_host_lookup and api_key and host_lookups_done < host_lookup_cap:
            ckey_h = f"host:{ip}"
            if ckey_h in cache:
                rich = ShodanHost(**cache[ckey_h])
                host = rich or host
            else:
                rich = lookup_host(ip, api_key)
                if rich:
                    cache[ckey_h] = rich.__dict__
                    host = rich
                    host_lookups_done += 1
                    time.sleep(rate_delay)

        if host and (host.ports or host.vulns or host.hostnames):
            results.append(host)

    _save_cache(outdir, cache)

    # write outputs
    safe_n = len(results)
    n_vulns = sum(len(h.vulns) for h in results)
    raw = outdir / "shodan_enrichment.json"
    raw.write_text(json.dumps([h.__dict__ for h in results], indent=2))
    csv_path = outdir / "shodan_enrichment.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["IP", "Ports", "Vulns (CVE)", "CPEs", "Hostnames", "Tags",
                    "Org", "OS", "Products", "Source"])
        for h in results:
            w.writerow(h.as_row())
    print(f"[\u2713] shodan: enriched {safe_n} IP(s), {n_vulns} CVE(s) flagged "
          f"-> {csv_path.name}")
    if use_host_lookup:
        print(f"    (host lookups used: {host_lookups_done}/{host_lookup_cap} budget)")
        # each fresh host lookup costs ~1 Shodan query credit (cache hits don't).
        if ledger is not None and host_lookups_done:
            try:
                ledger.record("shodan", host_lookups_done, kind="estimated",
                              note=f"{host_lookups_done} host lookup(s)")
            except Exception as e:  # noqa: BLE001
                print(f"[shodan] {e}")
    return results
