"""Standalone phase-0 single-tool execution.

Runs ONE phase-0 tool (nuclei, feroxbuster, testssl, sns, ssh-audit) against an
existing client's scan results, without re-running the nmap scan chain. It:

  1. lists client folders under results/ and asks which one to use
  2. loads that client's results.json
  3. re-probes the web/ssh endpoints with the pipeline's own probe logic to get
     CONFIRMED, current URLs (same confirmation the full run trusts)
  4. runs just the chosen tool against those endpoints
  5. writes a TIMESTAMPED scan_summary so the existing report is never overwritten

The gate prompt is skipped — the operator already chose this tool from the menu.
"""
from __future__ import annotations

import datetime
import json
from pathlib import Path

from .config import Config
from .tools import (build_tool_config, run_nuclei, run_feroxbuster,
                    run_testssl, run_sns, run_sshaudit)
from . import probe as probe_mod


def _list_clients(results_dir: Path) -> list[str]:
    if not results_dir.exists():
        return []
    return sorted(p.name for p in results_dir.iterdir()
                  if p.is_dir() and (p / "results.json").exists())


def _choose_client(results_dir: Path) -> str | None:
    clients = _list_clients(results_dir)
    if not clients:
        print(f"[!] No client scan results found under {results_dir}/.")
        print("    Run a phase-0 scan first (Everything, or Start from phase 0).")
        return None
    if len(clients) == 1:
        print(f"[i] using the only client with scan data: {clients[0]}")
        return clients[0]
    print("\nWhich client's scan results?")
    for i, c in enumerate(clients, 1):
        print(f"  {i}) {c}")
    try:
        ans = input(f"Choose [1-{len(clients)}]: ").strip()
        idx = int(ans) - 1
        if 0 <= idx < len(clients):
            return clients[idx]
    except (ValueError, EOFError):
        pass
    print("  (invalid choice)")
    return None


def _reprobe_web_endpoints(outdir: Path, cfg: Config,
                           command_log: Path) -> tuple[list[str], list[str]]:
    """Re-probe the host:port web endpoints from results.json, returning
    (confirmed_web_urls, confirmed_tls_endpoints). Uses the same probe logic as
    the full pipeline, so redirects are recorded-not-followed and only live,
    in-scope URLs come back."""
    results = json.loads((outdir / "results.json").read_text())
    web_urls: list[str] = []
    tls_eps: list[str] = []
    # candidate web ports: anything that looks like http(s) or a web-ish port
    web_ports = {80, 443, 8000, 8008, 8080, 8443, 8888, 9443, 3000, 5000}
    for addr, info in results.items():
        for svc in info.get("services", []):
            port = int(svc.get("port", 0))
            service = (svc.get("service", "") or "").lower()
            is_webish = (port in web_ports or "http" in service
                         or svc.get("tunnel") == "ssl")
            if not is_webish:
                continue
            pr = probe_mod.probe_endpoint(
                addr, port,
                timeout=cfg.probe_connect_timeout,
                max_time=cfg.probe_max_time,
                command_log=command_log)
            if pr.scheme and not pr.is_redirect:
                web_urls.append(pr.url)
                if pr.scheme == "https":
                    # verify real TLS before adding to the testssl list
                    if probe_mod.verify_tls(addr, port,
                                            timeout=cfg.probe_connect_timeout):
                        tls_eps.append(f"{addr}:{port}")
    return sorted(set(web_urls)), sorted(set(tls_eps))


def _ssh_endpoints(outdir: Path) -> list[tuple[str, int]]:
    results = json.loads((outdir / "results.json").read_text())
    eps = []
    for addr, info in results.items():
        for svc in info.get("services", []):
            if (svc.get("service", "").lower() == "ssh"
                    or int(svc.get("port", 0)) == 22):
                eps.append((addr, int(svc.get("port", 22))))
    return eps


def _timestamped_workbook(outdir: Path) -> None:
    """Build a fresh, timestamped scan_summary so the existing one is kept."""
    try:
        from openpyxl import Workbook
        from .scan_summary import (add_scan_summary_sheet,
                                   add_feroxbuster_sheet, add_sshaudit_sheet)
        wb = Workbook()
        wb.remove(wb.active)
        add_scan_summary_sheet(wb, outdir)
        add_feroxbuster_sheet(wb, outdir)
        add_sshaudit_sheet(wb, outdir)
        stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = outdir / f"scan_summary_{stamp}.xlsx"
        wb.save(path)
        print(f"[done] timestamped summary written to {path}")
    except Exception as e:  # noqa: BLE001
        print(f"[!] workbook build failed: {e}")


def run_standalone_phase0_tool(tool: str, results_dir: Path,
                               config_path: str) -> int:
    """Entry point: run one phase-0 tool against an existing client's results."""
    client = _choose_client(results_dir)
    if client is None:
        return 1
    outdir = results_dir / client
    cfg = Config.load(config_path)
    tc = build_tool_config(cfg)
    command_log = outdir / "commands.log"

    # SSH-audit doesn't need web probing; everything else does.
    if tool == "sshaudit":
        eps = _ssh_endpoints(outdir)
        if not eps:
            print("[!] no SSH endpoints in this client's results.")
            return 1
        run_sshaudit(tc, eps, outdir, command_log, assume_yes=True)
        _timestamped_workbook(outdir)
        return 0

    print(f"[i] re-probing {client}'s web endpoints for confirmed URLs...")
    web_urls, tls_eps = _reprobe_web_endpoints(outdir, cfg, command_log)
    print(f"[i] {len(web_urls)} live web URL(s), {len(tls_eps)} verified TLS endpoint(s)")

    # write the target files the tools read
    web_file = outdir / "targets" / "web_urls.txt"
    tls_file = outdir / "targets" / "tls_endpoints.txt"
    web_file.parent.mkdir(parents=True, exist_ok=True)
    web_file.write_text("\n".join(web_urls) + ("\n" if web_urls else ""))
    tls_file.write_text("\n".join(tls_eps) + ("\n" if tls_eps else ""))

    if tool == "nuclei":
        run_nuclei(tc, web_file, outdir, command_log, assume_yes=True)
    elif tool == "feroxbuster":
        run_feroxbuster(tc, web_file, outdir, command_log, assume_yes=True)
    elif tool == "testssl":
        run_testssl(tc, tls_file, outdir, command_log, assume_yes=True)
    elif tool == "sns":
        run_sns(tc, web_urls, outdir, command_log, assume_yes=True)
    else:
        print(f"[!] unknown phase-0 tool: {tool}")
        return 1

    _timestamped_workbook(outdir)
    return 0
