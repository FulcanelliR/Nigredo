"""api_budget.py — shared API credit tracking + optional caps for paid-API tools.

Design (per the engagement's credit-safety model):
  TRACK — transparency (always on):
      * CreditLedger records spend per tool, marked 'reported' (the API told us
        the real number) or 'estimated' (we inferred it from our own model).
        Printed to the terminal and totalled in the final report.
  CAP — optional ceiling (OFF by default):
      * if a per-tool credit cap is set in config (default: unset/None = no
        cap, full coverage), the ledger enforces it (record() raises
        BudgetExceeded, would_exceed() checks ahead of spend) and the tool stops.

Caps are OFF by default: full coverage out of the box. The APIs cap their own
spend server-side and the cost is billed to the client; this module's job is to
REPORT cost transparently and, optionally, to gate it — not to gate by default.

Note: anti-hang polling and per-request caching were previously scaffolded here
but were never wired in; each paid tool implements its own timeouts/caching
(e.g. shodan_tool's .shodan_cache.json), so that dead scaffolding was removed.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path


# ---------------------------------------------------------------- ledger ----

@dataclass
class CreditEntry:
    tool: str
    credits: float
    kind: str        # "reported" (API told us) or "estimated" (we inferred)
    note: str = ""


class BudgetExceeded(Exception):
    """Raised when a tool's optional credit cap is reached — caller stops."""


class CreditLedger:
    """Tracks credit spend across the run. One ledger per engagement, persisted
    so resumes keep a correct running total. Enforces optional per-tool caps."""

    def __init__(self, outdir: Path, caps: dict | None = None):
        self.outdir = Path(outdir)
        self.path = self.outdir / ".api_credits.json"
        self.caps = caps or {}          # {tool: max_credits}; absent/None = no cap
        self.entries: list[CreditEntry] = []
        self._load()

    def _load(self) -> None:
        if self.path.is_file():
            try:
                data = json.loads(self.path.read_text())
                self.entries = [CreditEntry(**e) for e in data.get("entries", [])]
            except (ValueError, TypeError):
                self.entries = []

    def _save(self) -> None:
        try:
            self.path.write_text(json.dumps(
                {"entries": [asdict(e) for e in self.entries]}, indent=2))
        except OSError:
            pass

    def spent(self, tool: str | None = None) -> float:
        if tool is None:
            return sum(e.credits for e in self.entries)
        return sum(e.credits for e in self.entries if e.tool == tool)

    def would_exceed(self, tool: str, credits: float) -> bool:
        """Would spending `credits` more on `tool` cross its cap (if one is set)?"""
        cap = self.caps.get(tool)
        if cap is None:
            return False           # no cap -> never exceeds
        return (self.spent(tool) + credits) > cap

    def record(self, tool: str, credits: float, kind: str = "estimated",
               note: str = "") -> None:
        """Record spend + print it. Raises BudgetExceeded if an optional cap set
        for this tool is crossed (caller should stop that tool)."""
        cap = self.caps.get(tool)
        if cap is not None and (self.spent(tool) + credits) > cap:
            raise BudgetExceeded(
                f"{tool} credit cap reached ({self.spent(tool):.0f}"
                f"+{credits:.0f} > {cap} cap) — stopping {tool}")
        self.entries.append(CreditEntry(tool, float(credits), kind, note))
        self._save()
        tag = "reported" if kind == "reported" else "~estimated"
        capnote = f" (cap {cap})" if cap is not None else ""
        print(f"[credits] {tool}: {credits:g} ({tag}){capnote} · "
              f"tool total {self.spent(tool):g}")

    def summary_rows(self) -> list[list]:
        """Rows for the report's API Credits sheet."""
        by_tool: dict[str, dict] = {}
        for e in self.entries:
            d = by_tool.setdefault(e.tool, {"reported": 0.0, "estimated": 0.0})
            d[e.kind if e.kind in ("reported", "estimated") else "estimated"] += e.credits
        rows = []
        for tool, d in sorted(by_tool.items()):
            total = d["reported"] + d["estimated"]
            kind = ("reported" if d["estimated"] == 0 else
                    "estimated" if d["reported"] == 0 else "mixed")
            rows.append([tool, f"{total:g}", kind])
        if rows:
            rows.append(["TOTAL", f"{self.spent():g}", ""])
        return rows

    def print_total(self) -> None:
        if not self.entries:
            return
        print(f"\n[credits] === API credit spend this run ===")
        for row in self.summary_rows():
            print(f"[credits]   {row[0]:12} {row[1]:>8} credits ({row[2]})")

