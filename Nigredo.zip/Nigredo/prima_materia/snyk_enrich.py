"""snyk_enrich.py — add Snyk reference URLs to retire.js findings via SerpAPI.

retire.js (run inside FunnelWeb) reports vulnerable JS components with
component/version/severity/CVE/GHSA. This nigredo-side step enriches each UNIQUE
component+version with a direct Snyk vulnerability-report URL — the page that
lays out all of that component's known vulnerabilities — for one-click
cross-reference in the final report.

Two ways to get the URL, in order:
  1. SerpAPI search `snyk <component> <version>` -> first result matching the
     Snyk package-page format (security.snyk.io/package/...). SerpAPI is the
     paid Google-results API nigredo already uses (fileenum/emailenum), so this
     is robust — no scraping, no blocking.
  2. Fallback: construct https://security.snyk.io/package/npm/<component>/<version>
     (retire.js components are npm packages). Used when SerpAPI returns nothing
     matching or no key is set.

NOTE: this uses Snyk purely as a public reference *website* (a link in the
report). It does NOT use Snyk's scanner/CLI/API — no Snyk software involved.

Deduped by component+version so the same library found in many files = one
SerpAPI query. Results cached in the outdir to avoid re-spending quota on re-runs.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

_SNYK_PKG_RE = re.compile(r"https://security\.snyk\.io/package/[^\s\"'<>]+", re.IGNORECASE)


def _constructed_url(component: str, version: str) -> str:
    """Fallback: build the npm Snyk package URL directly."""
    comp = (component or "").strip()
    ver = (version or "").strip()
    if not comp:
        return ""
    from urllib.parse import quote
    base = f"https://security.snyk.io/package/npm/{quote(comp, safe='')}"
    return f"{base}/{quote(ver, safe='')}" if ver else base


def _serpapi_snyk_url(component: str, version: str, api_key: str) -> str:
    """SerpAPI search for the Snyk page; return the first Snyk package URL found."""
    try:
        from serpapi import search as serp_search
    except ImportError:
        return ""
    query = f"snyk {component} {version}".strip()
    try:
        results = serp_search({"q": query, "api_key": api_key, "num": 10})
        data = results.as_dict() if hasattr(results, "as_dict") else dict(results)
    except Exception:  # noqa: BLE001
        return ""
    # scan organic results for the first Snyk package URL
    for item in data.get("organic_results", []) or []:
        link = item.get("link", "") or ""
        if _SNYK_PKG_RE.match(link):
            return link
    # some results carry the URL in a displayed_link / nested field
    blob = json.dumps(data)
    m = _SNYK_PKG_RE.search(blob)
    return m.group(0) if m else ""


def enrich(outdir: Path, api_key: str = "") -> list[list]:
    """Read FunnelWeb's retire.js findings, add a Snyk URL per unique component+
    version, and return rows for the report:
        [Component, Version, Severity, CVE, GHSA, Snyk URL, Source File]

    SerpAPI first (if key), constructed URL as fallback. Cached to
    .snyk_url_cache.json in outdir."""
    outdir = Path(outdir)
    # find retire.js findings json (FunnelWeb writes it under <domain>/js/)
    finding_files = list(outdir.glob("*/js/retirejs_findings.json"))
    if not finding_files:
        return []

    cache_path = outdir / ".snyk_url_cache.json"
    cache = {}
    if cache_path.is_file():
        try:
            cache = json.loads(cache_path.read_text())
        except ValueError:
            cache = {}

    # collect unique findings across all domains
    seen = {}
    for ff in finding_files:
        try:
            data = json.loads(ff.read_text(errors="replace"))
        except ValueError:
            continue
        entries = data.get("data") if isinstance(data, dict) else data
        for entry in entries or []:
            fpath = entry.get("file", "")
            for result in entry.get("results", []) or []:
                comp = result.get("component", "")
                ver = result.get("version", "")
                for vuln in result.get("vulnerabilities", []) or []:
                    idents = vuln.get("identifiers", {}) or {}
                    cves = idents.get("CVE", []) or []
                    ghsa = idents.get("githubID", "") or ""
                    sev = (vuln.get("severity", "") or "").upper()
                    key = f"{comp}\t{ver}\t{','.join(cves)}\t{ghsa}"
                    if key not in seen:
                        seen[key] = {
                            "component": comp, "version": ver, "severity": sev,
                            "cve": ", ".join(cves), "ghsa": ghsa, "file": fpath,
                        }

    rows = []
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    for key, f in sorted(seen.items(),
                         key=lambda kv: sev_rank.get(kv[1]["severity"], 4)):
        cv_key = f"{f['component']}\t{f['version']}"
        # resolve Snyk URL (cache -> SerpAPI -> constructed)
        if cv_key in cache:
            snyk_url = cache[cv_key]
        else:
            snyk_url = ""
            if api_key:
                snyk_url = _serpapi_snyk_url(f["component"], f["version"], api_key)
            if not snyk_url:
                snyk_url = _constructed_url(f["component"], f["version"])
            cache[cv_key] = snyk_url
        rows.append([f["component"], f["version"], f["severity"], f["cve"],
                     f["ghsa"], snyk_url, f["file"]])

    try:
        cache_path.write_text(json.dumps(cache, indent=2))
    except OSError:
        pass
    return rows
