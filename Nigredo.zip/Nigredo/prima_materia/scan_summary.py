"""Phase-0 scan summary sheet.

Builds a triage worktop: one row per IP:port (never collapsed), showing service,
banner, and resolved URL, plus tallies of what nuclei and testssl flagged for
that host/endpoint — so you can see at a glance which hosts need a second look
at which scan.

Columns (left to right):
  IP, Port, Service, Banner, Resolved URL,
  nuclei: Critical, High, Medium, Low,
  testssl: Expired Cert, Self-Signed, Chain Trust, SWEET32, BAR MITZVAH (RC4),
           Logjam, FREAK, POODLE, BEAST, DROWN, ROBOT, Heartbleed, CCS,
           SSLv2, SSLv3, TLS1.0

Sources (phase-0 output dir):
  results.json            -> host/port/service/banner/resolved_url
  nuclei.jsonl            -> severity counts, mapped to host:port by matched URL
  testssl_<host>_<port>.json -> per-endpoint vuln findings
"""
from __future__ import annotations

import json
import glob
import re
from pathlib import Path
from urllib.parse import urlparse
from .probe import build_web_url

from openpyxl.styles import Font, PatternFill, Alignment

FONT = "Roboto"
FONT_SIZE = 11
HEADER_FILL = PatternFill("solid", start_color="1F2937")
HEADER_FONT = Font(name=FONT, size=FONT_SIZE, bold=True, color="FFFFFF")
BODY_FONT = Font(name=FONT, size=FONT_SIZE)

NUCLEI_SEVERITIES = ["critical", "high", "medium", "low"]

# testssl vuln id (as it appears in the JSON 'id' field) -> column label.
# testssl uses these stable ids in its findings.
TESTSSL_VULNS = [
    ("cert_expirationStatus", "Expired Cert"),
    ("cert_selfSigned", "Self-Signed"),
    ("cert_chain_of_trust", "Chain Trust"),
    ("SWEET32", "SWEET32"),
    ("RC4", "BAR MITZVAH (RC4)"),
    ("LOGJAM", "Logjam"),
    ("FREAK", "FREAK"),
    ("POODLE_SSL", "POODLE"),
    ("BEAST", "BEAST"),
    ("DROWN", "DROWN"),
    ("ROBOT", "ROBOT"),
    ("heartbleed", "Heartbleed"),
    ("CCS", "CCS"),
    ("SSLv2", "SSLv2"),
    ("SSLv3", "SSLv3"),
    ("TLS1", "TLS1.0"),
]


def _banner(svc: dict) -> str:
    bits = [svc.get("product", ""), svc.get("version", ""), svc.get("extrainfo", "")]
    return " ".join(b for b in bits if b).strip()


def _is_iis(svc: dict) -> str:
    """Y if nmap's data indicates IIS (product, cpe, or ostype). High-value flag
    for triaging SNS results: SNS runs on everything, but this tells you where
    nmap actually fingerprinted IIS."""
    product = (svc.get("product", "") or "").lower()
    cpes = " ".join(svc.get("cpe", []) or []).lower()
    if "iis" in product or "microsoft-iis" in product or ":iis:" in cpes \
            or "microsoft:iis" in cpes:
        return "Y"
    return ""


def load_hosts(outdir: Path) -> list[dict]:
    """Flatten results.json into per-IP:port rows with HVT fields."""
    rj = outdir / "results.json"
    if not rj.exists():
        return []
    data = json.loads(rj.read_text())
    rows = []
    for addr, info in data.items():
        # host-level OS, used as fallback when the service has no ostype
        host_os = ""
        if info.get("os_matches"):
            host_os = info["os_matches"][0]
        hostnames = ", ".join(info.get("hostnames", []) or [])
        for svc in info.get("services", []):
            cpe = ", ".join(svc.get("cpe", []) or [])
            os_field = svc.get("ostype", "") or host_os
            rows.append({
                "ip": addr,
                "port": int(svc.get("port", 0)),
                "service": svc.get("service", ""),
                "banner": _banner(svc),
                "resolved_url": svc.get("resolved_url", ""),
                # HVT fields
                "os": os_field,
                "cpe": cpe,
                "tunnel": svc.get("tunnel", ""),
                "hostname": svc.get("hostname", ""),
                "hostnames": hostnames,
                "iis": _is_iis(svc),
            })
    rows.sort(key=lambda r: (r["ip"], r["port"]))
    return rows


def nuclei_tally(outdir: Path) -> dict[tuple[str, int], dict[str, int]]:
    """Map (host, port) -> {severity: count} from nuclei.jsonl."""
    tally: dict[tuple[str, int], dict[str, int]] = {}
    jpath = outdir / "nuclei.jsonl"
    if not jpath.exists():
        return tally
    for line in jpath.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
        except json.JSONDecodeError:
            continue
        sev = (obj.get("info", {}) or {}).get("severity", "").lower()
        if sev not in NUCLEI_SEVERITIES:
            continue
        # locate the matched host:port
        matched = obj.get("matched-at") or obj.get("host") or obj.get("matched_at") or ""
        host, port = _host_port_from_target(matched)
        if not host:
            continue
        key = (host, port)
        tally.setdefault(key, {s: 0 for s in NUCLEI_SEVERITIES})
        tally[key][sev] += 1
    return tally


def _host_port_from_target(target: str) -> tuple[str, int]:
    """Extract (host, port) from a nuclei matched-at value (URL or host:port)."""
    if not target:
        return ("", 0)
    t = target.strip()
    if "://" in t:
        p = urlparse(t)
        host = p.hostname or ""
        port = p.port or (443 if p.scheme == "https" else 80)
        return (host, int(port))
    # host:port form
    m = re.match(r"^([^:/\s]+):(\d+)", t)
    if m:
        return (m.group(1), int(m.group(2)))
    return (t, 0)


def testssl_tally(outdir: Path) -> dict[tuple[str, int], dict[str, int]]:
    """Map (host, port) -> {vuln_label: count} from testssl_*.json files."""
    tally: dict[tuple[str, int], dict[str, int]] = {}
    id_to_label = dict(TESTSSL_VULNS)
    for jf in glob.glob(str(outdir / "testssl_*.json")):
        try:
            data = json.loads(Path(jf).read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            continue
        findings = data if isinstance(data, list) else data.get("scanResult", data)
        if isinstance(findings, dict):
            findings = [findings]
        # testssl pretty-json: list of finding dicts each with id, severity, ip, port, finding
        for entry in _iter_findings(findings):
            fid = entry.get("id", "")
            sev = (entry.get("severity", "") or "").upper()
            host = entry.get("ip", "") or entry.get("hostname", "")
            host = host.split("/")[0] if host else ""
            port = int(entry.get("port", 0) or 0)
            label = _match_vuln_label(fid, id_to_label)
            if not label:
                continue
            finding_txt = (entry.get("finding", "") or "")
            # cert fields: judged by their finding text
            if label in ("Expired Cert", "Self-Signed", "Chain Trust"):
                if not _cert_is_problem(label, finding_txt):
                    continue
            else:
                # protocol/vuln tests: count only if the finding indicates a problem.
                # testssl says "VULNERABLE", "offered" (for deprecated protocols),
                # or carries a HIGH/MEDIUM/CRITICAL severity. "not vulnerable" /
                # "not offered" / OK severity => not an issue.
                if not _vuln_is_problem(sev, finding_txt):
                    continue
            key = (host, port)
            tally.setdefault(key, {})
            tally[key][label] = tally[key].get(label, 0) + 1
    return tally


def _vuln_is_problem(severity: str, finding: str) -> bool:
    f = (finding or "").lower()
    # explicit negatives win
    if "not vulnerable" in f or "not offered" in f or "not present" in f:
        return False
    if "vulnerable" in f or "offered" in f:
        return True
    # fall back to severity for findings without clear text
    return severity in ("HIGH", "MEDIUM", "CRITICAL")


def _iter_findings(obj):
    """Yield finding dicts from testssl JSON, tolerating nesting."""
    if isinstance(obj, list):
        for item in obj:
            yield from _iter_findings(item)
    elif isinstance(obj, dict):
        if "id" in obj and ("severity" in obj or "finding" in obj):
            yield obj
        else:
            for v in obj.values():
                if isinstance(v, (list, dict)):
                    yield from _iter_findings(v)


def _match_vuln_label(fid: str, id_to_label: dict) -> str:
    if not fid:
        return ""
    # exact id match first
    if fid in id_to_label:
        return id_to_label[fid]
    # prefix/substring match (testssl ids sometimes carry suffixes)
    for vid, label in id_to_label.items():
        if fid.startswith(vid) or vid.lower() in fid.lower():
            return label
    return ""


def _cert_is_problem(label: str, finding: str) -> bool:
    f = (finding or "").lower()
    if label == "Expired Cert":
        return "expired" in f
    if label == "Self-Signed":
        return "self-signed" in f or "self signed" in f
    if label == "Chain Trust":
        return ("not ok" in f or "fail" in f or "untrusted" in f
                or "chain of trust" in f and "ok" not in f)
    return False


def sns_flags(outdir: Path) -> dict[tuple[str, int], bool]:
    """Map (host, port) -> True if SNS reported the endpoint vulnerable.
    Parses sns_<host>_<port>.txt; vulnerability is signaled by a VULNERABLE line
    (check mode prints '[VULNERABLE-<METHOD>] <url>')."""
    flags: dict[tuple[str, int], bool] = {}
    for sf in glob.glob(str(outdir / "sns_*.txt")):
        name = Path(sf).stem[len("sns_"):]   # host_port
        # split on the last underscore to recover host and port
        if "_" not in name:
            continue
        host, _, port_s = name.rpartition("_")
        try:
            port = int(port_s)
        except ValueError:
            continue
        try:
            text = Path(sf).read_text(errors="replace")
        except FileNotFoundError:
            continue
        vulnerable = "VULNERABLE" in text.upper() and "NOT VULNERABLE" not in text.upper()
        flags[(host, port)] = vulnerable
    return flags


def feroxbuster_findings(outdir: Path) -> list[dict]:
    """Parse feroxbuster JSON-lines output into findings rows.

    feroxbuster --json emits one JSON object per line. Response records have
    type='response' with url, status, content_length, line_count, word_count,
    and (for redirects) a headers.location. We keep responses that carry
    information: 200s, redirects (3xx, with their Location), and auth-gated
    responses (401/403) which signal a private area worth noting.
    """
    findings: list[dict] = []
    seen: set[tuple] = set()
    INFORMATIVE = {200, 201, 204, 301, 302, 307, 308, 401, 403, 405, 500}
    for jf in sorted(glob.glob(str(outdir / "feroxbuster_*.json"))):
        for line in Path(jf).read_text(errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if obj.get("type") != "response":
                continue
            status = obj.get("status", 0)
            if status not in INFORMATIVE:
                continue
            url = obj.get("url", "")
            # redirect Location, if present
            location = ""
            headers = obj.get("headers", {}) or {}
            for k, v in headers.items():
                if k.lower() == "location":
                    location = v
                    break
            # flag a redirect that points somewhere off the current path/host
            redirect_flag = ""
            if location and 300 <= status < 400:
                redirect_flag = _redirect_note(url, location)
            key = (url, status)
            if key in seen:
                continue
            seen.add(key)
            findings.append({
                "url": url,
                "status": status,
                "length": obj.get("content_length", ""),
                "words": obj.get("word_count", ""),
                "lines": obj.get("line_count", ""),
                "redirect_to": location,
                "note": redirect_flag,
            })
    findings.sort(key=lambda f: (f["status"], f["url"]))
    return findings


def _redirect_note(url: str, location: str) -> str:
    """Describe a redirect: off-host (leaves the domain) or to an auth/login area."""
    from urllib.parse import urljoin
    src = urlparse(url)
    dest_abs = location if "://" in location else urljoin(url, location)
    dest = urlparse(dest_abs)
    if dest.netloc and dest.netloc.lower() != src.netloc.lower():
        return "off-host redirect"
    low = (dest.path or "").lower()
    if any(k in low for k in ("login", "signin", "sign-in", "auth", "sso",
                              "account", "admin", "portal", "dashboard")):
        return "redirect to auth/private area"
    return "redirect (same host)"


def feroxbuster_403_hotspots(outdir: Path) -> list[dict]:
    """Tally 403 (Forbidden) responses per PARENT DIRECTORY from BOTH feroxbuster
    and ffuf JSON output. Directories with many 403s are candidates for manual
    bypass testing (they're often protected areas that exist but block access) —
    and they're the pattern that trips --auto-bail, so surfacing them turns 'gave
    up here' into 'these spots are interesting, look closer'.

    Reads feroxbuster's newline-delimited JSON AND ffuf's {"results":[...]} JSON,
    so 403s from either tool are captured. Returns rows sorted by count desc.
    """
    from urllib.parse import urlparse
    counts: dict[str, int] = {}
    examples: dict[str, str] = {}

    def _tally(url: str):
        if not url:
            return
        try:
            p = urlparse(url)
            path = p.path or "/"
            parent = path.rsplit("/", 1)[0] or "/"
            dirkey = f"{p.scheme}://{p.netloc}{parent}"
        except Exception:  # noqa: BLE001
            dirkey = url
        counts[dirkey] = counts.get(dirkey, 0) + 1
        examples.setdefault(dirkey, url)

    # feroxbuster: newline-delimited JSON, type=response, status=403
    for jf in sorted(glob.glob(str(outdir / "feroxbuster_*.json"))):
        for line in Path(jf).read_text(errors="replace").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError:
                continue
            if obj.get("type") == "response" and obj.get("status") == 403:
                _tally(obj.get("url", ""))

    # ffuf: single JSON doc, results[].status == 403
    for jf in sorted(glob.glob(str(outdir / "ffuf_*.json"))):
        try:
            data = json.loads(Path(jf).read_text(errors="replace"))
        except (ValueError, OSError):
            continue
        for r in data.get("results", []) or []:
            if r.get("status") == 403:
                _tally(r.get("url", ""))

    rows = [{"directory": d, "count_403": c, "example": examples.get(d, "")}
            for d, c in counts.items()]
    rows.sort(key=lambda r: (-r["count_403"], r["directory"]))
    return rows


def add_nomore403_sheet(wb, outdir):
    """Add a '403 Bypasses' sheet from nomore403 results: access-control
    bypasses found on the forbidden URLs (403=>200 = likely real). Only added
    if there are findings."""
    outdir = Path(outdir)
    try:
        from .nomore403_tool import parse_results
    except ImportError:
        return None
    jsonl = outdir / "nomore403.jsonl"
    findings = parse_results(jsonl)
    if not findings:
        return None
    ws = wb.create_sheet("403 Bypasses")
    ws.sheet_properties.tabColor = "B91C1C"   # red: these are high-value
    headers = ["URL", "Transition", "Score", "Technique", "Payload/Item",
               "Why", "Replay (curl)"]
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "A2"
    for f in findings:
        ws.append(f.as_row())
    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            cell.font = BODY_FONT
    for c, w in ((1, 50), (2, 14), (3, 12), (4, 18), (5, 34), (6, 40), (7, 70)):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


def add_shodan_sheet(wb, outdir):
    """Add a 'Shodan (passive)' sheet from the enrichment CSV. Passive ports/
    CVEs/CPEs per target IP — cross-reference against nmap. Only if data exists."""
    outdir = Path(outdir)
    csv_path = outdir / "shodan_enrichment.csv"
    if not csv_path.is_file():
        return None
    import csv as _csv
    rows = []
    with open(csv_path, newline="", encoding="utf-8", errors="replace") as f:
        reader = _csv.reader(f)
        header = next(reader, None)
        for r in reader:
            rows.append(r)
    if not rows:
        return None
    ws = wb.create_sheet("Shodan (passive)")
    hdr = header or ["IP", "Ports", "Vulns (CVE)", "CPEs", "Hostnames", "Tags",
                     "Org", "OS", "Products", "Source"]
    for c, name in enumerate(hdr, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "A2"
    for r in rows:
        ws.append(r)
        # flag rows that carry a CVE (column index 3)
        if len(r) >= 3 and r[2].strip():
            for cell in ws[ws.max_row]:
                cell.font = Font(name=FONT, size=FONT_SIZE, bold=True, color="B91C1C")
    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            if not cell.font or cell.font.color is None:
                cell.font = BODY_FONT
    for c, w in ((1, 16), (2, 22), (3, 30), (4, 34), (5, 30), (6, 16),
                 (7, 20), (8, 12), (9, 30), (10, 12)):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


def add_takeover_sheet(wb, outdir):
    """Add a 'Subdomain Takeovers' sheet from the nuclei takeover passes. Only
    added if there are findings (a takeover finding is high-value)."""
    outdir = Path(outdir)
    try:
        from .takeover import parse_takeover
    except ImportError:
        return None
    findings = parse_takeover(outdir)
    if not findings:
        return None
    ws = wb.create_sheet("Subdomain Takeovers")
    ws.sheet_properties.tabColor = "B91C1C"   # red: high-value
    headers = ["Subdomain", "Service", "Template", "Severity", "Matched At"]
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "A2"
    for f in findings:
        ws.append(f.as_row())
    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            cell.font = BODY_FONT
    for c, w in ((1, 40), (2, 26), (3, 30), (4, 12), (5, 50)):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


def add_httpx_sheet(wb, outdir):
    """Raw httpx output tab: url, status, title, webserver, tech, cdn."""
    outdir = Path(outdir)
    try:
        from .web_discovery import parse_httpx
    except ImportError:
        return None
    rows = parse_httpx(outdir / "httpx_output.jsonl")
    if not rows:
        return None
    ws = wb.create_sheet("httpx")
    headers = ["URL", "Status", "Title", "Web Server", "Tech", "CDN"]
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "A2"
    for r in rows:
        ws.append([r["url"], r["status"], r["title"], r["webserver"],
                   r["tech"], r["cdn"]])
    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            cell.font = BODY_FONT
    for c, w in ((1, 55), (2, 8), (3, 40), (4, 22), (5, 40), (6, 16)):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


def _raw_lines_sheet(wb, outdir, filename, sheetname, header):
    """Generic: dump a raw one-URL-per-line file into its own tab."""
    outdir = Path(outdir)
    f = outdir / filename
    if not f.is_file():
        return None
    lines = [l.strip() for l in f.read_text(errors="replace").splitlines() if l.strip()]
    if not lines:
        return None
    ws = wb.create_sheet(sheetname)
    cell = ws.cell(row=1, column=1, value=header)
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    ws.freeze_panes = "A2"
    for u in lines:
        ws.append([u])
    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            cell.font = BODY_FONT
    ws.column_dimensions["A"].width = 90
    return ws


def add_katana_sheet(wb, outdir):
    """Raw katana crawl output tab."""
    return _raw_lines_sheet(wb, outdir, "katana_output.txt", "katana",
                            "Crawled URL (katana)")


def add_gau_sheet(wb, outdir):
    """Raw gau historical-URL output tab."""
    return _raw_lines_sheet(wb, outdir, "gau_output.txt", "gau",
                            "Historical URL (gau)")


def add_feroxbuster_403_hotspots_sheet(wb, outdir):
    """Add a '403 Hotspots' sheet: directories ranked by 403 count — manual
    bypass-testing candidates. Only added if there are 403s to report."""
    outdir = Path(outdir)
    hotspots = feroxbuster_403_hotspots(outdir)
    if not hotspots:
        return None
    ws = wb.create_sheet("403 Hotspots")
    headers = ["Directory", "403 Count", "Example URL", "Note"]
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "A2"
    for h in hotspots:
        note = ("heavy 403s — candidate for manual bypass testing"
                if h["count_403"] >= 10 else "")
        ws.append([h["directory"], h["count_403"], h["example"], note])
    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            cell.font = BODY_FONT
    for c, w in ((1, 60), (2, 11), (3, 60), (4, 44)):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


def add_feroxbuster_sheet(wb, outdir):
    """Add a 'Feroxbuster' findings sheet: informative responses + redirects."""
    outdir = Path(outdir)
    findings = feroxbuster_findings(outdir)
    headers = ["URL", "Status", "Length", "Words", "Lines", "Redirect To", "Note"]
    ws = wb.create_sheet("Feroxbuster")
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "A2"
    for f in findings:
        ws.append([f["url"], f["status"], f["length"], f["words"], f["lines"],
                   f["redirect_to"], f["note"]])
    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            cell.font = BODY_FONT
    widths = [60, 8, 9, 8, 8, 50, 26]
    for c, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


def sshaudit_findings(outdir: Path) -> list[dict]:
    """Parse ssh-audit JSON files into recommendation rows.

    The jtesta ssh-audit JSON includes a 'recommendations' structure (and CVE
    data). Recommendations are grouped by action (append/remove) and severity.
    We flatten into rows: endpoint, action, algorithm-type, algorithm, note.
    Tolerant of schema variation across versions.
    """
    rows: list[dict] = []
    for jf in sorted(glob.glob(str(outdir / "sshaudit_*.json"))):
        try:
            data = json.loads(Path(jf).read_text())
        except (json.JSONDecodeError, FileNotFoundError):
            continue
        # endpoint from the 'target' field if present, else from filename
        endpoint = ""
        if isinstance(data, dict):
            endpoint = data.get("target", "") or ""
        if not endpoint:
            endpoint = Path(jf).stem[len("sshaudit_"):].replace("_", ":")

        recs = data.get("recommendations") if isinstance(data, dict) else None
        if recs:
            rows.extend(_flatten_recs(endpoint, recs))

        # CVEs are worth surfacing alongside recommendations
        cves = data.get("cves") if isinstance(data, dict) else None
        if isinstance(cves, list):
            for c in cves:
                if isinstance(c, dict):
                    rows.append({
                        "endpoint": endpoint, "action": "CVE",
                        "alg_type": c.get("name", ""), "algorithm": "",
                        "note": f"CVSS {c.get('cvssv2','?')}: {c.get('description','')}",
                    })
    return rows


def _flatten_recs(endpoint: str, recs) -> list[dict]:
    """Flatten ssh-audit recommendations into rows, tolerant of shape.

    Common shape: {"critical"|"warning"|"informational": {
        "del"|"add"|"chg": {"kex"|"key"|"enc"|"mac": {algname: [notes]}}}}
    """
    out = []
    if not isinstance(recs, dict):
        return out

    def walk(node, severity, action):
        if isinstance(node, dict):
            for k, v in node.items():
                # action keys
                if k in ("del", "add", "chg"):
                    walk(v, severity, {"del": "remove", "add": "append",
                                       "chg": "change"}[k])
                # alg-type keys
                elif k in ("kex", "key", "enc", "mac"):
                    if isinstance(v, dict):
                        for alg, notes in v.items():
                            note = ""
                            if isinstance(notes, list):
                                note = "; ".join(str(n) for n in notes)
                            elif notes:
                                note = str(notes)
                            out.append({
                                "endpoint": endpoint,
                                "action": action or "",
                                "alg_type": k,
                                "algorithm": alg,
                                "note": (f"[{severity}] " if severity else "") + note,
                            })
                    elif isinstance(v, list):
                        for alg in v:
                            out.append({"endpoint": endpoint, "action": action or "",
                                        "alg_type": k, "algorithm": str(alg),
                                        "note": f"[{severity}]" if severity else ""})
                else:
                    # severity level or nested container
                    walk(v, k if k in ("critical", "warning", "informational") else severity, action)

    walk(recs, "", "")
    return out


def add_sshaudit_sheet(wb, outdir):
    """SSH-Audit sheet: hosts with SSH (port 22) open listed at the TOP, then the
    raw per-endpoint audit recommendations below."""
    outdir = Path(outdir)
    rows = sshaudit_findings(outdir)
    ws = wb.create_sheet("SSH-Audit")

    # --- top block: targets with SSH open (from results.json + Nessus) ---
    ssh_hosts = set()
    try:
        for r in (load_hosts(outdir) if (outdir / "results.json").exists() else []):
            svc = (r.get("service") or "").lower()
            if r.get("port") == 22 or "ssh" in svc:
                ssh_hosts.add(f"{r.get('hostnames') or r.get('ip')}:{r.get('port')}")
    except Exception:  # noqa: BLE001
        pass
    r_i = 1
    hdr = ws.cell(row=r_i, column=1, value="Hosts with SSH open")
    hdr.font = HEADER_FONT
    hdr.fill = HEADER_FILL
    r_i += 1
    if ssh_hosts:
        for h in sorted(ssh_hosts):
            ws.cell(row=r_i, column=1, value=h).font = BODY_FONT
            r_i += 1
    else:
        ws.cell(row=r_i, column=1, value="(none detected from scan data)").font = BODY_FONT
        r_i += 1
    r_i += 2   # blank rows before the raw audit block

    headers = ["Endpoint", "Action", "Algorithm Type", "Algorithm", "Note"]
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=r_i, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    r_i += 1
    action_order = {"remove": 0, "change": 1, "append": 2, "CVE": 3}
    rows.sort(key=lambda r: (r["endpoint"], action_order.get(r["action"], 9),
                             r["alg_type"], r["algorithm"]))
    for r in rows:
        for c, key in enumerate(["endpoint", "action", "alg_type", "algorithm", "note"], 1):
            ws.cell(row=r_i, column=c, value=r[key]).font = BODY_FONT
        r_i += 1
    widths = [24, 10, 16, 36, 50]
    for c, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


def add_subdomain_inventory_sheet(wb, outdir):
    """Subdomain Enumeration (Raw): the full, unfiltered subdomain list exactly as
    the enumeration (subfinder/subdomains) produced it — every host discovered,
    no collapsing. The concise CNAME-preferred view lives in its own sheet; this
    is the complete raw record for reference/audit."""
    from pathlib import Path
    outdir = Path(outdir)
    # Collect from every raw enumeration artifact. subfinder writes
    # `subdomains_<domain>.subfinder.txt` (bare names, one per line — the actual
    # filename, NOT `subfinder_*.txt`); the resolve chain writes
    # `subdomains_<domain>.raw.txt` (bare names) and `.raw.csv`
    # (subdomain,type,value rows). We dedup on the HOSTNAME only, so the same
    # name appearing as a bare line in one file and a CSV row in another collapses
    # to a single entry instead of showing twice.
    lines = []
    raw_candidates = (list(outdir.glob("subdomains_*.subfinder.txt"))
                      + list(outdir.glob("subdomains_*.raw.txt"))
                      + list(outdir.glob("subdomains_*.raw.csv")))
    seen = set()
    for p in raw_candidates:
        is_csv = p.suffix == ".csv"
        try:
            for ln in p.read_text(errors="replace").splitlines():
                s = ln.strip()
                if not s:
                    continue
                if is_csv:
                    # rows are `subdomain,type,value`; take the hostname column
                    # and skip the header row.
                    host = s.split(",", 1)[0].strip().lower()
                    if not host or host == "subdomain":
                        continue
                else:
                    host = s.lower()
                if host and host not in seen:
                    seen.add(host)
                    lines.append(host)
        except OSError:
            continue
    if not lines:
        return
    ws = wb.create_sheet("Subdomains (Raw)")
    hdr = ws.cell(row=1, column=1, value="Subdomain (raw enumeration — full list)")
    hdr.font = HEADER_FONT
    hdr.fill = HEADER_FILL
    for i, ln in enumerate(sorted(lines), start=2):
        ws.cell(row=i, column=1, value=ln).font = BODY_FONT
    ws.column_dimensions["A"].width = 60
    ws.freeze_panes = "A2"


def add_nessus_vs_nmap_sheet(wb, nmap_results: dict, nessus_rich: dict,
                             nessus_used: bool):
    """Side-by-side Nessus vs nmap per IP:port for at-a-glance validation.

    States in the Nessus columns:
      - real data  : Nessus saw this port
      - 'NEW!!!'   : nmap found it, Nessus (which ran) did NOT — investigate
      - 'N'        : no Nessus file was used for this run at all
      - blank      : n/a
    """
    ws = wb.create_sheet("Nessus vs nmap")
    headers = ["Source", "FQDN", "IP", "Port", "Protocol", "nmap Service",
               "Nessus Service", "Nessus Findings", "Validate With",
               "Plugin Output", "CVE", "CVSS v3.1"]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")

    # nmap side: (ip,port) -> (fqdns, service)
    nmap_ports = {}
    for ip, info in (nmap_results or {}).items():
        fqdns = ", ".join(info.get("hostnames", []) or [])
        svc_by_port = {}
        for s in info.get("services", []) or []:
            svc_by_port[int(s.get("port", 0))] = s.get("service", "")
        for p in filter(None, str(info.get("open_ports", "")).split(",")):
            try:
                port = int(p)
            except ValueError:
                continue
            nmap_ports[(ip, port)] = (fqdns, svc_by_port.get(port, ""))

    # nessus side: (ip,port) -> (host, port_details)
    nessus_ports = {}
    for ip, h in (nessus_rich or {}).items():
        for (proto, port), pd in h.get("ports", {}).items():
            nessus_ports[(ip, port)] = (h, pd)

    all_keys = sorted(set(nmap_ports) | set(nessus_ports),
                      key=lambda k: (k[0], k[1]))

    for (ip, port) in all_keys:
        in_nmap = (ip, port) in nmap_ports
        in_ness = (ip, port) in nessus_ports
        # provenance marker: (Ns)(Ng) both, (Ns) nessus-only, (Ng) nigredo-only
        if in_nmap and in_ness:
            source = "(Ns)(Ng)"
        elif in_ness:
            source = "(Ns)"
        else:
            source = "(Ng)"

        fqdn = nmap_svc = ""
        if in_nmap:
            fqdn, nmap_svc = nmap_ports[(ip, port)]
        if in_ness:
            h, pd = nessus_ports[(ip, port)]
            if not fqdn:
                fqdn = ", ".join(h.get("hostnames", []) or [])
            proto = pd.get("protocol", "TCP")
            ness_svc = pd.get("service", "")
            findings = "\n".join(pd.get("findings", []))
            output = "\n".join(pd.get("outputs", []))
            cves = ", ".join(sorted(set(pd.get("cves", []))))
            cvss = ", ".join(sorted(set(pd.get("cvss3", []))))
            # which validator(s) apply to this port's findings
            from .validation_map import parse_finding_line, validator_for
            vset = []
            for f in pd.get("findings", []):
                pid, pname = parse_finding_line(f)
                v = validator_for(pid, pname)
                if v not in vset:
                    vset.append(v)
            validate_with = ", ".join(vset) if vset else ""
        else:
            proto = "TCP"
            if not nessus_used:
                ness_svc = findings = output = cves = cvss = "N"
                validate_with = "N"
            else:
                ness_svc = findings = output = cves = cvss = "NEW!!!"
                validate_with = ""

        ws.append([source, fqdn, ip, port, proto, nmap_svc,
                   ness_svc, findings, validate_with, output, cves, cvss])

    widths = [10, 26, 16, 7, 9, 14, 14, 50, 16, 50, 22, 10]
    for i, w in enumerate(widths, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w
    ws.freeze_panes = "A2"
    for r in range(2, ws.max_row + 1):
        for col in (8, 10):     # findings + plugin output wrap
            ws.cell(row=r, column=col).alignment = Alignment(
                wrap_text=True, vertical="top")


def add_severity_matrix_sheet(wb, nessus_rich: dict):
    """Host x severity counts (Low/Medium/High/Critical), like n2csv's matrix."""
    ws = wb.create_sheet("Severity Matrix")
    headers = ["Host", "Low", "Medium", "High", "Critical", "Total"]
    for c, h in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL

    for ip, h in sorted((nessus_rich or {}).items()):
        counts = {"Low": 0, "Medium": 0, "High": 0, "Critical": 0}
        for pd in h.get("ports", {}).values():
            for f in pd.get("findings", []):
                for sev in counts:
                    if f"-{sev}-" in f:
                        counts[sev] += 1
        total = sum(counts.values())
        if total == 0:
            continue
        ws.append([ip, counts["Low"], counts["Medium"], counts["High"],
                   counts["Critical"], total])
    for i, w in enumerate([20, 8, 10, 8, 10, 8], start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w
    ws.freeze_panes = "A2"


def build_live_url_list(web_probes) -> list[str]:
    """Unique, live, NON-redirecting web URLs (scheme://host:port) for manual
    review in Burp/ZAP via a proxy-enabled browser.

    Includes anything that returned an HTTP response and is NOT a redirect —
    both IP forms and in-scope FQDN forms (each with its port). Excludes
    redirects entirely (origin and destination) and dead/refused endpoints.
    """
    urls, seen = [], set()
    for p in web_probes:
        # must have actually resolved (got a scheme + status) and not be a redirect
        if not (p.scheme and p.status is not None):
            continue
        if p.is_redirect:
            continue
        u = p.url or build_web_url(p.scheme, p.host, p.port)
        if u not in seen:
            seen.add(u)
            urls.append(u)
    return sorted(urls)


def add_live_urls_sheet(wb, urls: list[str]):
    """Add a 'Live URLs (Burp)' tab: one live, non-redirecting URL per row."""
    ws = wb.create_sheet("Live URLs (Burp)")
    cell = ws.cell(row=1, column=1, value="Live Web URL (proxy into Burp/ZAP)")
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="left", vertical="center")
    for i, u in enumerate(urls, start=2):
        c = ws.cell(row=i, column=1, value=u)
        c.font = BODY_FONT
    ws.column_dimensions["A"].width = 60
    ws.freeze_panes = "A2"


def build_web_hosts_at_a_glance(web_probes, outdir) -> list[str]:
    """Fold probe.py live URLs + httpx discovered URLs into ONE deduplicated
    list for the At a Glance view. Raw outputs stay on their own tabs; this is
    the merged actionable list. Dedup on the URL."""
    from pathlib import Path as _P
    seen, out = set(), []
    # probe.py live, non-redirecting URLs
    for p in (web_probes or []):
        if not (p.scheme and p.status is not None) or p.is_redirect:
            continue
        u = p.url or build_web_url(p.scheme, p.host, p.port)
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    # httpx discovered URLs
    try:
        from .web_discovery import parse_httpx
        for r in parse_httpx(_P(outdir) / "httpx_output.jsonl"):
            u = r.get("url", "")
            if u and u not in seen:
                seen.add(u)
                out.append(u)
    except Exception:  # noqa: BLE001
        pass
    return sorted(out)


def add_web_hosts_glance_sheet(wb, web_probes, outdir):
    """A single deduplicated 'Web Hosts (At a Glance)' tab folding probe + httpx.
    Raw probe (Live URLs) and raw httpx tabs remain separate."""
    urls = build_web_hosts_at_a_glance(web_probes, outdir)
    if not urls:
        return None
    ws = wb.create_sheet("Web Hosts (At a Glance)")
    cell = ws.cell(row=1, column=1, value="Live Web Host (probe + httpx, deduped)")
    cell.font = HEADER_FONT
    cell.fill = HEADER_FILL
    cell.alignment = Alignment(horizontal="left", vertical="center")
    for i, u in enumerate(urls, start=2):
        ws.cell(row=i, column=1, value=u).font = BODY_FONT
    ws.column_dimensions["A"].width = 70
    ws.freeze_panes = "A2"
    return ws


def add_hosts_by_port_sheet(wb, outdir):
    """Add a 'Hosts by Port' sheet: for each open port (TCP block first ascending,
    then UDP ascending), list the in-scope hosts that had it open, grouped by IP.

    Merges ALL sources that reported an open port — results.json (active scan +
    probes) and any .nessus files in the output dir (authoritative for the
    engagement's scanned hosts). Not 'verified/final' — anything any tool saw open.

    Layout (one column, copy-paste friendly):
        Port 22/tcp
        host1.site.com [10.0.0.1], host2.site.com [10.0.0.2]
        <blank>
        Port 443/tcp
        www.site.com, mail.site.com [10.0.0.3], 10.0.0.9

    Formatting: FQDNs sharing an IP are listed together comma-separated then the
    IP in [brackets]; a host with multiple IPs -> fqdn [ip1, ip2]; a bare IP with
    no FQDN has no brackets; chunks joined by ', '.
    """
    from pathlib import Path as _P

    outdir = _P(outdir)
    port_map: dict[tuple[str, int], dict[str, set]] = {}

    def _add(proto, port, ip, fqdns):
        try:
            port = int(port)
        except (TypeError, ValueError):
            return
        if not port or not ip:
            return
        proto = (proto or "tcp").lower()
        proto = "udp" if proto == "udp" else "tcp"
        d = port_map.setdefault((proto, port), {})
        s = d.setdefault(str(ip), set())
        for f in (fqdns or []):
            if f and str(f).strip() and str(f) != str(ip):
                s.add(str(f).strip())

    # source 1: results.json (active scan + probes; TCP)
    rj = outdir / "results.json"
    if rj.exists():
        try:
            data = json.loads(rj.read_text())
            for addr, info in data.items():
                hns = info.get("hostnames", []) or []
                for svc in info.get("services", []):
                    extra = [svc.get("hostname")] if svc.get("hostname") else []
                    _add("tcp", svc.get("port", 0), addr, hns + extra)
        except (ValueError, OSError):
            pass

    # source 2: Nessus files. Prefer the exact files chosen at the interview
    # (stashed as nessus_files) so ALL of them are merged; fall back to scanning
    # the output dir if none were stashed.
    try:
        from . import nessus_import
        nfiles = []
        try:
            from . import runmode
            nfiles = list(runmode.answer("nessus_files", []) or [])
        except Exception:  # noqa: BLE001
            nfiles = []
        if not nfiles:
            nfiles = [str(p) for p in outdir.rglob("*.nessus")]
        if nfiles:
            rich = (nessus_import.load_multi(nfiles) if len(nfiles) > 1
                    else nessus_import.load(nfiles[0]))
            # NOTE: iterate the RICH parse — to_target_dict() drops the per-port
            # 'ports' map (keeps only the open_ports csv string), so reading
            # .get("ports") off it silently yielded zero Nessus ports.
            for ip, h in rich.items():
                if not (h.get("ports") or {}):
                    continue
                hns = h.get("hostnames", []) or []
                for (proto, port) in h.get("ports", {}).keys():
                    _add(proto, port, ip, hns)
    except Exception:  # noqa: BLE001
        pass

    if not port_map:
        return

    ws = wb.create_sheet("Hosts by Port")

    def _ipkey(x):
        parts = x.split(".")
        if len(parts) == 4 and all(o.isdigit() for o in parts):
            return [int(o) for o in parts]
        return [0, 0, 0, 0]

    def _fmt(ipmap):
        fqdnset_to_ips: dict[tuple, list] = {}
        bare_ips = []
        for ip, fqdns in ipmap.items():
            fqdns = [f for f in (fqdns or []) if str(f).strip()]  # ignore blanks
            if fqdns:
                fqdnset_to_ips.setdefault(tuple(sorted(fqdns)), []).append(ip)
            else:
                bare_ips.append(ip)
        chunks = []
        for fset in sorted(fqdnset_to_ips.keys(), key=lambda t: t[0].lower()):
            ips = sorted(fqdnset_to_ips[fset], key=_ipkey)
            chunks.append(f"{', '.join(fset)} [{', '.join(ips)}]")
        for ip in sorted(bare_ips, key=_ipkey):
            chunks.append(ip)
        return ", ".join(chunks)

    tcp = sorted([k for k in port_map if k[0] == "tcp"], key=lambda k: k[1])
    udp = sorted([k for k in port_map if k[0] == "udp"], key=lambda k: k[1])
    r = 1
    for (proto, port) in tcp + udp:
        ws.cell(row=r, column=1, value=f"Port {port}/{proto}")
        ws.cell(row=r + 1, column=1, value=_fmt(port_map[(proto, port)]))
        r += 4   # host row + 2 blank rows
    ws.column_dimensions["A"].width = 160



def add_targets_grid_sheet(wb, outdir):
    """Analyst working grid — the External-Notebook 'Targets' page, populated.
    One row per host+port; first port shows Domain+IP, later ports blank those
    and just list the port (ascending). Multi-value cells stacked newline-sep
    with wrap so one click copies the whole list."""
    from pathlib import Path
    from collections import defaultdict
    outdir = Path(outdir)
    rows = load_hosts(outdir) if (outdir / "results.json").exists() else []
    # Item 7: nmap-confirmed ports + Nessus '?'-uncertain ports, for the
    # false-positive tag (a '?' port confirmed by neither nmap nor shodan = bogus).
    nmap_ports = {(r.get("ip", ""), int(r.get("port", 0) or 0)) for r in (rows or [])}
    uncertain_ports = set()
    nessus_cert_by: dict = {}   # "ip:port" -> [cert-related Nessus plugin names]
    nessus_all_by: dict = {}    # B4: "ip:port" -> [ALL Nessus findings]
    nessus_hsts_by: dict = {}   # B4: "ip:port" -> ["Missing"] when HSTS plugin fired
    try:
        from . import nessus_import, runmode
        nfiles = list(runmode.answer("nessus_files", []) or []) or \
            [str(p) for p in outdir.rglob("*.nessus")]
        if nfiles:
            rich = (nessus_import.load_multi(nfiles) if len(nfiles) > 1
                    else nessus_import.load(nfiles[0]))
            nessus_cert_by = _nessus_cert_by_hostport(rich)
            nessus_all_by = _nessus_all_by_hostport(rich)
            nessus_hsts_by = _nessus_hsts_by_hostport(rich)
            # iterate the RICH parse — to_target_dict() drops the per-port map
            for ip, h in rich.items():
                if not (h.get("ports") or {}):
                    continue
                hns = ", ".join(h.get("hostnames", []) or [])
                for (proto, port), pd in h.get("ports", {}).items():
                    svc = str(pd.get("service", "")).strip()
                    if svc.endswith("?"):
                        uncertain_ports.add((ip, int(port)))
                    rows.append({"ip": ip, "port": int(port), "service": svc,
                                 "banner": "", "resolved_url": "", "os": "",
                                 "cpe": "", "tunnel": proto, "hostname": "",
                                 "hostnames": hns, "iis": False, "_nessus": True})
    except Exception:
        pass
    if not rows:
        return
    by_host = defaultdict(dict)
    host_names = {}
    for r in rows:
        ip = r["ip"]
        by_host[ip].setdefault(r["port"], r)
        nm = r.get("hostnames") or r.get("hostname") or ""
        if nm and not host_names.get(ip):
            host_names[ip] = nm
    cert_by = _testssl_issues_by_hostport(outdir)
    dirs_by, files_by = _ffuf_ferox_by_hostport(outdir)
    nuclei_by = _nuclei_by_hostport(outdir)

    # C1: FQDN<->IP alias map. The per-hostport dicts above are keyed by the URL
    # HOSTNAME (often an FQDN — ffuf/ferox/nuclei/testssl fuzz FQDN vhosts), but
    # the grid rows are keyed by the nmap IP. Without this, FQDN-fuzzed hosts show
    # blank Directories/Files/Nuclei/Certificate cells. Build ip -> {fqdns}.
    # PRIMARY source (WebGet rework): results.tsv, WebGet's IP-keyed table where
    # each row is `<ip>\t<fqdn1>\t<fqdn2>...` (its "first tab" — better FQDN<->IP
    # assignment). FALLBACK: fqdn_resolve's fqdn_pairs.json (legacy / when WebGet
    # didn't run). WebGet may tag names ptr=/sub= (with --tag); strip those.
    fqdn_by_ip = defaultdict(set)
    _rt = Path(outdir) / "results.tsv"
    if _rt.is_file():
        try:
            for _ln in _rt.read_text(errors="replace").splitlines():
                _cols = [c.strip() for c in _ln.split("\t") if c.strip()]
                if len(_cols) < 2:
                    continue
                _ip = _cols[0]
                for _name in _cols[1:]:
                    # strip optional ptr=/sub= tags and the NO_PTR marker
                    _n = _name.split("=", 1)[1] if _name.startswith(("ptr=", "sub=")) else _name
                    if _n and _n != "NO_PTR" and "." in _n:
                        fqdn_by_ip[_ip].add(_n)
        except Exception:  # noqa: BLE001
            pass
    if not fqdn_by_ip:
        try:
            _pj = Path(outdir) / "fqdn_pairs.json"
            if _pj.is_file():
                _d = json.loads(_pj.read_text())
                for _k in ("confirmed_1to1", "confirmed_multi"):
                    for _p in (_d.get(_k, []) or []):
                        _ip = str(_p.get("ip", "")).strip()
                        _fq = str(_p.get("fqdn", "")).strip()
                        if _ip and _fq:
                            fqdn_by_ip[_ip].add(_fq)
        except Exception:  # noqa: BLE001
            pass

    # Item 7: honeypot IPs (full-scanned, but tagged so the analyst can strike them)
    honeypot_ips = set()
    try:
        _hp = Path(outdir) / "honeypots.txt"
        if _hp.is_file():
            honeypot_ips = {ln.split()[0].strip() for ln in
                            _hp.read_text(errors="replace").splitlines() if ln.strip()}
    except Exception:  # noqa: BLE001
        pass

    # Item 7: shodan-confirmed ports (shodan_enrichment.csv: IP, Ports, ...)
    shodan_ports = set()
    try:
        import csv as _csv2
        _sp = Path(outdir) / "shodan_enrichment.csv"
        if _sp.is_file():
            with open(_sp, newline="", errors="replace") as _fh:
                _rd = _csv2.reader(_fh)
                _hdr = next(_rd, None) or []
                _hl = [h.lower() for h in _hdr]
                _ii = _hl.index("ip") if "ip" in _hl else 0
                _pi = _hl.index("ports") if "ports" in _hl else 1
                for _rr in _rd:
                    if len(_rr) <= max(_ii, _pi):
                        continue
                    _ipv = _rr[_ii].strip()
                    for _pv in str(_rr[_pi]).split(","):
                        _pv = _pv.strip()
                        if _pv.isdigit():
                            shodan_ports.add((_ipv, int(_pv)))
    except Exception:  # noqa: BLE001
        pass

    def _svc_cell(ip, port, base):
        """Service cell + Item-7 tags: falsepositive (Nessus '?' unconfirmed by
        nmap AND shodan) and/or likely-filtered honeypot."""
        key = (ip, int(port))
        out = base
        if key in uncertain_ports and key not in nmap_ports and key not in shodan_ports:
            out += " — falsepositive"
        if ip in honeypot_ips:
            out += " [likely-filtered/honeypot]"
        return out

    def _multi(d, ip, port):
        """Merge a by-hostport dict across the IP key AND every FQDN alias key."""
        out = []
        for k in [f"{ip}:{port}"] + [f"{fq}:{port}" for fq in fqdn_by_ip.get(ip, ())]:
            out.extend(d.get(k, []) or [])
        return out

    def _domains_for(ip):
        """Domain cell: nmap hostnames + confirmed FQDN aliases, deduped/stacked."""
        seen, out = set(), []
        for part in (host_names.get(ip, "").split(",") if host_names.get(ip) else []):
            part = part.strip()
            if part and part.lower() not in seen:
                seen.add(part.lower()); out.append(part)
        for fq in sorted(fqdn_by_ip.get(ip, ())):
            if fq.lower() not in seen:
                seen.add(fq.lower()); out.append(fq)
        return "\n".join(out)

    headers = ["Domain Name(s)", "IP Addresses", "Port", "Service", "Protocol",
               "Certificate", "shodan.io", "Banners", "URLs", "CVEs", "HSTS",
               "Tech Stack", "Nuclei", "Directories (ffuf && ferox)",
               "DirSearch-Files (ffuf && ferox)", "testssl.sh",
               "Retire.js", "Nessus"]
    ws = wb.create_sheet("Targets")
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)

    def _stack(vals):
        seen, out = set(), []
        for v in vals or []:
            v = str(v).strip()
            if v and v not in seen:
                seen.add(v); out.append(v)
        return "\n".join(out)

    def _ipkey(x):
        parts = x.split(".")
        return [int(o) for o in parts] if len(parts) == 4 and all(o.isdigit() for o in parts) else [0, 0, 0, 0]

    r_i = 2
    for ip in sorted(by_host.keys(), key=_ipkey):
        first = True
        for port in sorted(by_host[ip].keys()):
            row = by_host[ip][port]
            hp = f"{ip}:{port}"
            proto = row.get("tunnel") or "tcp"
            vals = {1: _domains_for(ip) if first else "", 2: ip if first else "",
                    3: f"{port}",
                    4: _svc_cell(ip, port, row.get("service", "")),
                    5: proto,
                    6: _stack(_multi(nessus_cert_by, ip, port)), 7: "", 8: row.get("banner", ""),
                    9: row.get("resolved_url", ""), 10: "",
                    11: _stack(_multi(nessus_hsts_by, ip, port)),
                    12: row.get("cpe", ""), 13: _stack(_multi(nuclei_by, ip, port)),
                    14: _stack(_multi(dirs_by, ip, port)), 15: _stack(_multi(files_by, ip, port)),
                    16: _stack(_multi(cert_by, ip, port)), 17: "",
                    18: _stack(_multi(nessus_all_by, ip, port)) or ("yes" if row.get("_nessus") else "")}
            for c, v in vals.items():
                cell = ws.cell(row=r_i, column=c, value=v)
                cell.font = BODY_FONT
                cell.alignment = Alignment(vertical="top", wrap_text=True)
            r_i += 1
            first = False
    widths = {1: 28, 2: 16, 3: 8, 4: 12, 5: 9, 6: 30, 7: 16, 8: 30, 9: 30,
              10: 20, 11: 8, 12: 24, 13: 30, 14: 34, 15: 34, 16: 30, 17: 20, 18: 10}
    for c, w in widths.items():
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    ws.freeze_panes = "A2"


# Nessus plugin-ID map (operator-curated; keyword/family fallback covers the rest).
_HSTS_IDS = {"142960"}
_CERT_TLS_IDS = {"104743", "157288", "57582", "51192", "69551"}
_NESSUS_FIND_RE = None  # compiled lazily below


def _nessus_all_by_hostport(rich: dict) -> dict:
    """B4: EVERY Nessus finding per ip:port as 'Plugin Name [pluginID]' (incl. the
    cert + HSTS ones — intentional duplication with their dedicated columns)."""
    import re
    pat = re.compile(r"^\[[A-Z]+ (\d+)\]\s+-[^-]*-\s+(\d+)\s+(.*)$")
    out: dict = {}
    for _ip, host in (rich or {}).items():
        for (proto, port), pd in (host.get("ports", {}) or {}).items():
            for f in (pd.get("findings", []) or []):
                m = pat.match(str(f).strip())
                if m:
                    fport, pid, pname = m.group(1), m.group(2), m.group(3).strip()
                    label = f"{pname} [{pid}]"
                    key = f"{_ip}:{fport}"
                else:
                    label = str(f).strip()
                    key = f"{_ip}:{port}"
                bucket = out.setdefault(key, [])
                if label and label not in bucket:
                    bucket.append(label)
    return out


def _nessus_hsts_by_hostport(rich: dict) -> dict:
    """B4: HSTS-missing per ip:port (plugin 142960 or 'HSTS' in the name)."""
    import re
    pat = re.compile(r"^\[[A-Z]+ (\d+)\]\s+-[^-]*-\s+(\d+)\s+(.*)$")
    out: dict = {}
    for _ip, host in (rich or {}).items():
        for (proto, port), pd in (host.get("ports", {}) or {}).items():
            for f in (pd.get("findings", []) or []):
                m = pat.match(str(f).strip())
                if not m:
                    continue
                fport, pid, pname = m.group(1), m.group(2), m.group(3).strip()
                if pid in _HSTS_IDS or "hsts" in pname.lower():
                    key = f"{_ip}:{fport}"
                    if "Missing" not in out.setdefault(key, []):
                        out[key].append("Missing")
    return out


def _nessus_cert_by_hostport(rich: dict) -> dict:
    """Cert/TLS findings per 'ip:port' for the Targets grid Certificate column.
    Covers cert-object issues (expiry, self-signed, cannot-be-trusted, chain) AND
    weak-protocol / cipher findings that are really cert/TLS-config problems:
    SWEET32, TLS 1.0/1.1, SSLv2/3, RC4, medium-strength ciphers, POODLE/BEAST/etc.

    Sourced from each port's severity>0 findings (informational SSL/TLS
    enumerations carry severity 0 and are never recorded, so they can't leak in).
    Each entry is 'Plugin Name [pluginID]', matching how Nessus labels it."""
    import re
    _KW = ("certificate", "self-signed", "self signed", "ssl", "tls",
           "sweet32", "cipher", "poodle", "beast", "drown", "logjam",
           "freak", "rc4", "robot")
    # finding string format: "[TCP 443] -High- 42873 SSL ... (SWEET32)"
    _pat = re.compile(r"^\[[A-Z]+ (\d+)\]\s+-[^-]*-\s+(\d+)\s+(.*)$")
    out: dict = {}
    for _ip, host in (rich or {}).items():
        for (proto, port), pd in (host.get("ports", {}) or {}).items():
            for f in (pd.get("findings", []) or []):
                m = _pat.match(str(f).strip())
                if m:
                    fport, pid, pname = m.group(1), m.group(2), m.group(3).strip()
                else:
                    fport, pid, pname = str(port), "", str(f).strip()
                low = pname.lower()
                if pid not in _CERT_TLS_IDS and not any(k in low for k in _KW):
                    continue
                label = f"{pname} [{pid}]" if pid else pname
                key = f"{_ip}:{fport}"
                bucket = out.setdefault(key, [])
                if label not in bucket:
                    bucket.append(label)
    return out


def _testssl_issues_by_hostport(outdir):
    from pathlib import Path
    out = {}
    for p in Path(outdir).glob("testssl_*.json"):
        try:
            data = json.loads(p.read_text(errors="replace"))
        except (ValueError, OSError):
            continue
        findings = data if isinstance(data, list) else data.get("scanResult", [])
        for item in (findings or []):
            fid = str(item.get("id", "")).lower()
            sev = str(item.get("severity", "")).upper()
            fin = str(item.get("finding", ""))
            tgt = item.get("ip", "") or item.get("target", "")
            port = item.get("port", "")
            if not tgt or not port:
                continue
            hp = f"{tgt}:{port}"
            flag = None
            if "trust" in fid or "chain" in fid:
                flag = f"trust/chain: {fin}"
            elif "expire" in fid or "expiration" in fid:
                flag = f"expiry: {fin}"
            elif "selfsigned" in fid or "self signed" in fin.lower():
                flag = "self-signed certificate"
            elif ("algorithm" in fid or "sig" in fid) and (sev in ("HIGH", "CRITICAL") or "weak" in fin.lower()):
                flag = f"weak signing: {fin}"
            elif sev in ("HIGH", "CRITICAL") and "cert" in fid:
                flag = f"{fid}: {fin}"
            if flag:
                out.setdefault(hp, []).append(flag)
    return out


def _ffuf_ferox_rows(outdir):
    """B1: status-aware parse of ffuf/feroxbuster output. Returns a list of
    {host, port, url, status, tool} for EVERY hit. Parses structured fields
    (ffuf results[].url/.status; feroxbuster JSON-lines url/status) instead of
    regex-grepping URLs — so it carries the status code AND never picks up the
    ffuf commandline / FUZZ-template URL. Feeds both the 200-only Targets columns
    and the raw audit tabs."""
    from pathlib import Path
    from urllib.parse import urlsplit
    rows = []

    def _hp(url):
        try:
            parts = urlsplit(url)
        except ValueError:
            return None, None
        host = parts.hostname or ""
        try:
            port = parts.port
        except ValueError:
            port = None
        if not port:
            port = 443 if parts.scheme == "https" else 80
        return host, port

    # ffuf: ffuf_*.json -> {"results": [{"url":.., "status":..}, ...]}
    for p in Path(outdir).glob("ffuf_*.json"):
        try:
            data = json.loads(p.read_text(errors="replace"))
        except (ValueError, OSError):
            continue
        for r in (data.get("results", []) if isinstance(data, dict) else []):
            url = str(r.get("url", "")).strip()
            if not url:
                continue
            host, port = _hp(url)
            if not host:
                continue
            try:
                status = int(r.get("status", 0) or 0)
            except (TypeError, ValueError):
                status = 0
            rows.append({"host": host, "port": port, "url": url,
                         "status": status, "tool": "ffuf"})

    # feroxbuster: feroxbuster_*.json -> JSON-lines, type=="response"
    for p in Path(outdir).glob("feroxbuster_*.json"):
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        for ln in text.splitlines():
            ln = ln.strip()
            if not ln or '"response"' not in ln:
                continue
            try:
                o = json.loads(ln)
            except ValueError:
                continue
            if o.get("type") != "response":
                continue
            url = str(o.get("url", "")).strip()
            if not url:
                continue
            host, port = _hp(url)
            if not host:
                continue
            try:
                status = int(o.get("status", 0) or 0)
            except (TypeError, ValueError):
                status = 0
            rows.append({"host": host, "port": port, "url": url,
                         "status": status, "tool": "feroxbuster"})
    return rows


def _ffuf_ferox_by_hostport(outdir):
    """B2: Targets-grid Directories/Files, keyed host:port, 200-ONLY. Directory
    vs file split by whether the last path segment has an extension. Only 200s
    reach the Targets page; the raw tabs carry the full captured set."""
    from urllib.parse import urlsplit
    dirs, files = {}, {}
    for r in _ffuf_ferox_rows(outdir):
        if r["status"] != 200:
            continue
        hp = f'{r["host"]}:{r["port"]}'
        path = urlsplit(r["url"]).path or "/"
        bucket = files if ("." in path.rsplit("/", 1)[-1]) else dirs
        b = bucket.setdefault(hp, [])
        if r["url"] not in b:
            b.append(r["url"])
    return dirs, files


def _add_hits_sheet(wb, outdir, title, tool=None, status_only=None):
    """B3: raw/concise ffuf|feroxbuster hits tab. Single tab with a Host column,
    sorted by status (200 first, up to 500) so the useful groups scroll to the
    top. tool=None -> both tools; status_only=200 -> concise 200-only view.
    Returns True if the sheet was added."""
    rows = _ffuf_ferox_rows(outdir)
    if tool:
        rows = [r for r in rows if r["tool"] == tool]
    if status_only is not None:
        rows = [r for r in rows if r["status"] == status_only]
    if not rows:
        return False
    # Dedup identical hits. _ffuf_ferox_rows globs every ffuf_*.json /
    # feroxbuster_*.json in the folder; a re-run (or the ffuf->ferox roots+dirs
    # handoff) can leave more than one file reporting the same URL, which showed
    # up as duplicate rows in the raw tab. Key on the full identity of a hit so
    # genuinely distinct rows survive but exact repeats collapse.
    _seen, _uniq = set(), []
    for r in rows:
        k = (r["tool"], r["host"], r["port"], r["status"], r["url"])
        if k not in _seen:
            _seen.add(k)
            _uniq.append(r)
    rows = _uniq
    # sort by status ascending (200 first), then host, then url
    rows.sort(key=lambda r: (r["status"] if r["status"] else 9999, r["host"], r["url"]))
    ws = wb.create_sheet(title[:31])
    for c, h in enumerate(["Host", "Port", "Status", "URL", "Tool"], 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
    for i, r in enumerate(rows, 2):
        ws.cell(row=i, column=1, value=r["host"])
        ws.cell(row=i, column=2, value=r["port"])
        ws.cell(row=i, column=3, value=r["status"])
        ws.cell(row=i, column=4, value=r["url"])
        ws.cell(row=i, column=5, value=r["tool"])
    for c, w in {1: 30, 2: 8, 3: 8, 4: 80, 5: 12}.items():
        ws.column_dimensions[chr(64 + c)].width = w
    return True


def add_ffuf_raw_sheet(wb, outdir):
    """ffuf raw audit tab: every ffuf hit (all captured codes), status-sorted."""
    return _add_hits_sheet(wb, outdir, "ffuf (raw)", tool="ffuf")


def add_feroxbuster_raw_sheet(wb, outdir):
    """feroxbuster raw audit tab: every ferox hit (all captured codes), status-sorted."""
    return _add_hits_sheet(wb, outdir, "feroxbuster (raw)", tool="feroxbuster")


def add_feroxbuster_concise_sheet(wb, outdir):
    """feroxbuster concise tab: 200 responses only (the 'confirmed live' view)."""
    return _add_hits_sheet(wb, outdir, "feroxbuster (200s)", tool="feroxbuster", status_only=200)


# --- C2: disk-reading wrappers so live-state tabs fold into the final report ---
def _nessus_rich_from_disk(outdir):
    """Reconstruct the Nessus 'rich' parse from disk at report time. {} if none."""
    from pathlib import Path
    try:
        from . import nessus_import, runmode
        nfiles = list(runmode.answer("nessus_files", []) or []) or \
            [str(p) for p in Path(outdir).rglob("*.nessus")]
        if not nfiles:
            return {}
        return (nessus_import.load_multi(nfiles) if len(nfiles) > 1
                else nessus_import.load(nfiles[0]))
    except Exception:  # noqa: BLE001
        return {}


def add_severity_matrix_sheet_from_disk(wb, outdir):
    rich = _nessus_rich_from_disk(outdir)
    if not rich:
        return False
    return add_severity_matrix_sheet(wb, rich)


def add_nessus_vs_nmap_sheet_from_disk(wb, outdir):
    from pathlib import Path
    rich = _nessus_rich_from_disk(outdir)
    if not rich:
        return False
    nmap_results = {}
    rj = Path(outdir) / "results.json"
    if rj.exists():
        try:
            nmap_results = json.loads(rj.read_text())
        except Exception:  # noqa: BLE001
            nmap_results = {}
    return add_nessus_vs_nmap_sheet(wb, nmap_results, rich, nessus_used=True)


def add_secrets_sheet(wb, outdir):
    """R-1: trufflehog secrets -> parsed Secrets tab (was raw-only). Verified
    first. Columns: Detector, Verified, Source, Secret (redacted)."""
    from pathlib import Path
    rows = []
    for p in Path(outdir).glob("trufflehog_*.jsonl"):
        try:
            text = p.read_text(errors="replace")
        except OSError:
            continue
        for ln in text.splitlines():
            ln = ln.strip()
            if not ln.startswith("{"):
                continue
            try:
                o = json.loads(ln)
            except ValueError:
                continue
            det = o.get("DetectorName") or o.get("detector_name") or ""
            if not det:
                continue
            ver = "yes" if o.get("Verified") else ""
            red = o.get("Redacted") or o.get("Raw") or ""
            src = ""
            meta = (o.get("SourceMetadata") or {}).get("Data") or {}
            for k in ("Git", "Github", "Filesystem", "Gitlab"):
                d = meta.get(k) or {}
                if d:
                    src = d.get("repository") or d.get("file") or d.get("link") or str(d)
                    break
            rows.append((str(det), ver, str(src)[:120], str(red)[:200]))
    if not rows:
        return False
    rows.sort(key=lambda r: (r[1] != "yes", r[0]))
    ws = wb.create_sheet("Secrets")
    for c, h in enumerate(["Detector", "Verified", "Source", "Secret (redacted)"], 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
    for i, r in enumerate(rows, 2):
        for c, v in enumerate(r, 1):
            ws.cell(row=i, column=c, value=v)
    for c, w in {1: 20, 2: 10, 3: 50, 4: 60}.items():
        ws.column_dimensions[chr(64 + c)].width = w
    return True


def add_linkthief_emails_sheet(wb, outdir, spray_domains=None):
    """R-2: LinkThief (emailenum) GUESSED emails -> parsed tab (was raw-only).

    Filtered to the spray domain(s) — the same @domain filter the spray-list tab
    uses — so this sheet shows only the addresses that actually make it into the
    spray set, not every guessed address across every domain. With no
    spray_domains given, falls back to showing all guessed addresses (unfiltered),
    matching collect_spray's own no-domain behavior.
    """
    from pathlib import Path
    import csv as _csv
    doms = [d.strip().lstrip("@").lower()
            for d in (spray_domains or []) if d and d.strip()]
    suffixes = tuple("@" + d for d in doms)
    rows = []
    for p in Path(outdir).glob("linkthief_*.csv"):
        try:
            with open(p, newline="") as fh:
                for r in _csv.DictReader(fh):
                    em = (r.get("attempted_email") or "").strip().lower()
                    if "@" not in em:
                        continue
                    # only keep addresses on a spray domain (if any given)
                    if suffixes and not em.endswith(suffixes):
                        continue
                    cat = (r.get("category") or "").strip()
                    name = " ".join(x for x in [(r.get("first") or "").strip(),
                                                (r.get("last") or "").strip()] if x)
                    rows.append((em, cat, name))
        except OSError:
            continue
    if not rows:
        return False
    seen, uniq = set(), []
    for r in rows:
        if r[0] not in seen:
            seen.add(r[0]); uniq.append(r)
    uniq.sort(key=lambda r: r[0])
    ws = wb.create_sheet("LinkThief Emails")
    for c, h in enumerate(["Email (guessed)", "Category", "Name"], 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
    for i, r in enumerate(uniq, 2):
        for c, v in enumerate(r, 1):
            ws.cell(row=i, column=c, value=v)
    for c, w in {1: 40, 2: 16, 3: 30}.items():
        ws.column_dimensions[chr(64 + c)].width = w
    return True


def add_cloud_assets_sheet(wb, outdir):
    """R-3: wire cloud_enum.parse_findings (it existed but was never called) into
    a Cloud Assets tab: [provider, status, url/detail] rows."""
    try:
        from . import cloud_enum
        findings = cloud_enum.parse_findings(outdir)
    except Exception:  # noqa: BLE001
        return False
    if not findings:
        return False
    ws = wb.create_sheet("Cloud Assets")
    for c, h in enumerate(["Provider", "Status", "URL / Detail"], 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
    for i, row in enumerate(findings, 2):
        for c, v in enumerate(list(row)[:3], 1):
            ws.cell(row=i, column=c, value=v)
    for c, w in {1: 14, 2: 12, 3: 90}.items():
        ws.column_dimensions[chr(64 + c)].width = w
    return True


def add_live_urls_sheet_from_disk(wb, outdir):
    from pathlib import Path
    urls = []
    for p in Path(outdir).glob("*_live_urls.txt"):
        try:
            urls.extend(u.strip() for u in p.read_text(errors="replace").splitlines()
                        if u.strip())
        except OSError:
            continue
    urls = list(dict.fromkeys(urls))
    if not urls:
        return False
    return add_live_urls_sheet(wb, urls)


def _nuclei_by_hostport(outdir):
    from pathlib import Path
    from urllib.parse import urlsplit
    out = {}
    for p in list(Path(outdir).glob("nuclei*.jsonl")) + list(Path(outdir).glob("nuclei*.json")):
        try:
            for line in p.read_text(errors="replace").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    o = json.loads(line)
                except ValueError:
                    continue
                url = o.get("matched-at") or o.get("host") or ""
                info = o.get("info", {}) or {}
                name = info.get("name", "") or o.get("template-id", "")
                sev = (info.get("severity", "") or "").upper()
                try:
                    parts = urlsplit(url if "://" in url else f"http://{url}")
                    host = parts.hostname or url
                    port = parts.port or (443 if parts.scheme == "https" else 80)
                except ValueError:
                    continue
                hp = f"{host}:{port}"
                out.setdefault(hp, []).append(f"[{sev}] {name}")
        except OSError:
            continue
    return out



def add_manual_retest_sheet(wb, outdir):
    """Manual Re-Test (Failed/Errored/Cancelled commands): one place listing every
    target/command that did NOT complete cleanly, grouped by tool, so the analyst
    can re-run them by hand. Pulls: per-tool skip files (ffuf_skipped_dead.txt,
    ffuf_rate_limited.txt, feroxbuster_*), and <tool>_errors.txt across all tools."""
    from pathlib import Path
    outdir = Path(outdir)
    # tool -> list of (reason, detail) lines
    sections = {}

    def _add(tool, reason, lines):
        if not lines:
            return
        sections.setdefault(tool, [])
        sections[tool].append((reason, [l for l in lines if l.strip()]))

    # ffuf / feroxbuster skip + rate-limit files
    fmap = {
        "ffuf_skipped_dead.txt": ("ffuf", "skipped — no response (dead/rate-limited)"),
        "ffuf_rate_limited.txt": ("ffuf", "cancelled — strong rate limiting"),
        "feroxbuster_skipped.txt": ("feroxbuster", "skipped"),
        "feroxbuster_rate_limited.txt": ("feroxbuster", "cancelled — rate limiting"),
    }
    for fname, (tool, reason) in fmap.items():
        p = outdir / fname
        if p.is_file():
            try:
                _add(tool, reason, p.read_text(errors="replace").splitlines())
            except OSError:
                pass

    # every <tool>_errors.txt -> that tool's error section
    for p in sorted(outdir.glob("*_errors.txt")):
        tool = p.stem.replace("_errors", "")
        try:
            _add(tool, "errors (did-not-complete / completed-with-error)",
                 p.read_text(errors="replace").splitlines())
        except OSError:
            pass

    if not sections:
        return

    ws = wb.create_sheet("Manual Re-Test")
    title = ws.cell(row=1, column=1,
                    value="Manual Re-Test (Failed/Errored/Cancelled commands) — "
                          "re-run these by hand")
    title.font = HEADER_FONT
    title.fill = HEADER_FILL
    r = 3
    for tool in sorted(sections.keys()):
        tcell = ws.cell(row=r, column=1, value=f"=== {tool} ===")
        tcell.font = HEADER_FONT
        r += 1
        for reason, lines in sections[tool]:
            ws.cell(row=r, column=1, value=f"  [{reason}]").font = BODY_FONT
            r += 1
            for ln in lines:
                ws.cell(row=r, column=1, value=f"    {ln}").font = BODY_FONT
                r += 1
            r += 1   # blank between reason blocks
        r += 1       # blank between tools
    ws.column_dimensions["A"].width = 110



def add_analyst_synthesis_sheets(wb, outdir):
    """Five analyst-facing synthesis tabs that cross-reference the ENTIRE scan to
    surface the highest-value intelligence. Built by the tool as a working aid.

    1. Attack Surface Heatmap  — hosts ranked by exposure score
    2. Quick Wins              — 403-bypass candidates, login portals, takeovers
    3. Exposure & Credentials  — secrets, emails, leaks by host
    4. Tech Stack Rollup       — software/versions across the estate (patch targets)
    5. Coverage & Confidence   — what got scanned vs skipped/rate-limited
    """
    from pathlib import Path
    from collections import defaultdict
    outdir = Path(outdir)

    hosts = load_hosts(outdir) if (outdir / "results.json").exists() else []
    # ---- gather signals per host ----
    open_ports = defaultdict(set)
    services = defaultdict(set)
    for r in hosts:
        open_ports[r["ip"]].add(r["port"])
        if r.get("service"):
            services[r["ip"]].add(f"{r['port']}/{r['service']}")

    nuclei_by = {}
    try:
        nuclei_by = _nuclei_by_hostport(outdir)
    except Exception:
        pass
    sev_weight = {"CRITICAL": 10, "HIGH": 6, "MEDIUM": 3, "LOW": 1, "INFO": 0}

    # ===== TAB 1: Attack Surface Heatmap =====
    ws = wb.create_sheet("⚑ Attack Surface")
    ws.append(["Host / IP", "Open Ports", "Services", "Nuclei (weighted)",
               "Exposure Score", "Alive?"])
    for c in range(1, 7):
        ws.cell(row=1, column=c).font = HEADER_FONT
        ws.cell(row=1, column=c).fill = HEADER_FILL
    scored = []
    for ip in open_ports:
        ports = open_ports[ip]
        nscore = 0
        for hp, findings in nuclei_by.items():
            if hp.startswith(ip + ":"):
                for f in findings:
                    sev = f.split("]")[0].strip("[") if "]" in f else ""
                    nscore += sev_weight.get(sev.upper(), 0)
        exposure = len(ports) * 2 + nscore
        scored.append((exposure, ip, ports, nscore))
    scored.sort(reverse=True)
    for exposure, ip, ports, nscore in scored:
        ws.append([ip, ", ".join(str(p) for p in sorted(ports)),
                   ", ".join(sorted(services.get(ip, []))), nscore,
                   exposure, "yes" if ports else "no"])
    for col, w in zip("ABCDEF", (24, 26, 40, 16, 14, 8)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"

    # ===== (Quick Wins tab removed) =====
    # The old "⚑ Quick Wins" tab globbed *takeover*.txt (the takeover TARGET lists)
    # and mislabeled every candidate as a finding. It's been merged into the report's
    # "Findings" tab: CVSS-scored findings on top, then confirmed takeovers (from
    # parse_takeover), login portals, and 403 bypasses beneath.

    # ===== TAB 3: Exposure & Credentials =====
    ws3 = wb.create_sheet("⚑ Exposure & Creds")
    ws3.append(["Type", "Value / Host", "Source"])
    for c in range(1, 4):
        ws3.cell(row=1, column=c).font = HEADER_FONT
        ws3.cell(row=1, column=c).fill = HEADER_FILL
    for patt, label in (("*secret*.txt", "Secret"), ("*jsluice_secrets*", "JS Secret"),
                        ("trufflehog*", "Trufflehog"), ("gitleaks*", "Gitleaks"),
                        ("dehashed*", "Breach Cred")):
        for p in outdir.glob(patt):
            try:
                n = 0
                for ln in p.read_text(errors="replace").splitlines():
                    if ln.strip() and n < 200:
                        ws3.append([label, ln.strip()[:120], p.name]); n += 1
            except OSError:
                pass
    if ws3.max_row == 1:
        ws3.append(["(none found)", "", ""])
    for col, w in zip("ABC", (18, 70, 30)):
        ws3.column_dimensions[col].width = w
    ws3.freeze_panes = "A2"

    # ===== TAB 4: Tech Stack Rollup (by HOST, with VERSION + SOURCE) =====
    ws4 = wb.create_sheet("⚑ Tech Stack Rollup")
    ws4.append(["Host", "Technology", "Version", "Source"])
    for c in range(1, 5):
        ws4.cell(row=1, column=c).font = HEADER_FONT
        ws4.cell(row=1, column=c).fill = HEADER_FILL
    # gather per-host tech with version + where it was seen
    rows_out = []  # (host, tech, version, source)
    import re as _re
    for r in hosts:
        host = r.get("hostnames") or r.get("ip") or ""
        # from CPE (cpe:/a:vendor:product:version)
        for cpe in (r.get("cpe") or "").split(","):
            cpe = cpe.strip()
            if not cpe:
                continue
            parts = cpe.replace("cpe:/", "").replace("cpe:2.3:", "").split(":")
            prod = parts[2] if len(parts) > 2 else cpe
            ver = parts[3] if len(parts) > 3 else ""
            rows_out.append((host, prod, ver, "nmap/CPE"))
        # from banner (e.g. "nginx/1.18.0")
        ban = r.get("banner") or ""
        m = _re.search(r"([A-Za-z][\w\-]+)[/ ]v?(\d+[\w.\-]*)", ban)
        if m:
            rows_out.append((host, m.group(1), m.group(2), "banner"))
        elif ban:
            rows_out.append((host, ban[:40], "", "banner"))
    # httpx tech (from httpx_output.jsonl if present)
    hp = outdir / "httpx_output.jsonl"
    if hp.exists():
        try:
            for line in hp.read_text(errors="replace").splitlines():
                try:
                    o = json.loads(line)
                except ValueError:
                    continue
                host = o.get("input") or o.get("host") or o.get("url", "")
                for t in (o.get("tech") or o.get("technologies") or []):
                    tm = _re.match(r"(.+?)[: ]v?(\d[\w.\-]*)$", str(t))
                    if tm:
                        rows_out.append((host, tm.group(1), tm.group(2), "httpx"))
                    else:
                        rows_out.append((host, str(t), "", "httpx"))
        except OSError:
            pass
    # dedupe + sort by host then tech
    seen = set()
    for host, tech, ver, src in sorted(rows_out):
        key = (host, tech.lower(), ver)
        if key in seen:
            continue
        seen.add(key)
        ws4.append([host, tech, ver, src])
    if ws4.max_row == 1:
        ws4.append(["(none parsed)", "", "", ""])
    for col, w in zip("ABCD", (30, 34, 16, 14)):
        ws4.column_dimensions[col].width = w
    ws4.freeze_panes = "A2"

    # ===== TAB 5: Coverage & Confidence =====
    ws5 = wb.create_sheet("⚑ Coverage & Confidence")
    ws5.append(["Metric", "Value"])
    for c in range(1, 3):
        ws5.cell(row=1, column=c).font = HEADER_FONT
        ws5.cell(row=1, column=c).fill = HEADER_FILL
    n_hosts = len(open_ports)
    n_skipped = 0
    for sf in ("ffuf_skipped_dead.txt", "ffuf_rate_limited.txt"):
        p = outdir / sf
        if p.is_file():
            n_skipped += len([l for l in p.read_text(errors="replace").splitlines() if l.strip()])
    n_errors = len(list(outdir.glob("*_errors.txt")))
    ws5.append(["Hosts with open ports", n_hosts])
    ws5.append(["Targets skipped/rate-limited (ffuf)", n_skipped])
    ws5.append(["Tools that logged errors", n_errors])
    ws5.append(["Nuclei hosts with findings", len(set(hp.split(":")[0] for hp in nuclei_by))])
    ws5.append(["Note", "Skipped/errored items are in the Manual Re-Test tab"])
    for col, w in zip("AB", (40, 50)):
        ws5.column_dimensions[col].width = w


def add_nuclei_by_host_sheet(wb, outdir):
    """nuclei RAW results organized by host, with 2 blank rows separating each
    host block — so all the raw nuclei findings can be read in one place, grouped."""
    from pathlib import Path
    from collections import defaultdict
    outdir = Path(outdir)
    by_host = defaultdict(list)
    for p in list(outdir.glob("nuclei*.jsonl")) + list(outdir.glob("nuclei*.json")):
        try:
            for line in p.read_text(errors="replace").splitlines():
                line = line.strip()
                if not line:
                    continue
                try:
                    o = json.loads(line)
                except ValueError:
                    continue
                host = o.get("host") or o.get("matched-at") or "(unknown)"
                info = o.get("info", {}) or {}
                name = info.get("name", "") or o.get("template-id", "")
                sev = (info.get("severity", "") or "").upper()
                matched = o.get("matched-at", "")
                by_host[host].append((sev, name, matched))
        except OSError:
            continue
    if not by_host:
        return
    ws = wb.create_sheet("nuclei")
    for c, h in enumerate(["Host", "Severity", "Finding", "Matched At"], 1):
        cell = ws.cell(row=1, column=c, value=h)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
    r = 2
    _sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4, "": 5}
    for host in sorted(by_host):
        findings = sorted(by_host[host], key=lambda x: _sev_rank.get(x[0], 9))
        for sev, name, matched in findings:
            ws.cell(row=r, column=1, value=host).font = BODY_FONT
            ws.cell(row=r, column=2, value=sev).font = BODY_FONT
            ws.cell(row=r, column=3, value=name).font = BODY_FONT
            ws.cell(row=r, column=4, value=matched).font = BODY_FONT
            r += 1
        r += 2   # TWO blank rows between hosts
    for col, w in zip("ABCD", (34, 12, 50, 50)):
        ws.column_dimensions[col].width = w
    ws.freeze_panes = "A2"


def add_scan_summary_sheet(wb, outdir):
    """Add a 'Scan Summary' sheet to an existing workbook from phase-0 output."""
    outdir = Path(outdir)
    rows = load_hosts(outdir)
    ntally = nuclei_tally(outdir)
    ttally = testssl_tally(outdir)
    snsf = sns_flags(outdir)

    headers = (["IP", "Port", "Service", "Banner", "Resolved URL",
                "OS", "CPE", "TLS", "IIS (nmap)", "Hostnames (subdomains)"]
               + [s.capitalize() for s in NUCLEI_SEVERITIES]
               + [label for _, label in TESTSSL_VULNS]
               + ["IIS ShortName (SNS)"])

    ws = wb.create_sheet("Scan Summary")
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = "F2"   # keep IP/Port/Service/Banner/URL visible while scrolling

    for r in rows:
        key = (r["ip"], r["port"])
        nt = ntally.get(key, {})
        # testssl: match by ip:port; if resolved_url host differs, also try hostname
        tt = ttally.get(key, {})
        if not tt and r["resolved_url"]:
            h = urlparse(r["resolved_url"]).hostname or ""
            tt = ttally.get((h, r["port"]), {})

        row = [r["ip"], r["port"], r["service"], r["banner"], r["resolved_url"],
               r.get("os", ""), r.get("cpe", ""),
               "ssl" if r.get("tunnel") == "ssl" else "", r.get("iis", ""),
               r.get("hostnames", "")]
        row += [nt.get(s, 0) or "" for s in NUCLEI_SEVERITIES]
        row += [tt.get(label, 0) or "" for _, label in TESTSSL_VULNS]
        # SNS: Y if vulnerable, blank otherwise. Match by ip:port, then by
        # resolved-url host:port if the host form differs.
        sns_v = snsf.get(key)
        if sns_v is None and r["resolved_url"]:
            h = urlparse(r["resolved_url"]).hostname or ""
            sns_v = snsf.get((h, r["port"]))
        row += ["Y" if sns_v else ""]
        ws.append(row)

    for rrow in ws.iter_rows(min_row=2):
        for cell in rrow:
            cell.font = BODY_FONT

    # widths: context + HVT columns wider, tally columns narrow
    widths = ([16, 7, 14, 34, 40, 18, 34, 6, 11, 30] + [9] * len(NUCLEI_SEVERITIES)
              + [11] * len(TESTSSL_VULNS) + [18])
    for c, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=c).column_letter].width = w
    return ws


# ---- At a Glance (FunnelWeb actionable-intelligence rollup) ----

# Accent fills for the section headers on the At a Glance tab.
SECTION_FILL = PatternFill("solid", start_color="374151")
SECTION_FONT = Font(name=FONT, size=FONT_SIZE, bold=True, color="FFFFFF")
COUNT_LABEL_FONT = Font(name=FONT, size=FONT_SIZE, bold=True)


def add_at_a_glance_sheet(wb, summaries, outdir=None, spray_domains=None):
    """Add THE single 'At a Glance' tab: a deduplicated, actionable-intelligence
    dashboard. FunnelWeb summaries provide the crawl intel; when `outdir` is
    given, the TOTAL unique email list (all sources incl DeHashed — the Spray
    list) and the deduped file list are folded in too, so At a Glance shows the
    complete, copy-ready unique lists for reporting rather than only FunnelWeb's.
    """
    if summaries is None:
        summaries = []
    if not isinstance(summaries, (list, tuple)):
        summaries = [summaries]

    # ---- merge all summaries into one rollup (dedup across domains) ----
    emails = set()
    files = {}                     # filename -> source url
    secrets_high = []              # (type, value, where)
    secrets_other = 0
    ep_first, ep_third = set(), set()
    jsf_first, jsf_third = set(), set()
    documents = cdn_documents = skipped = 0
    external_documents = 0
    external_doc_list = []
    jsluice_flag = False
    retire_findings, retire_high = [], 0
    domains = []
    # host-attributed views (so the MERGED tab doesn't lose which host a finding
    # came from): each entry carries the crawled host label.
    secrets_by_host = []     # (host, type, value, where)
    emails_by_host = []      # (host, email)

    for s in summaries:
        if s is None:
            continue
        _host = getattr(s, "domain", "") or "?"
        domains.append(_host)
        emails |= s.emails
        for _e in sorted(s.emails):
            emails_by_host.append((_host, _e))
        files.update(s.files)
        secrets_high.extend(s.secrets_high)
        for _sec in s.secrets_high:
            # _sec is (type, value, where); prepend host for the attributed view
            try:
                _t, _v, _w = _sec
            except Exception:  # noqa: BLE001
                _t, _v, _w = ("", str(_sec), "")
            secrets_by_host.append((_host, _t, _v, _w))
        secrets_other += s.secrets_other_count
        ep_first |= s.js_endpoints_first
        ep_third |= s.js_endpoints_third
        jsf_first |= s.js_files_first
        jsf_third |= s.js_files_third
        documents += s.documents
        cdn_documents += s.cdn_documents
        external_documents += getattr(s, "external_documents", 0)
        external_doc_list.extend(getattr(s, "external_doc_list", []) or [])
        skipped += s.skipped_links
        jsluice_flag = jsluice_flag or s.jsluice_secret_flag
        retire_findings.extend(getattr(s, "retire_findings", []) or [])
        retire_high += getattr(s, "retire_high", 0)

    # Fold in the TOTAL unique lists from all tools (not just FunnelWeb) when we
    # have the output dir: the Spray email list (all sources incl DeHashed) and
    # the source-URL-deduped file list. This makes At a Glance the complete,
    # copy-ready unique-list view for reporting.
    if outdir is not None:
        try:
            from . import report as _rep
            _, spray_rows = _rep.collect_spray(outdir, spray_domains=spray_domains)
            for row in spray_rows:
                if row and row[0]:
                    emails.add(row[0].strip().lower())
            _, file_rows = _rep.collect_files(outdir)
            for fr in file_rows:
                # schema: [URL, FileName, ...]; key the listing by filename->URL
                if len(fr) >= 2 and fr[1]:
                    files.setdefault(fr[1], fr[0])
        except Exception:  # noqa: BLE001
            pass

    # sort HIGH secrets by type for stable, scannable output
    secrets_high = sorted(set(secrets_high), key=lambda t: (t[0].lower(), t[1]))

    ws = wb.create_sheet("At a Glance")
    ws.sheet_properties.tabColor = "B91C1C"   # red tab: this is the priority page

    def _section(row, title):
        c = ws.cell(row=row, column=1, value=title)
        c.font = SECTION_FONT
        c.fill = SECTION_FILL
        c.alignment = Alignment(horizontal="left", vertical="center")
        ws.cell(row=row, column=2, value="").fill = SECTION_FILL
        return row + 1

    def _count(row, label, value):
        lc = ws.cell(row=row, column=1, value=label)
        lc.font = COUNT_LABEL_FONT
        vc = ws.cell(row=row, column=2, value=value)
        vc.font = BODY_FONT
        return row + 1

    r = 1
    title = ws.cell(row=r, column=1, value="At a Glance — FunnelWeb actionable intelligence")
    title.font = Font(name=FONT, size=14, bold=True)
    if any(domains):
        ws.cell(row=r, column=4,
                value="domains: " + ", ".join(d for d in domains if d)).font = BODY_FONT
    r += 2

    # ---- 1) count dashboard ----
    r = _section(r, "COUNTS")
    r = _count(r, "Unique Emails", len(emails))
    r = _count(r, "Secrets (HIGH)", len(secrets_high))
    r = _count(r, "Secrets (MED/LOW)", secrets_other)
    r = _count(r, "Documents", documents)
    r = _count(r, "CDN Documents", cdn_documents)
    r = _count(r, "External Docs (off-domain, logged)", external_documents)
    r = _count(r, "JS Endpoints (first-party)", len(ep_first))
    r = _count(r, "JS Endpoints (third-party)", len(ep_third))
    r = _count(r, "JavaScript files (first-party)", len(jsf_first))
    r = _count(r, "JavaScript files (third-party)", len(jsf_third))
    r = _count(r, "Skipped Links", skipped)
    r = _count(r, "Jsluice Secret? (Y/N)", "Y" if jsluice_flag else "N")
    r = _count(r, "Retire.js Findings (vuln JS libs)", len(retire_findings))
    r = _count(r, "Retire.js High/Critical", retire_high)
    r += 1

    # ---- 2) actionable listings ----
    # HIGH secrets first (most actionable)
    r = _section(r, "HIGH-VALUE SECRETS  ([type] value — host — where found)")
    if secrets_by_host:
        # header row for the attributed view
        ws.cell(row=r, column=1, value="Secret").font = Font(name=FONT, size=FONT_SIZE, bold=True)
        ws.cell(row=r, column=2, value="Host").font = Font(name=FONT, size=FONT_SIZE, bold=True)
        ws.cell(row=r, column=3, value="Where").font = Font(name=FONT, size=FONT_SIZE, bold=True)
        r += 1
        for host, stype, value, where in sorted(secrets_by_host,
                                                key=lambda t: (t[0], t[1].lower(), t[2])):
            label = f"{stype}: " if stype else ""
            ws.cell(row=r, column=1, value=f"{label}{value}").font = BODY_FONT
            ws.cell(row=r, column=2, value=host).font = BODY_FONT
            ws.cell(row=r, column=3, value=where).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    # retire.js — vulnerable JS libraries
    r = _section(r, "RETIRE.JS — VULNERABLE JS LIBRARIES  ([sev] component version — advisory)")
    if retire_findings:
        for comp, sev, where, advisory in retire_findings:
            label = f"[{sev}] " if sev else ""
            ws.cell(row=r, column=1, value=f"{label}{comp}").font = BODY_FONT
            ws.cell(row=r, column=3, value=where).font = BODY_FONT
            if advisory:
                ws.cell(row=r, column=4, value=advisory).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    # external documents (off-domain / third-party — logged for audit, not downloaded)
    r = _section(r, "EXTERNAL DOCUMENTS (off-domain/third-party — URL + referring page; NOT downloaded)")
    if external_doc_list:
        for _url, _src in external_doc_list:
            ws.cell(row=r, column=1, value=_url).font = BODY_FONT
            ws.cell(row=r, column=3, value=_src).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    # unique emails
    r = _section(r, "UNIQUE EMAILS")
    if emails:
        for e in sorted(emails):
            ws.cell(row=r, column=1, value=e).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1
    r += 1

    # files
    r = _section(r, "FILES  (name — source URL)")
    if files:
        for name in sorted(files):
            ws.cell(row=r, column=1, value=name).font = BODY_FONT
            ws.cell(row=r, column=3, value=files[name]).font = BODY_FONT
            r += 1
    else:
        ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
        r += 1

    ws.column_dimensions["A"].width = 48
    ws.column_dimensions["B"].width = 14
    ws.column_dimensions["C"].width = 70
    ws.column_dimensions["D"].width = 40
    ws.freeze_panes = "A2"
    return ws


def _fw_raw_sheet_title(label: str, used: set) -> str:
    """Build an Excel-legal, unique sheet title 'FW - <host> (RAW)'.

    Excel caps sheet names at 31 chars and forbids : \\ / ? * [ ]. The host label
    (netloc) can exceed that and contains ':' for ports, so we sanitize + truncate,
    keeping the tail (which carries the port) and de-duplicating collisions.
    """
    host = (label or "host").replace(":", "_")
    for ch in "\\/?*[]":
        host = host.replace(ch, "_")
    prefix, suffix = "FW - ", " (RAW)"
    budget = 31 - len(prefix) - len(suffix)
    if len(host) > budget:
        # keep head + tail so both subdomain and port stay visible
        keep = budget - 1
        head = keep // 2
        tail = keep - head
        host = host[:head] + "~" + host[-tail:]
    title = f"{prefix}{host}{suffix}"
    # ensure uniqueness (multiple long hosts could truncate to the same title)
    base = title
    n = 2
    while title in used:
        tag = f"~{n}"
        title = base[:31 - len(tag)] + tag
        n += 1
    used.add(title)
    return title


def add_funnelweb_raw_sheets(wb, summaries):
    """One 'FW - <host> (RAW)' tab per crawled FunnelWeb target, showing THAT
    host's own findings (attribution preserved). Complements the merged, host-
    labeled At a Glance rollup. No cap: one tab per host, however many.
    """
    if not summaries:
        return
    if not isinstance(summaries, (list, tuple)):
        summaries = [summaries]
    used_titles = set()
    for s in summaries:
        label = getattr(s, "domain", "") or "host"
        ws = wb.create_sheet(_fw_raw_sheet_title(label, used_titles))
        r = 1
        # full host header (the sheet title may be truncated; this is exact)
        hc = ws.cell(row=r, column=1, value=f"FunnelWeb — {label} (raw findings)")
        hc.font = Font(name=FONT, size=13, bold=True)
        r += 2

        def _section(title, rows, cols):
            nonlocal r
            sc = ws.cell(row=r, column=1, value=title)
            sc.font = HEADER_FONT
            sc.fill = HEADER_FILL
            for ci in range(2, max(2, len(cols)) + 1):
                ws.cell(row=r, column=ci, value="").fill = HEADER_FILL
            r += 1
            for ci, cname in enumerate(cols, start=1):
                cc = ws.cell(row=r, column=ci, value=cname)
                cc.font = Font(name=FONT, size=FONT_SIZE, bold=True)
            r += 1
            if not rows:
                ws.cell(row=r, column=1, value="(none)").font = BODY_FONT
                r += 2
                return
            for row in rows:
                for ci, val in enumerate(row, start=1):
                    ws.cell(row=r, column=ci, value=val).font = BODY_FONT
                r += 1
            r += 1

        emails = sorted(getattr(s, "emails", set()) or [])
        _section("EMAILS", [[e] for e in emails], ["Email"])

        secrets = getattr(s, "secrets_high", []) or []
        _section("SECRETS (high)",
                 [[t, v, w] for (t, v, w) in secrets],
                 ["Type", "Value", "Where"])

        retire = getattr(s, "retire_findings", []) or []
        _section("RETIRE.JS (vulnerable libs)",
                 [[cv, sev, f, adv] for (cv, sev, f, adv) in retire],
                 ["Component/Version", "Severity", "File", "Advisory"])

        js_first = sorted(getattr(s, "js_endpoints_first", set()) or [])
        _section("JS ENDPOINTS (first-party)",
                 [[u] for u in js_first], ["Endpoint"])

        files = getattr(s, "files", {}) or {}
        _section("FILES", [[fn, src] for fn, src in sorted(files.items())],
                 ["File", "Source URL"])

        # counts footer
        csec = ws.cell(row=r, column=1, value="COUNTS")
        csec.font = HEADER_FONT
        csec.fill = HEADER_FILL
        r += 1
        for label_, val in (("Emails", len(emails)),
                            ("Secrets (high)", len(secrets)),
                            ("Secrets (other)", getattr(s, "secrets_other_count", 0)),
                            ("Retire.js findings", len(retire)),
                            ("Documents", getattr(s, "documents", 0)),
                            ("JS endpoints (1st)", len(js_first))):
            ws.cell(row=r, column=1, value=label_).font = BODY_FONT
            ws.cell(row=r, column=2, value=val).font = BODY_FONT
            r += 1

        ws.column_dimensions["A"].width = 40
        ws.column_dimensions["B"].width = 50
        ws.column_dimensions["C"].width = 40
        ws.column_dimensions["D"].width = 40
        ws.freeze_panes = "A3"
