"""Subdomain enumeration (passive + verify).

Pipeline, run as a single shell command exactly as the operator specified:

    subfinder -d <domain> | shuffledns -d <domain> -r <resolvers> -mode resolve \
        | dnsx -a -cname -resp

- subfinder: passive subdomain discovery from its API sources (no brute force).
- shuffledns -mode resolve: resolves the discovered names against the resolver
  list, returning only the unique, valid (currently-resolving) ones — this is
  the verification step that drops stale API data.
- dnsx -a -cname -resp: pulls live A and CNAME records for the verified names.

The resolver file path is prompted for at runtime (fresh resolvers matter for
accuracy, so nothing is hardcoded).

This is passive recon: discovered hosts are intel only and are NOT fed into the
active scanning phases.
"""
from __future__ import annotations

import shlex
import shutil
import subprocess
from pathlib import Path


def _prompt_resolvers(default: str = "") -> str:
    """Ask the operator where their resolvers file is. Returns the path.
    Unattended: uses the default (or empty) without blocking."""
    from .runmode import is_unattended
    if is_unattended():
        return default
    try:
        ans = input(f"Path to resolvers file{f' [{default}]' if default else ''}: ").strip()
    except EOFError:
        return default
    return ans or default


def _tools_present(tools=("subfinder", "shuffledns", "dnsx")) -> list[str]:
    """Return any of the given required tools missing from PATH."""
    missing = []
    for t in tools:
        if shutil.which(t) is None:
            missing.append(t)
    return missing


def run_subdomain_enum(domain: str, outdir: Path, command_log: Path,
                       resolvers: str = "", dry_run: bool = False,
                       dnsx_threads: int = 25, dnsx_retries: int = 5,
                       shuffledns_threads: int = 75) -> Path | None:
    """Run subfinder enumeration, then (if resolvers are available) the
    shuffledns|dnsx resolve/enrich stage, for one domain.

    Returns the path to the raw dnsx output file if STAGE 2 ran, else the path to
    subfinder's raw name list (STAGE 1 only), else None on failure.

    IMPORTANT: subfinder (STAGE 1) is passive enumeration and needs NO resolvers —
    it ALWAYS runs and writes subdomains_<domain>.subfinder.txt (which host
    validation consumes). ONLY the resolve/enrich stage (STAGE 2: shuffledns +
    dnsx) needs a resolvers file; if none is available we skip STAGE 2 and return
    the enumerated names, rather than skipping enumeration entirely.

    Thread/retry defaults are deliberately conservative to avoid the dnsx
    "failed to resolve (consider increasing -retry or reducing -threads)" warnings
    that drop live hosts under load: dnsx at 25 threads (vs its ~100 default) with
    5 retries, and shuffledns at 75 (NOT its 1000 default). The 1000 default is
    benchmark-chasing nonsense for public resolvers — Google/Cloudflare rate-limit
    per client IP, so 1000 concurrent queries just generates SERVFAILs and silently
    drops names (fast-but-wrong, the worst outcome for recon). You're bottlenecked
    by RESOLVER capacity, not client concurrency, so past ~50-100 threads you only
    add errors, not speed. 75 keeps it accurate with negligible extra runtime.
    Raise it only on a private/unmetered resolver you control.
    """
    # Resolvers are needed ONLY for STAGE 2. Resolve them now, but do NOT bail if
    # absent — enumeration (STAGE 1) proceeds regardless; STAGE 2 is what's gated.
    if not resolvers:
        resolvers = _prompt_resolvers()
    resolve_ok = bool(resolvers) and (dry_run or Path(resolvers).is_file())
    if not resolve_ok:
        if not resolvers:
            print("[subdomains] no resolvers file — running subfinder enumeration "
                  "only (skipping shuffledns/dnsx resolve stage)")
        else:
            print(f"[subdomains] resolvers file not found: {resolvers} — running "
                  f"subfinder enumeration only (skipping resolve stage)")

    safe = domain.replace("/", "_")
    raw_out = outdir / f"subdomains_{safe}.raw.txt"
    subfinder_out = outdir / f"subdomains_{safe}.subfinder.txt"

    if dry_run:
        cmd_preview = (f"subfinder -d {domain} -all -recursive -silent > {subfinder_out}"
                       + (f" ; cat {subfinder_out} | shuffledns -d {domain} "
                          f"-r {resolvers} -mode resolve -t {shuffledns_threads} "
                          f"-silent | dnsx -a -cname -resp -json -t {dnsx_threads} "
                          f"-retry {dnsx_retries} -silent" if resolve_ok else ""))
        with open(command_log, "a") as log:
            log.write(cmd_preview + f"  > {raw_out}\n")
        print("[dry-run]", cmd_preview, ">", raw_out)
        return raw_out

    # Without resolvers we only need subfinder; with resolvers we need the whole
    # chain. Check accordingly so a missing shuffledns/dnsx doesn't block the
    # enumeration-only path host validation depends on.
    need = ("subfinder", "shuffledns", "dnsx") if resolve_ok else ("subfinder",)
    missing = _tools_present(need)
    if missing:
        print(f"[subdomains] missing tools on PATH: {', '.join(missing)} — skipping")
        return None

    # STAGE 1 — subfinder ENUMERATION (run separately, NOT hidden in a pipe).
    # Running it as its own step means we can (a) see it actually ran, (b) count
    # what it found, and (c) DETECT FAILURE — a silent subfinder failure inside a
    # pipe looks identical to "found nothing" because the pipe's exit code is
    # dnsx's. -all uses every source; -recursive enumerates deeper. We drop
    # -silent's total suppression by capturing to a file and reporting the count.
    sf_cmd = ["subfinder", "-d", domain, "-all", "-recursive", "-silent"]
    with open(command_log, "a") as log:
        log.write(" ".join(sf_cmd) + f"  > {subfinder_out}\n")
    try:
        with open(subfinder_out, "w") as sfo:
            proc = subprocess.run(sf_cmd, stdout=sfo, stderr=subprocess.PIPE,
                                  text=True, errors="replace", timeout=600)
        n_enum = sum(1 for _ in open(subfinder_out)) if subfinder_out.exists() else 0
        if proc.returncode != 0:
            print(f"[subdomains] WARNING: subfinder exited {proc.returncode} — "
                  f"enumeration may be incomplete. stderr: "
                  f"{(proc.stderr or '').strip()[:200]}")
        if n_enum == 0:
            # This is the case the old pipe hid. Enumeration produced nothing —
            # could be a genuinely tiny footprint, OR subfinder failing (no API
            # keys/config, network, rate-limit). Say so loudly instead of quietly
            # sliding into validation-only.
            print(f"[subdomains] NOTE: subfinder found 0 names for {domain}. "
                  f"If this domain should have subdomains, check subfinder's API "
                  f"keys/config (~/.config/subfinder/provider-config.yaml) and "
                  f"network — validation will run but there's nothing new to verify.")
        else:
            print(f"[subdomains] subfinder enumerated {n_enum} candidate name(s)")
    except subprocess.TimeoutExpired:
        print("[subdomains] subfinder timed out (600s) — using whatever it wrote")
        n_enum = sum(1 for _ in open(subfinder_out)) if subfinder_out.exists() else 0
    except (OSError, subprocess.SubprocessError) as e:
        print(f"[subdomains] subfinder failed to run: {e} — skipping this domain")
        return None

    # STAGE 2 — VALIDATION: resolve the enumerated names (shuffledns) and pull
    # live A/CNAME records (dnsx). Feeds from subfinder's file so it only ever
    # validates what enumeration actually produced. SKIPPED when no resolvers are
    # available — in that case subfinder's name list is the deliverable (host
    # validation resolves names itself), so we return the subfinder output.
    if not resolve_ok:
        print("[subdomains] enumeration-only (no resolve stage): "
              f"{subfinder_out.name} is the output for host validation")
        return subfinder_out if subfinder_out.exists() else None

    # shlex.quote() every scope-derived / user-influenced value that reaches the
    # shell. domain and resolvers come from config/scope; subfinder_out is derived
    # from domain so it inherits the taint. Thread/retry counts are ints from
    # config and are not shell-injectable, so they stay bare.
    q_subfinder_out = shlex.quote(str(subfinder_out))
    q_domain = shlex.quote(domain)
    q_resolvers = shlex.quote(str(resolvers))
    pipeline = (
        f"cat {q_subfinder_out} "
        f"| shuffledns -d {q_domain} -r {q_resolvers} -mode resolve -t {shuffledns_threads} -silent "
        f"| dnsx -a -cname -resp -json -t {dnsx_threads} -retry {dnsx_retries} -silent"
    )
    with open(command_log, "a") as log:
        log.write(pipeline + f"  > {raw_out}\n")
    with open(raw_out, "w") as out:
        subprocess.run(pipeline, shell=True, stdout=out, check=False)
    return raw_out if raw_out.exists() else None


# ---- Parsing + cleaning ----

import csv
import re
from dataclasses import dataclass, field


@dataclass
class DnsxRecord:
    subdomain: str
    rtype: str          # A | CNAME | ...
    value: str


# dnsx output parsing. We request -json now (stable, structured), but also keep
# a text-format fallback so an older/text-mode dnsx still parses. ANSI color
# codes (dnsx sometimes emits them even to a pipe) are stripped first.
_ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")
# text -resp lines look like:  host [A] [1.2.3.4]   or   host [CNAME] [target.]
_LINE_RE = re.compile(r"^(?P<host>\S+)\s+\[(?P<type>[A-Z]+)\]\s+\[(?P<value>[^\]]+)\]")


def parse_dnsx(raw_path: Path) -> list[DnsxRecord]:
    records: list[DnsxRecord] = []
    try:
        text = raw_path.read_text(errors="replace")
    except FileNotFoundError:
        return records

    import json as _json
    for line in text.splitlines():
        line = _ANSI_RE.sub("", line).strip()
        if not line:
            continue

        # --- primary: JSON lines from `dnsx -json` ---
        if line.startswith("{"):
            try:
                obj = _json.loads(line)
            except ValueError:
                continue
            host = (obj.get("host") or "").strip().lower().rstrip(".")
            if not host:
                continue
            # A records: obj["a"] = ["1.2.3.4", ...]
            for ip in obj.get("a", []) or []:
                records.append(DnsxRecord(host, "A", str(ip).strip().rstrip(".")))
            # CNAME records: obj["cname"] = ["target.", ...]
            for cn in obj.get("cname", []) or []:
                records.append(DnsxRecord(host, "CNAME", str(cn).strip().rstrip(".")))
            # if neither present but host resolved, still record the host so it
            # isn't lost (value empty) — keeps the subdomain in inventory
            if not obj.get("a") and not obj.get("cname"):
                records.append(DnsxRecord(host, "A", ""))
            continue

        # --- fallback: bracketed text format  host [A] [1.2.3.4] ---
        m = _LINE_RE.match(line)
        if m:
            records.append(DnsxRecord(
                subdomain=m.group("host").strip().lower().rstrip("."),
                rtype=m.group("type").strip().upper(),
                value=m.group("value").strip().rstrip("."),
            ))
            continue

        # --- last resort: a bare hostname on its own line (subfinder-style) ---
        # if the line is just a domain-looking token, keep it as a host with no
        # value, so resolved names are never silently dropped.
        if re.fullmatch(r"[a-z0-9._-]+\.[a-z]{2,}", line, re.IGNORECASE):
            records.append(DnsxRecord(line.lower().rstrip("."), "A", ""))
    return records


def correlate_to_targets(records: list[DnsxRecord],
                         target_ips: set[str]) -> tuple[dict[str, list[str]], list[dict]]:
    """Correlate resolved subdomains against the KNOWN target IPs.

    SCOPE-SAFE: this only matches subdomains to IPs already in the target list.
    It never adds, suggests, or scans any new host. Subdomains resolving to
    non-target IPs are still recorded (for the report) but never scanned.

    Returns:
      enrichment: {target_ip: [hostname, ...]} for IPs that a subdomain resolves
                  to — used to annotate the scan summary.
      inventory:  [{subdomain, ip, cname, matched_target}] — the full record of
                  every subdomain found, for the report tab.
    """
    # build subdomain -> (ips, cnames)
    by_sub: dict[str, dict[str, list[str]]] = {}
    for r in records:
        d = by_sub.setdefault(r.subdomain, {"A": [], "CNAME": []})
        if r.rtype == "A":
            d["A"].append(r.value)
        elif r.rtype == "CNAME":
            d["CNAME"].append(r.value)

    enrichment: dict[str, list[str]] = {}
    inventory: list[dict] = []
    for sub, recs in sorted(by_sub.items()):
        ips = recs["A"]
        cnames = recs["CNAME"]
        matched = [ip for ip in ips if ip in target_ips]
        # enrichment: attach this hostname to any target IP it points at
        for ip in matched:
            enrichment.setdefault(ip, [])
            if sub not in enrichment[ip]:
                enrichment[ip].append(sub)
        # inventory row(s): one per resolved IP (or a bare row if only CNAME)
        if ips:
            for ip in ips:
                inventory.append({
                    "subdomain": sub,
                    "ip": ip,
                    "cname": ", ".join(cnames),
                    "matched_target": "Y" if ip in target_ips else "",
                })
        else:
            inventory.append({
                "subdomain": sub, "ip": "",
                "cname": ", ".join(cnames), "matched_target": "",
            })
    return enrichment, inventory


def run_phase0_correlation(domains: list[str], target_ips: set[str],
                           outdir: Path, command_log: Path,
                           resolvers_file: str = "",
                           dry_run: bool = False) -> tuple[dict, list]:
    """Phase-0 helper: run the subfinder|shuffledns|dnsx enum for each domain,
    correlate results to the known target IPs, and return (enrichment,
    inventory). Never expands scope."""
    all_records: list[DnsxRecord] = []
    for domain in domains:
        raw = run_subdomain_enum(domain, outdir, command_log,
                                 resolvers=resolvers_file, dry_run=dry_run)
        if raw:
            all_records.extend(parse_dnsx(raw))
    enrichment, inventory = correlate_to_targets(all_records, target_ips)
    if not dry_run:
        # write the full inventory CSV for the report tab
        import csv
        inv_csv = outdir / "subdomain_inventory.csv"
        with open(inv_csv, "w", newline="", encoding="utf-8") as fh:
            w = csv.writer(fh)
            w.writerow(["Subdomain", "Resolved IP", "CNAME", "Matched Target"])
            for row in inventory:
                w.writerow([row["subdomain"], row["ip"], row["cname"],
                            row["matched_target"]])
        n_match = sum(1 for r in inventory if r["matched_target"] == "Y")
        print(f"[subdomains] {len(inventory)} subdomain record(s), "
              f"{n_match} matched to target IP(s) -> {inv_csv}")
    return enrichment, inventory


def _pick_value(records: list[DnsxRecord]) -> tuple[str, str]:
    """For one subdomain's records, choose the representative value:
    prefer the SHORTEST CNAME; if no CNAME, any A record. Returns (type, value)."""
    cnames = [r.value for r in records if r.rtype == "CNAME" and r.value]
    if cnames:
        shortest = min(cnames, key=len)
        return ("CNAME", shortest)
    a_records = [r.value for r in records if r.rtype == "A" and r.value]
    if a_records:
        return ("A", a_records[0])
    # fallback: any record at all
    if records:
        return (records[0].rtype, records[0].value)
    return ("", "")


def write_raw_csv(records: list[DnsxRecord], csv_path: Path) -> int:
    """Raw CSV: every record as-is (all A/CNAME lines, no dedup), for analytics.
    Returns the number of rows written."""
    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["subdomain", "type", "value"])
        for r in records:
            w.writerow([r.subdomain, r.rtype, r.value])
    return len(records)


def write_cleaned_csv(records: list[DnsxRecord], csv_path: Path) -> int:
    """Cleaned CSV: exactly one row per UNIQUE subdomain. Value preference is
    shortest CNAME, else any A record. Returns the number of unique rows."""
    by_sub: dict[str, list[DnsxRecord]] = {}
    for r in records:
        by_sub.setdefault(r.subdomain, []).append(r)

    rows = []
    for sub in sorted(by_sub):
        rtype, value = _pick_value(by_sub[sub])
        rows.append([sub, rtype, value])

    with open(csv_path, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["subdomain", "type", "value"])
        w.writerows(rows)
    return len(rows)


def process_domain(domain: str, outdir: Path, command_log: Path,
                   resolvers: str = "", dry_run: bool = False) -> Path | None:
    """Run enumeration, then (if it resolved) write raw CSV (all records) and
    cleaned CSV (one row per unique subdomain). Returns the cleaned CSV path when
    the resolve stage ran, else the subfinder name list (enumeration-only), else
    None.

    Enumeration-only happens when no resolvers file is available: subfinder still
    produces subdomains_<domain>.subfinder.txt, which host validation consumes
    directly, so this is a SUCCESS (degraded), not a failure.
    """
    out = run_subdomain_enum(domain, outdir, command_log,
                             resolvers=resolvers, dry_run=dry_run)
    if dry_run or out is None:
        return None
    safe = domain.replace("/", "_")
    subfinder_out = outdir / f"subdomains_{safe}.subfinder.txt"
    # Enumeration-only: run_subdomain_enum returned the bare-name file (no dnsx
    # JSON to parse into CSVs). host validation reads the .subfinder.txt itself.
    if Path(out) == subfinder_out:
        n = sum(1 for _ in open(out)) if Path(out).is_file() else 0
        print(f"[subdomains] {domain}: {n} enumerated name(s) "
              f"(no resolve stage; {subfinder_out.name} ready for host validation)")
        return out
    records = parse_dnsx(out)
    raw_csv = outdir / f"subdomains_{safe}.raw.csv"
    clean_csv = outdir / f"subdomains_{safe}.clean.csv"
    write_raw_csv(records, raw_csv)
    n = write_cleaned_csv(records, clean_csv)
    print(f"[subdomains] {domain}: {len(records)} records -> {n} unique subdomains")
    return clean_csv
