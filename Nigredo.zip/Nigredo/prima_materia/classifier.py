"""Service classifier.

Takes parsed deep-scan results (host -> port -> service/banner) and tags each
open port with a logical service class so downstream tooling can be routed
cleanly.

Classes:
  web          - http/https and common alt ports; fed to nuclei, feroxbuster
  tls          - TLS-capable endpoints; fed to testssl.sh (independent of web)
  auth_surface - ftp/sftp/ssh/telnet/ldap/rdp/smb/sql-family; grouped for
                 FINGERPRINTING / version / misconfig scanning ONLY. This layer
                 deliberately does NOT generate credentials, auth payloads, or
                 wire these into brute-force tooling. Authentication testing is a
                 separate, manual, RoE-gated step.
  other        - everything else, captured with banner for review.

Classification uses the nmap service name first, then falls back to well-known
port numbers and any banner/product text.
"""
from __future__ import annotations

from dataclasses import dataclass, field

# nmap service-name -> class
_WEB_SERVICES = {"http", "https", "http-proxy", "http-alt", "https-alt", "ssl/http"}
_WEB_PORTS = {80, 443, 591, 2480, 3000, 4443, 5000, 7001, 8000, 8008, 8009,
              8080, 8081, 8088, 8443, 8800, 8888, 9000, 9090, 9443, 10000}

# tls-bearing services that aren't necessarily plain http
_TLS_SERVICES = {"https", "https-alt", "ssl/http", "ssl", "imaps", "pop3s",
                 "smtps", "ldaps", "ftps"}
_TLS_PORTS = {443, 465, 636, 989, 990, 993, 995, 8443, 9443}

# auth-surface services (login-bearing) -> fingerprint/version scan only
_AUTH_SERVICES = {
    "ftp", "ftps", "sftp", "ssh", "telnet", "ldap", "ldaps", "rdp", "ms-wbt-server",
    "smb", "microsoft-ds", "netbios-ssn", "mysql", "ms-sql-s", "ms-sql", "mssql",
    "postgresql", "postgres", "oracle", "oracle-tns", "mongodb", "mongod",
    "redis", "vnc", "rlogin", "rexec",
}
_AUTH_PORTS = {21, 22, 23, 389, 636, 1433, 1521, 3306, 3389, 5432, 5900, 5984,
               6379, 27017, 139, 445}


# web-server PRODUCT names nmap reports (in the product field, independent of the
# service name / port). Catches web servers nmap fingerprinted but didn't tag with
# an http service name or a standard web port — e.g. "Microsoft IIS httpd" on a
# non-standard port, which would otherwise fall through and never get scanned.
_WEB_PRODUCT_MARKERS = (
    "iis", "httpd", "http server", "nginx", "apache", "lighttpd", "tomcat",
    "jetty", "kestrel", "gunicorn", "werkzeug", "openresty", "caddy", "traefik",
    "websphere", "weblogic", "jboss", "wildfly", "glassfish", "coldfusion",
    "node.js", "express", "phusion", "litespeed", "cherokee", "haproxy",
)


def _looks_like_web_product(product: str) -> bool:
    """True if nmap's product string names a known web server / app server."""
    p = (product or "").lower()
    return any(marker in p for marker in _WEB_PRODUCT_MARKERS)


@dataclass
class ClassifiedEndpoint:
    host: str
    port: int
    protocol: str
    service: str
    product: str
    version: str
    banner: str
    classes: set[str] = field(default_factory=set)
    http_headers: dict[str, str] = field(default_factory=dict)


def _banner_of(port_info: dict) -> str:
    bits = [port_info.get("product", ""), port_info.get("version", ""),
            port_info.get("extrainfo", "")]
    return " ".join(b for b in bits if b).strip()


def classify_port(host: str, port_info: dict) -> ClassifiedEndpoint:
    svc = (port_info.get("service") or "").lower()
    portid = int(port_info.get("port", 0))
    protocol = port_info.get("protocol", "tcp")

    ep = ClassifiedEndpoint(
        host=host,
        port=portid,
        protocol=protocol,
        service=svc,
        product=port_info.get("product", ""),
        version=port_info.get("version", ""),
        banner=_banner_of(port_info),
    )

    # pull any HTTP headers NSE already captured
    scripts = port_info.get("scripts", {}) or {}
    for sid, out in scripts.items():
        if sid in ("http-headers", "http-server-header", "http-title"):
            ep.http_headers[sid] = out

    is_web = (svc in _WEB_SERVICES or svc.startswith("http")
              or portid in _WEB_PORTS
              or _looks_like_web_product(port_info.get("product", "")))
    is_tls = svc in _TLS_SERVICES or portid in _TLS_PORTS or "ssl" in svc
    is_auth = svc in _AUTH_SERVICES or portid in _AUTH_PORTS

    if is_web:
        ep.classes.add("web")
    if is_tls:
        ep.classes.add("tls")
    if is_auth:
        ep.classes.add("auth_surface")
    if not ep.classes:
        ep.classes.add("other")

    return ep


def classify_results(results: dict) -> list[ClassifiedEndpoint]:
    """results: the state['results'] dict from the pipeline, where each host has
    a 'services' list populated by the deep scan."""
    endpoints: list[ClassifiedEndpoint] = []
    for addr, info in results.items():
        for svc in info.get("services", []):
            endpoints.append(classify_port(addr, svc))
    return endpoints


def group_by_class(endpoints: list[ClassifiedEndpoint]) -> dict[str, list[ClassifiedEndpoint]]:
    groups: dict[str, list[ClassifiedEndpoint]] = {
        "web": [], "tls": [], "auth_surface": [], "other": []
    }
    for ep in endpoints:
        for cls in ep.classes:
            groups[cls].append(ep)
    return groups
