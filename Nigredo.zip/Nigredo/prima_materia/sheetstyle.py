"""Central worksheet styling — one look, applied everywhere.

Every sheet-builder used to repeat its own header/fill/width block, so the
workbook drifted into 24 slightly-different styles. This module is the single
source of truth: call style_sheet() after writing rows and every tab comes out
looking like it's from the same paid product.

Design tokens live here (dark slate header, white bold text, banded rows) so a
future restyle is one edit, not 40.
"""
from __future__ import annotations

from openpyxl.styles import Alignment, Font, PatternFill, Border, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.worksheet import Worksheet

# --- design tokens -----------------------------------------------------------
FONT = "Roboto"
FONT_SIZE = 11

HEADER_FILL = PatternFill("solid", fgColor="1F2937")     # dark slate
HEADER_FONT = Font(name=FONT, size=FONT_SIZE, bold=True, color="FFFFFF")
BODY_FONT = Font(name=FONT, size=FONT_SIZE)
BAND_FILL = PatternFill("solid", fgColor="F3F4F6")       # subtle zebra row
_THIN = Side(style="thin", color="E5E7EB")
CELL_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

# sensible width bounds for auto-fit
_MIN_W, _MAX_W = 10, 70


def style_header(ws: Worksheet, ncols: int, row: int = 1) -> None:
    """Bold dark header row, left-aligned, frozen."""
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.freeze_panes = ws.cell(row=row + 1, column=1).coordinate


def autofit(ws: Worksheet, ncols: int | None = None, sample_rows: int = 200) -> None:
    """Size each column to its widest cell, clamped to [_MIN_W, _MAX_W].
    Samples the first `sample_rows` so huge sheets stay fast."""
    ncols = ncols or ws.max_column
    for c in range(1, ncols + 1):
        width = _MIN_W
        for r, row in enumerate(ws.iter_rows(min_col=c, max_col=c, max_row=sample_rows)):
            val = row[0].value
            if val is not None:
                width = max(width, min(len(str(val)) + 2, _MAX_W))
        ws.column_dimensions[get_column_letter(c)].width = width


def band_rows(ws: Worksheet, ncols: int, start: int = 2) -> None:
    """Zebra-stripe body rows for readability. Body font applied here too."""
    for i, row in enumerate(ws.iter_rows(min_row=start, max_col=ncols)):
        fill = BAND_FILL if i % 2 else None
        for cell in row:
            cell.font = BODY_FONT
            if fill:
                cell.fill = fill


def style_sheet(ws: Worksheet, ncols: int | None = None, *,
                widths: dict[int, int] | None = None,
                band: bool = True, tab_color: str | None = None) -> Worksheet:
    """One call to make a finished sheet look professional.

    ws       : the worksheet, already populated with a header row + data.
    ncols    : number of columns (defaults to ws.max_column).
    widths   : optional {col_index: width} to override auto-fit for specific cols.
    band     : zebra-stripe body rows.
    tab_color: optional hex for the sheet tab (e.g. 'B91C1C' for high-value).
    """
    ncols = ncols or ws.max_column
    style_header(ws, ncols)
    if band:
        band_rows(ws, ncols)
    autofit(ws, ncols)
    if widths:                       # explicit overrides win over auto-fit
        for col, w in widths.items():
            ws.column_dimensions[get_column_letter(col)].width = w
    if tab_color:
        ws.sheet_properties.tabColor = tab_color
    return ws


def empty_notice(ws: Worksheet, message: str = "No findings for this target.") -> None:
    """Make a data-less sheet read as intentional, not broken."""
    ws.cell(row=2, column=1, value=message).font = Font(
        name=FONT, size=FONT_SIZE, italic=True, color="6B7280")
