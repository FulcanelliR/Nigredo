"""One-line logging setup, shared across modules.

Why this exists: the tool has ~770 print() calls, which have no severity — a
"tool not installed, skipping" message and a real crash look identical on
stdout, and neither captures a traceback. That's what made "getting error
logging to work" feel impossible: there was nothing to turn up or down.

get_logger(name) returns a stdlib logger whose output keeps the existing
"[name] message" prefix, so migrated lines look the same as the print()s they
replace. Severity now means something:

    log.info(...)      normal progress (was a plain print)
    log.warning(...)   something's off but survivable (a tab got skipped)
    log.debug(...)     detail you only want when chasing a bug
    log.warning("msg", exc_info=True)   ... plus the full traceback
    log.exception(...) shorthand for error-level + traceback, inside an except

NIGREDO_DEBUG=1 flips the level to DEBUG, so tracebacks and debug lines appear.
Default is INFO, so normal runs stay as quiet as they are today.
"""
from __future__ import annotations

import logging
import os


def _debug_on() -> bool:
    """True only when NIGREDO_DEBUG is set to a real 'on' value. Bare presence
    isn't enough: NIGREDO_DEBUG=0 / false / empty must NOT enable debug (the old
    check treated any non-empty value, including '0', as on)."""
    return os.getenv("NIGREDO_DEBUG", "").strip().lower() not in ("", "0", "false", "no", "off")


class _TracebackGate(logging.Filter):
    """Strip the traceback from a record unless debug mode is on.

    Call-sites pass exc_info=True so the traceback is AVAILABLE, but on a normal
    run we don't want a full traceback printed for every survivable skip — that's
    the noise the logging pass was meant to gate. When NIGREDO_DEBUG is on we
    leave exc_info intact so tracebacks appear. The message itself is untouched
    either way, so a skipped tab still logs its one-line reason.
    """
    def filter(self, record: logging.LogRecord) -> bool:
        if not _debug_on():
            record.exc_info = None
            record.exc_text = None
        return True


def get_logger(name: str) -> logging.Logger:
    log = logging.getLogger(name)
    if not log.handlers:                       # configure each logger once
        handler = logging.StreamHandler()      # stderr, like the tool's errors
        handler.setFormatter(logging.Formatter("[%(name)s] %(message)s"))
        handler.addFilter(_TracebackGate())    # tracebacks only when debug is on
        log.addHandler(handler)
        log.propagate = False                  # don't double-print via root
    log.setLevel(logging.DEBUG if _debug_on() else logging.INFO)
    return log
