"""dnsrecon runner + output cleaner.

dnsrecon's terminal output is noisy and hard to read. Instead of scraping
stdout, we run it with `-j <file>` (structured JSON) and reformat the records
into clean, grouped, per-domain output.

Enumeration: `-t std,axfr` per apex domain — full standard record set
(SOA, NS, A, AAAA, MX, TXT incl. SPF/DMARC) plus a zone-transfer attempt.
No OSINT modules, no general brute force (DKIM selector brute force is handled
separately in dkim.py, which dnsrecon's `brt` structurally can't do).

The dnsrecon JSON is a flat list of record objects. The first element is
typically a scan-info/arguments header; the rest are records, each with a
`type` field plus type-specific fields (name/address/target/exchange/mname...).
We group by type and render readable tables.
"""
from __future__ import annotations

import json
import subprocess
from pathlib import Path


# record type -> the fields we display for it, in order
_FIELDS_BY_TYPE = {
    "SOA":   ["mname", "address"],
    "NS":    ["target", "address"],
    "A":     ["name", "address"],
    "AAAA":  ["name", "address"],
    "MX":    ["exchange", "address", "preference"],
    "TXT":   ["name", "strings"],
    "SPF":   ["strings"],
    "SRV":   ["name", "target", "address", "port", "priority", "weight"],
    "CNAME": ["name", "target"],
    "PTR":   ["name", "address"],
}
_DISPLAY_ORDER = ["SOA", "NS", "MX", "A", "AAAA", "CNAME", "SRV", "TXT", "SPF", "PTR"]


def run_dnsrecon(domain: str, outdir: Path, command_log: Path,
                 dry_run: bool = False, lifetime: float = 10.0,
                 threads: int = 8) -> Path | None:
    """Run dnsrecon -t std,axfr -j on one domain. Returns the JSON path.

    lifetime is dnsrecon's per-query DNS timeout (--lifetime). Default raised to
    10s (from dnsrecon's own 3s) because some targets' DNS servers are slow to
    answer or lightly rate-limit, and 3s produces spurious 'timeout' errors on
    otherwise-fine targets. Raise further via config if a target is very slow.
    NOTE: the NOTIMP 'Zone Transfer Failed' line dnsrecon prints is NORMAL — it
    means the target correctly refuses AXFR zone transfers (not a nigredo error).
    """
    safe = domain.replace("/", "_")
    json_out = outdir / f"dnsrecon_{safe}.json"
    cmd = ["dnsrecon", "-d", domain, "-t", "std,axfr",
           "--lifetime", str(lifetime), "--threads", str(threads),
           "-j", str(json_out)]
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + "\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd))
        return json_out
    subprocess.run(cmd, check=False)
    return json_out if json_out.exists() else None


# dnsrecon emits header/meta elements with these type values; not DNS records.
_NON_RECORD_TYPES = {"scaninfo", "scan_info", "info"}


def _records_from_json(json_path: Path) -> list[dict]:
    try:
        data = json.loads(json_path.read_text())
    except (json.JSONDecodeError, FileNotFoundError):
        return []
    if not isinstance(data, list):
        return []
    # keep dicts whose "type" names an actual DNS record (drop scan-info header).
    return [
        r for r in data
        if isinstance(r, dict)
        and r.get("type")
        and str(r["type"]).lower() not in _NON_RECORD_TYPES
    ]


def _fmt_value(rec: dict, field: str) -> str:
    val = rec.get(field, "")
    if isinstance(val, list):
        return " ".join(str(v) for v in val)
    return str(val)


def process_domain(domain: str, outdir: Path, command_log: Path,
                   dry_run: bool = False, lifetime: float = 10.0) -> str:
    """Run dnsrecon on one domain, write the cleaned report to a .txt file
    alongside the raw JSON, and return the cleaned report text."""
    json_out = run_dnsrecon(domain, outdir, command_log, dry_run=dry_run,
                            lifetime=lifetime)
    if dry_run or json_out is None:
        return ""
    report = clean_report(domain, json_out)
    safe = domain.replace("/", "_")
    (outdir / f"dnsrecon_{safe}.txt").write_text(report)
    return report


def clean_report(domain: str, json_path: Path) -> str:
    """Parse the dnsrecon JSON and render a clean, grouped, per-type report."""
    records = _records_from_json(json_path)
    lines: list[str] = []
    lines.append(f"=== DNS records for {domain} ===")

    if not records:
        lines.append("  (no records parsed — see raw JSON / check resolution)")
        return "\n".join(lines) + "\n"

    by_type: dict[str, list[dict]] = {}
    for r in records:
        by_type.setdefault(r["type"].upper(), []).append(r)

    # zone transfer: dnsrecon tags AXFR-derived records; surface if present
    axfr_hit = any(r.get("zone_transfer") or r.get("type", "").upper() == "AXFR"
                   for r in records)

    shown_types = [t for t in _DISPLAY_ORDER if t in by_type]
    # include any unexpected types we didn't pre-order, so nothing is dropped
    shown_types += [t for t in by_type if t not in _DISPLAY_ORDER]

    for rtype in shown_types:
        recs = by_type[rtype]
        lines.append(f"\n  [{rtype}]  ({len(recs)})")
        fields = _FIELDS_BY_TYPE.get(rtype)
        for r in recs:
            if fields:
                parts = [f"{f}={_fmt_value(r, f)}" for f in fields
                         if r.get(f) not in (None, "", [])]
            else:
                # unknown type: dump all non-type fields
                parts = [f"{k}={_fmt_value(r, k)}" for k in r
                         if k != "type" and r.get(k) not in (None, "", [])]
            lines.append("    " + "  ".join(parts))

    lines.append("")
    lines.append(f"  Zone transfer (AXFR): "
                 + ("SUCCEEDED — records above include zone data" if axfr_hit
                    else "not available / refused"))
    return "\n".join(lines) + "\n"
