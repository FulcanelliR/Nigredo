"""ADJUDICATOR — rebuild the workbook from a folder + render a verdict on the run.

Point Adjudicator at an engagement output folder and it:

  1. REBUILDS a workbook from the files ON DISK — so if the live report generation
     crashed or produced a broken workbook, the run's work isn't lost. The raw
     tool output is on disk; Adjudicator turns it into a workbook on demand.

  2. RENDERS A VERDICT (the audit): which tools produced output, which are
     missing, which errored, whether the run looks like a CLEAN FINISH or a CRASH
     — printed to the terminal AND written as a "Verdict" tab at the front of the
     rebuilt workbook. No archaeology required.

It embodies the "every .txt/.csv the run produced goes into the workbook"
principle (Phase 1 — completeness + ordering, NOT parsing). It reuses nigredo's
own file-pattern map and sheet helpers so it stays in sync with the main tool and
can be called by the live run too (one shared code path, no drift).

Standalone usage:
    python3 -m prima_materia.adjudicator --folder /path/to/engagement_output
    python3 -m prima_materia.adjudicator --folder ./out --output rebuilt.xlsx
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path


# Priority order: what belongs closest to the FRONT (most important) vs the BACK
# (raw/audit). Lower number = closer to front. Tools not listed fall in the
# middle band (50). This drives the front-to-back ordering of the rebuilt book.
_FRONT_TO_BACK_PRIORITY = {
    # findings people care about first
    "nuclei": 10, "ffuf": 12, "feroxbuster": 12, "testssl": 15, "sns": 15,
    "nomore403": 16, "funnelweb": 18, "cvemap": 20, "takeover": 22,
    # exposure / secrets
    "fileenum": 25, "buckets": 26, "trufflehog": 27, "gitleaks": 27,
    "cloud_enum": 28,
    # people / email
    "emailenum": 35, "partyon": 36, "snov": 37, "dkim": 38,
    # discovery / recon substrate
    "httpx": 55, "katana": 56, "gau": 57, "subdomains": 58, "submutate": 59,
    "dnsrecon": 60, "dnstwist": 61,
}
_DEFAULT_PRIORITY = 50


def _safe_title(title: str, used: set = None) -> str:
    s = str(title or "Sheet")
    for ch in ":\\/?*[]":
        s = s.replace(ch, "_")
    s = s.replace("'", "").strip() or "Sheet"
    s = s[:31]
    # openpyxl RAISES on a duplicate sheet name — de-dupe by appending a counter
    # within the 31-char limit. (Two files truncating to the same 31 chars, or a
    # base[:20]+" Raw" collision across clusters, previously CRASHED the rebuild.)
    if used is not None:
        base = s
        n = 2
        while s.lower() in used:
            suffix = f"_{n}"
            s = base[:31 - len(suffix)] + suffix
            n += 1
        used.add(s.lower())
    return s


def audit_folder(folder: Path) -> dict:
    """Inspect the folder and return a verdict dict describing the run state.

    Reuses nigredo's tool->file-pattern map so it recognizes the same outputs the
    real report does. Determines per-tool: produced output? errored? and an
    overall clean-vs-crash read."""
    from . import workbook as _wbk

    folder = Path(folder)
    result = {
        "folder": str(folder),
        "tools_with_output": [],
        "tools_missing": [],
        "tools_errored": [],
        "all_text_csv": [],
        "orphans": [],          # text/csv files no tool pattern claimed
        "clean_finish": None,
        "notes": [],
    }
    if not folder.is_dir():
        result["notes"].append(f"folder does not exist: {folder}")
        return result

    claimed: set[Path] = set()
    for tool in _wbk._TOOL_FILE_PATTERNS:
        files = _wbk.tool_output_files(folder, tool)
        errs = _wbk.tool_error_lines(folder, tool) if hasattr(
            _wbk, "tool_error_lines") else []
        if files:
            result["tools_with_output"].append(tool)
            for f in files:
                claimed.add(f.resolve())
        else:
            result["tools_missing"].append(tool)
        if errs:
            result["tools_errored"].append(tool)

    # every text/csv on disk (the completeness sweep)
    for pattern in ("*.txt", "*.csv", "*.jsonl", "*.json"):
        for f in folder.rglob(pattern):
            if f.is_file():
                result["all_text_csv"].append(f)
                if f.resolve() not in claimed:
                    result["orphans"].append(f)

    # clean-vs-crash heuristic: a completion marker or a final report is a strong
    # "clean" signal; lots of errored tools + no report is a "crash" signal.
    has_report = any(folder.rglob("*final_report*.xlsx")) or \
        any(folder.rglob("*report*.xlsx"))
    has_commands = (folder / "commands.log").exists() or \
        any(folder.rglob("commands.log"))
    if has_report:
        result["clean_finish"] = True
        result["notes"].append("a report xlsx exists — live run likely finished.")
    elif result["tools_with_output"] and not has_report:
        result["clean_finish"] = False
        result["notes"].append(
            "tool output present but NO report xlsx — run likely CRASHED during "
            "report generation. Adjudicator can rebuild from the files on disk.")
    else:
        result["clean_finish"] = None
        result["notes"].append("insufficient signal to judge clean-vs-crash.")
    if not has_commands:
        result["notes"].append("no commands.log found — limited audit trail.")
    return result


def print_verdict(verdict: dict) -> None:
    """Print the run verdict to the terminal — the at-a-glance audit."""
    print("=" * 64)
    print("  ADJUDICATOR — RUN VERDICT")
    print("=" * 64)
    print(f"  folder: {verdict['folder']}")
    cf = verdict["clean_finish"]
    state = ("CLEAN FINISH" if cf is True
             else "LIKELY CRASH" if cf is False else "INDETERMINATE")
    print(f"  verdict: {state}")
    print(f"  tools with output : {len(verdict['tools_with_output'])}")
    print(f"  tools missing     : {len(verdict['tools_missing'])}")
    print(f"  tools with errors : {len(verdict['tools_errored'])}")
    print(f"  text/csv files    : {len(verdict['all_text_csv'])}")
    print(f"  orphan files      : {len(verdict['orphans'])} "
          f"(on disk but not claimed by any tool pattern)")
    if verdict["tools_errored"]:
        print(f"  ERRORED           : {', '.join(verdict['tools_errored'])}")
    if verdict["orphans"]:
        print("  orphans (will still be captured in the workbook):")
        for f in verdict["orphans"][:15]:
            print(f"      {f.name}")
        if len(verdict["orphans"]) > 15:
            print(f"      ... +{len(verdict['orphans']) - 15} more")
    for n in verdict["notes"]:
        print(f"  note: {n}")
    print("=" * 64)


def rebuild_workbook(folder: Path, output: Path, verdict: dict | None = None):
    """Rebuild a workbook from every text/csv in the folder, priority-ordered,
    with a Verdict tab at the front. Completeness-first (Phase 1): every file
    gets a home; parsing into structured findings is a separate later phase."""
    from openpyxl import Workbook
    from openpyxl.styles import Font
    from . import workbook as _wbk

    folder = Path(folder)
    if verdict is None:
        verdict = audit_folder(folder)

    wb = Workbook()
    # track sheet names to guarantee uniqueness (openpyxl raises on duplicates)
    _used_titles: set = {"verdict"}
    # --- Verdict tab (front) ---
    ws = wb.active
    ws.title = "Verdict"
    cf = verdict["clean_finish"]
    state = ("CLEAN FINISH" if cf is True
             else "LIKELY CRASH" if cf is False else "INDETERMINATE")
    rows = [
        ("ADJUDICATOR — RUN VERDICT", ""),
        ("folder", verdict["folder"]),
        ("verdict", state),
        ("rebuilt", time.strftime("%Y-%m-%d %H:%M:%S")),
        ("tools with output", ", ".join(verdict["tools_with_output"]) or "(none)"),
        ("tools missing", ", ".join(verdict["tools_missing"]) or "(none)"),
        ("tools with errors", ", ".join(verdict["tools_errored"]) or "(none)"),
        ("text/csv files", str(len(verdict["all_text_csv"]))),
        ("orphan files", str(len(verdict["orphans"]))),
    ]
    for n in verdict["notes"]:
        rows.append(("note", n))
    for r, (k, v) in enumerate(rows, 1):
        c1 = ws.cell(row=r, column=1, value=k)
        ws.cell(row=r, column=2, value=v)
        if r == 1:
            c1.font = Font(bold=True, size=13)
    ws.column_dimensions["A"].width = 22
    ws.column_dimensions["B"].width = 90

    # --- per-tool clusters, PRIORITY ORDERED (front-to-back) ---
    clusters = _wbk.per_tool_clusters(folder)
    clusters.sort(key=lambda c: (_FRONT_TO_BACK_PRIORITY.get(c["tool"],
                                                             _DEFAULT_PRIORITY),
                                 (c["display"] or c["tool"]).lower()))
    claimed: set[Path] = set()
    for cl in clusters:
        disp = cl["display"]
        base = disp[:20]
        for f in cl["raw_files"]:
            claimed.add(Path(f).resolve())
        if cl["raw_files"]:
            sections = []
            for f in cl["raw_files"]:
                sections.append((f.name, "\n".join(_wbk._read_text(f,
                                                                   limit_lines=5000))))
            _add_text_sheet(wb, f"{base} Raw", sections, used=_used_titles)
        if cl.get("errors"):
            _add_text_sheet(wb, f"{base} Err",
                            [(f"{disp} errors", "\n".join(cl["errors"]))],
                            used=_used_titles)
        if cl.get("commands"):
            _add_text_sheet(wb, f"{base} Cmd",
                            [(f"{disp} commands", "\n".join(cl["commands"]))],
                            used=_used_titles)

    # --- ORPHANS: text/csv on disk that no tool pattern claimed — capture them
    #     anyway (the "every file goes in the workbook" guarantee) ---
    orphan_sections = []
    for f in verdict["orphans"]:
        if Path(f).resolve() in claimed:
            continue
        try:
            orphan_sections.append((f.name, "\n".join(_wbk._read_text(f,
                                                                      limit_lines=3000))))
        except Exception:  # noqa: BLE001
            orphan_sections.append((f.name, "(could not read)"))
    if orphan_sections:
        # chunk orphans across sheets so no single sheet is enormous
        for i in range(0, len(orphan_sections), 20):
            _add_text_sheet(wb, f"Orphans {i // 20 + 1}",
                            orphan_sections[i:i + 20], used=_used_titles)

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)
    return output


def _add_text_sheet(wb, title: str, sections: list[tuple[str, str]], used=None):
    """One line per cell (so no cell hits Excel's 32767-char limit)."""
    ws = wb.create_sheet(_safe_title(title, used))
    r = 1
    for header, body in sections:
        ws.cell(row=r, column=1, value=f"=== {header} ===")
        r += 1
        for line in (body or "").splitlines():
            ws.cell(row=r, column=1, value=line[:32000])
            r += 1
        r += 1  # blank spacer between sections
    ws.column_dimensions["A"].width = 120


def main(argv=None) -> int:
    p = argparse.ArgumentParser(
        prog="adjudicator",
        description="ADJUDICATOR — rebuild the workbook from an engagement folder "
                    "and render a verdict on the run (recovery + audit).")
    p.add_argument("--folder", required=True,
                   help="Engagement output folder to adjudicate.")
    p.add_argument("--output", default="",
                   help="Rebuilt workbook path (default: "
                        "<folder>/ADJUDICATOR_rebuild.xlsx).")
    p.add_argument("--audit-only", action="store_true",
                   help="Only print the verdict; don't rebuild the workbook.")
    args = p.parse_args(argv)

    folder = Path(args.folder)
    if not folder.is_dir():
        print(f"ERROR: not a folder: {folder}", file=sys.stderr)
        return 2

    verdict = audit_folder(folder)
    print_verdict(verdict)

    if args.audit_only:
        return 0

    output = Path(args.output) if args.output else folder / "ADJUDICATOR_rebuild.xlsx"
    try:
        out = rebuild_workbook(folder, output, verdict)
        print(f"\n[Adjudicator] rebuilt workbook -> {out}")
    except Exception as e:  # noqa: BLE001
        print(f"[Adjudicator] rebuild failed: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
