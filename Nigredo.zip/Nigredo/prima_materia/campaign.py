"""Campaign launcher — prepare and run several client engagements at once.

The tool is already parallel-safe ACROSS clients: everything a run writes is
namespaced under results/<engagement>/ (outdir, commands.log, recon_state.json,
the credit ledger, the heartbeat), and there are no lockfiles, fixed temp paths,
or fixed listening ports to collide on. So "run 2-5 clients at once" needs no
change to the scan internals — just a way to launch N non-interactive runs, each
pointed at its own target list. That's this module.

Two-step flow, on purpose — prepare THEN run, never a mid-run pause:

  1. campaign init acme globex initech
        -> makes results/<client>/targets.txt (empty) + a per-client marker.
           Fast, interactive-free. You then fill each targets.txt at your own
           pace (paste the client's scope; one entry per line, # comments ok).

  2. campaign run
        -> validates EVERY ready client's targets up front, then spawns one
           subprocess per client (OS-isolated), capped at --max-parallel.
           Clients with an empty/missing targets.txt are skipped as "not ready",
           so you can re-run as you finish prepping — it only picks up the ready
           ones. Zero human interaction once it starts.

  campaign status  -> show which clients are ready / running / done.

Why subprocesses, not threads: a per-client process means a hung nuclei run or a
segfault in one client can't take down the other four, and each gets its own
memory and signal handling. For 2-5 clients that isolation is worth far more
than shared-process efficiency.
"""
from __future__ import annotations

import subprocess
import sys
import time
from pathlib import Path

from .recon_config import load_domains
from .log import get_logger

log = get_logger("campaign")

TARGETS_NAME = "targets.txt"
CAMPAIGN_MARKER = ".campaign"          # marks a folder as campaign-managed
_STAMP = "%Y-%m-%d %H:%M:%S"


def _client_dir(results_root: Path, client: str) -> Path:
    return results_root / client


def _targets_path(results_root: Path, client: str) -> Path:
    return _client_dir(results_root, client) / TARGETS_NAME


def _ready_targets(results_root: Path, client: str) -> list[str] | None:
    """Return the parsed targets for a client, or None if not ready.

    'Not ready' = no targets.txt, or it parses to zero entries. We reuse
    load_domains so campaign parsing is identical to what a normal run does
    (comments, comma/space separation, dedup, normalization).
    """
    tpath = _targets_path(results_root, client)
    if not tpath.is_file():
        return None
    try:
        domains = load_domains(tpath)
    except OSError as e:
        log.warning("could not read %s: %s", tpath, e)
        return None
    return domains or None


def _ready_domains(results_root: Path, client: str) -> list[str] | None:
    """Return the client's RECON domains (domains.txt), or None if none set.
    This is the recon scope (apex domains) the child's recon engine runs against
    — distinct from targets.txt (active scan scope). A client is runnable when it
    has recon domains; scan targets are optional."""
    dpath = _client_dir(results_root, client) / "domains.txt"
    if not dpath.is_file():
        return None
    try:
        doms = load_domains(dpath)
    except OSError as e:
        log.warning("could not read %s: %s", dpath, e)
        return None
    return doms or None


def _ready_scope(results_root: Path, client: str) -> list[str] | None:
    """Recon scope for this client: the RECON domains (domains.txt) ONLY. Never
    falls back to targets.txt — those are the SCAN scope (IPs/CIDRs/hosts), and
    feeding them here made recon (emailenum/fileenum/subfinder/DKIM) run against
    an IP pulled from the targets list instead of the client's domain. A client
    with no domains.txt is simply not recon-ready."""
    return _ready_domains(results_root, client)


def _discover_clients(results_root: Path) -> list[str]:
    """Every campaign-managed client folder under the results root."""
    if not results_root.is_dir():
        return []
    return sorted(
        p.name for p in results_root.iterdir()
        if p.is_dir() and (p / CAMPAIGN_MARKER).exists()
    )


# ---- init -------------------------------------------------------------------

def cmd_campaign_configure(args) -> int:
    """Per-client setup cycle. Walks each client through the existing interview
    so every target's settings are locked in BEFORE the parallel run — matching
    the 'prepare fully, then run unattended' pattern.

    Two modes:
      - same:  run the interview once, copy the answers to every client.
      - each:  loop clients, run the interview per client, saving to that
               client's own recon_config.json. Declining a tool during a
               client's setup simply leaves it off for that client (no separate
               feature-flag machinery — skipping is the off switch).

    Why per-client: scan depth is a cost/scope decision that legitimately
    differs per client — a larger or regulated client may warrant the deep dive
    (employees, files, cloud infra) that a smaller client can't absorb.
    """
    from .recon_config import ReconConfig
    from .interview import run_interview
    results_root = Path(ReconConfig.load(args.recon_config).output_dir
                        if Path(args.recon_config).exists() else "results")

    clients = args.clients or [c for c in _discover_clients(results_root)
                               if _ready_scope(results_root, c)]
    if not clients:
        print(f"[campaign] no ready clients under {results_root}. "
              f"Run 'campaign init' and fill in targets first.")
        return 2

    # mode: same settings for all, or configure each individually?
    mode = getattr(args, "mode", None)
    if mode not in ("same", "each"):
        try:
            ans = input(f"[campaign] {len(clients)} clients. Configure "
                        f"[s]ame settings for all, or [e]ach individually? "
                        f"[s/e] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print("\n[campaign] cancelled.")
            return 1
        mode = "each" if ans.startswith("e") else "same"

    if mode == "same":
        # configure once against the first client, then copy to the rest
        lead = clients[0]
        cfg, cpath = _client_config(results_root, lead, args.recon_config)
        print(f"[campaign] configuring shared settings (via {lead})…")
        run_interview(cfg=cfg, domains=_ready_scope(results_root, lead),
                      config_path=str(cpath))
        shared = ReconConfig.load(cpath)
        for c in clients:
            cfg_c, cpath_c = _client_config(results_root, c, args.recon_config)
            # copy shared answers but keep each client's own engagement/domains
            shared.engagement_name = c
            shared.domains_file = str(results_root / c / "domains.txt")
            shared.dump(cpath_c)
        print(f"[campaign] applied shared settings to {len(clients)} clients.")
    else:
        # API keys are shared across a whole campaign: enter them once (on the
        # first client that has them) and they carry to every other client's
        # config automatically. Each client still gets its own preflight for the
        # per-client settings (wordlist sizes, cloud depth, tool modes) — only the
        # keys are copied. We accumulate keys after each client's interview and
        # seed them into the next client's config BEFORE its interview, so the
        # interview sees them as already-set and doesn't re-ask.
        _API_KEY_FIELDS = ("serpapi_key", "snov_client_id", "snov_client_secret",
                           "grayhat_api_key", "shodan_api_key", "github_token",
                           "dehashed_api_key")
        carried: dict[str, str] = {}
        for c in clients:
            cfg, cpath = _client_config(results_root, c, args.recon_config)
            # seed any keys already collected from earlier clients into this one
            if carried:
                for k, v in carried.items():
                    setattr(cfg, k, v)
                cfg.dump(cpath)
            print(f"\n[campaign] === configuring {c} ===")
            run_interview(cfg=cfg, domains=_ready_scope(results_root, c),
                          config_path=str(cpath))
            # pick up any keys this client's interview just set, for the next ones
            fresh = ReconConfig.load(cpath)
            for k in _API_KEY_FIELDS:
                v = getattr(fresh, k, "")
                if v and k not in carried:
                    carried[k] = v
        print(f"[campaign] configured {len(clients)} clients individually.")
        if carried:
            print(f"[campaign] shared {len(carried)} API key(s) across all clients.")

    print("[campaign] all set. Launch with: campaign run "
          f"{' '.join(clients)}   (or --all)")
    return 0


def _client_config(results_root: Path, client: str, base_config: str):
    """Load-or-seed a client's own recon_config.json, tagged to that client.
    Returns (ReconConfig, path)."""
    from .recon_config import ReconConfig
    cdir = _client_dir(results_root, client)
    cdir.mkdir(parents=True, exist_ok=True)
    cpath = cdir / "recon_config.json"
    # Priority: this client's own config if it exists (re-configuring), else the
    # shared base config if the operator provided one that exists, else plain
    # defaults. The campaign flow uses 'campaign-init' (not 'engagement init'),
    # so there is usually NO top-level recon_config.json to fall back on — loading
    # the default "recon_config.json" path unconditionally is what raised
    # FileNotFoundError. Seed from ReconConfig() defaults instead of crashing.
    if cpath.exists():
        cfg = ReconConfig.load(cpath)
    elif base_config and Path(base_config).exists():
        cfg = ReconConfig.load(base_config)
    else:
        cfg = ReconConfig()
    cfg.engagement_name = client
    cfg.domains_file = str(cdir / "domains.txt")
    cfg.dump(cpath)
    return cfg, cpath


def cmd_campaign_init(args) -> int:
    from .recon_config import ReconConfig
    results_root = Path(ReconConfig.load(args.recon_config).output_dir
                        if Path(args.recon_config).exists() else "results")
    results_root.mkdir(parents=True, exist_ok=True)

    # Names can come as args (unchanged) or, if none were passed, be collected
    # interactively. For EACH client we also capture the client's domain(s) — the
    # apex domain(s) recon runs against (subfinder/dnsrecon/DKIM/etc.). These go
    # into the client's domains.txt and are SEPARATE from targets.txt (the active
    # scan scope: IPs/CIDRs/hosts). The run must never conflate the two.
    clients = list(args.clients or [])
    # {client_name: [domains]} — domains only collected interactively; when names
    # are passed as args we leave domains for the operator to fill in domains.txt.
    client_domains: dict[str, list[str]] = {}
    client_nessus: dict[str, str] = {}   # client -> source folder of .nessus files
    if not clients:
        print("[campaign] Enter each client, then its domain(s).")
        print("           Client name blank = done. Domains one per line, "
              "blank = next client.")
        while True:
            try:
                name = input("\n  client name> ").strip()
            except (EOFError, KeyboardInterrupt):
                print()
                break
            if not name:
                break
            doms: list[str] = []
            while True:
                try:
                    d = input(f"    domain for {name} (e.g. example.com, "
                              f"blank = done)> ").strip()
                except (EOFError, KeyboardInterrupt):
                    print()
                    break
                if not d:
                    break
                doms.append(d.rstrip(".").lower())
            clients.append(name)
            client_domains[name] = doms
            # Nessus: ask where this client's .nessus file(s) live and copy them
            # into the client's own folder now. Copying (vs storing a path) means
            # each client physically has its own Nessus files, so 'configure
            # --mode same' can share every other setting without the Nessus files
            # colliding. The run auto-discovers .nessus inside the client folder.
            try:
                npath = input(f"    Nessus folder for {name} "
                              f"(blank = none)> ").strip()
            except (EOFError, KeyboardInterrupt):
                npath = ""
            client_nessus[name] = npath
        if not clients:
            print("[campaign] no client names given — nothing to initialize.")
            return 2
    args.clients = clients   # so the closing 'run' hint prints the real names

    made, existed = [], []
    for client in clients:
        client = client.strip().rstrip(".").lower()
        if not client:
            continue
        cdir = _client_dir(results_root, client)
        tpath = cdir / TARGETS_NAME
        dpath = cdir / "domains.txt"
        cdir.mkdir(parents=True, exist_ok=True)
        (cdir / CAMPAIGN_MARKER).write_text(
            f"created {time.strftime(_STAMP)}\n")
        if tpath.exists():
            existed.append(client)
        else:
            tpath.write_text(
                "# Active-scan scope: one target per line (host, IP, or CIDR).\n"
                "# This is what nmap/nuclei/ffuf/feroxbuster hit. SEPARATE from\n"
                "# domains.txt (recon). '#' comments ignored. Optional — leave\n"
                "# empty to run recon-only on the domain(s).\n")
            made.append(client)
        # Write the client's domain(s) to domains.txt — the recon scope. If the
        # operator gave domains interactively, use them. Otherwise default to the
        # CLIENT NAME (which is normally the domain, e.g. client 'acme.com') so
        # domains.txt always has real, usable content and the client is recon-ready
        # without extra steps. NEVER copy targets.txt into here.
        doms = client_domains.get(client, [])
        if doms:
            dpath.write_text("\n".join(doms) + "\n")
        elif not dpath.exists():
            # default: the client name as the domain (edit the file if it differs)
            dpath.write_text(client + "\n")
        # Create this client's own recon_config.json NOW, at init, so the path
        # exists and is located per client before anything runs (seeded from the
        # base config if one exists, else defaults; configure fills it in later).
        _client_config(results_root, client, args.recon_config)
        # Copy this client's .nessus file(s) into the client folder so the run
        # picks them up by discovery (rglob "*.nessus" in the client dir). Each
        # client thus has its OWN Nessus files on disk — no shared path to collide
        # under 'configure --mode same'.
        src = (client_nessus.get(client) or "").strip()
        if src:
            srcdir = Path(src).expanduser()
            if srcdir.is_dir():
                nfiles = sorted(p for p in srcdir.iterdir()
                                if p.is_file() and p.suffix.lower() == ".nessus")
                if nfiles:
                    import shutil as _sh
                    for p in nfiles:
                        try:
                            _sh.copy2(p, cdir / p.name)
                        except OSError as e:
                            print(f"[campaign] {client}: could not copy {p.name}: {e}")
                    print(f"[campaign] {client}: copied {len(nfiles)} "
                          f".nessus file(s) into {cdir}")
                else:
                    print(f"[campaign] {client}: no .nessus files in {srcdir}")
            else:
                print(f"[campaign] {client}: not a directory: {srcdir}")

    if made:
        print(f"[campaign] prepared {len(made)} client folder(s): "
              f"{', '.join(made)}")
    if existed:
        print(f"[campaign] already existed (left as-is): {', '.join(existed)}")
    print(f"\nNext: fill in each client's {TARGETS_NAME} (scan scope) and "
          f"domains.txt (recon scope) under\n{results_root}/<client>/ as needed, "
          f"then run them by name:\n"
          f"    python -m prima_materia campaign run {' '.join(args.clients)}\n"
          f"(or 'campaign run --all' to run every ready client at once)\n")
    return 0


# ---- status -----------------------------------------------------------------

def _phase0_in_progress(results_root: Path, client: str) -> bool:
    """True if phase 0 (nmap + web fuzzers) is running for this client — its
    phase0_state.json exists and isn't marked completed. Phase 0 runs BEFORE the
    recon engine writes recon_state.json, so without this a scanning client looks
    'ready' and could be double-launched by a second `campaign run`."""
    f = _client_dir(results_root, client) / "phase0_state.json"
    try:
        import json
        d = json.loads(f.read_text())
        return isinstance(d, dict) and not d.get("completed", False)
    except (ValueError, OSError):
        return False


def _state_of(results_root: Path, client: str) -> str:
    """ready | not-ready | done | running (best-effort, from files on disk)."""
    cdir = _client_dir(results_root, client)
    if _is_completed(results_root, client):
        return "done"
    # a live run keeps recon_state.json fresh; we don't track PIDs, so this is a
    # heuristic — presence of state without a report means "in progress or
    # interrupted". Good enough for a glance.
    if (cdir / "recon_state.json").exists():
        return "running/partial"
    if _phase0_in_progress(results_root, client):
        return "running (scan)"
    return "ready" if _ready_scope(results_root, client) else "not-ready"


def cmd_campaign_status(args) -> int:
    from .recon_config import ReconConfig
    results_root = Path(ReconConfig.load(args.recon_config).output_dir
                        if Path(args.recon_config).exists() else "results")
    clients = _discover_clients(results_root)
    if not clients:
        print(f"[campaign] no campaign clients under {results_root}. "
              f"Run 'campaign init <client> ...' first.")
        return 0
    print(f"[campaign] {len(clients)} client(s) under {results_root}:\n")
    for c in clients:
        state = _state_of(results_root, c)
        tgts = _ready_targets(results_root, c)
        n = len(tgts) if tgts else 0
        print(f"  {c:<28} {state:<16} {n} target(s)")
    return 0


DONE_MARKER = ".campaign_complete"


def _is_completed(results_root: Path, client: str) -> bool:
    """A client is 'completed' if it has the explicit done-marker (written only
    when a run truly finishes) OR, as a fallback, a final report. Running it
    again would redo an expensive engagement, so campaign won't without --force."""
    cdir = _client_dir(results_root, client)
    return (cdir / DONE_MARKER).exists() or (cdir / "final_report.xlsx").exists()


def _has_partial_state(results_root: Path, client: str) -> bool:
    """Has run state but no final report: interrupted or crashed mid-run. Also
    NOT auto-eligible — resuming vs leaving it is the operator's call, so we make
    them name it explicitly rather than silently re-running."""
    cdir = _client_dir(results_root, client)
    running = ((cdir / "recon_state.json").exists()
               or _phase0_in_progress(results_root, client))
    return running and not _is_completed(results_root, client)


# ---- run --------------------------------------------------------------------

def cmd_campaign_run(args) -> int:
    from .recon_config import ReconConfig
    results_root = Path(ReconConfig.load(args.recon_config).output_dir
                        if Path(args.recon_config).exists() else "results")

    named = list(args.clients or [])
    run_all = getattr(args, "all", False)
    force = getattr(args, "force", False)

    # ---- decide WHICH clients, explicitly. Never sweep up everyone silently. ----
    if named:
        clients = named                       # explicit names always win
    elif run_all:
        clients = _discover_clients(results_root)   # opt-in "everyone" path
    else:
        # no names, no --all: refuse to sweep, but be helpful. First, auto-detect
        # clients that were interrupted (have run state but no done-marker) — a
        # power-out or crash leaves these — and offer to resume them, since that's
        # the most likely reason someone runs a bare 'campaign run' after a stop.
        interrupted = [c for c in _discover_clients(results_root)
                       if _has_partial_state(results_root, c)
                       and _ready_scope(results_root, c)]
        candidates = [c for c in _discover_clients(results_root)
                      if _ready_scope(results_root, c)
                      and not _is_completed(results_root, c)
                      and c not in interrupted]

        if interrupted:
            print(f"[campaign] {len(interrupted)} client(s) look interrupted "
                  f"(state on disk, not finished): {', '.join(interrupted)}")
            try:
                ans = input("[campaign] resume them now? [y/N] ").strip().lower()
            except (EOFError, KeyboardInterrupt):
                ans = "n"
            if ans == "y":
                # resume = run those clients; each orchestrator skips completed
                # tools and continues where it left off (no re-spend).
                args.clients = interrupted
                return cmd_campaign_run(args)
            print("[campaign] left interrupted clients as-is. To resume later: "
                  f"campaign run {' '.join(interrupted)}")

        if not candidates and not interrupted:
            print(f"[campaign] nothing new to run under {results_root}. "
                  f"('campaign status' shows why.)")
            return 0
        if candidates:
            print("[campaign] refusing to run all clients implicitly. Ready to run:")
            for c in candidates:
                n = len(_ready_scope(results_root, c) or [])
                print(f"    {c:<24} {n} target(s)")
            print(f"\nName them:   python -m prima_materia campaign run "
                  f"{' '.join(candidates)}")
            print(f"Or all:      python -m prima_materia campaign run --all")
        return 2

    if not clients:
        print(f"[campaign] no clients under {results_root}. "
              f"Run 'campaign init' first, or pass client names.")
        return 2

    # ---- classify each requested client, before spawning anything ----
    ready: list[tuple[str, list[str]]] = []
    not_ready: list[str] = []
    no_targets: list[str] = []
    completed: list[str] = []
    partial: list[str] = []
    for c in clients:
        # Runnable = has RECON domains (domains.txt). The child's recon engine
        # consumes these. We do NOT fall back to targets.txt here — those are scan
        # scope (IPs/CIDRs), and passing them as the recon domain made emailenum/
        # fileenum run against an IP from the targets list instead of the domain.
        domains = _ready_scope(results_root, c)
        if not domains:
            not_ready.append(c)
            continue
        # HARD REQUIREMENT: scan targets must exist too (targets.txt). Refuse to
        # launch a client with no targets — recon-only runs are disabled, so a child
        # is never spawned to burn a day/credits with nothing to scan.
        if not _ready_targets(results_root, c):
            no_targets.append(c)
            continue
        if _is_completed(results_root, c) and not force:
            completed.append(c)               # done already — needs --force
            continue
        if _has_partial_state(results_root, c) and not (force or c in named):
            # interrupted: only run if forced OR named explicitly (a bare --all
            # won't silently resume a half-finished run)
            partial.append(c)
            continue
        ready.append((c, domains))

    if not_ready:
        print(f"[campaign] skipping {len(not_ready)} with no recon domains "
              f"(domains.txt empty/missing): {', '.join(not_ready)}")
    if no_targets:
        print(f"[campaign] skipping {len(no_targets)} with NO scan targets "
              f"({TARGETS_NAME} empty — targets are REQUIRED, recon-only is off): "
              f"{', '.join(no_targets)}")
    if completed:
        print(f"[campaign] skipping {len(completed)} already-completed "
              f"(use --force to re-run): {', '.join(completed)}")
    if partial:
        print(f"[campaign] skipping {len(partial)} interrupted/partial — name "
              f"explicitly or --force to resume: {', '.join(partial)}")
    if not ready:
        print("[campaign] nothing to launch.")
        return 2

    print(f"[campaign] launching {len(ready)} run(s), "
          f"max {args.max_parallel} at a time:")
    for c, d in ready:
        print(f"    {c}: {len(d)} target(s)")
    if args.dry_run:
        print("[campaign] --dry-run: not spawning. Each would run:")
        for c, _ in ready:
            print(f"    (engagement={c})  python -m prima_materia recon "
                  f"--config {results_root}/{c}/recon_config.json --no-prompt")
        return 0

    # ---- spawn with a concurrency cap ----
    running: dict[str, subprocess.Popen] = {}
    queue = list(ready)
    results: dict[str, int] = {}

    def _launch(client: str, domains: list[str]) -> subprocess.Popen:
        cdir = _client_dir(results_root, client)
        cdir.mkdir(parents=True, exist_ok=True)
        # domains.txt is the RECON scope (client apex domains), written at init and
        # editable by the operator. It is NOT the scan targets — do NOT overwrite
        # it with targets.txt (that conflation fed IPs/CIDRs to subfinder/DKIM and
        # produced garbage). If for some reason it's missing/empty (older folder,
        # never set), fall back to the passed-in list so recon still has scope.
        domains_path = cdir / "domains.txt"
        existing = load_domains(domains_path) if domains_path.is_file() else []
        if not existing and domains:
            domains_path.write_text("\n".join(domains) + "\n")
        # Load THIS CLIENT'S OWN config if 'campaign configure' already wrote one
        # (results/<client>/recon_config.json) — that file holds the per-client
        # settings (wordlist sizes, cloud_enum depth, which tools/keys were set).
        # Only fall back to the shared base config for a client that was never
        # configured. Loading the base config here unconditionally is what used
        # to CLOBBER the configured file, so every client ran the global defaults.
        cfg_path = cdir / "recon_config.json"
        if cfg_path.exists():
            rcfg = ReconConfig.load(str(cfg_path))          # preserve configured settings
        elif args.recon_config and Path(args.recon_config).exists():
            rcfg = ReconConfig.load(args.recon_config)      # never configured -> base
        else:
            rcfg = ReconConfig()                            # no base file either -> defaults
        # Only override the things that MUST be per-client; leave every other
        # configured field untouched.
        rcfg.engagement_name = client
        rcfg.domains_file = str(domains_path)
        # Pin output_dir to the SAME results_root the dashboard reads from. The
        # child writes recon_state.json to <output_dir>/<engagement_name>; the
        # dashboard reads <results_root>/<client>. If these disagree (they did:
        # ReconConfig defaults output_dir to "recon_results" while the scan side's
        # Config defaults to "results"), the child writes state one place and the
        # dashboard watches another — so the progress bars never fill even though
        # the scan is running fine. Pinning it makes both point at the same dir.
        rcfg.output_dir = str(results_root)
        rcfg.dump(cfg_path)
        logf = open(cdir / "campaign_run.log", "w")
        cmd = [sys.executable, "-m", "prima_materia", "recon",
               "--config", str(cfg_path), "--no-prompt",
               "--with-scan", "--yes"]
        log.info("start %s -> %s", client, cdir)
        return subprocess.Popen(cmd, stdout=logf, stderr=subprocess.STDOUT)

    # ---- optional live dashboard (default on when attached to a terminal) ----
    import sys as _sys
    _want_dash = getattr(args, "dashboard", None)
    if _want_dash is None:
        _want_dash = _sys.stdout.isatty()      # auto: panel when interactive
    dash = None
    if _want_dash:
        try:
            from .campaign_dashboard import CampaignDashboard
            _configs = {}
            for c, _ in ready:
                cp = _client_dir(results_root, c) / "recon_config.json"
                if cp.exists():
                    try:
                        _configs[c] = ReconConfig.load(str(cp))
                    except Exception:
                        pass
            dash = CampaignDashboard(results_root, [c for c, _ in ready], _configs)
        except Exception as _e:  # noqa: BLE001 — never let the panel break the run
            print(f"[campaign] dashboard unavailable ({_e}); running headless.")
            dash = None

    try:
        while queue or running:
            while queue and len(running) < args.max_parallel:
                client, domains = queue.pop(0)
                running[client] = _launch(client, domains)
            # poll
            time.sleep(1)
            for client in list(running):
                rc = running[client].poll()
                if rc is not None:
                    results[client] = rc
                    del running[client]
                    if dash is None:
                        # headless: keep the old per-client completion line
                        tag = "ok" if rc == 0 else f"FAILED (exit {rc})"
                        print(f"[campaign] {client}: {tag}")
            if dash is not None:
                dash.render_once()
    except KeyboardInterrupt:
        print("\n[campaign] interrupted — terminating child runs...")
        for client, proc in running.items():
            proc.terminate()
        return 130

    ok = sum(1 for rc in results.values() if rc == 0)
    print(f"\n[campaign] done: {ok}/{len(results)} succeeded. "
          f"Reports under {results_root}/<client>/final_report.xlsx")
    return 0 if ok == len(results) else 1
