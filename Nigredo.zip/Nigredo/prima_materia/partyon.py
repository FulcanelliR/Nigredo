#!/usr/bin/env python3
"""PartyOn breach/credential lookup (phase 2) — replaces the old dehashed tool.

Runs an external PartyOn.py script:

    python3 PartyOn.py <domain> --url <proxy> --verbose -s <seconds>

Prompts at run time for:
  1. domain      -- confirm the engagement's primary domain [Y/n]; n = manual
  2. --url       -- proxy URL (REQUIRED; won't run without it)
  3. -s          -- delay in seconds (always entered, minimum 3)

Needs a DeHashed API key (config dehashed_api_key / env DEHASHED_API_KEY). If it
isn't set, the tool alerts on first run and offers to save it to the config.

RAW OUTPUT ONLY for now: the script's stdout and any file it writes are saved to
the engagement folder; parsing/report tabs come later. The DeHashed key is
passed to the subprocess via the environment (not the command line) so it never
lands in the command log. Skips safely if the script isn't found.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path


def _resolve_script(script: str) -> str | None:
    if shutil.which(script):
        return script
    if Path(script).is_file():
        return str(Path(script).resolve())
    if shutil.which("PartyOn.py"):
        return "PartyOn.py"
    return None


def _prompt_domain(primary: str) -> str:
    from .runmode import is_unattended, answer
    if is_unattended():
        return answer("partyon_domain", primary) or primary
    if not primary:
        try:
            return input("  PartyOn target domain: ").strip()
        except EOFError:
            return ""
    try:
        ans = input(f"  Use '{primary}' for PartyOn? [Y/n]: ").strip().lower()
    except EOFError:
        return primary
    if ans in ("", "y", "yes"):
        return primary
    try:
        return input("  Enter the domain to use: ").strip()
    except EOFError:
        return ""


def _prompt_proxy() -> str:
    from .runmode import is_unattended, answer, stash
    cached = answer("partyon_proxy", "")
    if cached:
        return cached                       # reuse across a multi-domain loop
    if is_unattended():
        return ""
    try:
        val = input("  Proxy URL for PartyOn (--url, required): ").strip()
    except EOFError:
        return ""
    if val:
        stash("partyon_proxy", val)         # ask once, reuse for the rest of the run
    return val


def _prompt_seconds(minimum: int = 3) -> int:
    from .runmode import is_unattended, answer, stash
    cached = answer("partyon_seconds", None)
    if cached is not None:
        try:
            return max(int(cached), minimum)
        except (ValueError, TypeError):
            return minimum
    if is_unattended():
        return minimum
    while True:
        try:
            raw = input(f"  Delay in seconds (-s, min {minimum}): ").strip()
        except EOFError:
            return minimum
        try:
            val = int(raw)
        except ValueError:
            print(f"    enter a whole number >= {minimum}")
            continue
        if val < minimum:
            print(f"    minimum is {minimum} seconds")
            continue
        stash("partyon_seconds", val)        # ask once, reuse for the rest of the run
        return val


def process(domain, outdir, command_log, primary_domain="",
            script="PartyOn.py", api_key="", config_path=None,
            ledger=None, dry_run=False, confirm_domain=True, spray=None,
            proxy=None, seconds=None):
    """Run PartyOn for a domain. Returns the raw output path (or None).

    confirm_domain=True  -> standalone/manual use: confirm the target interactively.
    confirm_domain=False -> carriage-driven: use `domain` EXACTLY as given, with no
                            prompt and no primary-domain fallback. This is what lets
                            the carriage loop PartyOn across several domains without
                            every run collapsing back onto the primary domain.
    spray=None  -> read the preflight choice (runmode 'partyon_spray'); default off.
    spray=False -> DeHashed results only: no --url, answer PartyOn's spray prompt
                   with 'no' so the credential-spray engine does NOT fire.
    spray=True  -> full harvest + spray: pass --url (if a proxy is set) and answer
                   PartyOn's spray prompt with ENTER so the spray engine fires."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    resolved = _resolve_script(script)
    if resolved is None and not dry_run:
        print(f"[partyon] '{script}' not found on PATH or as a file — skipping")
        return None

    # DeHashed key: config/env/interview, else alert + offer to save
    from .runmode import answer as _rm_answer
    api_key = api_key or os.getenv("DEHASHED_API_KEY", "") or _rm_answer("dehashed_api_key", "")
    if not api_key and not dry_run:
        from .runmode import is_unattended
        print("[partyon] no DeHashed API key set (dehashed_api_key / "
              "DEHASHED_API_KEY).")
        if is_unattended():
            print("[partyon] unattended + no key — skipping PartyOn")
            return None
        try:
            entered = input("  Enter DeHashed API key now (blank to skip PartyOn): ").strip()
        except EOFError:
            entered = ""
        if not entered:
            print("[partyon] no key provided — skipping")
            return None
        api_key = entered
        # offer to persist it to the config for next time
        if config_path:
            try:
                save = input("  Save this key to the config for next time? [Y/n]: ").strip().lower()
            except EOFError:
                save = "n"
            if save in ("", "y", "yes"):
                _save_key_to_config(config_path, entered)
                print(f"  saved to {config_path}")

    # spray mode: DeHashed-results-only (default) vs full harvest + credential
    # spray. Read the preflight choice unless the caller forced it.
    if spray is None:
        spray = bool(_rm_answer("partyon_spray", False))

    # runtime prompts: domain -> (proxy + seconds only when spraying)
    if dry_run or not confirm_domain:
        # carriage-driven (or dry-run): use exactly the domain we were handed, so a
        # multi-domain loop targets each domain instead of collapsing onto primary.
        target = domain
    else:
        target = _prompt_domain(domain)
    if not target:
        print("[partyon] no domain — skipping")
        return None
    # The proxy/--url is ONLY used by the spray engine. Results-only runs without it
    # (PartyOn pulls DeHashed + builds its workbook fine with no --url), so we don't
    # require or prompt for a proxy in results-only mode.
    proxy_val, seconds_val = "", 3
    if spray:
        # Caller (the campaign orchestrator) may pass proxy/seconds straight from
        # the client's config so the unattended child doesn't depend on an
        # interview stash it never ran. Fall back to the prompt/stash path for
        # standalone/manual use (proxy=None/seconds=None).
        if proxy is not None:
            proxy_val = proxy if not dry_run else "<proxy>"
        else:
            proxy_val = _prompt_proxy() if not dry_run else "<proxy>"
        if seconds is not None:
            try:
                seconds_val = max(int(seconds), 3)
            except (TypeError, ValueError):
                seconds_val = 3
        else:
            seconds_val = _prompt_seconds() if not dry_run else 3
    proxy, seconds = proxy_val, seconds_val
    print(f"[partyon] mode: {'FULL harvest + credential spray' if spray else 'DeHashed results only (no spray)'}")

    safe = target.replace("/", "_")
    stdout_file = outdir / f"partyon_{safe}.stdout.txt"

    if resolved and resolved.endswith(".py"):
        import sys
        cmd = [sys.executable, resolved]
    else:
        cmd = [resolved or script]
    cmd += [target]
    if spray and proxy:
        cmd += ["--url", proxy]
    cmd += ["--verbose", "-s", str(seconds)]

    # log WITHOUT the key (key goes via env, not the command line)
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + f"  > {stdout_file}  (DEHASHED_API_KEY via env)\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd), ">", stdout_file)
        return None

    env = dict(os.environ)
    if api_key:
        env["DEHASHED_API_KEY"] = api_key

    _via = f"via proxy (delay {seconds}s)" if (spray and proxy) else "(no proxy)"
    print(f"[partyon] running against {target} {_via}")
    try:
        # PartyOn asks two prompts in a stable order:
        #   1) "Proceed with the full harvest ...? (y/N)"       -> always 'y'
        #   2) "... ENTER to fire the spray engine or 'no' ..." -> ENTER if spraying,
        #                                                          'no' to abort spray
        stdin_feed = "y\n\n" if spray else "y\nno\n"
        res = subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                             env=env, cwd=str(outdir), input=stdin_feed, timeout=3600)
        stdout_file.write_text((res.stdout or "") + (res.stderr or ""))
        print(f"[\u2713] partyon raw output -> {stdout_file}")
        # DeHashed runs inside the PartyOn subprocess, so we can't see its exact
        # per-query credit use; record one domain-search unit as an estimate.
        if ledger is not None:
            try:
                ledger.record("dehashed", 1, kind="estimated",
                              note=f"PartyOn/DeHashed lookup / {target}")
            except Exception as e:  # noqa: BLE001
                print(f"[partyon] {e}")
    except subprocess.TimeoutExpired:
        stdout_file.write_text("partyon timed out after 3600s\n")
        print("[partyon] timed out (60m)")
    except Exception as e:  # noqa: BLE001
        stdout_file.write_text(f"partyon error: {e}\n")
        print(f"[partyon] error: {e}")
    return stdout_file if stdout_file.exists() else None


def _save_key_to_config(config_path, key):
    """Persist the DeHashed key into the JSON config file."""
    import json
    try:
        p = Path(config_path)
        cfg = json.loads(p.read_text()) if p.exists() else {}
        cfg["dehashed_api_key"] = key
        p.write_text(json.dumps(cfg, indent=2))
    except Exception as e:  # noqa: BLE001
        print(f"  [partyon] could not save key to config: {e}")
