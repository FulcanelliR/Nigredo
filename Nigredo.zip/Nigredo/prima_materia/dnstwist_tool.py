"""dnstwist runner + output cleaner.

Goal: for each apex domain, get the REGISTERED lookalike/permutation domains
(typosquats, homographs, etc.) and clean the noisy output down to what matters.

We run `--registered --format json`, which restricts results to permutations that
are actually registered, then parse the JSON into a compact per-domain view:
the lookalike domain, what it resolves to (A / NS / MX), which fuzzer generated
it, and optional WHOIS registrar/creation date.

These are intel/report artifacts only — lookalike domains are third-party owned
and are NEVER fed to the active scanning phases.

dnstwist JSON fields (current versions): "domain" (the permutation; older builds
use "domain-name"), "fuzzer", "dns_a"/"dns-a", "dns_ns"/"dns-ns",
"dns_mx"/"dns-mx", "whois_registrar", "whois_created".
"""
from __future__ import annotations

import json
import shutil
import subprocess
import time
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class TwistHit:
    fuzzer: str = ""          # 1) type (permutation algorithm; "*original" for apex)
    domain: str = ""          # 2) the lookalike domain
    registrar: str = ""       # 3) WHOIS registrar
    dns_ns: list[str] = field(default_factory=list)  # 4) NS records (lowercased, sorted)
    is_original: bool = False
    # backfill status flags (report/workbook only — not in raw JSON)
    ns_backfilled: bool = False       # NS filled in by a re-query
    ns_dead: bool = False             # NS re-query tried all methods, no answer
    registrar_backfilled: bool = False
    registrar_dead: bool = False      # WHOIS re-query yielded nothing
    registrar_uncapped: bool = False  # skipped WHOIS backfill (hit safety cap)


def _get(rec: dict, *keys) -> object:
    """Return the first present key's value (handles dns_a vs dns-a naming)."""
    for k in keys:
        if k in rec and rec[k]:
            return rec[k]
    return None


def _as_list(val) -> list[str]:
    if val is None:
        return []
    if isinstance(val, list):
        return [str(v) for v in val]
    return [str(val)]


def run_dnstwist(domain: str, outdir: Path, command_log: Path,
                 whois: bool = True, threads: int = 20,
                 whois_threads: int = 1, nameservers: str = "",
                 whois_timeout: int = 900, dry_run: bool = False) -> Path | None:
    """Run dnstwist --registered --format json on one domain. Returns JSON path.

    WHOIS is ON by default because the registrar is a required output field.
    It is the slow part of dnstwist AND the flaky part: WHOIS servers rate-limit
    hard, so firing many parallel lookups (the normal --threads value) makes most
    registrar lookups FAIL (blank/NA). dnstwist shares one thread pool for DNS
    and WHOIS, so when WHOIS is on we drop to `whois_threads` (default 1) to let
    the registrar actually come through. Without WHOIS, DNS uses the full
    `threads`. This trades speed for the registrar field you need.

    whois_timeout caps the whole dnstwist run (default 15 min) so a stalled WHOIS
    phase can't hang the engagement — partial output is kept.
    """
    safe = domain.replace("/", "_")
    json_out = outdir / f"dnstwist_{safe}.json"
    effective_threads = whois_threads if whois else threads
    cmd = ["dnstwist", "--registered", "--format", "json",
           "--threads", str(effective_threads)]
    if whois:
        cmd.append("--whois")
    if nameservers:
        cmd += ["--nameservers", nameservers]
    cmd += ["--output", str(json_out), domain]

    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + "\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd))
        return json_out
    # Timeout backstop: --whois at 1 thread does registrar lookups SERIALLY against
    # rate-limiting WHOIS servers, which can stall for a very long time on a domain
    # with many registered permutations. Without a cap it looks hung forever. The
    # cap lets a genuinely-slow WHOIS phase run a long while but not indefinitely;
    # on timeout we keep whatever dnstwist already wrote to --output.
    try:
        subprocess.run(cmd, check=False, timeout=whois_timeout)
    except subprocess.TimeoutExpired:
        print(f"[dnstwist] WHOIS phase exceeded {whois_timeout}s — moving on "
              f"(partial results kept). Lower --whois load or disable whois to speed up.")
    return json_out if json_out.exists() else None


def _ns_sort_key(name: str):
    """Natural sort key: split into text and numeric chunks so ns1 < ns2 < ns10
    rather than lexicographic ns1 < ns10 < ns2."""
    import re
    return [int(c) if c.isdigit() else c
            for c in re.split(r"(\d+)", name)]


def _sort_ns(ns_list: list[str]) -> list[str]:
    """Lowercase and natural-sort NS records, dropping dnstwist error markers
    and any stray IPs. dnstwist emits '!ServFail', '!NXDOMAIN', etc. when a
    lookup fails — these are NOT nameservers and must not appear in the output
    (they were the 'nonsense data' polluting the NS column). We also drop empty
    strings and anything that looks like an IP (NS records are hostnames)."""
    import re
    ip_re = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")           # IPv4
    cleaned = []
    for n in ns_list:
        if not n or not n.strip():
            continue
        v = n.strip().lower().rstrip(".")
        if v.startswith("!"):        # dnstwist error marker (!servfail, !nxdomain…)
            continue
        if ip_re.match(v) or ":" in v and not v.replace(":", "").isalpha():
            # skip IPv4 and IPv6-looking values (NS records are hostnames)
            if ip_re.match(v) or re.match(r"^[0-9a-f:]+$", v):
                continue
        cleaned.append(v)
    return sorted(set(cleaned), key=_ns_sort_key)


def _clean_registrar(value: str) -> str:
    """Return a clean registrar string, or '' if it's an error marker / junk.
    Guards against dnstwist error tokens or stray non-registrar data landing in
    this field."""
    v = (value or "").strip()
    if not v or v.startswith("!"):     # !ServFail etc.
        return ""
    import re
    # a bare IP is never a registrar (guards the 'IPs in registrar' symptom)
    if re.match(r"^\d{1,3}(\.\d{1,3}){3}$", v) or re.match(r"^[0-9a-f:]+$", v.lower()):
        return ""
    return v


def parse_hits(domain: str, json_path: Path) -> list[TwistHit]:
    try:
        data = json.loads(json_path.read_text())
    except (json.JSONDecodeError, FileNotFoundError):
        return []
    if not isinstance(data, list):
        return []

    hits: list[TwistHit] = []
    for rec in data:
        if not isinstance(rec, dict):
            continue
        name = _get(rec, "domain", "domain-name")
        if not name:
            continue
        fuzzer = str(_get(rec, "fuzzer") or "")
        is_original = fuzzer.lower() in ("*original", "original")
        hits.append(TwistHit(
            fuzzer=fuzzer,
            domain=str(name),
            registrar=_clean_registrar(_get(rec, "whois_registrar", "whois-registrar")),
            dns_ns=_sort_ns(_as_list(_get(rec, "dns_ns", "dns-ns"))),
            is_original=is_original,
        ))

    # Order: original row(s) first, then the rest sorted alphabetically by type
    # (fuzzer), with domain as a tiebreaker for stable output.
    originals = [h for h in hits if h.is_original]
    rest = sorted((h for h in hits if not h.is_original),
                  key=lambda h: (h.fuzzer.lower(), h.domain.lower()))
    return originals + rest


def write_csv(domain: str, hits: list[TwistHit], csv_path: Path) -> None:
    """Write the four cleaned fields to CSV: type, domain, registrar, ns_records.
    Opens cleanly in Excel. Multiple NS records are joined with '; ' within the
    single NS cell (csv quoting handles it, but '; ' avoids delimiter confusion)."""
    import csv
    with open(csv_path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["type", "domain", "registrar", "ns_records"])
        for h in hits:
            rtype = "original" if h.is_original else h.fuzzer
            writer.writerow([
                rtype,
                h.domain,
                h.registrar,
                "; ".join(h.dns_ns),
            ])


def clean_report(domain: str, hits: list[TwistHit]) -> str:
    lines = [f"=== Registered look-alike domains for {domain} ==="]
    if not hits:
        lines.append("  (no registered permutations found)")
        return "\n".join(lines) + "\n"

    # Build rows: type | domain | registrar | NS (joined). "*original" shown as
    # "original" for readability; it is pinned at top by parse_hits ordering.
    rows = []
    for h in hits:
        rtype = "original" if h.is_original else h.fuzzer
        rows.append([
            rtype,
            h.domain,
            h.registrar or "-",
            ", ".join(h.dns_ns) if h.dns_ns else "-",
        ])

    headers = ["TYPE", "DOMAIN", "REGISTRAR", "NS RECORDS"]
    # column widths (cap NS column so a long NS list doesn't blow out alignment)
    widths = [len(headers[i]) for i in range(4)]
    for r in rows:
        for i in range(3):  # type/domain/registrar get fully measured
            widths[i] = max(widths[i], len(r[i]))
    widths[3] = max(widths[3], len(headers[3]))

    def fmt(cols: list[str]) -> str:
        return "  ".join(
            cols[i].ljust(widths[i]) if i < 3 else cols[i]
            for i in range(4)
        )

    lines.append("")
    lines.append("  " + fmt(headers))
    lines.append("  " + fmt(["-" * widths[i] for i in range(3)] + ["-" * widths[3]]))
    for r in rows:
        lines.append("  " + fmt(r))
    lines.append("")
    return "\n".join(lines) + "\n"


def _needs_backfill(values: list[str]) -> bool:
    """True if a field is empty or holds a dnstwist error marker (any '!' token).
    dnstwist prefixes ALL its lookup errors with '!' (!ServFail, !NXDOMAIN,
    !Timeout, !Refused, ...), so this catches every error class + empties."""
    if not values:
        return True
    real = [v for v in values if v and v.strip() and not v.strip().startswith("!")]
    return len(real) == 0


def _backfill_ns(domain: str, timeout: int = 5) -> list[str]:
    """Directly re-query a domain's NS records, trying each method in turn until
    one answers: dnspython -> dig -> nslookup. Returns lowercased hostnames (the
    _sort_ns cleaning is applied by the caller). Empty list = genuinely no answer
    from any method (domain likely really dead)."""
    # 1) dnspython
    try:
        import dns.resolver  # type: ignore
        r = dns.resolver.Resolver()
        r.lifetime = timeout
        r.timeout = timeout
        ans = r.resolve(domain, "NS")
        out = [str(rr.target).rstrip(".").lower() for rr in ans]
        if out:
            return out
    except Exception:  # noqa: BLE001  (ImportError, NXDOMAIN, timeout, etc.)
        pass
    # 2) dig
    dig = shutil.which("dig")
    if dig:
        try:
            p = subprocess.run([dig, "NS", domain, "+short"],
                               capture_output=True, text=True, errors="replace", timeout=timeout + 2)
            out = [l.strip().rstrip(".").lower() for l in p.stdout.splitlines()
                   if l.strip() and not l.strip().startswith(";")]
            # dig +short NS returns hostnames; guard against stray non-NS lines
            out = [x for x in out if "." in x and not x[0].isdigit()]
            if out:
                return out
        except (OSError, subprocess.SubprocessError):
            pass
    # 3) nslookup
    ns = shutil.which("nslookup")
    if ns:
        try:
            p = subprocess.run([ns, "-type=NS", domain],
                               capture_output=True, text=True, errors="replace", timeout=timeout + 2)
            out = []
            for line in p.stdout.splitlines():
                # "example.com   nameserver = ns1.example.net."
                if "nameserver" in line.lower() and "=" in line:
                    val = line.split("=", 1)[1].strip().rstrip(".").lower()
                    if val:
                        out.append(val)
            if out:
                return out
        except (OSError, subprocess.SubprocessError):
            pass
    return []


def _backfill_registrar(domain: str, timeout: int = 10) -> str:
    """Re-query WHOIS for a domain's registrar, python-whois first then the
    `whois` CLI. Returns '' if neither yields a registrar.

    IMPORTANT: python-whois opens a raw socket with NO timeout of its own — if a
    WHOIS server accepts the connection but never replies, it hangs FOREVER. That
    was a real hang (dnstwist backfill wedging the whole run on a single lookup).
    So the python-whois call is run in a worker thread we can abandon after
    `timeout` seconds; the `whois` CLI path already has its own timeout.

    Tier order: RDAP (structured JSON, reliable, less rate-limited) FIRST, then
    python-whois, then whois-CLI grep. RDAP closes most of the ~10-30% of cases
    where WHOIS rate-limiting/thin-WHOIS returned a blank registrar.
    """
    # 0) RDAP — structured JSON over HTTPS, far more reliable than WHOIS and not
    #    as aggressively rate-limited. rdap.org redirects to the authoritative
    #    registry RDAP server for the TLD. The registrar name is in the
    #    'entities' array with role 'registrar'.
    try:
        import urllib.request as _u
        import json as _json
        req = _u.Request(f"https://rdap.org/domain/{domain}",
                         headers={"User-Agent": "nigredo-dnstwist"})
        with _u.urlopen(req, timeout=timeout) as resp:
            data = _json.loads(resp.read().decode("utf-8", "replace"))
        for ent in data.get("entities", []):
            roles = ent.get("roles", [])
            if "registrar" in roles:
                # registrar name lives in the vcardArray -> 'fn' entry
                vcard = ent.get("vcardArray", [])
                if len(vcard) > 1:
                    for field in vcard[1]:
                        if len(field) >= 4 and field[0] == "fn":
                            reg = _clean_registrar(str(field[3] or ""))
                            if reg:
                                return reg
                # fallback: some registries put it in a handle/publicIds
                pid = ent.get("publicIds", [])
                for p in pid:
                    if p.get("type", "").lower().startswith("iana"):
                        # publicId is the IANA number, not the name — skip
                        pass
    except Exception:  # noqa: BLE001
        pass  # RDAP miss -> fall through to WHOIS tiers

    # 1) python-whois — guarded with a hard timeout via a worker thread
    def _py_whois():
        import whois as _whois  # type: ignore
        w = _whois.whois(domain)
        reg = w.get("registrar") if isinstance(w, dict) else getattr(w, "registrar", None)
        if isinstance(reg, list):
            reg = reg[0] if reg else ""
        return _clean_registrar(str(reg or ""))

    try:
        import concurrent.futures as _cf
        # NOTE: do NOT use `with ThreadPoolExecutor(...)` — its __exit__ blocks
        # waiting for the worker to finish, which re-introduces the very hang we're
        # preventing. Create it, grab the result with a timeout, and on timeout
        # shut down WITHOUT waiting (the daemon worker is abandoned to die later).
        ex = _cf.ThreadPoolExecutor(max_workers=1)
        fut = ex.submit(_py_whois)
        try:
            reg = fut.result(timeout=timeout)
            ex.shutdown(wait=False)
            if reg:
                return reg
        except _cf.TimeoutError:
            ex.shutdown(wait=False)     # abandon the wedged lookup, don't block
    except Exception:  # noqa: BLE001
        pass
    # 2) whois CLI
    cli = shutil.which("whois")
    if cli:
        try:
            p = subprocess.run([cli, domain], capture_output=True,
                               text=True, errors="replace", timeout=timeout)
            for line in p.stdout.splitlines():
                low = line.lower()
                if "registrar:" in low and "url" not in low and "iana" not in low:
                    val = line.split(":", 1)[1].strip()
                    val = _clean_registrar(val)
                    if val:
                        return val
        except (OSError, subprocess.SubprocessError):
            pass
    return ""


def backfill_hits(hits: list[TwistHit], whois_delay: float = 2.0,
                  whois_cap: int = 100, ns_delay: float = 0.2,
                  verbose: bool = True) -> list[TwistHit]:
    """Fill in NS/registrar for hits where dnstwist's bulk run failed (!error or
    empty). Modifies the hits in place (report/workbook only — raw JSON is never
    touched). WHOIS is throttled (whois_delay between lookups) and capped
    (whois_cap per run) to avoid tripping WHOIS server rate-limits/bans; NS uses
    a lighter delay. Marks still-failed lookups so 'we tried, it's dead' is
    distinguishable from 'not looked up'."""
    ns_todo = [h for h in hits if _needs_backfill(h.dns_ns)]
    reg_todo = [h for h in hits if _needs_backfill([h.registrar])]

    if verbose and (ns_todo or reg_todo):
        print(f"[dnstwist] backfilling {len(ns_todo)} NS + {len(reg_todo)} "
              f"registrar gap(s) from failed lookups "
              f"(WHOIS capped at {whois_cap}, {whois_delay}s apart)")

    # NS backfill (DNS — light throttle)
    for h in ns_todo:
        found = _backfill_ns(h.domain)
        if found:
            h.dns_ns = _sort_ns(found)
            h.ns_backfilled = True
        else:
            h.dns_ns = []             # clear the !error token; show clean/empty
            h.ns_dead = True          # tried all methods, genuinely no answer
        if ns_delay:
            time.sleep(ns_delay)

    # Registrar backfill (WHOIS — strict throttle + cap to avoid bans)
    whois_done = 0
    for h in reg_todo:
        if whois_done >= whois_cap:
            h.registrar_uncapped = True   # would've tried but hit the safety cap
            continue
        reg = _backfill_registrar(h.domain)
        whois_done += 1
        if reg:
            h.registrar = reg
            h.registrar_backfilled = True
        else:
            h.registrar_dead = True
        time.sleep(whois_delay)

    if verbose and reg_todo:
        print(f"[dnstwist] WHOIS backfill used {whois_done}/{whois_cap} lookups")
    return hits


def process_domain(domain: str, outdir: Path, command_log: Path,
                   whois: bool = False, backfill: bool = True,
                   whois_delay: float = 2.0, whois_cap: int = 100,
                   dry_run: bool = False) -> str:
    json_out = run_dnstwist(domain, outdir, command_log, whois=whois, dry_run=dry_run)
    if dry_run or json_out is None:
        return ""
    hits = parse_hits(domain, json_out)
    # Backfill failed NS/registrar lookups (report + workbook only; raw JSON
    # stays as dnstwist emitted it). The registrar backfill is RDAP-FIRST, which
    # is fast and reliable (NOT the slow hang-prone WHOIS), so we run it even when
    # dnstwist's own --whois is OFF — otherwise the Registrar column comes back
    # totally blank (dnstwist without --whois emits no registrar, and capping the
    # backfill at 0 meant nothing filled it). Keep the safety cap to avoid bans.
    if backfill:
        backfill_hits(hits, whois_delay=whois_delay, whois_cap=whois_cap)
    safe = domain.replace("/", "_")
    # CSV is the primary cleaned artifact (opens in Excel for the workbook);
    # the aligned text report is kept for quick terminal review.
    write_csv(domain, hits, outdir / f"dnstwist_{safe}.csv")
    report = clean_report(domain, hits)
    (outdir / f"dnstwist_{safe}.txt").write_text(report)
    return report
