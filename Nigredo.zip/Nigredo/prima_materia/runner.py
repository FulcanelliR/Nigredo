"""Phase runner: builds and executes nmap commands for each scan phase.

Always emits XML (-oX) so the handoff between phases is structured data, never
scraped stdout. Each phase is a thin, explicit command builder so the exact
nmap invocation is auditable and reproducible from the saved command log.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path

from .config import Config, PhaseParams


class NmapNotFound(Exception):
    pass


def _require_nmap() -> str:
    path = shutil.which("nmap")
    if not path:
        raise NmapNotFound("nmap executable not found on PATH")
    return path


def _timing_and_rate(p: PhaseParams, defeat_rst: bool = False,
                     is_syn: bool = True) -> list[str]:
    args = [
        f"-T{p.timing_template}",
        "--min-rate", str(p.min_rate),
    ]
    # max_retries: 0 or negative = don't set it (let nmap use its own default)
    if getattr(p, "max_retries", 0) and p.max_retries > 0:
        args += ["--max-retries", str(p.max_retries)]
    args += ["--max-rtt-timeout", p.max_rtt_timeout]
    # host_timeout "0" (or empty) means NO timeout — never abandon a host
    # mid-scan, so slow/filtered hosts get fully enumerated.
    if p.host_timeout and str(p.host_timeout) not in ("0", "0s", "0m"):
        args += ["--host-timeout", p.host_timeout]
    # defeat RST rate-limiting: stops nmap throttling when a firewall
    # rate-limits RST replies. nmap ONLY accepts this with a SYN scan (-sS) — it
    # quits with an error on -sT/-sA/etc. So only add it for SYN scans. (The deep
    # scan is -sT by default, so it won't get this flag; the SYN sweep does.)
    if defeat_rst and is_syn:
        args.append("--defeat-rst-ratelimit")
    args.extend(p.extra_args)
    return args


class PhaseRunner:
    def __init__(self, cfg: Config, outdir: Path, dry_run: bool = False) -> None:
        self.cfg = cfg
        self.outdir = outdir
        self.dry_run = dry_run
        self.nmap = _require_nmap() if not dry_run else "nmap"
        self.command_log = outdir / "commands.log"

    def _run(self, args: list[str], xml_out: Path) -> Path:
        # -oX for structured parsing, -oN for human-readable auditing. Both are
        # kept so when a result looks wrong, the .nmap text file is easy to read
        # next to the .xml the tool parses.
        normal_out = xml_out.with_suffix(".nmap")
        cmd = [self.nmap, *args, "-oX", str(xml_out), "-oN", str(normal_out)]
        with open(self.command_log, "a") as log:
            log.write(" ".join(cmd) + "\n")
        if self.dry_run:
            print("[dry-run]", " ".join(cmd))
            return xml_out
        subprocess.run(cmd, check=True)
        return xml_out

    # ---- Phase 1: full-range SYN discovery sweep ----
    def sweep(self, targets: list[str]) -> Path:
        cfg = self.cfg
        args = ["-sS"]
        if cfg.pn:
            args.append("-Pn")
        # fold service/version + default scripts into the sweep (-sCV) to match
        # a single-pass workflow instead of splitting sweep/deep
        if getattr(cfg, "sweep_service_detection", False):
            args.extend(["-sV", "-sC"])
        args.extend(cfg.sweep_ports.split())
        args.extend(_timing_and_rate(cfg.sweep, getattr(cfg, 'defeat_rst_ratelimit', False)))
        args.extend(targets)
        return self._run(args, self.outdir / "phase1_sweep.xml")

    # ---- Phase 2: targeted deep scan on known-open ports ----
    def deep(self, target: str, port_spec: str) -> Path:
        cfg = self.cfg
        # Deep scan CHARACTERIZES already-known-open ports (the sweep found them),
        # so it uses -sT (full TCP connect) rather than -sS: -sV/-sC complete
        # connections anyway, and a full connect gives more reliable service
        # detection on a handful of known ports. (Configurable for the rare
        # stealth engagement that wants to minimize completed connections.)
        args = [getattr(cfg, "deep_scan_type", "-sT")]
        if cfg.pn:
            args.append("-Pn")
        if cfg.deep_service_detection:
            args.append("-sV")
        if cfg.deep_default_scripts:
            args.append("-sC")
        # -O (OS detection) is per-HOST and belongs on the sweep (once per host,
        # where the open/closed port mix it needs exists), not repeated per-port
        # on the deep scan. Off by default here.
        if getattr(cfg, "deep_os_detection", False):
            args.append("-O")
        args.extend(["-p", port_spec])
        # is_syn reflects the ACTUAL deep scan type: -sT/-sA/etc. are not SYN, so
        # SYN-only flags (--defeat-rst-ratelimit) must be suppressed. If an
        # operator sets deep_scan_type back to -sS, this correctly re-enables it.
        _deep_is_syn = getattr(cfg, "deep_scan_type", "-sT") == "-sS"
        args.extend(_timing_and_rate(cfg.deep,
                                     getattr(cfg, 'defeat_rst_ratelimit', False),
                                     is_syn=_deep_is_syn))
        args.append(target)
        safe = target.replace("/", "_").replace(":", "_")
        return self._run(args, self.outdir / f"phase2_deep_{safe}.xml")

    # ---- Optional: ACK firewall fingerprint ----
    def ack(self, target: str, port_spec: str) -> Path:
        cfg = self.cfg
        args = ["-sA"]
        if cfg.pn:
            args.append("-Pn")
        args.extend(["-p", port_spec])
        # -sA (ACK) is not a SYN scan -> no --defeat-rst-ratelimit
        args.extend(_timing_and_rate(cfg.sweep,
                                     getattr(cfg, 'defeat_rst_ratelimit', False),
                                     is_syn=False))
        args.append(target)
        safe = target.replace("/", "_").replace(":", "_")
        return self._run(args, self.outdir / f"phase3_ack_{safe}.xml")

    # ---- Optional: UDP scan on a curated port list ----
    def udp(self, target: str) -> Path:
        cfg = self.cfg
        args = ["-sU"]
        if cfg.pn:
            args.append("-Pn")
        args.extend(["-p", cfg.udp_ports])
        # -sU (UDP) is not a SYN scan -> no --defeat-rst-ratelimit
        args.extend(_timing_and_rate(cfg.deep,
                                     getattr(cfg, 'defeat_rst_ratelimit', False),
                                     is_syn=False))
        args.append(target)
        safe = target.replace("/", "_").replace(":", "_")
        return self._run(args, self.outdir / f"phase_udp_{safe}.xml")

    # ---- Stacked stealth sweeps: catch ports a SYN scan's filter drops ----
    def _stealth_sweep(self, scan_flag: str, tag: str,
                       targets: list[str]) -> Path:
        """Full-range sweep with an alternate TCP flag set (FIN/NULL/Xmas/ACK).
        Different flag combos slip past stateless firewalls that only watch for
        SYN, revealing ports a -sS sweep marked filtered."""
        cfg = self.cfg
        args = [scan_flag]
        if cfg.pn:
            args.append("-Pn")
        args.extend(cfg.sweep_ports.split())
        # stealth sweeps use FIN/NULL/Xmas/ACK flags — none are SYN, so the
        # SYN-only --defeat-rst-ratelimit must not be added.
        args.extend(_timing_and_rate(cfg.sweep,
                                     getattr(cfg, 'defeat_rst_ratelimit', False),
                                     is_syn=False))
        args.extend(targets)
        return self._run(args, self.outdir / f"phase_stack_{tag}.xml")

    def fin_sweep(self, targets: list[str]) -> Path:
        return self._stealth_sweep("-sF", "fin", targets)

    def null_sweep(self, targets: list[str]) -> Path:
        return self._stealth_sweep("-sN", "null", targets)

    def xmas_sweep(self, targets: list[str]) -> Path:
        return self._stealth_sweep("-sX", "xmas", targets)

    def ack_sweep(self, targets: list[str]) -> Path:
        return self._stealth_sweep("-sA", "ack", targets)

