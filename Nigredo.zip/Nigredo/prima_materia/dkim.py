"""DKIM selector brute-forcer.

dnsrecon's `-t brt` prepends wordlist entries as plain subdomains
(word.domain.com), so it structurally cannot find DKIM keys, which live at
`<selector>._domainkey.<domain>`. This module does that specific lookup: for
each bare selector in a wordlist it queries the TXT record at
`<selector>._domainkey.<domain>` and confirms the result is an actual DKIM key
(contains DKIM markers) rather than just any TXT record that happens to resolve.

Design: the live DNS call (`_query_txt`) is isolated from the detection/parsing
logic (`looks_like_dkim`, `parse_dkim`) so the detection can be unit-tested
against mocked TXT strings without a live resolver or network.

Requires dnspython on the engagement box:  pip install dnspython
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class DkimHit:
    domain: str
    selector: str
    fqdn: str                       # <selector>._domainkey.<domain>
    record: str                     # the full TXT string
    version: str = ""               # v= tag (e.g. DKIM1)
    key_type: str = ""              # k= tag (e.g. rsa, ed25519)
    has_public_key: bool = False    # p= present and non-empty
    revoked: bool = False           # p= present but empty -> revoked key


# ---- Detection / parsing (pure, unit-testable, no network) ----

def _tags(record: str) -> dict[str, str]:
    """Parse a DKIM TXT record's semicolon-separated tag=value pairs."""
    tags: dict[str, str] = {}
    for part in record.split(";"):
        part = part.strip()
        if "=" in part:
            k, _, v = part.partition("=")
            tags[k.strip().lower()] = v.strip()
    return tags


def looks_like_dkim(record: str) -> bool:
    """True if a TXT string is plausibly a DKIM key record.

    A DKIM record is identified by content, not just location: it should declare
    v=DKIM1 and/or carry a public-key tag (p=). This filters out unrelated TXT
    records that happen to sit at the queried name.
    """
    if not record:
        return False
    tags = _tags(record)
    v = tags.get("v", "").upper()

    # Explicit DKIM declaration is the strongest signal.
    if v == "DKIM1":
        return True
    # Any other declared version (DMARC1, spf1, etc.) is NOT DKIM. Reject so a
    # DMARC policy tag (p=reject) can't be mistaken for a DKIM public key.
    if v:
        return False
    # No v= tag: accept only if it carries a key type (k=) alongside a p= tag,
    # which together are DKIM-specific. A bare p= with no k= is too ambiguous.
    if "k" in tags and "p" in tags:
        return True
    return False


def parse_dkim(domain: str, selector: str, fqdn: str, record: str) -> DkimHit:
    tags = _tags(record)
    p = tags.get("p")
    return DkimHit(
        domain=domain,
        selector=selector,
        fqdn=fqdn,
        record=record,
        version=tags.get("v", ""),
        key_type=tags.get("k", ""),
        has_public_key=bool(p),
        revoked=("p" in tags and not p),  # p= present but empty = revoked
    )


# ---- Live resolution (thin wrapper around dnspython) ----

def _query_txt(fqdn: str, lifetime: float = 3.0) -> list[str]:
    """Return TXT strings at fqdn, or [] if none / NXDOMAIN / timeout.
    Isolated so the rest of the module is testable without dnspython."""
    import dns.resolver  # imported lazily so the module loads without dnspython

    try:
        resolver = dns.resolver.Resolver()
        resolver.lifetime = lifetime
        answers = resolver.resolve(fqdn, "TXT")
    except Exception:  # NXDOMAIN, NoAnswer, Timeout, etc. -> simply no hit
        return []
    out: list[str] = []
    for rdata in answers:
        # TXT rdata may be split into multiple quoted strings; join them.
        try:
            joined = "".join(
                s.decode() if isinstance(s, bytes) else str(s)
                for s in rdata.strings
            )
        except AttributeError:
            joined = str(rdata).strip('"')
        out.append(joined)
    return out


def _check_selector(domain: str, selector: str, lifetime: float) -> DkimHit | None:
    fqdn = f"{selector}._domainkey.{domain}"
    for record in _query_txt(fqdn, lifetime=lifetime):
        if looks_like_dkim(record):
            return parse_dkim(domain, selector, fqdn, record)
    return None


def brute_dkim(domain: str, selectors: list[str], threads: int = 10,
               lifetime: float = 3.0) -> list[DkimHit]:
    """Try every selector against domain; return confirmed DKIM hits."""
    hits: list[DkimHit] = []
    with ThreadPoolExecutor(max_workers=threads) as pool:
        futures = {
            pool.submit(_check_selector, domain, sel, lifetime): sel
            for sel in selectors
        }
        for fut in as_completed(futures):
            hit = fut.result()
            if hit is not None:
                hits.append(hit)
    hits.sort(key=lambda h: h.selector)
    return hits


# ---- Wordlist loading + clean output ----

def _bundled_selectors_path() -> Path | None:
    """Locate the bundled dkim_selectors.txt that ships with nigredo. Checked as a
    fallback when no wordlist is configured, so DKIM ALWAYS has the full selector
    list to brute-force instead of silently skipping. Looks next to the package
    and in the cwd (where nigredo is launched)."""
    here = Path(__file__).resolve().parent
    for cand in (here.parent / "dkim_selectors.txt",   # project root (alongside package)
                 here / "dkim_selectors.txt",           # inside package
                 Path("dkim_selectors.txt")):           # cwd
        if cand.is_file():
            return cand
    return None


def load_selectors(path: str | Path = "") -> list[str]:
    """Load DKIM selectors from `path`. If `path` is empty/missing, fall back to
    the bundled dkim_selectors.txt (full ~837-selector list) so DKIM runs with the
    complete list rather than skipping. Never trims the list."""
    src = None
    if path and Path(path).is_file():
        src = Path(path)
    else:
        src = _bundled_selectors_path()
    if src is None:
        return []
    out: list[str] = []
    for raw in src.read_text().splitlines():
        s = raw.strip()
        if not s or s.startswith("#"):
            continue
        # accept either bare selectors or already-suffixed forms; normalize to bare
        if s.endswith("._domainkey"):
            s = s[: -len("._domainkey")]
        out.append(s)
    # dedupe, preserve order
    seen = set()
    uniq = []
    for s in out:
        if s not in seen:
            seen.add(s)
            uniq.append(s)
    return uniq


def clean_report(domain: str, hits: list[DkimHit]) -> str:
    lines = [f"=== DKIM selectors for {domain} ==="]
    if not hits:
        lines.append("  (no DKIM selectors found from this wordlist)")
        return "\n".join(lines) + "\n"
    for h in hits:
        status = "REVOKED (empty p=)" if h.revoked else (
            "valid key" if h.has_public_key else "present")
        ktype = f" k={h.key_type}" if h.key_type else ""
        lines.append(f"\n  selector: {h.selector}")
        lines.append(f"    name:   {h.fqdn}")
        lines.append(f"    status: {status}{ktype}")
        # truncate the raw record for readability; full value is in the record field
        rec = h.record if len(h.record) <= 120 else h.record[:117] + "..."
        lines.append(f"    record: {rec}")
    return "\n".join(lines) + "\n"
