"""Web probe.

Two steps, run only against ports already classified as `web`:

  Step 1 - protocol confirmation: determine whether the port speaks HTTPS or
           HTTP, using the stdlib (no httpx dependency). HTTPS is tried first,
           then HTTP. One redirect is followed to capture the effective URL.

  Step 2 - curl pass: a rate-controllable curl request per confirmed endpoint
           capturing HTTP status code, effective URL, Server header, and title.
           curl is used (vs raw sockets) because it is universally present on an
           engagement box, easy to timeout/rate-limit, and routes through the
           same command logger for auditability.

Every endpoint here has already passed the scope guard upstream (it came from
the scanned target set), but the probe is still the first thing that sends live
application-layer traffic, so it is kept deliberately light: capped timeout,
single retry, HEAD-style where possible.
"""
from __future__ import annotations

from urllib.parse import urlsplit, urlunsplit

import http.client
import socket
import ssl
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class ProbeResult:
    host: str
    port: int
    scheme: str = ""          # "https" | "http" | "" (no response)
    url: str = ""             # ORIGINAL in-scope endpoint; this is what tools use
    status: int | None = None
    server: str = ""
    title: str = ""
    error: str = ""
    # Redirect handling: we do NOT follow redirects (see curl_probe). If the
    # endpoint returns a 3xx, the destination is recorded here for operator
    # review but is NEVER fed to downstream tools — it is frequently off-scope
    # (MSO/Okta/etc.). The original `url` above is what nuclei/feroxbuster get.
    is_redirect: bool = False
    redirect_location: str = ""
    same_host_redirect: bool = False   # redirect stayed on-host and was followed


def _try_scheme(host: str, port: int, scheme: str, timeout: float) -> int | None:
    """Return an HTTP status code if the port answers HTTP(S), else None."""
    try:
        if scheme == "https":
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            conn = http.client.HTTPSConnection(host, port, timeout=timeout, context=ctx)
        else:
            conn = http.client.HTTPConnection(host, port, timeout=timeout)
        conn.request("HEAD", "/")
        resp = conn.getresponse()
        conn.close()
        return resp.status
    except (ssl.SSLError, http.client.HTTPException, socket.error, OSError):
        return None


def confirm_protocol(host: str, port: int, timeout: float = 6.0) -> str:
    """Return 'https', 'http', or '' based on what the port actually speaks."""
    # HTTPS first; common case for 443/8443 and increasingly for everything.
    if _try_scheme(host, port, "https", timeout) is not None:
        return "https"
    if _try_scheme(host, port, "http", timeout) is not None:
        return "http"
    return ""


def verify_tls(host: str, port: int, timeout: float = 6.0) -> bool:
    """Confirm the port actually completes a TLS handshake — independent of HTTP.

    This catches TLS services that aren't HTTP (SMTPS/IMAPS/POP3S/LDAPS on
    465/993/995/636, etc.) as well as plain HTTPS. Returns True only if a real
    TLS handshake succeeds, so the testssl list contains verified-TLS endpoints
    rather than port-based guesses.
    """
    ctx = ssl.create_default_context()
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    sock = None
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        with ctx.wrap_socket(sock, server_hostname=host) as tls:
            # a completed handshake yields a negotiated protocol version
            return tls.version() is not None
    except (ssl.SSLError, socket.error, OSError):
        return False
    finally:
        if sock is not None:
            try:
                sock.close()
            except OSError:
                pass


def _same_host_redirect(original_url: str, location: str) -> bool:
    """Is the redirect Location the SAME host as the original (just a different
    path)? e.g. https://site.com -> https://site.com/login/ is same-host and
    safe to follow (same in-scope target). https://site.com ->
    https://login.okta.com is cross-host and must NOT be followed (off-scope)."""
    if not location:
        return False
    from urllib.parse import urljoin, urlparse
    orig_host = urlparse(original_url).hostname or ""
    dest = urljoin(original_url, location)   # handles relative /login/ too
    dest_host = urlparse(dest).hostname or ""
    return bool(orig_host) and orig_host.lower() == dest_host.lower()


def curl_probe(url: str, timeout: int, max_time: int,
               command_log: Path | None = None,
               dry_run: bool = False, proxy: str = "",
               follow_same_host: bool = False) -> ProbeResult:
    """Step 2: curl the endpoint, capturing status, server, and — if the endpoint
    redirects — the Location it points to.

    IMPORTANT: cross-host redirects are deliberately NOT followed (no -L).
    Following one routinely lands on an off-scope third-party auth page (MSO,
    Okta, etc.); if curl chased it, that off-scope URL could leak into the tool
    target lists. We record the 3xx + Location for review and keep the ORIGINAL
    in-scope url as the value tools consume.

    EXCEPTION (follow_same_host=True): if the redirect stays on the SAME host
    (e.g. https://site.com -> https://site.com/login/), it's the same in-scope
    target on a different path — the redirect destination is promoted as the
    effective URL so the useful landing page isn't lost. Cross-host redirects are
    still never followed, regardless of this flag.

    If `proxy` is set, curl routes through it (-x) so the target sees the proxy.
    """
    # strip any path/query first so a URL like https://h:8443/x doesn't make the
    # port parse choke on int("8443/x")
    host_port = url.split("://", 1)[-1].split("/", 1)[0]
    host = host_port.split(":")[0]
    port = int(host_port.split(":")[1]) if ":" in host_port else (443 if url.startswith("https") else 80)
    res = ProbeResult(host=host, port=port, scheme=url.split("://", 1)[0], url=url)

    # -s silent, -k insecure (self-signed common), NO -L (do not follow),
    # -m max time, --retry 1. Dump headers so we can read status + Location.
    cmd = [
        "curl", "-s", "-k",
        "--max-time", str(max_time),
        "--connect-timeout", str(timeout),
        "--retry", "1",
        "-D", "-",                      # dump headers to stdout
        "-o", "/dev/null",              # discard body
        "-w", "\n%{http_code}",
    ]
    if proxy:
        cmd += ["-x", proxy]            # route through forwarding proxy
    cmd.append(url)
    if command_log is not None:
        with open(command_log, "a") as log:
            log.write(" ".join(cmd) + "\n")
    if dry_run:
        res.error = "dry-run"
        return res

    try:
        out = subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                             timeout=max_time + 5)
        lines = out.stdout.splitlines()
        if lines:
            last = lines[-1].strip()
            if last.isdigit():
                res.status = int(last)
        for line in lines:
            low = line.lower()
            if low.startswith("server:"):
                res.server = line.split(":", 1)[1].strip()
            elif low.startswith("location:"):
                res.redirect_location = line.split(":", 1)[1].strip()
        if res.status is not None and 300 <= res.status < 400:
            res.is_redirect = True
            # same-host redirect (e.g. / -> /login/): promote the destination as
            # the effective URL so we don't lose the useful in-scope landing page.
            # Cross-host redirects are never promoted (off-scope protection).
            if follow_same_host and _same_host_redirect(url, res.redirect_location):
                from urllib.parse import urljoin
                res.url = urljoin(url, res.redirect_location)
                res.same_host_redirect = True
    except subprocess.TimeoutExpired:
        res.error = "timeout"
    except Exception as e:  # noqa: BLE001
        res.error = str(e)
    return res


def strip_default_port(url: str) -> str:
    """Normalise a full URL string by dropping a redundant default port:
    https://host:443/path -> https://host/path,  http://host:80 -> http://host.
    Non-default ports (:8443, :8080) are preserved. Safe on URLs without a port.
    Any tool that consumes web URLs can call this to avoid the explicit-default-
    port form that some tools (ffuf, sns, ...) mishandle."""
    try:
        parts = urlsplit(url)
    except ValueError:
        return url
    scheme = parts.scheme.lower()
    host = parts.hostname or ""
    port = parts.port
    if not host:
        return url
    default = (scheme == "https" and port == 443) or (scheme == "http" and port == 80)
    if port is None or not default:
        return url          # no port, or a non-default port we must keep
    # rebuild without the port (preserve path/query/fragment and any userinfo)
    userinfo = ""
    if parts.username:
        userinfo = parts.username
        if parts.password:
            userinfo += f":{parts.password}"
        userinfo += "@"
    netloc = f"{userinfo}{host}"
    return urlunsplit((scheme, netloc, parts.path, parts.query, parts.fragment))


def build_web_url(scheme: str, host: str, port: int) -> str:
    """Build a web URL, omitting the port when it's the scheme default.

    https + 443 -> https://host   (NOT https://host:443)
    http  + 80  -> http://host    (NOT http://host:80)
    Any non-default port is kept (https://host:8443, http://host:8080).

    The redundant default port (https://host:443) is technically valid but some
    tools — ffuf in particular — mishandle or reject it, so we normalise it away.
    """
    default = (scheme == "https" and port == 443) or (scheme == "http" and port == 80)
    return f"{scheme}://{host}" if default else f"{scheme}://{host}:{port}"


def probe_endpoint(host: str, port: int, timeout: int, max_time: int,
                   command_log: Path | None = None,
                   dry_run: bool = False, proxy: str = "",
                   follow_same_host: bool = False) -> ProbeResult:
    scheme = confirm_protocol(host, port, timeout=float(timeout)) if not dry_run else "http"
    if not scheme:
        return ProbeResult(host=host, port=port, error="no-http-response")
    url = build_web_url(scheme, host, port)
    return curl_probe(url, timeout, max_time, command_log=command_log,
                      dry_run=dry_run, proxy=proxy,
                      follow_same_host=follow_same_host)
