"""Phase 1 (passive recon) + Phase 2 (email/breach) orchestrator.

This is one of the two "carriage" engines (the other is pipeline.Pipeline, the
active-scan side). It runs the recon/enumeration tools back-to-back against each
domain, driven by the entered domain list (cfg.domains_file), and writes all
output into the engagement folder (output_dir/engagement_name).

WHAT IT DOES (flow):
  run()  ->  for each domain:  _run_phase1()  then  _run_phase2()
    Phase 1 (passive recon): dnsrecon, dnstwist, dkim, subdomains (+takeover,
      +mutations), fileenum, buckets, cloud_enum, trufflehog, gitleaks, funnelweb
    Phase 2 (email/breach): emailenum, partyon (DeHashed), snov
  then build_report() -> final_report.xlsx

KEY CONTRACTS (what an auditor should know):
  - INPUT: domains come from cfg.domains_file; NOT targets.txt (that's the active
    scan's scope). These recon tools are discovery, not active scanning, so they
    are NOT gated by the scope guard.
  - ISOLATION: each domain is wrapped in try/except in run() — one tool throwing
    does NOT crash the engagement or lose the report. State is saved and the run
    continues. Only missing SEEDS (handled upstream) hard-fail.
  - CREDIT LEDGER: a shared CreditLedger (self.ledger) is created here and passed
    to every paid-API tool (snov, buckets/grayhat, shodan, fileenum/serpapi,
    partyon/dehashed). It tracks spend, enforces optional caps, prints the total.
  - RESUME: progress is checkpointed to recon_state.json; an interrupted run
    resumes where it left off instead of re-running (and re-spending).
  - PROMPT CACHING: resolver path / company name / GitHub org are prompted ONCE
    and cached across domains+tools (the _*_prompted fields).
"""
from __future__ import annotations

import json
import time
from pathlib import Path

from .recon_config import ReconConfig, load_domains
from . import preflight


class ReconOrchestrator:
    def __init__(self, cfg: ReconConfig, dry_run: bool = False,
                 prompt_between: bool = True, config_path: str = None,
                 assume_yes: bool = False):
        self.cfg = cfg
        self.dry_run = dry_run
        self.prompt_between = prompt_between   # pause/confirm between tools & phases
        self.assume_yes = assume_yes           # auto-proceed volume prompts (GHW >500)
        # NOTE: outdir/command_log/state_file MUST be set before the ledger, which
        # persists .api_credits.json into outdir. (Ordering bug fixed here once —
        # ledger referenced self.outdir before it existed. Keep this order.)
        self.outdir = Path(cfg.output_dir) / cfg.engagement_name
        self.outdir.mkdir(parents=True, exist_ok=True)
        self.command_log = self.outdir / "commands.log"
        self.state_file = self.outdir / "recon_state.json"
        # shared API credit ledger — tracks spend across all paid-API tools,
        # enforces optional per-tool caps (None = uncapped), reports the total.
        from .api_budget import CreditLedger
        self.ledger = CreditLedger(self.outdir, caps={
            "snov": getattr(cfg, "snov_credit_cap", None),
            "grayhat": getattr(cfg, "grayhat_credit_cap", None),
            "shodan": getattr(cfg, "shodan_credit_cap", None),
            "serpapi": getattr(cfg, "serpapi_credit_cap", None),
            "dehashed": getattr(cfg, "dehashed_credit_cap", None),
        })
        self._resolvers_prompted = ""     # cache so we prompt once, not per-domain
        self._company_prompted = None     # cache company name across GHW + cloud_enum
        self._org_prompted = None          # cache GitHub org across trufflehog + gitleaks
        self._config_path = config_path    # for saving keys (e.g. DeHashed) back
        self._primary_domain = ""          # first domain; PartyOn confirms against it
        self.funnelweb_summaries = []       # FunnelWebSummary per domain -> At a Glance
        # HEARTHBEAT: the between-tool pulse (fires at every _dispatch exit).
        from .hearthbeat import Hearthbeat
        self.hearthbeat = Hearthbeat(self.outdir)
        self.hearthbeat.start_spacebar_watch()   # SPACEBAR spot-check (TTY only)

    def _forward_proxy(self) -> str:
        """Forwarding proxy for target-hitting HTTP tools (mirrors pipeline).
        Interview stash wins; else config; else empty (direct)."""
        try:
            from .runmode import answer, has_answer
            if has_answer("forward_proxy"):
                return answer("forward_proxy", "") or ""
        except Exception:  # noqa: BLE001
            pass
        return getattr(self.cfg, "forward_proxy", "") or ""

    def _resolve_fqdn_pairs(self, domain: str):
        """Build the confirmed FQDN<->IP pairs (2-of-3: dnsx, nessus, dig) and
        persist the derivation. Stashes Part-2 (harvest) FQDNs for FunnelWeb.

        Safeguards-first: only PROMOTES via confirmation; never edits targets.txt.
        Skipped entirely (per-domain isolation) if anything goes wrong."""
        from . import fqdn_resolve as fr

        dnsx_pairs = fr.gather_dnsx_pairs(self.outdir)
        if not dnsx_pairs:
            return   # nothing resolved yet for this domain; skip quietly

        # nessus pairs (if a .nessus was provided/parsed this run)
        nessus_pairs = {}
        nessus_hosts = getattr(self, "_nessus_hosts", None)
        if nessus_hosts:
            nessus_pairs = fr.gather_nessus_pairs(nessus_hosts)

        # dig callables (forward + reverse) — reuse the pipeline helpers
        from .pipeline import _dig_ipv4, _dig_reverse
        fwd = lambda f: _dig_ipv4(f, self.command_log)
        rev = lambda ip: _dig_reverse(ip, self.command_log)

        result = fr.resolve_pairs(dnsx_pairs, nessus_pairs, fwd, rev)
        out = fr.write_pairs_json(result, self.outdir)

        n1 = len(result.confirmed_1to1)
        nm = len(result.confirmed_multi)
        nu = len(result.unconfirmed)
        print(f"[fqdn] {domain}: {n1} confirmed 1:1 (full scan), {nm} multi "
              f"(harvest-only), {nu} unconfirmed (report-only) -> {out.name}")

    def _get_org(self, domain: str) -> str:
        """GitHub org/handle, reused across github tools. Priority: the value
        persisted in this client's config (set in the interview) -> the in-session
        interview answer -> the domain base as a last-resort guess. The config
        read is what makes the campaign child use the REAL org; without it the
        unattended child fell back to the domain's first label (e.g. 'acme' from
        'acme.com'), which is usually the wrong GitHub org and finds nothing."""
        if self._org_prompted is not None:
            return self._org_prompted
        from .runmode import is_unattended, has_answer, answer
        base = domain.split(".")[0]
        if self.dry_run:
            self._org_prompted = ""
            return ""
        cfg_org = (getattr(self.cfg, "github_org", "") or "").strip()
        if cfg_org:
            self._org_prompted = cfg_org
            return self._org_prompted
        if is_unattended():
            self._org_prompted = answer("github_org", base) or base
            return self._org_prompted
        try:
            ans = input(f"  GitHub org/handle for {domain} "
                        f"(blank to skip) [{base}]: ").strip()
        except EOFError:
            ans = ""
        self._org_prompted = ans or base
        return self._org_prompted

    def _get_company(self, domain: str) -> str:
        """Company name, reused across bucket tools. Unattended pulls the
        interview answer; else derives from the domain base."""
        if self._company_prompted is not None:
            return self._company_prompted
        from .runmode import is_unattended, answer
        if self.dry_run:
            self._company_prompted = ""
            return ""
        if is_unattended():
            # Interview stash wins; else this client's config (the campaign child
            # skips the interview, so the answer lives in recon_config.json); else
            # the domain-derived base as a last resort.
            from .runmode import has_answer
            _base = domain.split(".")[0]
            if has_answer("company"):
                self._company_prompted = answer("company", _base) or _base
            else:
                self._company_prompted = getattr(self.cfg, "company", "") or _base
            return self._company_prompted
        try:
            ans = input(f"  Company name for {domain} bucket search "
                        "(blank to search domain only): ").strip()
        except EOFError:
            ans = ""
        self._company_prompted = ans
        return ans

    def _gate(self, label: str) -> bool:
        """Ask whether to run the next tool/phase. Returns True to proceed,
        False to skip. Auto-proceeds when unattended, prompting disabled, or
        dry-run. Re-prompts on unrecognized input; 'q' quits the run."""
        from .runmode import is_unattended, prompt_choice
        if not self.prompt_between or self.dry_run or is_unattended():
            return True
        # blank -> proceed (the [Y/...] default); y/yes proceed; n/no/skip skip;
        # q/quit raises KeyboardInterrupt (caught upstream as operator-quit).
        return prompt_choice(
            f"  -> run {label}? [Y/n/q] ",
            {"y": True, "yes": True, "n": False, "no": False, "skip": False},
            default=True)

    # ---- state / resume ----
    def _load_state(self) -> dict:
        default = {"done": {}, "completed": False}   # {domain: [tool, ...]}
        if self.state_file.exists():
            try:
                state = json.loads(self.state_file.read_text())
            except (ValueError, OSError):
                # corrupt/partial state file — start clean rather than crash the run
                return dict(default)
            if not isinstance(state, dict):
                return dict(default)
            state.setdefault("done", {})          # tolerate older/partial formats
            state.setdefault("completed", False)
            return state
        return dict(default)

    def _save_state(self, state: dict) -> None:
        self.state_file.write_text(json.dumps(state, indent=2))

    def _fresh_start_if_completed(self) -> None:
        """Archive a completed prior recon run and start clean, so a new run
        doesn't replay finished output. An incomplete run is left to resume."""
        if not self.state_file.exists():
            return
        try:
            prev = json.loads(self.state_file.read_text())
        except (json.JSONDecodeError, OSError):
            return
        if prev.get("completed"):
            import datetime
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            archived = self.outdir.parent / f"{self.outdir.name}_archived_{stamp}"
            self.outdir.rename(archived)
            self.outdir.mkdir(parents=True, exist_ok=True)
            self.command_log = self.outdir / "commands.log"
            self.state_file = self.outdir / "recon_state.json"
            print(f"[i] previous recon was complete — archived to {archived.name}, "
                  f"starting fresh")

    def _is_done(self, state: dict, domain: str, tool: str) -> bool:
        return tool in state["done"].get(domain, [])

    def _mark_done(self, state: dict, domain: str, tool: str) -> None:
        state["done"].setdefault(domain, []).append(tool)
        self._save_state(state)

    # ---- run ----
    def run(self):
        domains = load_domains(self.cfg.domains_file)
        print(f"[i] {len(domains)} domain(s) loaded from {self.cfg.domains_file}")
        if domains and not self._primary_domain:
            self._primary_domain = domains[0]

        # archive a completed prior run so we start fresh
        self._fresh_start_if_completed()

        # preflight — only check tools that are actually ENABLED for this run.
        # In single-tool mode just the chosen tool is enabled, so this filters the
        # preflight to the relevant tool instead of printing all 16 (which buried
        # the one line that mattered under SKIPs for tools that weren't running).
        all_tools = preflight.PHASE1_TOOLS + preflight.PHASE2_TOOLS
        enabled_tools = [t for t in all_tools
                         if getattr(self.cfg, f"run_{t}", True)]
        if not enabled_tools:            # safety: never preflight an empty set
            enabled_tools = all_tools
        statuses = preflight.run_preflight(
            enabled_tools,
            config_keys=self.cfg.config_keys())
        print(preflight.format_preflight(statuses))
        ready = {name for name, st in statuses.items() if st.ready}

        state = self._load_state()

        # MAIN LOOP: one domain at a time, each fully isolated. The try/except is
        # the run's safety backstop — see the class docstring "ISOLATION" note.
        # Order per domain: gate -> phase1 -> gate -> phase2. After all domains:
        # credit total -> cvemap (once, needs full tech list) -> final report.
        from . import resources as _res
        for domain in domains:
            print(f"\n=== {domain} ===")
            _res.log_snapshot(self.outdir, f"before-phase1:{domain}")
            try:
                if self._gate(f"PHASE 1 (passive recon) for {domain}"):
                    self._run_phase1(domain, ready, state)
                if self._gate(f"PHASE 2 (email) for {domain}"):
                    self._run_phase2(domain, ready, state)
            except KeyboardInterrupt:
                # A KeyboardInterrupt reaching here means the operator chose QUIT
                # from a tool's pause menu (tools handle their own skip/retry via
                # _dispatch and do NOT propagate those). Save and exit gracefully.
                self._save_state(state)
                print("\n[i] operator quit; progress saved, resume to continue.")
                return
            except Exception as e:  # noqa: BLE001
                # A single tool blowing up must NOT crash the whole engagement or
                # cost us the final report. Log it, save state, move on. (Tools
                # should handle their own errors; this is the backstop.)
                import traceback
                print(f"\n[!] {domain}: unhandled error in a recon phase — "
                      f"continuing with the rest of the run.\n    {type(e).__name__}: {e}")
                traceback.print_exc()
                self._save_state(state)

        # mark complete so a future run starts fresh instead of replaying
        state["completed"] = True
        self._save_state(state)
        print(f"\n[\u2713] recon complete. Output in {self.outdir}")

        # report total API credit spend for the run (transparency)
        try:
            self.ledger.print_total()
        except Exception:  # noqa: BLE001
            pass

        # ========================= FINAL STAGE =========================
        # Post-processing enrichment: NOT recon tools (phases 0-2), but the final
        # analysis pass that runs ONCE after ALL domains/tools have produced their
        # data. cvemap maps the complete discovered-tech list -> CVEs; Cache looks
        # up public PoC exploits for those CVEs. They are last because they consume
        # the union of everything the phases discovered (httpx + shodan + FunnelWeb
        # tech). Then the final report collates it all.
        _res.log_snapshot(self.outdir, "before-final-stage")
        self._run_final_stage()
        _res.log_snapshot(self.outdir, "after-final-stage")

        # Final report: collate all cleaned outputs into one workbook.
        if not self.dry_run:
            try:
                from . import report
                path = report.build_report(
                    self.outdir,
                    funnelweb_summaries=self.funnelweb_summaries,
                    spray_domains=load_domains(self.cfg.domains_file),
                    ledger=self.ledger)
                print(f"[\u2713] final report: {path}")
                # DONE-MARKER: an explicit, unambiguous "this engagement finished"
                # flag. campaign checks THIS (not just the presence of a report
                # file, which could be half-written or left from a partial run) to
                # know a client shouldn't be re-run without --force.
                try:
                    (self.outdir / ".campaign_complete").write_text(
                        f"completed {time.strftime('%Y-%m-%d %H:%M:%S')}\n")
                except OSError:
                    pass
            except Exception as e:
                print(f"[!] report build failed: {e}")

    # ---- phase 1 ----
    def _cve_ids_from_csv(self) -> list:
        """Fallback: read CVE IDs from cvemap_findings.csv if cvemap didn't
        return hits directly (e.g. resumed run). Returns a deduped list."""
        import csv as _csv
        p = self.outdir / "cvemap_findings.csv"
        ids = set()
        if p.is_file():
            try:
                with open(p, newline="") as f:
                    for row in _csv.reader(f):
                        for cell in row:
                            c = (cell or "").strip().upper()
                            if c.startswith("CVE-"):
                                ids.add(c)
            except OSError:
                pass
        return sorted(ids)

    def _dispatch(self, label, state, domain, tool_key, fn, *args,
                  targets=None, action=None, **kwargs):
        """The carriage's single tool-execution path. Every tool goes through
        here so all four audit/control concerns are handled uniformly:

          1. RESUME  — if a completion marker exists for (tool_key, domain), skip
             (the tool already finished cleanly on a prior run). Distinguishes a
             finished tool from one that stalled mid-write.
          2. AUDIT   — log the tool's action to the unified commands.log, and save
             its target list to <tool>_targets.txt, so the run is traceable.
          3. INTERRUPT — run under the Ctrl+C pause menu: [s]kip this tool and
             continue, [t] retry, [q] quit (saves state + exits). No more
             hard-killing the box to escape a runaway tool.
          4. MARKER  — on clean completion, drop a <tool>_<domain>.done marker so
             a later resume knows this stage is done.

        `targets`  optional list saved as this tool's target record.
        `action`   optional human string for the audit log (defaults to label).
        `output`   optional expected output path (reserved for output-based resume).
        """
        from .interrupt import _prompt_menu
        from . import audit

        # 1. RESUME: skip if this tool already completed cleanly for this domain.
        if tool_key and audit.is_complete(self.outdir, tool_key, domain):
            print(f"[resume] {label}: already complete — skipping")
            if not self._is_done(state, domain, tool_key):
                self._mark_done(state, domain, tool_key)
            # keep the pulse alive during a resume so the operator sees the run
            # moving through skipped tools, not a frozen terminal.
            self.hearthbeat.beat(f"{label} (skipped/resume)")
            return

        # 2. AUDIT: record intent + targets BEFORE running (so a crash still logs).
        audit.log_action(self.command_log, tool_key or label, action or label)
        if targets is not None:
            audit.save_targets(self.outdir, tool_key or label, targets)

        # 3. INTERRUPT-wrapped execution with skip/retry/quit.
        self.hearthbeat.tool_starting()
        self.hearthbeat.set_current_tool(label)
        while True:
            try:
                fn(*args, **kwargs)
                # 4. MARKER + done on clean completion.
                if tool_key:
                    audit.mark_complete(self.outdir, tool_key, domain)
                    self._mark_done(state, domain, tool_key)
                self.hearthbeat.beat(label)
                return
            except KeyboardInterrupt:
                act = _prompt_menu(label, resumable=False)
                if act == "s":
                    print(f"[i] skipped '{label}' — continuing to the next tool.")
                    if tool_key:
                        # mark done (but NOT a completion marker — it didn't finish)
                        self._mark_done(state, domain, tool_key)
                    return
                if act == "q":
                    raise            # bubble to the domain loop -> save + exit
                print(f"[i] retrying '{label}'…")
                continue
            except Exception as e:  # noqa: BLE001
                # CONTAINMENT: a tool that raises (e.g. a SerpAPI 429 / quota
                # exhaustion, a network blip, a bad API response) must NOT blow out
                # of the whole phase and skip every tool scheduled after it — that
                # is exactly what caused FunnelWeb (last in phase 1) to never run
                # when an earlier API tool (fileenum/LinkThief) hit its rate limit.
                # Log it, mark the tool attempted (so resume doesn't retry a
                # quota-dead API forever), and CONTINUE to the next tool.
                etype = type(e).__name__
                msg = str(e)
                if "429" in msg or "Too Many Requests" in msg or "quota" in msg.lower():
                    print(f"[{label}] API rate limit / quota hit ({etype}) — "
                          f"saving any partial results and continuing to the next tool.")
                else:
                    print(f"[{label}] error ({etype}): {msg[:200]} — continuing "
                          f"to the next tool.")
                if tool_key:
                    # mark done so the phase moves on and resume doesn't re-run a
                    # dead-quota API; the failure is recorded in commands.log.
                    self._mark_done(state, domain, tool_key)
                    audit.log_action(self.command_log, tool_key or label,
                                     f"FAILED: {etype}: {msg[:200]}")
                    # Per-tool error file (workbook collects these). A raised
                    # exception = did-not-complete (crashed), distinct from a tool
                    # that ran clean but found nothing.
                    audit.append_error(self.outdir, tool_key or label,
                                       f"{etype}: {msg}", completed=False)
                self.hearthbeat.beat(f"{label} (errored)")
                return

    # NOTE: the former _guarded() helper was removed — every tool now routes
    # through _dispatch(), which supersedes it (adds audit logging, target
    # saving, completion markers, and resume-skip on top of the same interrupt
    # menu). Kept this note so the history is clear.

    def _run_phase1(self, domain: str, ready: set, state: dict):
        cfg = self.cfg

        if cfg.run_dnsrecon and "dnsrecon" in ready and not self._is_done(state, domain, "dnsrecon"):
            if self._gate("dnsrecon"):
                from . import dnsrecon_tool
                print("[phase1] dnsrecon")
                self._dispatch("dnsrecon", state, domain, "dnsrecon",
                               dnsrecon_tool.process_domain,
                               domain, self.outdir, self.command_log,
                               dry_run=self.dry_run,
                               lifetime=getattr(cfg, "dnsrecon_lifetime", 10.0),
                               targets=[domain], action=f"dnsrecon -d {domain}")

        if cfg.run_dnstwist and "dnstwist" in ready and not self._is_done(state, domain, "dnstwist"):
            if self._gate("dnstwist"):
                from . import dnstwist_tool
                print("[phase1] dnstwist")
                self._dispatch("dnstwist", state, domain, "dnstwist",
                               dnstwist_tool.process_domain,
                               domain, self.outdir, self.command_log,
                               whois=getattr(cfg, "dnstwist_whois", False),
                               backfill=getattr(cfg, "dnstwist_backfill", True),
                               whois_delay=getattr(cfg, "dnstwist_whois_delay", 2.0),
                               whois_cap=getattr(cfg, "dnstwist_whois_backfill_cap", 100),
                               dry_run=self.dry_run,
                               targets=[domain], action=f"dnstwist {domain}")

        if cfg.run_dkim and "dkim" in ready and not self._is_done(state, domain, "dkim"):
            if self._gate("dkim"):
                from . import dkim
                # No wordlist configured -> fall back to the bundled full selector
                # list (dkim.load_selectors handles the fallback) instead of
                # skipping. DKIM should ALWAYS run with the complete list.
                _wl = cfg.dkim_wordlist or ""
                if not _wl:
                    print("[phase1] dkim: no wordlist configured — using bundled "
                          "full selector list")
                else:
                    print("[phase1] dkim")
                def _run_dkim():
                    if not self.dry_run:
                        selectors = dkim.load_selectors(_wl)
                        if not selectors:
                            print("[dkim] no selectors available (bundled list "
                                  "missing?) — skipping")
                            return
                        hits = dkim.brute_dkim(domain, selectors)
                        safe = domain.replace("/", "_")
                        (self.outdir / f"dkim_{safe}.txt").write_text(dkim.clean_report(domain, hits))
                self._dispatch("dkim", state, domain, "dkim", _run_dkim,
                               targets=[domain],
                               action=f"dkim selector brute -d {domain} "
                                      f"(wordlist={_wl or 'bundled'})")

        if cfg.run_subdomains and "subdomains" in ready and not self._is_done(state, domain, "subdomains"):
            # DISCOVERY-BEFORE-SCAN: if phase 0 already ran full discovery (it
            # writes a subdomains completion marker), don't run it again here —
            # just mark done so the report picks up the phase-0 output.
            from . import audit as _audit
            if _audit.is_complete(self.outdir, "subdomains", domain):
                print("[phase1] subdomains: already done in phase 0 discovery — skipping")
                self._mark_done(state, domain, "subdomains")
                for _t in ("takeover", "submutate", "fqdn_resolve"):
                    self._mark_done(state, domain, _t)
            elif self._gate("subdomains (subfinder|shuffledns|dnsx)"):
                from . import subdomains
                print("[phase1] subdomains")
                resolvers = cfg.resolvers_file or self._prompt_resolvers_once()
                def _run_subdomains():
                    subdomains.process_domain(domain, self.outdir, self.command_log,
                                              resolvers=resolvers, dry_run=self.dry_run)
                self._dispatch("subdomains", state, domain, "subdomains",
                               _run_subdomains, targets=[domain],
                               action=f"subfinder|shuffledns|dnsx -d {domain}")

                # Subdomain-takeover pass (nuclei takeover templates, CNAME hotlist
                # first). CONSOLIDATION: single takeover run against the discovered
                # subdomain master list. Fault-isolated via _dispatch.
                if getattr(cfg, "run_takeover", True):
                    from . import takeover
                    print("[phase1] subdomain takeover (single master-list pass)")
                    def _run_takeover():
                        takeover.run_takeover(
                            self.outdir, self.command_log,
                            rate_limit=getattr(cfg, "nuclei_rate_limit", 3),
                            proxy=self._forward_proxy(), dry_run=self.dry_run)
                    self._dispatch("takeover", state, domain, "takeover",
                                   _run_takeover, targets=[domain],
                                   action="nuclei -tags takeover (master list)")

                # Target-specific subdomain mutation (scoped-safe). Fault-isolated.
                if getattr(cfg, "run_submutate", True):
                    from . import submutate
                    print("[phase1] subdomain mutations")
                    def _run_submutate():
                        submutate.process_domain(
                            domain, self.outdir, self.command_log,
                            resolvers=resolvers,
                            max_words=getattr(cfg, "submutate_max_words", 40),
                            max_candidates=getattr(cfg, "submutate_max_candidates", 5000),
                            proxy=self._forward_proxy(), dry_run=self.dry_run)
                    self._dispatch("submutate", state, domain, "submutate",
                                   _run_submutate, targets=[domain],
                                   action=f"subdomain mutations -d {domain}")

                # FQDN<->IP confirmed-scope resolution (safeguards-first). Runs
                # after subdomains+mutations so all dnsx A-records exist. Builds
                # 2-of-3 confirmed pairs (dnsx + nessus + dig), writes the audit
                # JSON, and stashes the Part-2 (client-side harvest) FQDN list for
                # FunnelWeb. Part-1 (full active scan) promotion is surfaced in the
                # report but NOT auto-fed to the already-run scan phase — see the
                # report tab / fqdn_pairs.json. targets.txt is never modified.
                if getattr(cfg, "run_fqdn_resolve", True):
                    try:
                        self._resolve_fqdn_pairs(domain)
                    except Exception as e:  # noqa: BLE001
                        print(f"[fqdn] resolution skipped: {e}")

        if cfg.run_fileenum and "fileenum" in ready and not self._is_done(state, domain, "fileenum"):
            if self._gate("fileenum (SerpAPI file search)"):
                from . import fileenum
                print("[phase1] fileenum")
                def _run_fileenum():
                    if not self.dry_run:
                        from .runmode import answer as _rm_answer, has_answer
                        # basic (default, credit-safe): metadata-bearing office/PDF
                        # types only, no sensitive-dork pass (~8 credits). full: all
                        # configured types + sensitive dorks (~60 credits).
                        # Interview stash wins; else this client's config (the
                        # campaign child skips the interview), else basic.
                        if has_answer("fileenum_mode"):
                            _mode = str(_rm_answer("fileenum_mode", "basic")).lower()
                        else:
                            _mode = str(getattr(cfg, "fileenum_mode", "basic")).lower()
                        if _mode == "full":
                            _types = cfg.file_types
                            _sensitive = True
                        else:
                            _types = fileenum.BASIC_FILE_TYPES
                            _sensitive = False
                        fileenum.process_files(
                            domain, self.outdir, api_key=cfg.serpapi_key,
                            types=_types, apex_domains=[domain],
                            sensitive_dorks=_sensitive,
                            use_crawler=cfg.file_use_crawler, ledger=self.ledger)
                self._dispatch("fileenum", state, domain, "fileenum", _run_fileenum,
                               targets=[domain],
                               action=f"fileenum serpapi filetype search -d {domain} "
                                      f"(types={cfg.file_types})")

        # GrayHatWarfare cloud storage (bucket/blob) enumeration — queries a
        # third-party index by domain + company name + harvested S3 hostnames.
        if cfg.run_buckets and "buckets" in ready and not self._is_done(state, domain, "buckets"):
            if self._gate("buckets (GrayHatWarfare cloud storage)"):
                from . import buckets
                from .runmode import answer, has_answer
                print("[phase1] buckets (GrayHatWarfare)")
                company = self._get_company(domain)
                tier = (answer("grayhat_tier", "low")
                        if has_answer("grayhat_tier")
                        else getattr(cfg, "grayhat_tier", "low"))
                def _run_buckets():
                    buckets.process(domain, self.outdir, self.command_log,
                                    company=company, api_key=cfg.grayhat_api_key,
                                    file_cap_per_bucket=cfg.buckets_file_cap,
                                    tier=tier,
                                    file_prompt_threshold=getattr(cfg, "grayhat_file_prompt_threshold", 500),
                                    assume_yes=self.assume_yes,
                                    ledger=self.ledger, dry_run=self.dry_run)
                self._dispatch("buckets", state, domain, "buckets", _run_buckets,
                               targets=[domain, company],
                               action=f"grayhatwarfare buckets/files "
                                      f"keywords=[{domain}, {company}] tier={tier}")

        # cloud_enum (initstring) — active multi-cloud bucket brute-force. Raw
        # output only (logfile + stdout) saved to the engagement folder; no
        # parsing/report yet. Skips safely if the binary isn't on PATH.
        if cfg.run_cloud_enum and "cloud_enum" in ready and not self._is_done(state, domain, "cloud_enum"):
            if self._gate("cloud_enum (active bucket brute-force)"):
                from . import cloud_enum
                print("[phase1] cloud_enum")
                company = self._get_company(domain)
                # Prefer the preflight-stashed depth choice; fall back to config.
                from .runmode import answer as _rm_answer
                _ce_depth = _rm_answer("cloud_enum_depth", cfg.cloud_enum_depth)
                def _run_cloud_enum():
                    cloud_enum.process(domain, self.outdir, self.command_log,
                                       company=company, script=cfg.cloud_enum_script,
                                       extra=cfg.cloud_enum_extra,
                                       depth=_ce_depth,
                                       dry_run=self.dry_run)
                self._dispatch("cloud_enum", state, domain, "cloud_enum", _run_cloud_enum,
                               targets=[domain, company],
                               action=f"cloud_enum -k {domain} -k {company} "
                                      f"(active multi-cloud bucket brute-force)")

        # GitHub secret scanning — TruffleHog (org scan via API, live verify)
        if cfg.run_trufflehog and "trufflehog" in ready and not self._is_done(state, domain, "trufflehog"):
            if self._gate("trufflehog (GitHub org secret scan)"):
                from . import github_enum
                print("[phase1] trufflehog (GitHub)")
                org = self._get_org(domain)
                if org:
                    def _run_trufflehog():
                        github_enum.run_trufflehog(
                            org, self.outdir, self.command_log,
                            token=cfg.github_token, results=cfg.trufflehog_results,
                            include_members=cfg.trufflehog_include_members,
                            include_comments=cfg.trufflehog_include_comments,
                            dry_run=self.dry_run)
                    self._dispatch("trufflehog", state, domain, "trufflehog",
                                   _run_trufflehog, targets=[org],
                                   action=f"trufflehog github --org={org}")
                else:
                    self._mark_done(state, domain, "trufflehog")

        # GitHub secret scanning — Gitleaks (clone org public repos, scan each)
        if cfg.run_gitleaks and "gitleaks" in ready and not self._is_done(state, domain, "gitleaks"):
            if self._gate("gitleaks (GitHub repo clone + scan)"):
                from . import github_enum
                print("[phase1] gitleaks (GitHub)")
                org = self._get_org(domain)
                if org:
                    def _run_gitleaks():
                        github_enum.run_gitleaks(
                            org, self.outdir, self.command_log,
                            token=cfg.github_token,
                            clone_depth=cfg.gitleaks_clone_depth,
                            max_repos=cfg.gitleaks_max_repos,
                            dry_run=self.dry_run)
                    self._dispatch("gitleaks", state, domain, "gitleaks",
                                   _run_gitleaks, targets=[org],
                                   action=f"gitleaks github org={org} "
                                          f"(clone+scan, max_repos={cfg.gitleaks_max_repos})")
                else:
                    self._mark_done(state, domain, "gitleaks")

        # FunnelWeb is REQUIRED — it does a core chunk of the crawl/discovery work.
        # It is NOT optional and NOT gated by a prompt. If it's enabled (the
        # default), it RUNS. If its deps are missing, we auto-install them and
        # proceed rather than skip. The ONLY way it does not run is if the operator
        # explicitly sets run_funnelweb=false in the config.
        if not cfg.run_funnelweb:
            print("[funnelweb] disabled in config (run_funnelweb=false) — the only "
                  "way to skip this REQUIRED step. Skipping.")
        elif not self._is_done(state, domain, "funnelweb"):
            if "funnelweb" not in ready:
                # Required step is not ready — do NOT skip. Try to make it ready by
                # installing the missing dependencies, then run it anyway. Skip the
                # install during a dry-run preview (never pip/apt on a dry-run).
                if self.dry_run:
                    print("[funnelweb] (dry-run) REQUIRED but not ready — would "
                          "auto-install deps and run in a real run.")
                else:
                    print("[funnelweb] REQUIRED step not ready — attempting to install "
                          "missing dependencies now (this is not optional)…")
                    self._ensure_funnelweb_deps()
            from . import funnelweb
            print("[phase1] funnelweb (REQUIRED)")
            fwd_proxy = self._forward_proxy()

            # Multi-target: crawl every VALIDATED WEBAPP host (WebGet's urls.txt),
            # one at a time, so FunnelWeb covers each app the fuzzers hit — not just
            # the bare domain. Fall back to [domain] if urls.txt isn't present
            # (WebGet didn't run / degraded), preserving the old single-seed run.
            fw_targets = self._funnelweb_targets(domain)

            def _run_funnelweb():
                labels = funnelweb.run_funnelweb_multi(
                    fw_targets, self.outdir, self.command_log,
                    script=cfg.funnelweb_script,
                    workers=cfg.funnelweb_workers,
                    rate_limit=cfg.funnelweb_rate_limit,
                    proxy=fwd_proxy,
                    stealth=cfg.funnelweb_stealth,
                    dry_run=self.dry_run)
                self._funnelweb_labels = labels
            self._dispatch("funnelweb", state, domain, "funnelweb",
                           _run_funnelweb, targets=fw_targets,
                           action=f"FunnelWeb.py --url (x{len(fw_targets)} webapp "
                                  f"targets, async crawler, REQUIRED)")
            # ingest each target's output for the At a Glance tab (skip on dry-run).
            # Each summary is tagged 'FunnelWeb - <target label>' so the workbook
            # covers every crawled host distinctly.
            if not self.dry_run:
                for label in getattr(self, "_funnelweb_labels", []):
                    report_csv = funnelweb.find_report(self.outdir, label)
                    if report_csv:
                        summary = funnelweb.ingest_report(report_csv, [label])
                        try:
                            summary.domain = label   # tag = the crawled target
                        except Exception:  # noqa: BLE001
                            pass
                        self.funnelweb_summaries.append(summary)

    # ---- phase 2 ----
    def _funnelweb_targets(self, domain: str) -> list:
        """The webapp targets FunnelWeb crawls, IN ORDER: the recon DOMAIN first,
        then WebGet's urls.txt hosts (the same validated set the fuzzers hit),
        deduped. Domain-first so the client's main site is crawled before the
        per-host validated URLs. Scope-safe: the domain is the operator's recon
        scope and urls.txt is already in-scope by WebGet's construction. If there is
        no urls.txt (WebGet didn't run / degraded), the domain alone is crawled."""
        targets, seen = [], set()

        def _add(u):
            u = (u or "").strip()
            if u and not u.startswith("#") and u not in seen:
                seen.add(u)
                targets.append(u)

        _add(domain)                                    # 1) recon domain first
        n_domain = len(targets)
        urls_file = self.outdir / getattr(self.cfg, "hostval_urls_file", "urls.txt")
        if urls_file.is_file():                         # 2) then urls.txt hosts
            for line in urls_file.read_text(errors="replace").splitlines():
                _add(line)
        n_from_urls = len(targets) - n_domain
        print(f"[funnelweb] {len(targets)} webapp target(s): recon domain "
              f"'{domain}' first + {n_from_urls} from urls.txt")
        return targets or [domain]


    def _funnelweb_missing_deps(self) -> list:
        """Return the list of missing FunnelWeb python deps (import names)."""
        import importlib.util
        want = ["patchright", "aiohttp", "aiofiles", "magic"]
        return [m for m in want if importlib.util.find_spec(m) is None]

    def _ensure_funnelweb_deps(self) -> None:
        """FunnelWeb is REQUIRED, so if its deps are missing we install them and
        proceed — we do not skip. Installs the pip packages, the Playwright
        chromium browser, and best-effort the libmagic system lib. Anything that
        can't be auto-installed is reported clearly, but the run still attempts
        FunnelWeb (it may partially work / the user can fix the remainder)."""
        import importlib, importlib.util, subprocess, sys, shutil
        pip_for = {"patchright": "patchright", "aiohttp": "aiohttp",
                   "aiofiles": "aiofiles", "magic": "python-magic"}
        missing = self._funnelweb_missing_deps()
        if missing:
            pkgs = [pip_for[m] for m in missing]
            print(f"[funnelweb] installing required deps: {', '.join(pkgs)}")
            try:
                subprocess.run([sys.executable, "-m", "pip", "install",
                                "--quiet", *pkgs], check=False)
            except Exception as e:  # noqa: BLE001
                print(f"[funnelweb] pip install error: {e}")
            importlib.invalidate_caches()

        # Patchright needs its browser binary; install chromium if patchright is now present.
        if importlib.util.find_spec("patchright") is not None:
            try:
                print("[funnelweb] ensuring Playwright chromium is installed…")
                subprocess.run([sys.executable, "-m", "patchright", "install",
                                "chromium"], check=False)
            except Exception as e:  # noqa: BLE001
                print(f"[funnelweb] patchright browser install error: {e}")

        # libmagic system lib (python-magic imports but fails at runtime without it).
        if importlib.util.find_spec("magic") is not None:
            try:
                import magic  # noqa: F401
                magic.Magic(mime=True)
            except Exception:
                print("[funnelweb] python-magic present but libmagic system lib "
                      "missing — attempting apt install libmagic1 (needs sudo)…")
                if shutil.which("apt") or shutil.which("apt-get"):
                    apt = shutil.which("apt-get") or shutil.which("apt")
                    for cmd in ([apt, "install", "-y", "libmagic1"],
                                ["sudo", apt, "install", "-y", "libmagic1"]):
                        try:
                            r = subprocess.run(cmd, check=False)
                            if r.returncode == 0:
                                break
                        except Exception:  # noqa: BLE001
                            continue

        still = self._funnelweb_missing_deps()
        if still:
            pkgs = [pip_for[m] for m in still]
            print(f"[funnelweb] WARNING: still missing after auto-install: "
                  f"{', '.join(pkgs)}. FunnelWeb will attempt to run anyway; if it "
                  f"fails, install manually: pip install {' '.join(pkgs)} && "
                  f"patchright install chromium && sudo apt install libmagic1")
        else:
            print("[funnelweb] all dependencies satisfied — proceeding.")

    def _run_final_stage(self) -> None:
        """The FINAL STAGE — post-processing enrichment, run once after every
        recon phase (0-2) is done for every domain. These are NOT recon tools;
        they consume the COMPLETE union of discovered data:

          cvemap : discovered tech (httpx tech-detect + shodan CPEs + FunnelWeb
                   crawl signals) -> CVE IDs for the client's stack.
          Cache  : those CVE IDs -> public PoC exploit URLs (poc-in-github API).

        Ordered last because each needs the full picture the phases produced.
        Each is independently fault-isolated (a failure here never costs the
        final report). Results are stashed for the report/workbook.
        """
        self._cvemap_hits = []
        # --- Shodan on-demand scan collection (if one was submitted early) ---
        # Async scan submitted during phase-0 shodan step has had the whole run to
        # complete; collect + save now, before cvemap (fresh CPEs/vulns can feed it).
        if getattr(self.cfg, "run_shodan", True):
            try:
                from . import shodan_tool
                api_key = getattr(self.cfg, "shodan_api_key", "")
                if api_key:
                    client = (self.cfg.domains[0] if getattr(self.cfg, "domains", None)
                              else getattr(self.cfg, "engagement_name", "client"))
                    shodan_tool.collect_ondemand_scan(
                        self.outdir, api_key, client=client,
                        command_log=self.command_log)
            except Exception as e:  # noqa: BLE001
                print(f"[final:shodan-scan] collection skipped: {e}")

        # --- cvemap: complete tech list -> CVEs ---
        if getattr(self.cfg, "run_cvemap", True):
            try:
                from . import cvemap_tool
                print("[final:cvemap] CVE lookup on ALL discovered tech "
                      "(httpx + shodan + FunnelWeb)")
                self._cvemap_hits = cvemap_tool.process(
                    self.outdir, self.command_log, dry_run=self.dry_run,
                    api_key=getattr(self.cfg, "cvemap_api_key", "")) or []
            except Exception as e:  # noqa: BLE001
                print(f"[final:cvemap] skipped: {e}")

        # --- Cache (Stockpiler Exp): CVEs -> public PoC exploit URLs ---
        if getattr(self.cfg, "run_cache", True) and not self.dry_run:
            try:
                from . import cache
                cve_ids = sorted({h.cve_id for h in self._cvemap_hits
                                  if getattr(h, "cve_id", "")})
                if not cve_ids:
                    cve_ids = self._cve_ids_from_csv()   # fall back to cvemap CSV
                cache.run_cache(self.outdir, cve_ids,
                                tech_names=None,   # CVE-driven primary; tech is noisy
                                enabled=True)
            except Exception as e:  # noqa: BLE001
                print(f"[final:Cache (Stockpiler Exp)] skipped: {e}")

    def _run_phase2(self, domain: str, ready: set, state: dict):
        cfg = self.cfg

        if cfg.run_emailenum and "emailenum" in ready and not self._is_done(state, domain, "emailenum"):
            if self._gate("LinkThief (LinkedIn email enumeration)"):
                from . import emailenum
                print("[LinkThief] LinkedIn email enumeration (SerpAPI)")
                business = (emailenum.prompt_business(
                                getattr(cfg, "email_business", ""))
                            if not self.dry_run else "")
                # If no business name was provided, auto-discover the LinkedIn
                # company page from the domain (SerpAPI), confirm it, and derive
                # the business name from its slug — so a blank field doesn't just
                # skip LinkThief entirely.
                if not business and not self.dry_run and getattr(cfg, "serpapi_key", ""):
                    discovered = emailenum.discover_company_url(
                        domain, cfg.serpapi_key)
                    if discovered:
                        import re as _re
                        m = _re.search(r"/company/([^/?#]+)", discovered)
                        if m:
                            business = m.group(1).replace("-", " ").strip()
                            print(f"[LinkThief] using discovered company name: "
                                  f"'{business}'")
                # email format changes per client — prompt, defaulting to config value
                email_format = (emailenum.prompt_email_format(cfg.email_format)
                                if not self.dry_run else cfg.email_format)
                def _run_linkthief():
                    if business and not self.dry_run:
                        emailenum.process(business, domain, email_format,
                                          cfg.serpapi_key, self.outdir)
                # LinkThief previously logged NOTHING (API tool) — now its SerpAPI
                # action is recorded in the unified commands.log via _dispatch.
                self._dispatch("LinkThief", state, domain, "emailenum",
                               _run_linkthief, targets=[business or domain],
                               action=f"LinkThief serpapi q='site:linkedin.com/in "
                                      f"{business}' domain={domain} format={email_format}")

        if cfg.run_partyon and "partyon" in ready and not self._is_done(state, domain, "partyon"):
            if self._gate("partyon (breach/credential lookup)"):
                from . import partyon
                print("[phase2] partyon")
                def _run_partyon():
                    # SECURITY-SENSITIVE: partyon_spray FIRES credential stuffing.
                    # Read it from THIS client's config (the campaign child skips
                    # the interview); default False (results-only) if unset.
                    _spray = bool(getattr(cfg, "partyon_spray", False))
                    _proxy = getattr(cfg, "partyon_proxy", "") or ""
                    _seconds = getattr(cfg, "partyon_seconds", 3)
                    partyon.process(domain, self.outdir, self.command_log,
                                    primary_domain=self._primary_domain,
                                    script=cfg.partyon_script,
                                    api_key=cfg.dehashed_api_key,
                                    config_path=getattr(self, "_config_path", None),
                                    ledger=self.ledger, dry_run=self.dry_run,
                                    confirm_domain=False,
                                    spray=_spray, proxy=_proxy, seconds=_seconds)
                self._dispatch("partyon", state, domain, "partyon", _run_partyon,
                               targets=[domain],
                               action=f"partyon dehashed breach lookup domain={domain}")

        if cfg.run_snov and "snov" in ready and not self._is_done(state, domain, "snov"):
            if self._gate("snov"):
                from . import snov
                print("[phase2] snov")
                def _run_snov():
                    snov.process(domain, self.outdir, self.command_log,
                                 client_id=cfg.snov_client_id,
                                 client_secret=cfg.snov_client_secret,
                                 ledger=self.ledger, dry_run=self.dry_run)
                self._dispatch("snov", state, domain, "snov", _run_snov,
                               targets=[domain],
                               action=f"snov.io domain-search domain={domain}")

    def _prompt_resolvers_once(self) -> str:
        if self._resolvers_prompted:
            return self._resolvers_prompted
        from .runmode import is_unattended
        if is_unattended():
            # fall back to the configured resolvers file, else empty
            self._resolvers_prompted = getattr(self.cfg, "resolvers_file", "") or ""
            return self._resolvers_prompted
        try:
            ans = input("Path to resolvers file (for subdomain resolution): ").strip()
        except EOFError:
            ans = ""
        self._resolvers_prompted = ans
        return ans
