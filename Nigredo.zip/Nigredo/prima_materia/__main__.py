"""Command-line interface + top-level dispatch — the outermost layer of the carriage.

This module parses the command, gathers inputs, and dispatches to one of the two
engines: Pipeline (active scan, Phase 0) or ReconOrchestrator (recon, Phase 1+2).

PRIMARY COMMANDS (what operators actually use):
  engagement-init   scaffold config + data files for a new engagement folder
                    (PRESERVES existing config files; only refreshes targets.txt)
  engagement        the main run. Shows a menu (all / from a phase / single tool),
                    gathers domains + runs the setup interview UP FRONT, then runs
                    UNATTENDED to completion. --manual restores step-by-step prompts.

LEGACY/SIMPLE COMMANDS:
  init              older single-file scaffold (config.json + scope.txt + targets.txt)
  run  -c cfg.json  run the active-scan Pipeline directly (--dry-run prints commands)

DISPATCH MAP (command -> engine):
  engagement/all         -> _run_phase0 (Pipeline)  then  _run_recon (ReconOrchestrator)
  engagement/from_phase  -> whichever phase(s) the operator picked
  run                    -> Pipeline only

SEED PREREQUISITES (the only things that HARD-FAIL a run — everything else is
isolated and skips): no targets (targets.txt empty + scope unexpandable ->
ScopeViolation), no nmap on PATH (NmapNotFound -> Phase 0 skipped), no nessus
seed where required. These are caught here at the dispatch level.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .config import Config
from .pipeline import Pipeline
from .runner import NmapNotFound
from .scope import ScopeViolation
from .recon_config import ReconConfig
from .recon_orchestrator import ReconOrchestrator


def cmd_init(args: argparse.Namespace) -> int:
    cfg = Config()
    cfg.dump("config.json")
    if not Path("scope.txt").exists():
        Path("scope.txt").write_text(
            "# Authorization allowlist. One rule per line.\n"
            "# CIDR / IP / hostname / *.wildcard.example.com\n"
            "# 203.0.113.0/24\n"
            "# app.client.com\n"
            "# *.client.com\n"
        )
    if not Path("targets.txt").exists():
        Path("targets.txt").write_text(
            "# Hosts to scan, one per line. Each must be covered by scope.txt.\n"
        )
    print("Wrote config.json, scope.txt, targets.txt. Edit these before running.")
    print("IMPORTANT: scope.txt must reflect your written authorization for this engagement.")
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    cfg = Config.load(args.config)
    try:
        pipeline = Pipeline(cfg, dry_run=args.dry_run, assume_yes=args.yes)
        pipeline.run()
    except ScopeViolation as e:
        print(f"\n[SCOPE VIOLATION] {e}", file=sys.stderr)
        print("Run halted. No further scanning performed. "
              "Fix targets.txt or scope.txt and re-run.", file=sys.stderr)
        return 2
    except ValueError as e:
        print(f"\n[ERROR] {e}", file=sys.stderr)
        print("Run halted. Check that scope.txt contains at least one "
              "IP/CIDR/hostname rule, then re-run.", file=sys.stderr)
        return 2
    return 0


_DEFAULT_DKIM_SELECTORS = (
    # full selector wordlist (operator-provided)
    "04042017\n0xdeadbeef\n1\nfid48\n2020-07\n1000073432\n10dkim1\n11dkim1\n123\n12345\n12dkim1\n13q2\n2\n2005\n200505\n2006\n200608\n2007\n2008\n2009\n2010\n2011\n2012\n2013\n2014\n2015\n20150120150420144305.pm\n2016\n20160523212918pm\n2017\n2018\n2019\n2020\n2021\n2022\n2023\n2024\n247\n3\n384\n512\n768\n86\nac_v1\nac_v2\nallselector\nalpha\namazonses\namazonses2\namazonses3\namp\napi\nauth\nauthsmtp\naweber_key_a\naweber_key_b\naweber_key_c\nbdk\nbenchmarkemail\nbeta\nbfi\nb-rail\nbrj\nbronto\nbronto2\nbronto3\nC2\nca\ncare\nccnt\nccnt2\nccnt3\ncentralsmtp\ncerner-2\nciprod\nclass\ncm\ncmail1\ncmail2\ncmail3\ncmail4\ncoa\nconnect_1\nconvio1\ncorp\nCorporate\ncritsend2\ncv-usprod-1\nd2005\nd2006\nd2007\nd2008\nd2009\nd2010\nd2011\nd2012\nd2013\nd2014\nd2015\nd2016\nd2017\nd2018\nd2019\nd2020\nd2021\nd2022\nd2023\nd2024\ndefault\ndefault1k\ndelta\ndesmoines\ndk\ndk01\ndk02\ndk03\ndk04\ndk05\ndk06\ndk07\ndk08\ndk09\ndk1\ndk10\ndk1024\ndk1024-2012\ndk1024-2013\ndk1024-2014\ndk1024-2015\ndk1024-2016\ndk1024-2017\ndk1024-2018\ndk1024-2019\ndk1024-2020\ndk1024-2021\ndk1024-2022\ndk1024-2023\ndk1024-2024\ndk11\ndk12\ndk13\ndk14\ndk15\ndk16\ndk17\ndk18\ndk19\ndk2\ndk20\ndk2005\ndk20050327\ndk2006\ndk2007\ndk2008\ndk2009\ndk2010\ndk2011\ndk2012\ndk2013\ndk2014\ndk2015\ndk2016\ndk2017\ndk2018\ndk2019\ndk2020\ndk2021\ndk2022\ndk2023\ndk2024\ndk2048\ndk256\ndk3\ndk384\ndk4\ndk5\ndk512\ndk6\ndk7\ndk768\ndk8\ndk9\n_dkim\ndkim\ndkim01\ndkim02\ndkim03\ndkim04\ndkim05\ndkim06\ndkim07\ndkim08\ndkim09\ndkim1\ndkim10\ndkim1024\ndkim11\ndkim12\ndkim13\ndkim14\ndkim15\ndkim16\ndkim17\ndkim18\ndkim19\ndkim1k\ndkim2\ndkim20\ndkim-201303\ndkim2048\ndkim256\ndkim3\ndkim384\ndkim4\ndkim5\ndkim512\ndkim6\ndkim7\ndkim768\ndkim8\ndkim9\ndkimmail\ndkimrnt\ndkim_s1024\ndkrnt\ndksel\ndomk\nduh\ndyn\ndyn2\ndyn3\ndynect\ndynect1213\neb1\neb10\neb11\neb12\neb13\neb14\neb15\neb16\neb17\neb18\neb19\neb2\neb20\neb3\neb4\neb5\neb6\neb7\neb8\neb9\nebmailerd\nec\neclinicalmail\nED-DKIM\nED-DKIM-V3\neentf\nei\nelq\nelq2\nelq3\nemail0517\nemailvision\nemarsys\nemarsys1\nemarsys2\nemarsys2007\nemarsys3\nemk01\nemma\nemv\nent\net\net1\net2\net3\neverlytickey1\neverlytickey2\nexacttarget\nexim\nexim4u\nexpertsender\nEXPNSER28042022\nfacebook\nfandango\nfishbowl\nfitnessintl\nfm1\nfm2\nfm3\nfm4\nfm5\nfm6\nfm7\nfm8\nfm9\nfnt\ngamma\ngears\nglobal\ngmmailerd\ngodaddy\ngoldlasso\ngoogle\ngoogleapps\nhilton\nhs1\nhs2\nhubris\nhubspot1\nhubspot2\nhubspot3\nicontact\niconzdkim\nid\ninsideapple0517\ninsideapple2048\ninsideicloud2048\niport\niron.johnscreek7\nitunes\nitunes2048\niweb\njul13mimi\nk1\nk10\nk11\nk12\nk13\nk14\nk15\nk16\nk17\nk18\nk19\nk2\nk20\nk3\nk4\nk5\nk6\nk7\nk8\nk9\nkey\nkey1\nkey10\nkey11\nkey12\nkey13\nkey14\nkey15\nkey16\nkey17\nkey18\nkey19\nkey2\nkey20\nkey3\nkey4\nkey5\nkey6\nkey7\nkey8\nkey9\nkrs\nlistrak\nlists\nlocaweb\nls1\nls10\nls11\nls12\nls13\nls14\nls15\nls16\nls17\nls18\nls19\nls2\nls20\nls3\nls4\nls5\nls6\nls7\nls8\nls9\nlufthansa-group\nm\nm1\nm10\nm1024\nm11\nm12\nm13\nm14\nm15\nm16\nm17\nm18\nm19\nm2\nm20\nm2048\nm21\nm22\nm23\nm24\nm25\nm3\nm384\nm4\nm5\nm512\nm6\nm7\nm768\nm8\nm9\nmail\nmail1\nmail2\nmail3\nmail4\nmail5\nmailchannels\nmailchannels1\nmailchannels2\nmailchannels3\nmailchannels4\nmailchannels5\nmail-dkim\nmailer\nmailgun\nmailigen\nmail-in\nmailjet\nmailjet1\nmailjet2\nmailo\nmailrelay\nmain\nmandrill\nmarketo\nmcdkim\nmcdkim1\nmcdkim2\nmcdkim3\nmcdkim4\nmcdkim5\nmdaemon\nmesmtp\nmessagebus\nmg\nmga\nmikd\nmimecast\nmimecast20230622\nmimi\nmixmax\nmixpanel\nmkt\nml\nml1\nml2\nml3\nmonkey\nmsa\nmt\nmta0\nmx\nmxvault\nmy1\nmy10\nmy11\nmy12\nmy13\nmy14\nmy15\nmy16\nmy17\nmy18\nmy19\nmy2\nmy20\nmy3\nmy4\nmy5\nmy6\nmy7\nmy8\nmy9\nncr1\nneolane\nneomailout\nNewSelectorA\nnewyork\nnl1\nnl2\nnl3\none\nops\nops2\nops3\noraclersys\noriginating\noutbound\noutbound20\np1211\npardot\npf2005\npf2006\npf2007\npf2008\npf2009\npf2010\npf2011\npf2012\npf2013\npf2014\npf2015\npf2016\npf2017\npf2018\npf2019\npf2020\npf2021\npf2022\npf2023\npf2024\npgr\npic\npm\npm2\npm3\npmta\npostfix\npostfix.private\npostmark\npp\npp1\npp2\npp3\npp4\npp5\npp6\npp7\npp8\npp9\npp-dkim1\npps1\nPPS1\npps2\npps3\npps4\nprimary\nprimus\nprivate\nprod\nproddkim\nproddkim1024\nproddkim2048\nproddkim256\nproddkim384\nproddkim512\nproddkim768\nproton\nprotonmail\nprotonmail1\nprotonmail2\nprotonmail3\nprotonmail4\nprotonmail5\nprotonmail6\nprotonmail7\nprotonmail8\nprotonmail9\nprv2019\npub\npublickey\npvt\nqcdkim\nqualtrics\nr2v2\nresponsys\nrit1608\nrocketmail\nrsa\nrsa1\nrsa10\nrsa1024\nrsa11\nrsa12\nrsa13\nrsa14\nrsa15\nrsa16\nrsa17\nrsa18\nrsa19\nrsa2\nrsa20\nrsa3\nrsa384\nrsa4\nrsa5\nrsa512\nrsa6\nrsa7\nrsa768\nrsa8\nrsa9\nrsys\nrsys2\nrsys3\ns\ns1\ns10\ns1024\ns11\ns12\ns13\ns14\ns15\ns16\ns17\ns18\ns19\ns2\ns20\ns2005\ns2006\ns2007\ns2008\ns2009\ns2010\ns2011\ns2012\ns2013\ns2014\ns2015\ns2016\ns2017\ns2018\ns2019\ns2020\ns2021\ns2022\ns2023\ns2024\ns2048\ns2048g1\ns3\ns384\ns4\ns5\ns512\ns6\ns7\ns768\ns8\ns9\nsafe\nsailthru\nsalesforce\nsalesforce1\nsalesforce2\nsalesforce3\nsasl\nscarlet\nscooby\nscph\nscph0121\nscph0319\nscph0420\nscph0919\nsel1\nsel10\nsel11\nsel12\nsel13\nsel14\nsel15\nsel16\nsel17\nsel18\nsel19\nsel2\nsel20\nsel3\nsel4\nsel5\nsel6\nsel7\nsel8\nsel9\nselector\nselector1\nselector10\nselector11\nselector12\nselector13\nselector14\nselector15\nselector16\nselector17\nselector18\nselector19\nselector2\nselector20\nselector3\nselector4\nselector5\nselector6\nselector7\nselector8\nselector9\nselector_ups\nsendinblue\nserver\nses\nsfdc\nsfmc48\nsg\nsharedpool\nsilverpop\nsitemail\nsl\nsl1\nsl10\nsl11\nsl12\nsl13\nsl14\nsl15\nsl16\nsl17\nsl18\nsl19\nsl2\nsl20\nsl3\nsl4\nsl5\nsl512\nsl6\nsl7\nsl8\nsl9\nsm\nsm1024\nsmtp\nsmtpapi\nsmtpauth\nsmtpcomcustomers\nsmtpout\nsnowcrash\nsocketlabs\nsp1024sep2015\nsparkpost\nsparkpost1\nsparkpost2\nsparkpost3\nsparkpostmail\nspf\nspop\nspop1024\nspop2048\nspop512\nspop768\nsquaremail\nstigmate\nsusa1024\ntayl\ntest\ntestdk\ntestdkim\ntestdkim1024\ntestdkim2048\ntestdkim256\ntestdkim384\ntestdkim512\ntestdkim768\nthisismyselector1234\ntilprivate\nto\nturbosmtp\nunited\nv1\nv2\nv3\nv4\nv5\nvii09\nvr\nvzrelay\nwesmail\nwww\nx\nyahoo\nyandex\nyesmail\nyesmail1\nyesmail10\nyesmail11\nyesmail12\nyesmail13\nyesmail14\nyesmail15\nyesmail16\nyesmail17\nyesmail18\nyesmail19\nyesmail2\nyesmail20\nyesmail3\nyesmail4\nyesmail5\nyesmail6\nyesmail7\nyesmail8\nyesmail9\nyibm\nym1024\nymail\nymail4\nyousendit\nzendesk1\nzendesk2\nzendesk3\nzendesk4\nzm1\nzoho\n"
)


def cmd_engagement_init(args: argparse.Namespace) -> int:
    """Scaffold input files for a full phase 0+1+2 chained run.

    Config files (config.json, recon_config.json, resolvers.txt,
    dkim_selectors.txt) are PRESERVED if they already exist — so a user's
    filled-in keys/tuning (or a dropped-in backup) survive re-running init.
    targets.txt is ALWAYS refreshed to a clean template, so nobody ever runs
    stale targets from a previous engagement.
    """
    created, kept = [], []

    # --- config files: keep if present, create only if missing ---
    if Path("config.json").exists():
        kept.append("config.json")
    else:
        Config().dump("config.json"); created.append("config.json")

    if Path("resolvers.txt").exists():
        kept.append("resolvers.txt")
    else:
        Path("resolvers.txt").write_text("8.8.8.8\n8.8.4.4\n")
        created.append("resolvers.txt")

    if Path("dkim_selectors.txt").exists():
        kept.append("dkim_selectors.txt")
    else:
        Path("dkim_selectors.txt").write_text(_DEFAULT_DKIM_SELECTORS)
        created.append("dkim_selectors.txt")

    if Path("recon_config.json").exists():
        kept.append("recon_config.json")
    else:
        rcfg = ReconConfig()
        rcfg.resolvers_file = "resolvers.txt"
        rcfg.dkim_wordlist = "dkim_selectors.txt"
        rcfg.dump("recon_config.json")
        created.append("recon_config.json")

    # --- targets.txt: ALWAYS refreshed so stale targets can't linger ---
    _TARGETS_TEMPLATE = (
        "# Put the IPs / CIDR / hostnames you are AUTHORIZED to scan here,\n"
        "# one per line. Everything listed here is treated as in-scope and\n"
        "# will be scanned in phase 0.\n"
        "#\n"
        "# Domains for recon + email (phase 1/2) are NOT put here — the tool\n"
        "# will ASK you for those when it reaches that stage.\n"
        "#\n"
        "# 203.0.113.42\n"
        "# 203.0.113.0/24\n"
        "# host.client.com\n"
    )
    # PRESERVE a filled targets.txt (like the config files above). The old behavior
    # ALWAYS reset targets.txt to a blank template, which silently wiped your scan
    # scope whenever init was re-run — the exact "filled the run before, empty the
    # next" footgun. Only (re)write the template when targets.txt is missing or has
    # no real targets (comment/blank-only). A filled file is always kept.
    def _has_real_targets(p):
        try:
            return any(ln.strip() and not ln.strip().startswith("#")
                       for ln in Path(p).read_text(errors="replace").splitlines())
        except OSError:
            return False

    targets_filled = Path("targets.txt").exists() and _has_real_targets("targets.txt")
    if targets_filled:
        kept.append("targets.txt")
    else:
        Path("targets.txt").write_text(_TARGETS_TEMPLATE)
        created.append("targets.txt")

    # --- report what happened ---
    if created:
        print("Created: " + ", ".join(created))
    if kept:
        print("Kept (already present, not overwritten): " + ", ".join(kept))
    if targets_filled:
        print("\n>>> targets.txt already has scan targets — kept as-is.")
    else:
        print("\n>>> Fill in targets.txt with THIS engagement's authorized "
              "IP(s)/host(s)/CIDR(s), one per line, before you run.")
    print("Config files are preserved — your keys/tuning carry over.")
    print("You'll be asked for recon domains when the run reaches that stage.")
    return 0


def _run_discovery_prepass(args, client_name, domains) -> None:
    """OPTION 3 ordering fix: run subdomain discovery (subfinder) and host
    validation (WebGet) BEFORE phase 0's fuzzers, so nuclei/ffuf/feroxbuster aim
    at WebGet's validated urls.txt instead of bare IPs.

    Why a pre-pass (not inside phase0): subfinder normally lives in the recon
    engine, which runs AFTER phase0 — too late for the fuzzers. Rather than open
    the recon/scan firewall (correlate_domains stays []), we run subfinder here as
    passive OSINT (it never widens scope; targets.txt stays the spine), write its
    output into the UNIFIED engagement folder, then run WebGet to build urls.txt /
    403.txt there. Phase 0 then consumes urls.txt; the recon engine later AUTO-
    SKIPS subfinder via the shared audit 'subdomains' completion marker.

    Scope-safe, resumable (markers skip repeat work), and degrades: no domains ->
    nothing to enumerate (WebGet still runs IP-only from targets.txt); any failure
    is logged and phase 0 re-runs host validation in-process to (re)build urls.txt
    (and skips the web-fuzz tools if that too yields nothing).
    """
    if args.dry_run:
        return
    try:
        cfg = Config.load(args.config)
        cfg.targets_file = "targets.txt"
        cfg.scope_file = "targets.txt"
        cfg.engagement_name = client_name
        outdir = Path(cfg.output_dir) / cfg.engagement_name
        outdir.mkdir(parents=True, exist_ok=True)
        command_log = outdir / "commands.log"
    except Exception as e:  # noqa: BLE001
        print(f"[prepass] setup skipped ({e}); phase 0 will (re)build urls.txt "
              f"in-process via host validation")
        return

    print("\n" + "=" * 60)
    print(" DISCOVERY PRE-PASS — subfinder + host validation (before fuzzers)")
    print("=" * 60)

    # 1) subfinder per domain (passive OSINT). Skipped per-domain by the shared
    #    audit marker, which the recon engine also honors (no double run).
    if domains and getattr(cfg, "run_subdomains", True):
        from . import audit
        from . import subdomains
        # Forward the configured resolvers file so the FULL resolve stage
        # (shuffledns/dnsx) runs, giving host validation richer .clean.csv data
        # (names WITH IPs). If it's unset/missing, subfinder still runs
        # enumeration-only (bare names) — host validation resolves them itself.
        resolvers = getattr(cfg, "resolvers_file", "") or ""
        if resolvers and not Path(resolvers).is_file():
            print(f"[prepass] configured resolvers file '{resolvers}' not found — "
                  f"subfinder will run enumeration-only")
            resolvers = ""
        for domain in domains:
            try:
                if audit.is_complete(outdir, "subdomains", domain):
                    print(f"[prepass] subfinder already done for {domain} — skip")
                    continue
                audit.log_action(command_log, "subdomains",
                                 f"subfinder -d {domain} (pre-pass)")
                subdomains.process_domain(domain, outdir, command_log,
                                          resolvers=resolvers,
                                          dry_run=args.dry_run)
                audit.mark_complete(outdir, "subdomains", domain)
            except Exception as e:  # noqa: BLE001
                print(f"[prepass] subfinder {domain} failed ({e}); continuing")
    elif not domains:
        print("[prepass] no domains — WebGet will correlate targets.txt IP-only")

    # 2) host validation (WebGet): targets.txt + discovered subdomains -> urls.txt
    #    / 403.txt in the same unified folder. Runs standalone (no Pipeline needed).
    if getattr(cfg, "hostval_enabled", True):
        _run_prepass_hostval(cfg, outdir, command_log, domains, args)


def _run_prepass_hostval(cfg, outdir, command_log, domains, args) -> None:
    """Run WebGet in the pre-pass: combine subfinder outputs, correlate, emit
    urls.txt/403.txt into the unified folder. Mirrors Pipeline._run_host_validation
    but standalone (no Pipeline instance needed)."""
    from . import audit
    if audit.is_complete(outdir, "host_validation"):
        print("[prepass] host_validation already complete — reusing urls.txt/403.txt")
        return
    # combine subfinder raw name lists (bare hostnames)
    sf_files = sorted(outdir.glob("subdomains_*.subfinder.txt"))
    combined = None
    if sf_files:
        combined = outdir / "hostval_subdomains.txt"
        seen, lines = set(), []
        for p in sf_files:
            try:
                for ln in p.read_text(errors="replace").splitlines():
                    s = ln.strip()
                    if s and s not in seen:
                        seen.add(s); lines.append(s)
            except OSError:
                continue
        combined.write_text("\n".join(lines) + ("\n" if lines else ""))
        print(f"[prepass] {len(lines)} discovered name(s) from "
              f"{len(sf_files)} subfinder file(s)")
    else:
        print("[prepass] no subfinder output; WebGet correlates targets.txt IP-only")
    try:
        from .host_validation import run_host_validation
        audit.log_action(command_log, "host_validation",
                         "pre-pass correlate targets+subdomains -> urls.txt/403.txt")
        result = run_host_validation(
            cfg.targets_file, combined, outdir,
            resolve=True,
            no_probe=getattr(cfg, "hostval_no_probe", False),
            httpx_bin=getattr(cfg, "httpx_bin", None),
            jobs=getattr(cfg, "hostval_jobs", 5),
            ports=(getattr(cfg, "hostval_ports", "") or None),
            timeout=getattr(cfg, "hostval_timeout", 10),
        )
    except Exception as e:  # noqa: BLE001
        print(f"[prepass] host_validation skipped ({e}); phase 0 will (re)build "
              f"urls.txt in-process")
        return
    if result.get("ok"):
        audit.mark_complete(outdir, "host_validation")
        try:
            nu = len([u for u in Path(result["urls"]).read_text().splitlines()
                      if u.strip()])
        except OSError:
            nu = 0
        print(f"[prepass] host_validation complete — urls.txt has {nu} URL(s)")
    else:
        print("[prepass] host_validation produced no output; phase 0 will (re)build "
              "urls.txt in-process (web-fuzz tools skip if it stays empty)")


def _scan_targets_present(path) -> bool:
    """True if the targets file has >=1 real (non-comment, non-blank) scan target."""
    try:
        for ln in Path(path).read_text(errors="replace").splitlines():
            s = ln.strip()
            if s and not s.startswith("#"):
                return True
    except OSError:
        pass
    return False


def _require_scan_targets(path, label="targets.txt") -> bool:
    """HARD REQUIREMENT: every run must have scan targets. If the targets file is
    empty (missing/blank/comments-only), print a clear stop and return False so the
    caller aborts — recon-only runs are disabled so a run never wastes time/credits
    with nothing to scan."""
    if _scan_targets_present(path):
        return True
    print("\n" + "!" * 64)
    print("  [STOP] No scan targets — this run will not start.")
    print(f"         {label} is empty (missing, blank, or only comments):")
    print(f"           {path}")
    print("         Add at least one authorized host / IP / CIDR (one per line),")
    print("         then run again. Targets are REQUIRED — recon-only runs are off.")
    print("!" * 64 + "\n")
    return False


def _run_phase0(args, client_name, domains=None) -> bool:
    """Run phase 0 active scanning. Returns True if it ran."""
    print("\n" + "=" * 60)
    print(" PHASE 0 — active scanning")
    print("=" * 60)
    try:
        cfg = Config.load(args.config)
        _tgt = getattr(args, "_scan_targets_file", None) or "targets.txt"
        cfg.scope_file = _tgt
        cfg.targets_file = _tgt
        cfg.engagement_name = client_name
        # Nothing to scan? targets.txt is the active-scan scope. If it's empty (or
        # only comments), phase 0 (nmap / WebGet+urls.txt / ffuf / nuclei /
        # feroxbuster / testssl / sns) has NO targets. Say so LOUDLY and run recon-
        # only — instead of dying with a cryptic "scope file has no usable rules"
        # error that hid the real reason (WebGet lives in phase 0, so an empty
        # targets.txt means WebGet never runs and the run goes straight to recon).
        _tgt_lines = []
        try:
            for _ln in Path(_tgt).read_text(errors="replace").splitlines():
                _s = _ln.strip()
                if _s and not _s.startswith("#"):
                    _tgt_lines.append(_s)
        except OSError:
            pass
        if not _tgt_lines:
            print("\n" + "!" * 64)
            print("  [SKIP] PHASE 0 not run — targets.txt has NO scan targets.")
            print(f"         file: {_tgt}")
            print("         Active scanning (nmap, WebGet/urls.txt, ffuf, nuclei,")
            print("         feroxbuster, testssl, sns) reads targets.txt, and it is")
            print("         empty (only comments) — so there is nothing to scan and")
            print("         WebGet never runs. Running RECON-ONLY (from domains.txt).")
            print("         To run the scan + WebGet: add one host / IP / CIDR per")
            print("         line to targets.txt, then re-run.")
            print("!" * 64 + "\n")
            return False
        print(f"[phase0] {len(_tgt_lines)} scan target(s) from "
              f"{Path(_tgt).name}: {', '.join(_tgt_lines[:8])}"
              f"{' …' if len(_tgt_lines) > 8 else ''}")
        from . import runmode
        pipeline = Pipeline(cfg, dry_run=args.dry_run, assume_yes=args.yes,
                            # Recon/targets firewall: the domains typed at the
                            # preflight "Client domain(s)" prompt are RECON INPUT
                            # ONLY (subfinder, dnsrecon, dnstwist, dkim, fileenum,
                            # funnelweb, snov, emailenum, github, buckets, cloud_enum,
                            # partyon — all run by the recon engine). They must NEVER
                            # be resolved to IPs or fed to the scan/fuzz side. The
                            # active-scan engine (nmap/nuclei/ffuf/ferox/httpx-pool/
                            # testssl/etc.) is driven EXCLUSIVELY by targets.txt, so
                            # the typed domains are not handed to it at all.
                            correlate_domains=[],
                            # read-only confirmation key (redirect-to-own-FQDN only)
                            recon_domains_ref=domains or [],
                            # Nessus files: prefer the .nessus copied into THIS
                            # client's folder at campaign init (each client has its
                            # own, so --mode same can't collide). Fall back to the
                            # interview stash for the single-engagement flow.
                            nessus_files=(
                                [str(p) for p in
                                 (Path(cfg.output_dir) / client_name).rglob("*.nessus")]
                                or runmode.answer("nessus_files", None)))
        pipeline.run()
        return True
    except NmapNotFound:
        print("[notice] nmap not found on PATH — skipping phase 0 (active scan).",
              file=sys.stderr)
        return False
    except ScopeViolation as e:
        print(f"\n[notice] Phase 0 not run: {e}", file=sys.stderr)
        print("(Add IP(s)/host(s) to targets.txt to enable scanning.)",
              file=sys.stderr)
        return False
    except UnicodeDecodeError as e:
        # A decode error is NOT a benign scope/config skip — it means a file read
        # inside the scan pipeline hit a non-UTF-8 byte (e.g. a Windows-1252 smart
        # quote 0x92 in scraped gau/httpx output) and the whole active-scan phase
        # (nuclei/ffuf/feroxbuster/nomore403/testssl/sns) aborted before running.
        # This used to be swallowed by the `except ValueError` below and mislabeled
        # as "Phase 0 not run", silently killing the web tools. Surface it loudly
        # with a traceback so the failing read is visible, not disguised.
        import traceback
        print(f"\n[ERROR] Phase 0 CRASHED on a text-decoding error: {e}",
              file=sys.stderr)
        print("        A file read in the scan pipeline hit a non-UTF-8 byte. "
              "The web tools (nuclei/ffuf/feroxbuster/...) did NOT run.",
              file=sys.stderr)
        traceback.print_exc()
        return False
    except ValueError as e:
        # Genuine scope/config ValueErrors remain a soft skip. (UnicodeDecodeError,
        # a ValueError subclass, is intercepted above so it can't hide here.)
        print(f"\n[notice] Phase 0 not run: {e}", file=sys.stderr)
        return False
    except Exception as e:  # noqa: BLE001
        # Any other unexpected crash in the scan phase must be visible too, not
        # silently returning False. Recon still runs; the operator sees the cause.
        import traceback
        print(f"\n[ERROR] Phase 0 CRASHED unexpectedly: "
              f"{type(e).__name__}: {e}", file=sys.stderr)
        print("        The web tools (nuclei/ffuf/feroxbuster/...) did NOT run.",
              file=sys.stderr)
        traceback.print_exc()
        return False
    except KeyboardInterrupt:
        print("\n[i] Phase 0 interrupted; state saved.", file=sys.stderr)
        return False


def _run_recon(args, client_name, domains, phase1=True, phase2=True) -> bool:
    """Run phases 1 and/or 2. Returns True if anything ran."""
    print("\n" + "=" * 60)
    print(" PHASES 1 & 2 — passive recon + email enumeration")
    print("=" * 60)
    if not domains and not args.dry_run:
        print("[i] No domains entered — skipping recon/email phases.")
        return False
    rcfg = ReconConfig.load(args.recon_config)
    if client_name:
        rcfg.engagement_name = client_name
    # UNIFIED ENGAGEMENT FOLDER: phase 0 (Pipeline/Config) and recon
    # (ReconOrchestrator/ReconConfig) historically wrote to DIFFERENT folders
    # ("results" vs "recon_results"), so commands + outputs were split across two
    # places and the report/other tools couldn't see the whole run. Force recon to
    # use phase 0's folder so EVERYTHING (nmap, web tools, recon, email, the single
    # commands.log, every tool's targets + results) lands in one engagement folder.
    rcfg.output_dir = Config().output_dir      # same root as phase 0 ("results")
    if client_name:
        rcfg.engagement_name = client_name
    if domains:
        Path(rcfg.domains_file).write_text("\n".join(domains) + "\n")
        print(f"[i] recon will run against: {', '.join(domains)}")
        print(f"[i] output folder: {rcfg.output_dir}/{rcfg.engagement_name} (unified)")
    # toggle which phases run
    for t in ("dnsrecon", "dnstwist", "subdomains", "dkim", "fileenum"):
        setattr(rcfg, f"run_{t}", phase1 and getattr(rcfg, f"run_{t}"))
    for t in ("emailenum", "partyon", "snov"):
        setattr(rcfg, f"run_{t}", phase2 and getattr(rcfg, f"run_{t}"))
    try:
        orch = ReconOrchestrator(rcfg, dry_run=args.dry_run,
                                 prompt_between=not args.no_prompt,
                                 assume_yes=getattr(args, 'yes', False),
                                 config_path=getattr(args, 'recon_config', getattr(args, 'config', None)))
        orch.run()
        return True
    except FileNotFoundError:
        print("[notice] recon_config.json missing — skipping recon phases.",
              file=sys.stderr)
        return False
    except KeyboardInterrupt:
        print("\n[i] recon interrupted; progress saved, re-run to resume.",
              file=sys.stderr)
        return False


def _ask_domains() -> list[str]:
    # if the interview already gathered domains this run, reuse them (don't
    # re-prompt in the per-mode branches)
    from . import runmode
    if runmode.has_answer("_domains"):
        return runmode.answer("_domains", [])
    print("Enter the client domain(s). Separate multiple domains with commas.")
    print("  example:  example.com, client.com, target.org")
    # A valid domain: labels of letters/digits/hyphens (not starting/ending with a
    # hyphen), separated by dots, with a TLD of 2+ letters. This rejects bare
    # numbers ("1"), IPs, spaces, and anything with illegal characters — so a
    # fat-fingered menu pick can't silently become the "client name".
    import re as _re
    _DOMAIN_RE = _re.compile(
        r"^(?=.{1,253}$)"
        r"(?:[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?\.)+"
        r"[A-Za-z]{2,63}$")

    def _valid(d: str) -> bool:
        d = d.strip().rstrip(".").lower()
        # strip a scheme/path if the user pasted a URL
        d = _re.sub(r"^https?://", "", d).split("/")[0].split(":")[0]
        return bool(_DOMAIN_RE.match(d))

    def _clean(d: str) -> str:
        d = d.strip().rstrip(".").lower()
        d = _re.sub(r"^https?://", "", d).split("/")[0].split(":")[0]
        return d

    while True:
        try:
            raw = input("Client domain(s) "
                        "(first names the output folder; blank = scan only): ").strip()
        except EOFError:
            raw = ""
        if not raw:
            return []
        candidates = [d.strip() for d in raw.replace(",", " ").split() if d.strip()]
        good = [_clean(d) for d in candidates if _valid(d)]
        bad = [d for d in candidates if not _valid(d)]
        if bad:
            print(f"  [!] Not valid domain(s): {', '.join(bad)}")
            print("      Enter real domains like 'client.com' (no bare numbers, "
                  "IPs, or stray characters). Try again.")
            continue
        if good:
            return good
        print("  [!] No valid domains entered. Try again, or leave blank to skip.")


def cmd_engagement(args: argparse.Namespace) -> int:
    """Show the run menu, then run the chosen scope: full chain, from a phase,
    or a single tool. Output is foldered under the client domain.

    Runs UNATTENDED by default (collects needed answers up front, then runs to
    completion without blocking). --manual restores step-by-step prompting."""
    from . import run_menu, runmode

    # set global run mode: unattended unless --manual
    runmode.set_manual(getattr(args, "manual", False))
    runmode.set_verbose(getattr(args, "verbose", False))

    # dry-run bypasses the menu and previews the full chain
    if args.dry_run:
        client_name = "engagement"
        _run_phase0(args, client_name)
        _run_recon(args, client_name, [])
        return 0

    results_dir = Path(Config().output_dir)   # default "results"
    choice = run_menu.main_menu(results_dir)
    if choice is None:
        print("Quit.")
        return 0

    mode = choice["mode"]

    # HARD REQUIREMENT: a full or phased run needs scan targets. Check BEFORE the
    # interview so we don't collect answers for a run that has nothing to scan.
    # (single-tool mode is a deliberate one-off and is exempt.)
    if mode in ("all", "from_phase") and not _require_scan_targets("targets.txt"):
        return 2

    # For unattended runs, gather domains and run the full setup interview NOW —
    # before any scanning — so every human-required input is collected up front.
    # This is the prep checkpoint; after it, the run goes hands-off.
    if runmode.is_unattended() and mode in ("all", "from_phase"):
        _pre_gathered_domains = _ask_domains()
        # Skip the pre-run interview when this run was already configured and is
        # non-interactive (the campaign child passes --no-prompt against a
        # per-client recon_config.json written by 'campaign configure'). Re-running
        # the interview here on a closed stdin would EOF every answer back to the
        # default, silently discarding the per-client settings. Trust the config.
        _preconfigured = (getattr(args, "no_prompt", False)
                          and Path(args.recon_config).exists())
        if _preconfigured:
            print("[recon] using pre-configured settings from "
                  f"{args.recon_config} (skipping interview).")
        else:
            try:
                from .interview import run_interview
                from .recon_config import ReconConfig
                _rcfg = ReconConfig.load(args.recon_config) \
                    if Path(args.recon_config).exists() else None
                run_interview(cfg=_rcfg, domains=_pre_gathered_domains,
                              config_path=args.recon_config)
            except Exception as e:  # noqa: BLE001
                print(f"[interview] note: {e}")
        # stash so the branches below reuse these instead of re-asking
        runmode.stash("_domains", _pre_gathered_domains)

    if mode == "all":
        domains = _ask_domains()
        client_name = domains[0] if domains else "engagement"
        _run_discovery_prepass(args, client_name, domains)
        ran0 = _run_phase0(args, client_name, domains)
        ranR = _run_recon(args, client_name, domains)
        _print_complete(ran0, bool(domains))
        return 0

    if mode == "from_phase":
        phase = choice["phase"]
        if phase == 0:
            domains = _ask_domains()
            client_name = domains[0] if domains else "engagement"
            _run_discovery_prepass(args, client_name, domains)
            ran0 = _run_phase0(args, client_name, domains)
            ranR = _run_recon(args, client_name, domains)
            _print_complete(ran0, bool(domains))
        elif phase == 1:
            domains = _ask_domains()
            client_name = domains[0] if domains else "engagement"
            _run_recon(args, client_name, domains, phase1=True, phase2=True)
            _print_complete(False, bool(domains))
        elif phase == 2:
            domains = _ask_domains()
            client_name = domains[0] if domains else "engagement"
            _run_recon(args, client_name, domains, phase1=False, phase2=True)
            _print_complete(False, bool(domains))
        return 0

    if mode == "single":
        return _run_single_tool(args, choice["tool"])

    return 0


def _print_complete(ran0: bool, had_domains: bool) -> None:
    print("\n" + "=" * 60)
    print(" COMPLETE")
    print("=" * 60)
    if ran0:
        print(" Phase 0 scan output + scan_summary.xlsx in results/<engagement>/")
    if had_domains:
        print(" Recon output + final_report.xlsx in results/<engagement>/ "
              "(unified with phase 0)")


def _run_single_tool(args, tool: str) -> int:
    """Run exactly one tool. Phase-0 web/ssh tools reuse existing scan results."""
    from . import run_menu
    print(f"\n[single] running: {run_menu.TOOL_LABELS.get(tool, tool)}")

    if tool in run_menu.PHASE1_TOOLS or tool in run_menu.PHASE2_TOOLS:
        # recon/email single tool: needs a domain
        domains = _ask_domains()
        if not domains:
            print("[!] this tool needs a domain. Nothing entered — aborting.")
            return 1
        client_name = domains[0]
        rcfg = ReconConfig.load(args.recon_config)
        rcfg.engagement_name = client_name
        Path(rcfg.domains_file).write_text("\n".join(domains) + "\n")
        # disable everything, enable only the chosen tool
        for t in (run_menu.PHASE1_TOOLS + run_menu.PHASE2_TOOLS):
            if hasattr(rcfg, f"run_{t}"):
                setattr(rcfg, f"run_{t}", False)
        if hasattr(rcfg, f"run_{tool}"):
            setattr(rcfg, f"run_{tool}", True)
        # FunnelWeb single-tool: RV5 is the only supported branch (RV4 is a dead
        # branch). It runs the full JS/PHP audit pipeline (retire.js, jsluice,
        # JS/PHP harvest, semgrep, secret_scan, login detect).
        if tool == "funnelweb":
            rcfg.funnelweb_script = "FunnelWeb.py"
            print("    [single] FunnelWeb version: FunnelWeb.py "
                  "(full audit pipeline)")
            print("    (ensure retire.js / jsluice / semgrep are installed for "
                  "their audits to run.)")
        orch = ReconOrchestrator(rcfg, dry_run=args.dry_run, prompt_between=False,
                                 assume_yes=getattr(args, 'yes', False),
                                 config_path=getattr(args, 'recon_config', getattr(args, 'config', None)))
        orch.run()
        return 0

    # phase-0 tool: reuse existing scan results, re-probe for confirmed URLs
    from . import standalone
    results_dir = Path(Config().output_dir)   # default "results"
    return standalone.run_standalone_phase0_tool(tool, results_dir, args.config)


def cmd_recon_init(args: argparse.Namespace) -> int:
    cfg = ReconConfig()
    cfg.dump("recon_config.json")
    if not Path("domains.txt").exists():
        Path("domains.txt").write_text(
            "# Apex domains for passive recon + email enumeration, one per line.\n"
            "# example.com\n"
        )
    print("Wrote recon_config.json and domains.txt. Edit these before running.")
    print("Set SERPAPI_KEY / SNOV_CLIENT_ID / SNOV_CLIENT_SECRET in your env, or in the config.")
    return 0


def cmd_recon(args: argparse.Namespace) -> int:
    cfg = ReconConfig.load(args.config)
    # HARD REQUIREMENT: scan targets must exist before ANY run (scan or recon). This
    # covers the campaign child (recon --with-scan) and a direct recon run. Empty
    # targets.txt -> stop now, don't waste a run.
    _tgt_path = Path(cfg.output_dir) / cfg.engagement_name / "targets.txt"
    if not _require_scan_targets(_tgt_path):
        return 2
    # Optional phase-0 active scan (ffuf -> feroxbuster -> nuclei) BEFORE recon.
    # The campaign child passes --with-scan so a campaign run does the FULL flow
    # (scan + recon), not recon-only. Without this, campaign runs skipped the
    # entire web-scan phase — no ffuf/feroxbuster/nuclei logs, because those live
    # in the Pipeline (phase 0), which the recon orchestrator never invokes.
    if getattr(args, "with_scan", False):
        try:
            from .recon_config import load_domains
            _domains = load_domains(cfg.domains_file) if cfg.domains_file else []
            # targets.txt lives in the client's folder (output_dir/engagement_name).
            # _run_phase0 uses a relative "targets.txt"; point it at the client's
            # actual file so the scan hits THIS client's targets, not cwd.
            _client_dir = Path(cfg.output_dir) / cfg.engagement_name
            _tgt = _client_dir / "targets.txt"
            if _tgt.is_file():
                args._scan_targets_file = str(_tgt)
            _run_phase0(args, cfg.engagement_name, _domains)
        except Exception as e:  # noqa: BLE001
            print(f"[phase0] scan phase error (continuing to recon): {e}",
                  file=sys.stderr)
    try:
        orch = ReconOrchestrator(cfg, dry_run=args.dry_run,
                                 prompt_between=not args.no_prompt,
                                 assume_yes=getattr(args, 'yes', False),
                                 config_path=getattr(args, 'config', None))
        orch.run()
    except KeyboardInterrupt:
        print("\n[i] interrupted; progress saved, re-run to resume.", file=sys.stderr)
        return 130
    return 0


def cmd_report(args: argparse.Namespace) -> int:
    from .report import build_report
    from .recon_config import ReconConfig
    from . import funnelweb
    cfg = ReconConfig.load(args.config)
    outdir = Path(cfg.output_dir) / cfg.engagement_name
    # Rebuild the FunnelWeb At-a-Glance summaries from disk. The live run passes
    # these in-memory via the orchestrator; a standalone `report` rebuild has no
    # such list, so without this the At a Glance tab silently never gets built.
    try:
        fw_summaries = funnelweb.reconstruct_summaries_from_disk(outdir)
    except Exception as e:  # noqa: BLE001
        print(f"[report] could not rebuild FunnelWeb summaries: {e}", file=sys.stderr)
        fw_summaries = []
    path = build_report(outdir, report_path=args.output,
                        funnelweb_summaries=fw_summaries or None)
    print(f"Final report written: {path}")
    return 0


def _campaign_init(args: argparse.Namespace) -> int:
    from .campaign import cmd_campaign_init
    return cmd_campaign_init(args)


def _campaign_run(args: argparse.Namespace) -> int:
    from .campaign import cmd_campaign_run
    return cmd_campaign_run(args)


def _campaign_configure(args: argparse.Namespace) -> int:
    from .campaign import cmd_campaign_configure
    return cmd_campaign_configure(args)


def _campaign_status(args: argparse.Namespace) -> int:
    from .campaign import cmd_campaign_status
    return cmd_campaign_status(args)


def cmd_install_missing(args: argparse.Namespace) -> int:
    """Interactively install missing external tools (full toolset)."""
    from .toolsetup import run_installer
    return run_installer()


def main(argv: list[str] | None = None) -> int:
    # Fix PATH first so external tools (nuclei/ffuf/subfinder/...) resolve even
    # when run under sudo, which otherwise strips ~/go/bin and /usr/local/bin.
    from .pathfix import repair_path
    repair_path()

    parser = argparse.ArgumentParser(prog="nigredo",
                                     description="Staged nmap recon pipeline with scope enforcement")
    sub = parser.add_subparsers(dest="command", required=True)

    p_init = sub.add_parser("init", help="write starter config and input files")
    p_init.set_defaults(func=cmd_init)

    p_run = sub.add_parser("run", help="run the pipeline")
    p_run.add_argument("-c", "--config", default="config.json")
    p_run.add_argument("--verbose", action="store_true",
                       help="show detailed per-tool output (default: quiet — "
                            "just HEARTHBEAT + current tool; press SPACEBAR for a "
                            "spot-check of where the run is)")
    p_run.add_argument("--dry-run", action="store_true",
                       help="build and print commands without executing")
    p_run.add_argument("--yes", action="store_true",
                       help="auto-confirm all tool-run prompts (non-interactive)")
    p_run.set_defaults(func=cmd_run)

    p_recon_init = sub.add_parser("recon-init",
                                  help="write starter recon_config.json and domains.txt")
    p_recon_init.set_defaults(func=cmd_recon_init)

    p_recon = sub.add_parser("recon",
                             help="run phase 1 (passive recon) + phase 2 (email) tools")
    p_recon.add_argument("-c", "--config", default="recon_config.json")
    p_recon.add_argument("--dry-run", action="store_true",
                         help="show what would run without executing")
    p_recon.add_argument("--no-prompt", action="store_true",
                         help="run all tools back-to-back without pausing between them")
    p_recon.add_argument("--with-scan", action="store_true",
                         help="also run the phase-0 active scan (ffuf/feroxbuster/"
                              "nuclei against targets.txt) BEFORE recon — used by "
                              "campaign runs so they do the full flow, not recon-only")
    p_recon.add_argument("--yes", action="store_true",
                         help="auto-yes phase-0 tool prompts (for --with-scan)")
    p_recon.set_defaults(func=cmd_recon)

    # --- campaign: prep + run several client engagements at once ---
    p_camp = sub.add_parser(
        "campaign",
        help="prepare and run several client engagements in parallel")
    camp_sub = p_camp.add_subparsers(dest="campaign_action", required=True)

    p_camp_init = camp_sub.add_parser(
        "init", help="scaffold results/<client>/targets.txt for each client")
    p_camp_init.add_argument("clients", nargs="*",
                             help="client names (omit to be prompted interactively)")
    p_camp_init.add_argument("-r", "--recon-config", default="recon_config.json")
    p_camp_init.set_defaults(func=_campaign_init)

    p_camp_run = camp_sub.add_parser(
        "run", help="run named clients (or --all ready) in parallel")
    p_camp_run.add_argument("clients", nargs="*",
                            help="clients to run (omit + --all to run every "
                                 "ready, not-yet-completed client)")
    p_camp_run.add_argument("-r", "--recon-config", default="recon_config.json")
    p_camp_run.add_argument("--all", action="store_true",
                            help="run every ready client that isn't already "
                                 "completed (opt-in; bare 'run' refuses)")
    p_camp_run.add_argument("--force", action="store_true",
                            help="re-run even completed/interrupted clients")
    p_camp_run.add_argument("--max-parallel", type=int, default=3,
                            help="max concurrent runs (default: 3)")
    p_camp_run.add_argument("--dry-run", action="store_true",
                            help="show what would run without spawning")
    p_camp_run.add_argument("--dashboard", dest="dashboard",
                            action="store_true", default=None,
                            help="force the live status panel on")
    p_camp_run.add_argument("--no-dashboard", dest="dashboard",
                            action="store_false",
                            help="disable the panel; print per-client completion "
                                 "lines instead (default when not a terminal)")
    p_camp_run.set_defaults(func=_campaign_run)

    p_camp_configure = camp_sub.add_parser(
        "configure", help="set each client's scan settings before running "
                          "(same for all, or per-client depth/cost control)")
    p_camp_configure.add_argument("clients", nargs="*",
                                  help="clients to configure (default: all ready)")
    p_camp_configure.add_argument("-r", "--recon-config",
                                  default="recon_config.json")
    p_camp_configure.add_argument("--mode", choices=["same", "each"],
                                  help="skip the prompt: same settings for all, "
                                       "or configure each individually")
    p_camp_configure.set_defaults(func=_campaign_configure)

    p_camp_status = camp_sub.add_parser(
        "status", help="show which clients are ready / running / done")
    p_camp_status.add_argument("-r", "--recon-config", default="recon_config.json")
    p_camp_status.set_defaults(func=_campaign_status)

    p_report = sub.add_parser("report",
                              help="collate cleaned outputs into the final xlsx workbook")
    p_report.add_argument("-c", "--config", default="recon_config.json")
    p_report.add_argument("-o", "--output", default=None,
                          help="output path (default: <engagement>/final_report.xlsx)")
    p_report.set_defaults(func=cmd_report)

    # --- install-missing: interactive installer for external tools ---
    p_install = sub.add_parser(
        "install-missing",
        help="check for missing external tools and interactively install them "
             "(run with sudo; go/apt/pip/git)")
    p_install.set_defaults(func=cmd_install_missing)

    # --- unified chained run: phase 0 + 1 + 2 together ---
    p_eng_init = sub.add_parser(
        "engagement-init",
        help="scaffold ALL input files for a full chained run (phases 0+1+2)")
    p_eng_init.set_defaults(func=cmd_engagement_init)

    p_eng = sub.add_parser(
        "engagement",
        help="run ALL phases as one chain (scan -> recon -> email), y/n per tool")
    p_eng.add_argument("-c", "--config", default="config.json",
                       help="phase-0 config (default: config.json)")
    p_eng.add_argument("-r", "--recon-config", default="recon_config.json",
                       help="phase 1/2 config (default: recon_config.json)")
    p_eng.add_argument("--dry-run", action="store_true",
                       help="preview all commands without executing")
    p_eng.add_argument("--yes", action="store_true",
                       help="auto-yes phase-0 tool prompts")
    p_eng.add_argument("--no-prompt", action="store_true",
                       help="run recon phases without pausing between tools")
    p_eng.add_argument("--manual", action="store_true",
                       help="prompt step-by-step as tools are reached "
                            "(default is unattended/fire-and-forget)")
    p_eng.set_defaults(func=cmd_engagement)

    args = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
