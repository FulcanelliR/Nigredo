#!/usr/bin/env python3
"""Fix PATH so external tools resolve when nigredo is run under sudo.

nmap's SYN/stealth scans need root, so the tool is typically run with `sudo`.
But sudo resets PATH to a restricted set (often without /usr/local/bin), and
Go-installed tools (nuclei, ffuf, feroxbuster, subfinder, ...) live in the
invoking user's ~/go/bin — which falls off PATH entirely under sudo. The result
is "tool not found" for tools that work fine as the normal user.

This repairs PATH in-process (and therefore for every subprocess nigredo
spawns) by prepending the common tool locations, including the ORIGINAL user's
~/go/bin resolved via $SUDO_USER. It's idempotent and safe to call on every run;
it only adds directories that exist and aren't already on PATH.
"""
from __future__ import annotations

import os
from pathlib import Path


def _candidate_dirs() -> list[str]:
    dirs: list[str] = []

    # the user who invoked sudo (their home is where go/bin usually lives)
    sudo_user = os.environ.get("SUDO_USER")
    homes: list[Path] = []
    if sudo_user:
        # resolve that user's home without assuming /home/<user>
        try:
            import pwd
            homes.append(Path(pwd.getpwnam(sudo_user).pw_dir))
        except (KeyError, ImportError):
            homes.append(Path(f"/home/{sudo_user}"))
    # current HOME too (covers non-sudo and root-owned installs)
    if os.environ.get("HOME"):
        homes.append(Path(os.environ["HOME"]))
    homes.append(Path("/root"))

    for h in homes:
        dirs.append(str(h / "go" / "bin"))          # Go tools
        dirs.append(str(h / ".local" / "bin"))      # pipx / pip --user
        dirs.append(str(h / ".cargo" / "bin"))      # Rust (feroxbuster if cargo)

    # system locations that a stripped sudo PATH often omits
    dirs += [
        "/usr/local/bin",
        "/usr/local/go/bin",
        "/snap/bin",
        "/opt/go/bin",
    ]
    return dirs


def _user_site_packages() -> list[str]:
    """The invoking user's Python site-packages dirs (pip install --user).

    Under sudo, a user-installed Python TOOL (e.g. dnstwist at ~/.local/bin/
    dnstwist) is found on PATH, but its launcher does `from dnstwist import run`
    and fails because root's Python can't see the module in the USER's
    ~/.local/lib/pythonX.Y/site-packages. Adding those dirs to PYTHONPATH lets
    root's Python import user-installed modules, fixing that class of tool."""
    sudo_user = os.environ.get("SUDO_USER")
    if not sudo_user:
        return []                      # not under sudo; nothing to bridge
    try:
        import pwd
        home = Path(pwd.getpwnam(sudo_user).pw_dir)
    except (KeyError, ImportError):
        home = Path(f"/home/{sudo_user}")

    base = home / ".local" / "lib"
    if not base.is_dir():
        return []
    # include every pythonX.Y/site-packages under ~/.local/lib (version-agnostic)
    out = []
    for py in sorted(base.glob("python*")):
        sp = py / "site-packages"
        if sp.is_dir():
            out.append(str(sp))
    return out


def repair_pythonpath(verbose: bool = True) -> list[str]:
    """Add the invoking user's site-packages to PYTHONPATH (in-process) so
    user-pip-installed Python tools work when nigredo runs under sudo."""
    dirs = _user_site_packages()
    if not dirs:
        return []
    current = os.environ.get("PYTHONPATH", "")
    parts = current.split(os.pathsep) if current else []
    have = set(parts)
    added = []
    for d in dirs:
        if d not in have:
            parts.append(d)            # append: don't shadow root's own modules
            have.add(d)
            added.append(d)
    if added:
        os.environ["PYTHONPATH"] = os.pathsep.join(p for p in parts if p)
        if verbose:
            print(f"[path] added {len(added)} user site-packages dir(s) to "
                  f"PYTHONPATH (sudo bridge): " + ", ".join(added))
    return added


def repair_path(verbose: bool = True) -> list[str]:
    """Prepend existing tool dirs to PATH (in-process). Returns dirs added.
    Also bridges the invoking user's site-packages into PYTHONPATH under sudo."""
    current = os.environ.get("PATH", "")
    parts = current.split(os.pathsep) if current else []
    have = set(parts)
    added: list[str] = []

    for d in _candidate_dirs():
        if d and d not in have and Path(d).is_dir():
            parts.insert(0, d)      # prepend so our tools win
            have.add(d)
            added.append(d)

    if added:
        os.environ["PATH"] = os.pathsep.join(parts)
        if verbose:
            running_sudo = os.environ.get("SUDO_USER") is not None
            ctx = " (running under sudo)" if running_sudo else ""
            print(f"[path] added {len(added)} tool dir(s) to PATH{ctx}: "
                  + ", ".join(added))

    # bridge user site-packages into PYTHONPATH (fixes user-pip tools under sudo)
    repair_pythonpath(verbose=verbose)
    return added
