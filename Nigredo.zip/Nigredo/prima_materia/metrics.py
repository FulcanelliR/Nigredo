#!/usr/bin/env python3
"""Run metrics: a host-by-tool status matrix + timing, written to a Metrics tab.

Rows are host-forms (each IP and each in-scope FQDN that a tool targeted).
Columns are the phase-0 steps/tools. Each cell reports that host-form's status
in that tool (ok / no-result / skipped / error / n-a). A Remarks column carries
the granular detail (why something failed). A timing section records
start-to-finish wall-clock per tool and per phase.

The matrix is reconstructed AFTER the run from evidence on disk (each tool's
target list + its output files) plus a live timing/error log the pipeline keeps,
so tools don't need to change their return contracts.
"""
from __future__ import annotations

import time
from pathlib import Path


class RunMetrics:
    """Collects timing + per-host-per-tool status during a phase-0 run."""

    # canonical tool/step order for the matrix columns
    STEPS = ["nmap", "nmap-ack", "nmap-fin", "nmap-null", "nmap-xmas", "shodan",
             "httpx", "katana", "gau", "nuclei", "ffuf", "feroxbuster", "nomore403", "testssl", "sns", "sshaudit"]

    # The core phase-0 stages used as the LIVE progress denominator (the always-in-
    # play tools, in run order). Conditional/stealth steps (nmap-ack/fin/null/xmas,
    # shodan) are excluded so the progress bar tracks the main pipeline cleanly.
    PROGRESS_STEPS = ["nmap", "httpx", "katana", "gau", "nuclei", "ffuf",
                      "feroxbuster", "nomore403", "testssl", "sns", "sshaudit"]

    def __init__(self, outdir=None):
        # host_form -> {step -> status}, and host_form -> remarks list
        self.matrix: dict[str, dict[str, str]] = {}
        self.remarks: dict[str, list[str]] = {}
        # step -> seconds
        self.timing: dict[str, float] = {}
        # step -> count of hosts it failed on
        self.failed_counts: dict[str, int] = {}
        # hosts from targets.txt that nmap found nothing on
        self.dead_on_arrival: list[str] = []
        self._timers: dict[str, float] = {}
        # LIVE progress: written to <outdir>/phase0_state.json on each start/stop so
        # the campaign dashboard can show phase-0 movement (the fuzzers now do real
        # work; without this the bars sit at 0 until the recon engine starts).
        self.outdir = Path(outdir) if outdir else None
        self._done_steps: list[str] = []
        self._current: str | None = None

    # ---- live progress (phase-0 dashboard) ----
    def _write_progress(self, completed: bool = False) -> None:
        if not self.outdir:
            return
        try:
            import json
            cur = self._current
            idx = (self.PROGRESS_STEPS.index(cur)
                   if cur in self.PROGRESS_STEPS else len(self._done_steps))
            (self.outdir / "phase0_state.json").write_text(json.dumps({
                "current": cur,
                "done": self._done_steps,
                "step_index": idx,
                "total": len(self.PROGRESS_STEPS),
                "completed": completed,
                "ts": time.time(),
            }))
        except OSError:
            pass

    def mark_phase0_complete(self) -> None:
        """Called once the phase-0 scan/web tools finish, so the dashboard flips this
        client from the phase-0 bar to the recon-engine bar."""
        self._current = None
        self._write_progress(completed=True)

    # ---- timing ----
    def start(self, step: str):
        self._timers[step] = time.time()
        self._current = step
        self._write_progress()

    def stop(self, step: str):
        if step in self._timers:
            self.timing[step] = self.timing.get(step, 0.0) + (
                time.time() - self._timers.pop(step))
        if step not in self._done_steps:
            self._done_steps.append(step)
        self._write_progress()

    # ---- status ----
    def set_status(self, host_form: str, step: str, status: str,
                   remark: str = ""):
        self.matrix.setdefault(host_form, {})[step] = status
        if remark:
            self.remarks.setdefault(host_form, []).append(f"{step}: {remark}")
        if status in ("error", "failed"):
            self.failed_counts[step] = self.failed_counts.get(step, 0) + 1

    def mark_dead_on_arrival(self, host: str, remark: str = "host up, 0 open ports"):
        if host not in self.dead_on_arrival:
            self.dead_on_arrival.append(host)
        self.set_status(host, "nmap", "no-ports", remark)

    def ensure_host(self, host_form: str):
        self.matrix.setdefault(host_form, {})

    def to_dict(self) -> dict:
        return {
            "matrix": self.matrix,
            "remarks": {k: "; ".join(v) for k, v in self.remarks.items()},
            "timing": self.timing,
            "failed_counts": self.failed_counts,
            "dead_on_arrival": self.dead_on_arrival,
        }


def _fmt_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    m, s = divmod(int(seconds), 60)
    if m < 60:
        return f"{m}m{s:02d}s"
    h, m = divmod(m, 60)
    return f"{h}h{m:02d}m"


def add_metrics_sheet(wb, metrics: "RunMetrics"):
    """Write the Metrics tab: host-by-tool matrix + Remarks, then a timing and
    failure-count summary below it."""
    from openpyxl.styles import Font, PatternFill, Alignment

    HEADER_FONT = Font(name="Roboto", size=11, bold=True, color="FFFFFF")
    HEADER_FILL = PatternFill("solid", fgColor="374151")
    BODY = Font(name="Roboto", size=11)
    OK_FILL = PatternFill("solid", fgColor="D1FAE5")     # green-ish
    ERR_FILL = PatternFill("solid", fgColor="FEE2E2")    # red-ish
    SKIP_FILL = PatternFill("solid", fgColor="F3F4F6")   # grey

    ws = wb.create_sheet("Metrics")
    steps = RunMetrics.STEPS
    headers = ["Host / Target"] + [s for s in steps] + ["Remarks"]
    for c, name in enumerate(headers, 1):
        cell = ws.cell(row=1, column=c, value=name)
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal="left", vertical="center")

    d = metrics.to_dict()
    matrix = d["matrix"]
    remarks = d["remarks"]

    r = 2
    for host in sorted(matrix):
        ws.cell(row=r, column=1, value=host).font = BODY
        for i, step in enumerate(steps, start=2):
            status = matrix[host].get(step, "")
            cell = ws.cell(row=r, column=i, value=status or "—")
            cell.font = BODY
            if status in ("ok", "found", "scanned"):
                cell.fill = OK_FILL
            elif status in ("error", "failed"):
                cell.fill = ERR_FILL
            elif status in ("skipped", "n-a", "no-ports", "no-result"):
                cell.fill = SKIP_FILL
        rc = ws.cell(row=r, column=len(steps) + 2, value=remarks.get(host, ""))
        rc.font = BODY
        r += 1

    # widths
    ws.column_dimensions["A"].width = 34
    from openpyxl.utils import get_column_letter
    for i in range(2, len(steps) + 2):
        ws.column_dimensions[get_column_letter(i)].width = 12
    ws.column_dimensions[get_column_letter(len(steps) + 2)].width = 50
    ws.freeze_panes = "B2"

    # --- summary block below the matrix ---
    r += 2
    ws.cell(row=r, column=1, value="STEP SUMMARY").font = HEADER_FONT
    ws.cell(row=r, column=1).fill = HEADER_FILL
    r += 1
    ws.cell(row=r, column=1, value="Step").font = HEADER_FONT
    ws.cell(row=r, column=2, value="Duration").font = HEADER_FONT
    ws.cell(row=r, column=3, value="Hosts failed").font = HEADER_FONT
    r += 1
    for step in steps:
        ws.cell(row=r, column=1, value=step).font = BODY
        dur = d["timing"].get(step)
        ws.cell(row=r, column=2,
                value=_fmt_duration(dur) if dur is not None else "—").font = BODY
        ws.cell(row=r, column=3,
                value=d["failed_counts"].get(step, 0)).font = BODY
        r += 1

    # dead-on-arrival summary
    r += 1
    doa = d["dead_on_arrival"]
    ws.cell(row=r, column=1,
            value=f"Hosts dead on arrival (nmap found nothing): {len(doa)}"
            ).font = Font(name="Roboto", size=11, bold=True)
    r += 1
    if doa:
        ws.cell(row=r, column=1, value=", ".join(doa)).font = BODY
