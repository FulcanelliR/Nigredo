#!/usr/bin/env python3
"""File enumeration (phase 1 recon).

Finds and downloads exposed documents for a target, then extracts their metadata.
Key behaviors:

  - No hardcoded API key. Key comes from --api-key or SERPAPI_KEY env only.
  - Narrowed, consistent metadata schema (one clean column per field; no
    key=value blobs). PDF and Office formats are mapped to the SAME field names
    so a column means the same thing regardless of file type.
  - Scope guardrail: the set of in-scope hosts is DERIVED from the SerpAPI
    results themselves (hosts Google already associates with site:<domain>),
    plus the apex domain. The crawler and file extractors reject any URL whose
    host isn't in that derived allowlist. Out-of-allowlist URLs are logged for
    review rather than silently dropped or blindly fetched.
  - PLATFORM_PATTERNS expanded — used ONLY for the Platform label, not for scope.
  - De-duplication of file URLs before download (normalized), so the same file
    isn't fetched twice.
  - LinkedIn/email mode lives in a separate phase.

The metadata fields kept are the ones that regularly carry useful/private intel:
Author, Creator, CreatorTool/Producer, LastModifiedBy, Company, Created,
Modified — plus URL/FileName/FileType/Platform for context.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import os
import re
import time
from dataclasses import dataclass, asdict, field
from io import BytesIO
from urllib.parse import urlparse, unquote, parse_qs, urljoin

import requests

# Optional parsers — degrade gracefully if a library isn't installed.
try:
    from bs4 import BeautifulSoup
except Exception:
    BeautifulSoup = None
try:
    from pypdf import PdfReader
except Exception:
    PdfReader = None
try:
    from docx import Document
except Exception:
    Document = None
try:
    import openpyxl
except Exception:
    openpyxl = None
try:
    from pptx import Presentation
except Exception:
    Presentation = None
try:
    import olefile
except Exception:
    olefile = None

import logging
logging.getLogger("pypdf").setLevel(logging.ERROR)

try:
    from serpapi import search as serp_search
except Exception:
    serp_search = None


# ---------------- Cleaned metadata schema ----------------
@dataclass
class FileRow:
    URL: str
    FileName: str
    FileType: str
    Platform: str
    Author: str = ""
    Creator: str = ""           # authoring app/person (PDF /Creator, Office author)
    CreatorTool: str = ""       # PDF /Producer or Office application (tool+version)
    Producer: str = ""          # PDF /Producer (exact producing library/tool)
    LastModifiedBy: str = ""
    Company: str = ""
    Software: str = ""          # software + version (vuln stack angle)
    Template: str = ""          # document template (classic OSINT dork field)
    Created: str = ""
    Modified: str = ""
    # kept for the raw artifact / triage, not the cleaned report
    SHA256: str = ""
    LocalPath: str = ""     # where the downloaded file was saved (for exiftool + artifact)
    TextFindings: str = ""
    Sensitive: str = ""     # shared sensitive_patterns category (consistent w/ buckets)
    Error: str = ""


# ---------------- Platform labels (labeling ONLY, not scope) ----------------
PLATFORM_PATTERNS = [
    ("NetSuite", [r"/core/media/media\.nl\b", r"[?&]_xt=\.", r"[?&]c=\d+"]),
    ("SharePoint/OneDrive", [
        r"sharepoint\.com", r"sharepoint-df\.com", r"-my\.sharepoint\.com",
        r"/_layouts/15/download\.aspx", r"/_layouts/15/Doc\.aspx",
        r"/:b:/s/", r"/personal/",
    ]),
    ("AWS S3", [r"\.s3[.-][a-z0-9-]*\.amazonaws\.com", r"s3\.amazonaws\.com"]),
    ("AWS CloudFront", [r"\.cloudfront\.net"]),
    ("Azure Blob", [r"\.blob\.core\.windows\.net", r"\.azureedge\.net"]),
    ("Google Cloud Storage", [r"storage\.googleapis\.com", r"\.storage\.googleapis\.com"]),
    ("Google Drive/Docs", [
        r"drive\.google\.com/file/d/",
        r"docs\.google\.com/(?:document|spreadsheets|presentation)/d/",
    ]),
    ("Cloudflare R2", [r"\.r2\.cloudflarestorage\.com", r"\.r2\.dev"]),
    ("Fastly", [r"\.fastly\.net", r"\.fastlylb\.net"]),
    ("Akamai", [r"\.akamaihd\.net", r"\.akamaized\.net", r"\.akamai\.net"]),
    ("Bunny CDN", [r"\.b-cdn\.net", r"\.bunnycdn\.com"]),
    ("Wasabi", [r"\.wasabisys\.com"]),
    ("DigitalOcean Spaces", [r"\.digitaloceanspaces\.com"]),
    ("Salesforce", [
        r"content\.force\.com", r"/servlet/servlet\.FileDownload",
        r"/file-asset/", r"\.my\.salesforce\.com",
    ]),
    ("Thrillshare/Apptegy", [
        r"files-backend\.assets\.thrillshare\.com", r"\b5il\.co\b", r"apptegy",
    ]),
    ("Finalsite", [r"finalsite\.net", r"fs\.resource", r"resources\.finalsite\.net"]),
    ("Edlio", [r"edlio\.com", r"edl\.io"]),
    ("CivicPlus", [r"civicplus", r"civicclerk"]),
]


def detect_platform(url: str) -> str:
    u = url.lower()
    for platform, patterns in PLATFORM_PATTERNS:
        for pat in patterns:
            if re.search(pat, u, re.IGNORECASE):
                return platform
    return ""


DOCUMENT_PATHS = [
    "/documents", "/forms", "/resources", "/downloads", "/policies", "/board",
    "/departments", "/staff", "/media", "/files", "/directory", "/publications",
    "/public-notices", "/agendas", "/minutes",
]

FILE_EXT_RE = (r"\.(pdf|docx?|xlsx?|pptx?|csv|txt|rtf|odt|zip|bak|old|backup|swp|"
               r"tar|rar|7z|gz|tgz|env|config|conf|cfg|ini|ya?ml|json|xml|sql|db|"
               r"sqlite|mdb|accdb|log|key|pem|p12|pfx|crt|cer|asc|properties|"
               r"htpasswd|git)(?:\?|#|$)")


# ---------------- URL helpers + de-dup ----------------
def safe_filename_from_url(url: str) -> str:
    name = os.path.basename(urlparse(url).path) or "unknown"
    name = unquote(name)
    name = re.sub(r"[^\w.\-() ]+", "_", name).strip()
    return name or "unknown"


def guess_ext(url: str) -> str:
    parsed = urlparse(url)
    qs = parse_qs(parsed.query)
    if "_xt" in qs:                       # NetSuite style ?_xt=.pdf
        return qs["_xt"][0].lower().lstrip(".")
    _, ext = os.path.splitext(safe_filename_from_url(url))
    return ext.lower().lstrip(".")


def _normalize_url(url: str) -> str:
    """Canonical form for de-dup: lowercase scheme+host, strip fragment, strip a
    trailing slash. Query is kept (often required to fetch the file)."""
    p = urlparse(url)
    scheme = p.scheme.lower()
    host = p.netloc.lower()
    path = p.path.rstrip("/")
    norm = f"{scheme}://{host}{path}"
    if p.query:
        norm += f"?{p.query}"
    return norm


def dedupe_urls(urls) -> list[str]:
    """De-duplicate by normalized form, preserving first-seen original URL."""
    seen: set[str] = set()
    out: list[str] = []
    for u in urls:
        key = _normalize_url(u)
        if key in seen:
            continue
        seen.add(key)
        out.append(u)
    return out


def host_of(url: str) -> str:
    return urlparse(url).netloc.lower()


# ---------------- Beefed-up text content scanner ----------------
# Patterns aimed at metadata/secret leakage in document text.
_email_re = re.compile(r"\b[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[A-Za-z]{2,}\b")
_winuser_re = re.compile(r"(?<![\\:/\w])([A-Za-z][A-Za-z0-9-]{1,14})\\([A-Za-z0-9_.-]{2,})\b")  # DOMAIN\user, not path frags
_unc_re = re.compile(r"\\\\[A-Za-z0-9_.$-]+\\[A-Za-z0-9_.$\\-]+")          # \\server\share
_winpath_re = re.compile(r"\b[A-Za-z]:\\[^\s\"'<>|]{2,}")                  # C:\path
_nixpath_re = re.compile(r"(?:/home|/Users|/srv|/var/www|/opt|/mnt|/etc|/root)/[^\s\"'<>|]{2,}")
_ipv4_re = re.compile(r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b")
_url_re = re.compile(r"https?://[^\s\"'<>)]+")
_priv_ip_re = re.compile(
    r"\b(?:10\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    r"|192\.168\.\d{1,3}\.\d{1,3}"
    r"|172\.(?:1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3})\b"
)
# secret-ish tokens
_secret_res = {
    "AWS Access Key": re.compile(r"\bAKIA[0-9A-Z]{16}\b"),
    "Google API Key": re.compile(r"\bAIza[0-9A-Za-z_\-]{35}\b"),
    "Slack Token": re.compile(r"\bxox[baprs]-[0-9A-Za-z\-]{10,}\b"),
    "Private Key Block": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----"),
    "JWT": re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b"),
}
SECRET_KEYWORDS = [
    "password", "passwd", "pwd", "token", "apikey", "api_key", "secret",
    "client_secret", "authorization", "bearer", "connectionstring",
    "jdbc:", "odbc", "ldap://", "ldaps://", "saml",
]


def _detect_encoding(sample: bytes) -> str:
    for enc in ("utf-8", "utf-16", "latin-1"):
        try:
            sample.decode(enc)
            return enc
        except Exception:
            continue
    return "latin-1"


def _summarize(items, max_samples=5):
    uniq, seen = [], set()
    for i in items:
        if i in seen:
            continue
        seen.add(i)
        uniq.append(i)
        if len(uniq) >= max_samples:
            break
    return len(seen), uniq


def scan_text(content: bytes, sample_limit: int = 500_000) -> dict:
    """Scan document text for high-signal leakage: emails, AD/UNC/local paths,
    private IPs, internal URLs, secret tokens and keywords.

    Returns a dict with a compact 'TextFindings' string and structured counts.
    Each category is summarized as count + a few samples; no giant blob dump.
    """
    sample = content[:sample_limit]
    enc = _detect_encoding(sample)
    text = sample.decode(enc, errors="replace")
    lower = text.lower()

    # _winuser_re has two groups (domain, user); rebuild "DOMAIN\user" strings.
    ad_users = [f"{d}\\{u}" for (d, u) in _winuser_re.findall(text)]

    categories: list[tuple[str, list[str]]] = [
        ("emails", _email_re.findall(text)),
        ("ad_users", ad_users),
        ("unc_paths", _unc_re.findall(text)),
        ("win_paths", _winpath_re.findall(text)),
        ("nix_paths", _nixpath_re.findall(text)),
        ("private_ips", _priv_ip_re.findall(text)),
        ("internal_urls", _url_re.findall(text)),
    ]

    parts: list[str] = []
    structured: dict[str, object] = {"Encoding": enc}
    for label, items in categories:
        count, samples = _summarize(items)
        if count:
            parts.append(f"{label}={count} {samples}")
            structured[label] = {"count": count, "samples": samples}

    # secret token patterns (presence is high-signal; show the type, not the value)
    secret_types = [name for name, rx in _secret_res.items() if rx.search(text)]
    if secret_types:
        parts.append(f"secrets={sorted(secret_types)}")
        structured["secret_types"] = sorted(secret_types)

    # secret-ish keywords
    kw_hits = sorted({kw for kw in SECRET_KEYWORDS if kw.lower() in lower})
    if kw_hits:
        parts.append(f"keywords={kw_hits}")
        structured["keywords"] = kw_hits

    structured["TextFindings"] = "; ".join(parts)
    return structured


# ---------------- Metadata extractors (consistent schema) ----------------
def _norm_dt(dt) -> str:
    if not dt:
        return ""
    try:
        return dt.isoformat()
    except Exception:
        return str(dt)


def extract_pdf(content: bytes) -> dict:
    if PdfReader is None:
        raise RuntimeError("pypdf not installed")
    md = {}
    meta = PdfReader(BytesIO(content)).metadata
    if meta:
        md = {str(k): ("" if v is None else str(v)) for k, v in dict(meta).items()}
    return {
        "Author": md.get("/Author", ""),
        "Creator": md.get("/Creator", ""),
        "CreatorTool": md.get("/Producer", ""),
        "LastModifiedBy": "",
        "Company": "",
        "Created": md.get("/CreationDate", ""),
        "Modified": md.get("/ModDate", ""),
    }


def extract_docx(content: bytes) -> dict:
    if Document is None:
        raise RuntimeError("python-docx not installed")
    cp = Document(BytesIO(content)).core_properties
    return {
        "Author": cp.author or "",
        "Creator": cp.author or "",
        "CreatorTool": getattr(cp, "application", "") or "",
        "LastModifiedBy": cp.last_modified_by or "",
        "Company": getattr(cp, "company", "") or "",
        "Created": _norm_dt(cp.created),
        "Modified": _norm_dt(cp.modified),
    }


def extract_xlsx(content: bytes) -> dict:
    if openpyxl is None:
        raise RuntimeError("openpyxl not installed")
    p = openpyxl.load_workbook(filename=BytesIO(content), read_only=True, data_only=True).properties
    return {
        "Author": p.creator or "",
        "Creator": p.creator or "",
        "CreatorTool": getattr(p, "application", "") or "",
        "LastModifiedBy": p.lastModifiedBy or "",
        "Company": getattr(p, "company", "") or "",
        "Created": _norm_dt(p.created),
        "Modified": _norm_dt(p.modified),
    }


def extract_pptx(content: bytes) -> dict:
    if Presentation is None:
        raise RuntimeError("python-pptx not installed")
    cp = Presentation(BytesIO(content)).core_properties
    return {
        "Author": cp.author or "",
        "Creator": cp.author or "",
        "CreatorTool": getattr(cp, "application", "") or "",
        "LastModifiedBy": cp.last_modified_by or "",
        "Company": getattr(cp, "company", "") or "",
        "Created": _norm_dt(cp.created),
        "Modified": _norm_dt(cp.modified),
    }


def extract_ole(content: bytes) -> dict:
    if olefile is None:
        raise RuntimeError("olefile not installed")
    ole = olefile.OleFileIO(BytesIO(content))
    meta = olefile.OleMetadata()
    meta.parse(ole)
    ole.close()
    return {
        "Author": meta.author or "",
        "Creator": meta.author or "",
        "CreatorTool": meta.creating_application or "",
        "LastModifiedBy": meta.last_saved_by or "",
        "Company": meta.company or "",
        "Created": _norm_dt(getattr(meta, "create_time", None)),
        "Modified": _norm_dt(getattr(meta, "last_saved_time", None)),
    }


METADATA_EXTRACTORS = {
    "pdf": extract_pdf, "docx": extract_docx, "xlsx": extract_xlsx,
    "pptx": extract_pptx, "doc": extract_ole, "xls": extract_ole, "ppt": extract_ole,
}
TEXT_TYPES = {"txt", "csv"}

# Basic mode: only metadata-bearing office/PDF types (cheap — 1 SerpAPI credit each,
# no sensitive-dork pass). Full mode adds every other extension + the ~15 sensitive
# dorks, which is where the ~60-credit burn comes from.
BASIC_FILE_TYPES = ["pdf", "docx", "doc", "xlsx", "xls", "pptx", "ppt", "csv"]

CONTENT_TYPE_MAP = {
    "application/pdf": "pdf",
    "application/msword": "doc",
    "application/vnd.ms-excel": "xls",
    "application/vnd.ms-powerpoint": "ppt",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document": "docx",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": "xlsx",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation": "pptx",
    "text/csv": "csv", "text/plain": "txt",
}


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def http_fetch(url: str, timeout, max_bytes: int, user_agent: str):
    headers = {"User-Agent": user_agent}
    # Split timeout into (connect, read): connect SHORT (fail fast on dead hosts),
    # read GENEROUS (patient with slow-rendering documents — some take 30s+ to
    # start sending). With stream=True the read timeout RESETS per chunk, so an
    # actively-progressing download never bails; only a genuine STALL trips it.
    # Accepts either an int (legacy) or a (connect, read) tuple.
    if isinstance(timeout, (int, float)):
        to = (min(10, timeout), max(90, timeout))
    else:
        to = timeout
    with requests.get(url, headers=headers, timeout=to, stream=True,
                      allow_redirects=True) as r:
        r.raise_for_status()
        ct = r.headers.get("Content-Type", "").split(";")[0].strip()
        cl = r.headers.get("Content-Length")
        if cl and cl.isdigit() and int(cl) > max_bytes:
            raise ValueError(f"Content-Length {cl} exceeds max_bytes {max_bytes}")
        buf = BytesIO()
        total = 0
        for chunk in r.iter_content(chunk_size=64 * 1024):
            if not chunk:
                continue
            total += len(chunk)
            if total > max_bytes:
                raise ValueError(f"download exceeded max_bytes {max_bytes}")
            buf.write(chunk)
        return buf.getvalue(), ct


# ---------------- SerpAPI search + derived host allowlist ----------------
# module-level counter of SerpAPI searches this run (1 search credit each)
_serpapi_call_count = 0


# Content-aware sensitive dorks — find exposed secrets/configs/dumps, not just
# plain documents. Run via the SerpAPI plumbing.
SENSITIVE_DORKS = [
    'intitle:"index of" "parent directory"',
    'filetype:env "DB_PASSWORD"',
    'filetype:env "API_KEY"',
    'filetype:config "password"',
    'filetype:log "password" | "username"',
    'filetype:sql "INSERT INTO" "VALUES"',
    'filetype:json "api_key" | "apikey" | "api-key"',
    'ext:yml "password" | "passwd" | "pwd"',
    'inurl:backup | inurl:dump | inurl:old',
    'intitle:"index of" .git',
    'filetype:txt "BEGIN RSA PRIVATE KEY"',
    'filetype:pem "BEGIN"',
    '"-----BEGIN PRIVATE KEY-----"',
    'filetype:properties "password"',
    'filetype:xml "password" | "connectionString"',
]


def serp_search_sensitive(domain: str, api_key: str, sleep_s: float) -> dict:
    """Run the sensitive-dork pass via SerpAPI. Returns {url: dork_that_found_it}.
    Fewer pages per dork than the filetype pass (targeted). Stops a dork on the
    first empty page (efficient, saves credits)."""
    global _serpapi_call_count
    if serp_search is None:
        raise RuntimeError("serpapi not installed")
    found: dict[str, str] = {}
    for dork in SENSITIVE_DORKS:
        q = f"site:{domain} {dork}"
        for start in range(0, 30, 10):   # targeted: fewer pages
            print(f"[+] (sensitive) {dork[:40]} offset {start}")
            params = {"engine": "google", "q": q, "api_key": api_key,
                      "start": start, "num": 10}
            _serpapi_call_count += 1
            try:
                results = serp_search(params)
            except Exception as e:  # noqa: BLE001
                print(f"    dork search error: {e}")
                break
            organic = results.get("organic_results", [])
            if not organic:
                break   # early termination on first empty page
            for r in organic:
                link = (r.get("link") or "").strip()
                if link and link not in found:
                    found[link] = dork
            time.sleep(sleep_s)
    return found


def serp_search_filetype(domain: str, ext: str, api_key: str,
                         max_results: int, sleep_s: float) -> set[str]:
    global _serpapi_call_count
    if serp_search is None:
        raise RuntimeError("serpapi not installed")
    q = f"site:{domain} filetype:{ext}"
    urls: set[str] = set()
    for start in range(0, max_results, 10):
        print(f"[+] ({ext}) SerpAPI offset {start}")
        params = {"engine": "google", "q": q, "api_key": api_key,
                  "start": start, "num": 10}
        _serpapi_call_count += 1        # each search = 1 SerpAPI credit
        results = serp_search(params)
        organic = results.get("organic_results", [])
        if not organic:
            break
        for r in organic:
            link = (r.get("link") or "").strip()
            if link:
                urls.add(link)
        time.sleep(sleep_s)
    return urls


def derive_allowlist(serp_urls, apex_domains: list[str]) -> set[str]:
    """In-scope hosts = the apex domain(s) plus every host that appeared in the
    SerpAPI site:<domain> results (Google already associates these with the
    target). This is the evidence-based scope gate for the crawl/fetch."""
    allow = set()
    for d in apex_domains:
        allow.add(d.lower())
    for u in serp_urls:
        allow.add(host_of(u))
    return allow


def host_in_allowlist(url: str, allowlist: set[str]) -> bool:
    host = host_of(url)
    # exact host match, or host is a subdomain of an allowed apex
    for allowed in allowlist:
        if host == allowed or host.endswith("." + allowed):
            return True
    return False


# ---------------- Allowlist-constrained document crawler ----------------
def discover_document_pages(domain: str, user_agent: str, timeout: int) -> set[str]:
    """Probe common document-portal paths on the apex domain."""
    discovered = set()
    for path in DOCUMENT_PATHS:
        url = f"https://{domain}{path}"
        try:
            r = requests.get(url, headers={"User-Agent": user_agent},
                             timeout=timeout, allow_redirects=True)
            if r.status_code == 200:
                discovered.add(r.url)
        except Exception:
            pass
    return discovered


def _extract_file_links(html: str, base_url: str) -> set[str]:
    urls = set()
    if BeautifulSoup is not None:
        soup = BeautifulSoup(html, "html.parser")
        for tag in soup.find_all(["a", "iframe", "link"]):
            link = tag.get("href") or tag.get("src")
            if not link:
                continue
            absolute = urljoin(base_url, link)
            if re.search(FILE_EXT_RE, absolute, re.I):
                urls.add(absolute)
    # raw/JSON regex pass (catches escaped and script-embedded links)
    for m in re.finditer(r'https?://[^"\'<>\s]+?\.(?:pdf|docx?|xlsx?|pptx?|csv|txt|zip)(?:\?[^"\'<>\s]*)?', html, re.I):
        urls.add(m.group(0))
    return urls


def crawl_document_tree(start_pages, allowlist: set[str], user_agent: str,
                        timeout: int, out_of_scope: set[str],
                        max_depth: int = 5, sleep_s: float = 0.25) -> set[str]:
    """Crawl document portals for file links, REJECTING any URL whose host is not
    in the derived allowlist. Out-of-scope URLs are collected for review."""
    found: set[str] = set()
    visited: set[str] = set()
    queue = [(p, 0) for p in start_pages]

    while queue:
        page, depth = queue.pop(0)
        if page in visited or depth > max_depth:
            continue
        visited.add(page)
        # never crawl a page outside the allowlist
        if not host_in_allowlist(page, allowlist):
            out_of_scope.add(page)
            continue
        print(f"[+] crawl depth={depth}: {page}")
        try:
            r = requests.get(page, headers={"User-Agent": user_agent},
                             timeout=timeout, allow_redirects=True)
            if r.status_code != 200:
                continue
            html = r.text
            for furl in _extract_file_links(html, page):
                if host_in_allowlist(furl, allowlist):
                    found.add(furl)
                else:
                    out_of_scope.add(furl)
            # enqueue same-host document subfolders
            if BeautifulSoup is not None:
                soup = BeautifulSoup(html, "html.parser")
                for a in soup.find_all("a"):
                    link = a.get("href")
                    if not link:
                        continue
                    absolute = urljoin(page, link)
                    if (host_in_allowlist(absolute, allowlist)
                            and "/documents/" in urlparse(absolute).path.lower()
                            and not re.search(FILE_EXT_RE, absolute, re.I)
                            and absolute not in visited):
                        queue.append((absolute, depth + 1))
            time.sleep(sleep_s)
        except Exception as e:
            print(f"[-] crawl failed {page}: {e}")
    return found


# ---------------- Cleaned vs raw CSV ----------------
CLEANED_COLUMNS = ["URL", "FileName", "FileType", "Platform", "Author",
                   "Creator", "CreatorTool", "Producer", "LastModifiedBy",
                   "Company", "Software", "Template", "Created", "Modified"]
RAW_COLUMNS = CLEANED_COLUMNS + ["SHA256", "TextFindings", "Error"]


def _run_exiftool_batch(files_dir, rows) -> None:
    """Run exiftool ONCE over the whole saved-files folder and merge the results
    back into the rows.

    exiftool natively takes a directory and processes every file in one call, so
    this is a single subprocess, not one-per-file. It fills fields the native
    pypdf/docx/xlsx extractors miss — GPS*, Manager, Software, DocumentID — and
    covers file types that have no native extractor at all. Writes a human-
    readable metadata.txt into the folder (and sensitive/ gets its own). If
    exiftool isn't installed, this no-ops.

    Native-extractor fields already on a row are NOT overwritten; exiftool only
    FILLS BLANKS + adds the extra fields, so nothing regresses."""
    import shutil as _sh
    import subprocess as _sp
    import json as _json
    from pathlib import Path as _P

    files_dir = _P(files_dir)
    if not files_dir.is_dir():
        return
    if _sh.which("exiftool") is None:
        print("[fileenum] exiftool not installed — skipping metadata augment "
              "(install libimage-exiftool-perl for GPS/Manager/Software fields)")
        return

    # map LocalPath -> row for merge-back
    by_path = {}
    for r in rows:
        if getattr(r, "LocalPath", ""):
            by_path[str(_P(r.LocalPath).resolve())] = r

    # one batch call, JSON output, recursive over the folder
    fields = ["-Author", "-Creator", "-CreatorTool", "-Producer", "-Title",
              "-Template", "-LastModifiedBy", "-Company", "-Manager", "-Software",
              "-DocumentID", "-InstanceID", "-CreateDate", "-ModifyDate",
              "-GPSLatitude", "-GPSLongitude", "-GPSPosition"]
    cmd = ["exiftool", "-json", "-r", *fields, str(files_dir)]
    try:
        res = _sp.run(cmd, capture_output=True, text=True, errors="replace", timeout=600)
    except (_sp.TimeoutExpired, OSError) as e:
        print(f"[fileenum] exiftool run failed: {e}")
        return
    if not res.stdout.strip():
        return
    try:
        meta_list = _json.loads(res.stdout)
    except ValueError:
        return

    # merge exiftool fields into rows (fill blanks + add GPS/Manager/Software)
    _map = {"Author": "Author", "Creator": "Creator", "CreatorTool": "CreatorTool",
            "Producer": "Producer", "LastModifiedBy": "LastModifiedBy",
            "Company": "Company", "Software": "Software", "Template": "Template",
            "CreateDate": "Created", "ModifyDate": "Modified"}
    for m in meta_list:
        src = m.get("SourceFile", "")
        row = by_path.get(str(_P(src).resolve())) if src else None
        if row is None:
            continue
        for ex_key, row_attr in _map.items():
            val = m.get(ex_key)
            if val and hasattr(row, row_attr) and not getattr(row, row_attr):
                setattr(row, row_attr, str(val))
        # GPS + Manager + Software are extra intel — fold into TextFindings so
        # they surface without needing new columns.
        extras = []
        for k in ("GPSPosition", "GPSLatitude", "GPSLongitude", "Manager",
                  "Software", "DocumentID"):
            if m.get(k):
                extras.append(f"{k}={m[k]}")
        if extras:
            cur = getattr(row, "TextFindings", "")
            row.TextFindings = (cur + " | " if cur else "") + "; ".join(extras)

    # write a clean, human-readable metadata.txt per folder
    def _write_meta_txt(folder):
        folder = _P(folder)
        if not folder.is_dir():
            return
        sub = [m for m in meta_list
               if str(_P(m.get("SourceFile", "")).parent.resolve())
               == str(folder.resolve())]
        if not sub:
            return
        try:
            with open(folder / "metadata.txt", "w") as f:
                for m in sub:
                    f.write("=" * 60 + "\n")
                    f.write(f"File: {_P(m.get('SourceFile','')).name}\n")
                    f.write("=" * 60 + "\n")
                    for k, v in m.items():
                        if k != "SourceFile" and v:
                            f.write(f"  {k}: {v}\n")
                    f.write("\n")
        except OSError:
            pass

    _write_meta_txt(files_dir)
    _write_meta_txt(files_dir / "sensitive")
    print(f"[fileenum] exiftool: metadata written for {len(meta_list)} file(s)")


def process_files(domain: str, outdir, api_key: str, types: list[str],
                  apex_domains: list[str], max_results: int = 700,
                  sleep_s: float = 1.0, timeout: int = 20,
                  max_bytes: int = 20_000_000,
                  user_agent: str = "Mozilla/5.0 (compatible; FileEnum/4.0)",
                  use_crawler: bool = True, ledger=None,
                  sensitive_dorks: bool = True):
    from pathlib import Path
    global _serpapi_call_count
    _serpapi_start = _serpapi_call_count   # snapshot to compute this-run delta
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    safe = domain.replace("/", "_")
    # Downloaded files are saved here so they're engagement artifacts
    # AND exiftool can batch the whole folder at the end. Sensitive -> subfolder.
    files_dir = outdir / f"fileenum_{safe}_files"

    # 1) SerpAPI search per filetype
    serp_urls: set[str] = set()
    for ext in types:
        serp_urls |= serp_search_filetype(domain, ext, api_key, max_results, sleep_s)

    # 1b) sensitive-dork pass (content-aware: exposed secrets/configs/dumps).
    #     Records url -> dork so the report can flag WHY each was sensitive.
    sensitive_map: dict = {}
    if sensitive_dorks:
        try:
            sensitive_map = serp_search_sensitive(domain, api_key, sleep_s)
            if sensitive_map:
                print(f"[FileEnum] sensitive-dork pass: {len(sensitive_map)} "
                      f"flagged URL(s) (will be scope-filtered before use)")
                # NOTE: intentionally NOT merged into serp_urls here — that would
                # poison the allowlist derived below. They're filtered in step 2.
        except Exception as e:  # noqa: BLE001
            print(f"[FileEnum] sensitive-dork pass error (continuing): {e}")

    # 2) derive the scope allowlist FIRST, from the trusted site:<domain> filetype
    #    results + apex domains ONLY. Do NOT derive it from the sensitive-dork
    #    results — Google often returns global "related" pages for dorks like
    #    filetype:config "password" (Wikipedia, LastPass, passwords.google.com),
    #    and folding those into the allowlist would let them whitelist THEMSELVES.
    allowlist = derive_allowlist(serp_urls, apex_domains)
    print(f"[i] derived allowlist ({len(allowlist)} hosts): {sorted(allowlist)}")

    # NOW bring in the sensitive-dork hits — but only ones whose host is already
    # in the clean allowlist. Off-scope dork noise is logged, never trusted.
    out_of_scope: set[str] = set()
    if sensitive_map:
        for u in sensitive_map:
            if host_in_allowlist(u, allowlist):
                serp_urls.add(u)
            else:
                out_of_scope.add(u)

    all_urls = set(u for u in serp_urls if host_in_allowlist(u, allowlist))
    out_of_scope |= (serp_urls - all_urls)

    # 3) optional document-portal crawl, constrained to the allowlist
    if use_crawler:
        pages = discover_document_pages(domain, user_agent, timeout)
        all_urls |= crawl_document_tree(pages, allowlist, user_agent, timeout,
                                        out_of_scope)

    # 4) de-dup before any download
    ordered = dedupe_urls(sorted(all_urls))
    print(f"[i] {len(ordered)} unique in-scope file URLs after dedupe")

    # log out-of-scope URLs for review (never fetched)
    if out_of_scope:
        (outdir / f"fileenum_{safe}.out_of_scope.txt").write_text(
            "\n".join(sorted(out_of_scope)) + "\n")
        print(f"[i] {len(out_of_scope)} out-of-allowlist URLs logged for review")

    # 5) fetch + extract, with DEFERRED retry: a failed download goes into a
    #    retry_later list instead of retrying immediately. We grab all the easy
    #    wins first, then run the retry_later list AFTER the main pass — giving a
    #    busy/slow server recovery time (immediate retry would just hit the same
    #    busy server), and one stubborn slow file never stalls the whole queue.
    rows: list[FileRow] = []
    retry_later: list[str] = []

    def _fetch_one(url: str) -> FileRow:
        ext = guess_ext(url) or "unknown"
        row = FileRow(URL=url, FileName=safe_filename_from_url(url),
                      FileType=ext, Platform=detect_platform(url))
        # Consistent sensitive-flagging via the SHARED sensitive_patterns library
        # (same brain buckets.py uses), plus any sensitive-dork that surfaced it.
        try:
            from . import sensitive_patterns as _sp
            cat = _sp.categorize(row.FileName, url)
        except Exception:  # noqa: BLE001
            cat = ""
        dork = sensitive_map.get(url, "") if sensitive_dorks else ""
        if cat and dork:
            row.Sensitive = f"{cat}; dork:{dork[:40]}"
        elif cat:
            row.Sensitive = cat
        elif dork:
            row.Sensitive = f"dork:{dork[:40]}"
        try:
            content, ct = http_fetch(url, timeout, max_bytes, user_agent)
            if ext not in METADATA_EXTRACTORS and ext not in TEXT_TYPES and ct in CONTENT_TYPE_MAP:
                ext = CONTENT_TYPE_MAP[ct]
                row.FileType = ext
            row.SHA256 = sha256_bytes(content)
            # Save the downloaded file to disk: the file itself is an
            # engagement artifact, AND it lets us run exiftool over the whole
            # folder at the end (one batch call). Sensitive files -> sensitive/
            # subfolder. Guarded so a save failure never loses the row.
            try:
                dest_dir = files_dir / "sensitive" if row.Sensitive else files_dir
                dest_dir.mkdir(parents=True, exist_ok=True)
                fname = row.FileName or f"file_{row.SHA256[:12]}.{ext}"
                # de-dupe on-disk name collisions
                dest = dest_dir / fname
                n = 1
                while dest.exists():
                    stem = dest.stem
                    dest = dest_dir / f"{stem}_{n}{dest.suffix}"
                    n += 1
                dest.write_bytes(content)
                row.LocalPath = str(dest)
            except OSError as _se:
                row.Error = (row.Error + f" | save failed: {_se}").strip(" |")
            if ext in METADATA_EXTRACTORS:
                md = METADATA_EXTRACTORS[ext](content)
                for k, v in md.items():
                    if hasattr(row, k) and v:
                        setattr(row, k, str(v))
            elif ext in TEXT_TYPES:
                row.TextFindings = scan_text(content).get("TextFindings", "")
            else:
                row.Error = f"no extractor for {ext}"
        except Exception as e:
            row.Error = str(e)
        return row

    # what counts as a "transient" error worth deferring (server was busy/slow,
    # may succeed after recovery time) vs. a permanent failure. Beyond timeouts:
    # 503 (overloaded), 429 (rate-limited), and dropped/reset connections.
    def _is_transient(err: str) -> bool:
        e = (err or "").lower()
        return any(s in e for s in (
            "timeout", "timed out", "503", "429", "connection reset",
            "connection aborted", "connectionreset", "temporarily",
            "too many requests", "read timed out"))

    # main pass
    for idx, url in enumerate(ordered, 1):
        print(f"[+] ({idx}/{len(ordered)}) {url}")
        row = _fetch_one(url)
        if row.Error and _is_transient(row.Error):
            # transient/slow — defer, don't give up yet
            retry_later.append(url)
            print(f"    deferred (will retry after main pass): {row.Error}")
        else:
            rows.append(row)

    # deferred retry passes (cap 2) — after time has passed, busy servers recover
    for rpass in range(1, 3):
        if not retry_later:
            break
        print(f"[FileEnum] deferred retry pass {rpass}: "
              f"{len(retry_later)} URL(s)")
        still_failing: list[str] = []
        for url in retry_later:
            print(f"[retry {rpass}] {url}")
            row = _fetch_one(url)
            if row.Error and _is_transient(row.Error) and rpass < 2:
                still_failing.append(url)   # one more chance next pass
            else:
                rows.append(row)   # success OR final failure (logged with reason)
        retry_later = still_failing

    # exiftool batch pass over the saved-files folder: one call does
    # the whole directory. Fills metadata the native extractors miss (GPS,
    # Manager, Software, DocumentID) + covers file types without a native
    # extractor. Writes metadata.txt into the folder (and sensitive/ its own).
    # Merges key fields back into the rows by LocalPath. exiftool absent = skipped.
    try:
        _run_exiftool_batch(files_dir, rows)
    except Exception as e:  # noqa: BLE001
        print(f"[fileenum] exiftool pass skipped: {e}")

    # 6) write raw + cleaned CSVs
    raw_csv = outdir / f"fileenum_{safe}.raw.csv"
    clean_csv = outdir / f"fileenum_{safe}.clean.csv"
    with open(raw_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=RAW_COLUMNS)
        w.writeheader()
        for r in rows:
            w.writerow({k: getattr(r, k) for k in RAW_COLUMNS})
    with open(clean_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=CLEANED_COLUMNS)
        w.writeheader()
        for r in rows:
            w.writerow({k: getattr(r, k) for k in CLEANED_COLUMNS})

    print(f"[\u2713] raw: {raw_csv}  |  cleaned: {clean_csv}")
    # record SerpAPI usage: searches made THIS call (1 credit each)
    if ledger is not None:
        used = _serpapi_call_count - _serpapi_start
        if used > 0:
            try:
                ledger.record("serpapi", used, kind="estimated",
                              note=f"{used} search(es) / {domain} filetypes")
            except Exception as e:  # noqa: BLE001
                print(f"[fileenum] {e}")
    return clean_csv
