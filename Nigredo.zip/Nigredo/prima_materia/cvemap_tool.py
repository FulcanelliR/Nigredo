"""cvemap_tool.py — CVE enrichment for discovered technologies (ProjectDiscovery cvemap).

The "new rock to look under": after web_discovery (httpx -tech-detect) and shodan
(CPEs) identify what software the target runs, we feed that unique technology list
to ProjectDiscovery's `cvemap` to surface known CVEs — with EPSS score, CISA-KEV
status, and public-PoC / nuclei-template availability per CVE.

Passive: cvemap queries CVE databases (NVD/CISA/etc.), NOT the target. It's a
lookup against what we already fingerprinted, so it adds no target traffic.

  cvemap -product <name> -json          (per discovered product)

Requires the `cvemap` binary (go install github.com/projectdiscovery/cvemap/...).
Graceful skip if absent.
"""
from __future__ import annotations

import json
import re
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


def cvemap_available() -> bool:
    return shutil.which("cvemap") is not None


# techs that are too generic to yield useful CVE mappings (noise filter)
_SKIP_TECH = {
    "html", "css", "javascript", "json", "xml", "http", "https", "html5",
    "gzip", "chunked", "utf-8", "cloudflare", "amazon", "google", "font",
}


@dataclass
class CVEHit:
    product: str = ""
    cve_id: str = ""
    severity: str = ""
    cvss: str = ""
    epss: str = ""
    is_kev: bool = False          # CISA Known-Exploited
    has_poc: bool = False         # public PoC exists
    has_template: bool = False    # nuclei template exists
    description: str = ""

    def as_row(self) -> list:
        flags = []
        if self.is_kev:
            flags.append("KEV")
        if self.has_poc:
            flags.append("PoC")
        if self.has_template:
            flags.append("nuclei")
        return [self.product, self.cve_id, self.severity, self.cvss, self.epss,
                ", ".join(flags), self.description[:200]]


def _clean_products(techs: list[str]) -> list[str]:
    """Normalize + dedupe the discovered technology names into cvemap queries.
    Strips version numbers (cvemap matches on product name), drops generic noise."""
    seen, out = set(), []
    for t in techs:
        if not t:
            continue
        # split "nginx:1.21.0" or "nginx 1.21.0" -> "nginx"
        name = re.split(r"[:\s/]", t.strip())[0].lower()
        name = re.sub(r"[^a-z0-9._-]", "", name)
        if not name or name in _SKIP_TECH or len(name) < 2:
            continue
        if name not in seen:
            seen.add(name)
            out.append(name)
    return out


def collect_technologies(outdir: Path) -> list[str]:
    """Gather the unique technology list from httpx tech-detect + shodan CPEs +
    FunnelWeb's crawl (server/CDN/framework signals). FunnelWeb crawls the live
    app and detects infrastructure/tech its passive fingerprint misses, so its
    findings are a real third source of products to CVE-map."""
    techs: list[str] = []

    # httpx rows (web_discovery writes httpx_*.csv with a 'tech' column)
    import csv
    for p in outdir.glob("httpx_*.csv"):
        try:
            with open(p, newline="", encoding="utf-8", errors="replace") as f:
                r = csv.DictReader(f)
                for row in r:
                    tv = row.get("tech") or row.get("technologies") or ""
                    for t in re.split(r"[,;]", tv):
                        if t.strip():
                            techs.append(t.strip())
        except OSError:
            pass

    # shodan CPEs (shodan_*.csv has a CPEs column; also parse cpe:2.3 strings)
    for p in outdir.glob("shodan_*.csv"):
        try:
            with open(p, newline="", encoding="utf-8", errors="replace") as f:
                r = csv.DictReader(f)
                for row in r:
                    cpev = row.get("CPEs") or row.get("cpes") or ""
                    for cpe in re.split(r"[,;]", cpev):
                        cpe = cpe.strip()
                        # cpe:2.3:a:vendor:product:version -> product
                        m = re.match(r"cpe:2\.3:[aho]:[^:]+:([^:]+):", cpe)
                        if m:
                            techs.append(m.group(1).replace("_", " "))
                        elif cpe:
                            techs.append(cpe)
        except OSError:
            pass

    # FunnelWeb crawl output: its report.csv carries Category/Detail rows, some of
    # which are technology/server/CDN/framework signals. Harvest those so the
    # crawler's discoveries reach cvemap (and, downstream, Cache). FunnelWeb writes
    # under funnelweb_*/report.csv (per-domain) or a report.csv it locates.
    techs += collect_funnelweb_technologies(outdir)

    return _clean_products(techs)


# Category labels in FunnelWeb's report.csv that carry technology/product signals.
_FW_TECH_CATEGORIES = {
    "technology", "technologies", "tech", "server", "cdn", "framework",
    "powered-by", "x-powered-by", "generator", "software", "waf", "webserver",
}


def collect_funnelweb_technologies(outdir: Path) -> list[str]:
    """Read FunnelWeb report.csv files and pull technology-relevant rows.

    FunnelWeb rows are [Category, Detail, Source URL, Local Path, Notes]. We take
    the Detail of any row whose Category looks technology-related (server, CDN,
    framework, generator, etc.), plus any 'header:<name>' CDN signals it recorded.
    """
    import csv
    found: list[str] = []
    # search both the per-domain funnelweb dirs and any stray report.csv
    candidates = list(outdir.glob("funnelweb_*/report.csv"))
    candidates += list(outdir.glob("**/report.csv"))
    seen_files = set()
    for p in candidates:
        rp = p.resolve()
        if rp in seen_files:
            continue
        seen_files.add(rp)
        try:
            with open(p, newline="", encoding="utf-8", errors="replace") as f:
                r = csv.reader(f)
                header = next(r, None)
                # locate Category + Detail columns (default 0,1)
                ci, di = 0, 1
                if header:
                    low = [h.strip().lower() for h in header]
                    if "category" in low:
                        ci = low.index("category")
                    if "detail" in low:
                        di = low.index("detail")
                for row in r:
                    if len(row) <= max(ci, di):
                        continue
                    cat = (row[ci] or "").strip().lower()
                    detail = (row[di] or "").strip()
                    if not detail:
                        continue
                    # tech-relevant category, or a CDN header signal
                    if cat in _FW_TECH_CATEGORIES or cat.startswith("header:") \
                            or "cdn" in cat or "server" in cat:
                        # strip a leading 'header:' marker FunnelWeb uses for CDN hits
                        detail = re.sub(r"^header:\s*", "", detail, flags=re.I)
                        found.append(detail)
        except (OSError, StopIteration):
            pass
    return found




def run_product(product: str, timeout: int = 60, api_key: str = "") -> list[CVEHit]:
    """Query cvemap for one product, return parsed CVE hits.

    api_key: a ProjectDiscovery PDCP key. When set it is passed via the PDCP_API_KEY
    env var so cvemap runs AUTHENTICATED (much higher CVE-API rate limit). Blank =
    free/anonymous tier (works, but ProjectDiscovery throttles it — that's why the
    stage crawls without a key)."""
    import os as _os
    cmd = ["cvemap", "-product", product, "-json", "-silent"]
    env = None
    if api_key:
        env = dict(_os.environ)
        env["PDCP_API_KEY"] = api_key
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, errors="replace",
                              timeout=timeout, env=env)
    except subprocess.TimeoutExpired:
        print(f"[cvemap] {product}: timed out")
        return []
    except OSError as e:
        print(f"[cvemap] failed to run: {e}")
        return []

    out = proc.stdout or ""
    hits: list[CVEHit] = []
    # cvemap -json emits a JSON array (or JSONL depending on version); handle both
    records = []
    out = out.strip()
    if not out:
        return []
    try:
        parsed = json.loads(out)
        records = parsed if isinstance(parsed, list) else [parsed]
    except ValueError:
        for line in out.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                records.append(json.loads(line))
            except ValueError:
                continue

    for rec in records:
        if not isinstance(rec, dict):
            continue
        cve_id = rec.get("cve_id") or rec.get("id") or ""
        if not cve_id:
            continue
        # severity / cvss can live in a few shapes across cvemap versions
        sev = (rec.get("severity") or rec.get("cvss_severity") or "").upper()
        cvss = str(rec.get("cvss_score") or rec.get("cvss") or "")
        epss_obj = rec.get("epss") or {}
        epss = str(epss_obj.get("epss_score") if isinstance(epss_obj, dict) else epss_obj or "")
        is_kev = bool(rec.get("is_kev") or (rec.get("kev") or {}))
        poc = rec.get("poc") or rec.get("pocs") or []
        has_poc = bool(poc)
        tmpl = rec.get("is_template") or rec.get("nuclei_template") or rec.get("is_nuclei")
        has_template = bool(tmpl)
        desc = rec.get("cve_description") or rec.get("description") or ""
        hits.append(CVEHit(product=product, cve_id=cve_id, severity=sev,
                           cvss=cvss, epss=epss, is_kev=is_kev, has_poc=has_poc,
                           has_template=has_template, description=desc))
    return hits


def process(outdir: Path, command_log: Path, max_products: int = 40,
            dry_run: bool = False, api_key: str = "") -> list[CVEHit]:
    """Full pass: collect discovered tech -> cvemap each -> write findings CSV.
    Returns all CVE hits (empty if cvemap missing or no tech found).

    api_key: optional ProjectDiscovery PDCP key. With it, cvemap runs authenticated
    (higher rate limit); without it, the free/anonymous tier is used (slower — PD
    throttles it)."""
    outdir = Path(outdir)
    if not cvemap_available():
        print("[cvemap] not installed — skipping tech CVE lookup "
              "(go install github.com/projectdiscovery/cvemap/cmd/cvemap@latest)")
        return []

    products = collect_technologies(outdir)
    if not products:
        print("[cvemap] no technologies discovered yet (need httpx tech-detect "
              "or shodan CPEs first)")
        return []
    products = products[:max_products]
    _tier = "authenticated (PDCP key)" if api_key else ("free/anonymous tier — "
            "ProjectDiscovery rate-limits this, so it can be slow; add a free PDCP "
            "key to speed it up")
    print(f"[cvemap] looking up CVEs for {len(products)} discovered tech "
          f"[{_tier}]: {', '.join(products[:10])}{'...' if len(products) > 10 else ''}")

    with open(command_log, "a") as log:
        log.write(f"# cvemap over {len(products)} discovered products\n")
    if dry_run:
        for p in products:
            print(f"[dry-run] cvemap -product {p} -json")
        return []

    all_hits: list[CVEHit] = []
    for prod in products:
        hits = run_product(prod, api_key=api_key)
        if hits:
            all_hits.extend(hits)
            kev = sum(1 for h in hits if h.is_kev)
            print(f"[cvemap] {prod}: {len(hits)} CVE(s)"
                  f"{f', {kev} KEV' if kev else ''}")

    # sort: KEV first, then by severity, then EPSS desc
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}

    def _epss_val(h):
        try:
            return -float(h.epss)
        except (ValueError, TypeError):
            return 0.0
    all_hits.sort(key=lambda h: (not h.is_kev, sev_rank.get(h.severity, 4), _epss_val(h)))

    # write findings CSV
    out_csv = outdir / "cvemap_findings.csv"
    import csv as _csv
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = _csv.writer(f)
        w.writerow(["Product", "CVE", "Severity", "CVSS", "EPSS", "Flags",
                    "Description"])
        for h in all_hits:
            w.writerow(h.as_row())
    kev_total = sum(1 for h in all_hits if h.is_kev)
    print(f"[cvemap] {len(all_hits)} total CVE(s), {kev_total} KEV "
          f"-> cvemap_findings.csv")
    return all_hits
