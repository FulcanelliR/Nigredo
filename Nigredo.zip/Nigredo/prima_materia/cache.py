"""Cache (Stockpiler Exp) — online PoC-exploit lookup for the client's CVEs.

WHAT IT DOES
  After cvemap maps the client's discovered tech -> CVE IDs, Cache looks up which
  of those CVEs have PUBLIC proof-of-concept exploits available, and records the
  PoC URLs so the analyst has actionable starting resources the moment the scan
  finishes. This is the "here are the vulns AND the exploits that already exist
  for them" intelligence layer.

SOURCE (online, no local collection, no GitHub token)
  Queries the public PoC-in-GitHub aggregator API:
      https://poc-in-github.motikan2010.net/api/v1/?cve_id=CVE-XXXX-YYYY
  This is the SAME data as the local Stockpiler collection (both derive from
  nomi-sec/PoC-in-GitHub), served live by a purpose-built API. So Cache is the
  universal freebie: it needs no 1TB local collection and never hits GitHub's own
  API/rate limits. If the local Stockpiler tool IS installed, that can be used
  instead (faster/offline) — Cache is the default that works for everyone.

QUERY STRATEGY (keeps request volume low)
  1. CVE ID  — primary, precise. One request per CVE cvemap found. Listed first.
  2. tech    — supplementary, noisy substring match. Listed at the BOTTOM of the
               workbook for the analyst. Optional.

OUTPUT
  Groups PoC URLs under the query (CVE/tech) that found them, into the "Cache"
  workbook tab + a log file. URL + short description + star count (all free from
  the API JSON). NEVER downloads/clones any repo — just records URLs.

SAFETY
  PoCs are third-party; some are fake or malware (upstream's own warning). The
  report tab carries that caveat. Network calls are bounded (timeout + skip) so a
  slow/down API never hangs the run.
"""
from __future__ import annotations

import json
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path


API_BASE = "https://poc-in-github.motikan2010.net/api/v1/"


@dataclass
class PoCEntry:
    cve_id: str
    html_url: str
    description: str = ""
    stars: int = 0


@dataclass
class CacheResult:
    query: str                      # the CVE ID or tech name searched
    kind: str                       # "cve" | "tech"
    pocs: list = field(default_factory=list)   # list[PoCEntry]


def _api_get(params: dict, timeout: int = 15) -> dict | None:
    """One GET to the PoC-in-GitHub API. Returns parsed JSON or None on any
    failure (never raises — a down/slow API must not break the run)."""
    url = API_BASE + "?" + urllib.parse.urlencode(params)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "nigredo-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode("utf-8", errors="replace"))
    except Exception:  # noqa: BLE001 (network/JSON/timeout -> treat as no result)
        return None


def _parse_pocs(data: dict, cve_hint: str = "") -> list:
    """Pull PoCEntry list out of the API's {"pocs":[...]} response."""
    out = []
    for p in (data or {}).get("pocs", []) or []:
        url = p.get("html_url", "") or ""
        if not url:
            continue
        try:
            stars = int(p.get("stargazers_count", 0) or 0)
        except (ValueError, TypeError):
            stars = 0
        out.append(PoCEntry(
            cve_id=p.get("cve_id", cve_hint) or cve_hint,
            html_url=url,
            description=(p.get("description") or "").strip(),
            stars=stars,
        ))
    # highest-starred first — a rough quality/popularity signal
    out.sort(key=lambda e: e.stars, reverse=True)
    return out


def lookup_cve(cve_id: str, delay: float = 0.5) -> CacheResult:
    """Look up PoCs for one exact CVE ID."""
    cve_id = cve_id.strip().upper()
    data = _api_get({"cve_id": cve_id})
    pocs = _parse_pocs(data, cve_hint=cve_id)
    if delay:
        time.sleep(delay)     # gentle spacing between API calls
    return CacheResult(query=cve_id, kind="cve", pocs=pocs)


def lookup_tech(tech: str, delay: float = 0.5) -> CacheResult:
    """Supplementary: fuzzy search by tech/product name (noisier)."""
    tech = tech.strip()
    data = _api_get({"q": tech})
    pocs = _parse_pocs(data)
    if delay:
        time.sleep(delay)
    return CacheResult(query=tech, kind="tech", pocs=pocs)


def run_cache(outdir: Path, cve_ids: list, tech_names: list | None = None,
              enabled: bool = True) -> Path | None:
    """Look up PoCs for the client's CVEs (primary) and tech (supplementary).
    Writes cache_pocs.json + a log, returns the json path. Prints a summary with
    the 'Cache (Stockpiler Exp)' label. Skips cleanly if disabled or no input."""
    if not enabled:
        return None
    cve_ids = sorted({c.strip().upper() for c in (cve_ids or []) if c.strip()})
    tech_names = sorted({t.strip() for t in (tech_names or []) if t.strip()})
    if not cve_ids and not tech_names:
        print("[Cache (Stockpiler Exp)] no CVEs or tech to look up — skipping")
        return None

    print(f"[Cache (Stockpiler Exp)] looking up public PoCs for "
          f"{len(cve_ids)} CVE(s)"
          + (f" + {len(tech_names)} tech name(s)" if tech_names else "")
          + " via poc-in-github API…")

    results: list = []
    hit_cves = 0
    for cve in cve_ids:
        r = lookup_cve(cve)
        results.append(r)
        if r.pocs:
            hit_cves += 1
    for tech in tech_names:
        r = lookup_tech(tech)
        results.append(r)

    total_pocs = sum(len(r.pocs) for r in results)
    if hit_cves:
        print(f"[Cache (Stockpiler Exp)] {hit_cves}/{len(cve_ids)} CVE(s) have "
              f"public PoCs — {total_pocs} exploit URL(s) recorded. See the "
              f"'Cache' report tab (review before running — some PoCs are malware).")
    else:
        print(f"[Cache (Stockpiler Exp)] no public PoCs found for the client's CVEs.")

    # persist for the report
    out = Path(outdir) / "cache_pocs.json"
    payload = []
    for r in results:
        payload.append({
            "query": r.query, "kind": r.kind,
            "pocs": [{"cve_id": p.cve_id, "url": p.html_url,
                      "description": p.description, "stars": p.stars}
                     for p in r.pocs],
        })
    out.write_text(json.dumps(payload, indent=2))

    # human-readable log too
    log = Path(outdir) / "cache_pocs.log"
    lines = ["Cache (Stockpiler Exp) — public PoC lookup",
             "WARNING: PoCs are third-party; some may be fake or malware. "
             "Review source before executing.", ""]
    for r in results:
        if not r.pocs:
            continue
        lines.append(f"[{r.kind.upper()}] {r.query}")
        for p in r.pocs:
            lines.append(f"    {p.html_url}  (★{p.stars})  {p.description[:100]}")
        lines.append("")
    log.write_text("\n".join(lines))
    return out
