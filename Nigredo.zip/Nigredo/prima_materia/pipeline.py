"""Pipeline — the active-scan engine (Phase 0). One of the two carriage engines.

Seeded by targets.txt (the scope boundary). Everything here can send packets to
the client, so scope enforcement and the proxy boundary live here.

END-TO-END FLOW:
  1. Load targets.txt (fall back to expanding scope.txt if empty).
  2. SCOPE GATE: ScopeGuard validates every target before any nmap packet.
     Out-of-scope target -> ScopeViolation halts the run. No targets -> hard stop.
  3. nmap: staged sweep -> parse -> per-host open ports -> classified endpoints.
  4. probe.py: verify each web endpoint, resolve scheme (https/http), build the
     `web_urls` seed list (live roots). Same-host redirects handled; cross-host
     (off-scope SSO/Okta) never followed.
  5. shodan enrich (in-scope IPs only; InternetDB free / host-lookup paid+capped).
  6. WEB DISCOVERY (passive/light, NO forwarding proxy — see PROXY BOUNDARY):
     httpx (fingerprint) / katana (crawl) / gau (historical URLs) / httpx liveness
     -> build_url_pool() -> nuclei_full_pool.
  7. nuclei TWO passes:
       PASS 1 takeover-only  -> the FULL pool (incl. out-of-scope subs), takeover
         templates only (safe to reach broadly; just dangling-DNS fingerprints).
       PASS 2 full templates -> _scope_filter_urls() keeps ONLY in-scope hosts.
  8. ffuf -> feroxbuster -> nomore403 (client-hammering, DO use the proxy).
  9. testssl / sns / ssh-audit (TLS + service checks).
  10. report.build_report() -> final_report.xlsx. Results persisted as JSON;
      resumable across crashes.

PROXY BOUNDARY (audit this — it caused a real bug once):
  - Passive/discovery tools (httpx, katana, gau, liveness) get NO forwarding proxy.
    (gau rejects an https:// proxy scheme; and none of these hammer the client.)
  - Client-hammering tools (probe, ffuf, feroxbuster, nomore403, FunnelWeb) DO get
    the forwarding proxy — that's the traffic you want routed through it.

CREDIT LEDGER: shodan host-lookups record here. The ledger is shared with the
recon engine when passed in; otherwise this engine makes its own.
"""
from __future__ import annotations

import json
import sys
from dataclasses import asdict
from pathlib import Path

from .config import Config
from .scope import ScopeGuard, ScopeViolation
from .runner import PhaseRunner
from . import nmap_parser
from . import classifier
from .probe import probe_endpoint
from .tools import (ToolConfig, emit_target_files, run_nuclei,
                    run_feroxbuster, run_testssl, run_sns, run_sshaudit)


def _looks_like_ip(s: str) -> bool:
    """True if s is a bare IPv4/IPv6 address (not a CIDR or hostname)."""
    import ipaddress
    try:
        ipaddress.ip_address(s.strip())
        return True
    except ValueError:
        return False


def _dig_ipv4(fqdn: str, command_log=None) -> list[str]:
    """Resolve a FQDN's A records (IPv4 only; AAAA/IPv6 intentionally ignored).
    Uses `dig +short A` if available, else falls back to socket resolution.
    Returns the list of IPv4 addresses the name resolves to."""
    import shutil, subprocess, socket
    ips: list[str] = []
    if shutil.which("dig"):
        try:
            if command_log:
                with open(command_log, "a") as log:
                    log.write(f"dig +short A {fqdn}\n")
            out = subprocess.run(["dig", "+short", "A", fqdn],
                                 capture_output=True, text=True, errors="replace", timeout=15)
            for line in out.stdout.splitlines():
                line = line.strip()
                if _looks_like_ip(line) and ":" not in line:   # IPv4 only
                    ips.append(line)
        except (subprocess.SubprocessError, OSError):
            pass
    if not ips:
        # fallback: socket resolution, filter to IPv4
        try:
            for res in socket.getaddrinfo(fqdn, None, socket.AF_INET):
                ip = res[4][0]
                if ip not in ips:
                    ips.append(ip)
        except (socket.gaierror, OSError):
            pass
    return ips


def _dig_reverse(ip: str, command_log=None) -> list[str]:
    """Reverse-resolve an IP to hostname(s) via `dig -x` (PTR), socket fallback.
    Used ONLY to CONFIRM already-known candidate FQDNs (never to invent new ones
    — see fqdn_resolve.gather_dig_pairs). Returns the list of PTR names."""
    import shutil, subprocess, socket
    names: list[str] = []
    if shutil.which("dig"):
        try:
            if command_log:
                with open(command_log, "a") as log:
                    log.write(f"dig -x {ip}\n")
            out = subprocess.run(["dig", "+short", "-x", ip],
                                 capture_output=True, text=True, errors="replace", timeout=15)
            for line in out.stdout.splitlines():
                line = line.strip().rstrip(".")
                if line:
                    names.append(line)
        except (subprocess.SubprocessError, OSError):
            pass
    if not names:
        try:
            host, _aliases, _ = socket.gethostbyaddr(ip)
            if host:
                names.append(host.rstrip("."))
        except (socket.herror, socket.gaierror, OSError):
            pass
    return names


def _has_real_targets(path: str | Path) -> bool:
    """True if `path` exists and holds at least one non-blank line.

    Used instead of a bare `st_size > 0` check at the scan-authority gate and the
    tool entry guards: a urls.txt containing only newlines/whitespace has a
    non-zero size but zero real targets, and would otherwise pass the size gate
    yet make every fuzzer silently scan nothing (the "ran, produced no output"
    symptom). Decode-safe so a stray non-UTF-8 byte can't turn the check into a
    crash on the scan path.
    """
    try:
        p = Path(path)
        if not p.is_file():
            return False
        for raw in p.read_text(errors="replace").splitlines():
            if raw.strip():
                return True
        return False
    except OSError:
        return False


def _load_lines(path: str | Path) -> list[str]:
    out = []
    for raw in Path(path).read_text(errors="replace").splitlines():
        line = raw.strip()
        if line and not line.startswith("#"):
            out.append(line)
    return out


class Pipeline:
    def __init__(self, cfg: Config, dry_run: bool = False,
                 assume_yes: bool = False, correlate_domains=None,
                 nessus_file=None, nessus_files=None, ledger=None,
                 recon_domains_ref=None) -> None:
        self.cfg = cfg
        self.dry_run = dry_run
        self.assume_yes = assume_yes
        self.ledger = ledger
        self.correlate_domains = correlate_domains or []
        # READ-ONLY confirmation key: operator-entered recon domains, used ONLY to
        # recognize when a target IP redirects to its own declared FQDN front door
        # (see emit_target_files). Never fed to any scan/fuzz/discovery tool.
        self.recon_domains_ref = {str(d).strip().lower()
                                  for d in (recon_domains_ref or []) if d}
        self._confirmed_redirect_hosts: set = set()
        # accept either a single file (legacy) or a list of labeled files
        files = list(nessus_files) if nessus_files else []
        if nessus_file and nessus_file not in files:
            files.append(nessus_file)
        self.nessus_files = [f for f in files if f]
        self.nessus_file = self.nessus_files[0] if self.nessus_files else None
        self.outdir = Path(cfg.output_dir) / cfg.engagement_name
        self.outdir.mkdir(parents=True, exist_ok=True)
        # credit ledger: use the one passed in (shared with the recon orchestrator)
        # or create one for the scan side. Shodan host-lookups record here.
        if self.ledger is None:
            from .api_budget import CreditLedger
            self.ledger = CreditLedger(self.outdir, caps={
                "snov": getattr(cfg, "snov_credit_cap", None),
                "grayhat": getattr(cfg, "grayhat_credit_cap", None),
                "shodan": getattr(cfg, "shodan_credit_cap", None),
                "serpapi": getattr(cfg, "serpapi_credit_cap", None),
                "dehashed": getattr(cfg, "dehashed_credit_cap", None),
            })
        self.state_file = self.outdir / "state.json"
        self.runner = PhaseRunner(cfg, self.outdir, dry_run=dry_run)
        self.guard = ScopeGuard.from_file(cfg.scope_file)
        from .tools import build_tool_config
        self.tool_config = build_tool_config(cfg)
        self._subdomain_enrichment: dict = {}
        self._live_urls: list = []
        # True only after host validation produced a non-empty urls.txt (the single
        # web pool). Gates the web-fuzz tools + the add-only pool augmentation, so an
        # empty WebGet result can never be silently backfilled from another source.
        self._web_pool_ok: bool = False
        self._nessus_rich: dict = {}
        self._honeypot_ips: set = set()
        self._nessus_reconciled: dict = {}
        self._force_validate: dict = {}

    def _fwd_proxy(self) -> str:
        """The forwarding proxy for target-hitting HTTP tools (probe/ffuf/ferox).
        Interview stash wins; else config; else empty (direct)."""
        try:
            from .runmode import answer, has_answer
            if has_answer("forward_proxy"):
                return answer("forward_proxy", "") or ""
        except Exception:  # noqa: BLE001
            pass
        return getattr(self.cfg, "forward_proxy", "") or ""

    def _takeover_targets(self):
        """Build the subdomain-TAKEOVER target list from SUBFINDER's discovered
        subdomains — a fundamentally different set from the fuzzer pool.

        Takeover testing looks for dangling/unclaimed DNS (CNAME -> deprovisioned
        S3/Azure/GitHub-Pages/etc.). The right candidates are the ENUMERATED
        subdomain NAMES, whether or not they currently resolve:
          - NXDOMAIN-but-enumerated names ARE the classic takeover case (a claimed
            subdomain whose backing service is gone) — the old code DROPPED these.
          - dangling CNAMEs — kept.
        This is NOT the live-web pool the fuzzers use; feeding takeover the fuzzer
        pool (live IPs/hosts) and then filtering OUT non-resolving names inverted
        the whole point. nuclei's takeover templates fingerprint the service
        response, so they want the names, resolving or not.

        Sources: subdomains_<domain>.subfinder.txt (bare names) + the name column
        of subdomains_<domain>.clean.csv. Deduped. Returns a written file path, or
        None if no subdomains were discovered (takeover pass then skips).
        """
        names, seen = [], set()
        for p in sorted(self.outdir.glob("subdomains_*.subfinder.txt")):
            try:
                for ln in p.read_text(errors="replace").splitlines():
                    h = ln.strip().lower()
                    if h and not h.startswith("#") and h not in seen:
                        seen.add(h); names.append(h)
            except OSError:
                continue
        for p in sorted(self.outdir.glob("subdomains_*.clean.csv")):
            try:
                for ln in p.read_text(errors="replace").splitlines():
                    h = ln.split(",", 1)[0].strip().lower()
                    if h and h != "subdomain" and h not in seen:
                        seen.add(h); names.append(h)
            except OSError:
                continue
        if not names:
            return None
        out = self.outdir / "takeover_candidates.txt"
        out.write_text("\n".join(names) + "\n")
        print(f"[takeover] {len(names)} subdomain candidate(s) from subfinder "
              f"(dangling + NXDOMAIN-enumerated) -> {out.name}")
        return out

    def _scan_pool(self, web_urls_file):
        """The URL pool the intrusive web tools (nuclei/ffuf/feroxbuster/FunnelWeb/
        sns) actually scan. There is exactly ONE source now: WebGet's urls.txt
        (built by host validation, which already expanded CIDR and scope-confirmed
        every host). No fair-game filtering, no fallback pool — `web_urls_file`
        points at urls.txt. Returns the file if it holds real targets, else None
        (the caller prints a clear skip/stop and does not silently substitute
        another pool)."""
        src = Path(web_urls_file)
        return src if _has_real_targets(src) else None

    def _testssl_input(self, tls_endpoints_file, urls_file):
        """Build testssl's endpoint list = (A) UNION (B), deduped on host:port.

        A = the https:// endpoints from WebGet's urls.txt, trimmed to TLS only
            (drop http:// — plaintext has no TLS to test), rewritten as host:port
            (default 443 when no explicit port). Gives testssl WebGet's superior
            FQDN<->IP correlation for the webapp side.
        B = the classifier's TLS group (tls_endpoints.txt): non-web TLS services
            (imaps/pop3s/smtps/ldaps/ftps + standard TLS ports) that WebGet can't
            know about because it's a webapp-only builder. This is the ONE place we
            still read nmap-derived data — non-web TLS ports are the single thing
            WebGet structurally can't produce.

        Returns a written file path, or None if nothing qualifies.
        """
        from urllib.parse import urlparse as _up
        eps, seen = [], set()

        def _add(host, port):
            if not host:
                return
            key = f"{host.lower()}:{port}"
            if key not in seen:
                seen.add(key)
                eps.append(key)

        # A: https endpoints from urls.txt
        up = Path(urls_file) if urls_file else None
        if up and up.is_file():
            for line in up.read_text(errors="replace").splitlines():
                u = line.strip()
                if not u or not u.lower().startswith("https://"):
                    continue  # trim http:// — no TLS to test
                pu = _up(u)
                _add((pu.hostname or "").lower(), pu.port or 443)

        # B: classifier TLS group (non-web TLS ports WebGet can't see). These come
        # from nmap scanning in-scope target IPs, so they are in-scope BY
        # CONSTRUCTION — we do NOT re-guard them by hostname (that would wrongly
        # drop legitimate mail/LDAP/FTP-over-TLS whose PTR name looks off-scope).
        tp = Path(tls_endpoints_file) if tls_endpoints_file else None
        if tp and tp.is_file():
            for line in tp.read_text(errors="replace").splitlines():
                s = line.strip()
                if not s:
                    continue
                host = s.split(":")[0].strip().lower()
                port = s.split(":")[1].strip() if ":" in s else "443"
                _add(host, port)

        if not eps:
            print("[scope] testssl: no in-scope TLS endpoints after WebGet union")
            return None
        out = self.outdir / "testssl_input.txt"
        out.write_text("\n".join(eps) + "\n")
        print(f"[scope] testssl: {len(eps)} TLS endpoint(s) "
              f"(WebGet https + non-web TLS from classifier)")
        return out

    def _scope_filter_urls(self, url_file):
        """Return a NEW file containing only the URLs whose host is in scope
        (per targets.txt / the scope guard). Used so the FULL nuclei template
        pass only ever touches in-scope hosts — the takeover pass uses the
        unfiltered pool. Returns None if nothing in-scope remains."""
        from pathlib import Path as _P
        from urllib.parse import urlparse as _up
        src = _P(url_file)
        if not src.exists():
            return None
        kept = []
        for line in src.read_text(errors="replace").splitlines():
            u = line.strip()
            if not u:
                continue
            host = _up(u).hostname or ""
            if not host:
                continue
            try:
                # check() raises ScopeViolation if the host isn't in scope
                self.guard.check(host)
                kept.append(u)
            except Exception:  # noqa: BLE001 (ScopeViolation -> drop this URL)
                continue
        dropped = len(src.read_text(errors="replace").splitlines()) - len(kept)
        print(f"[nuclei] scope filter for FULL pass: kept {len(kept)} in-scope "
              f"URL(s), dropped {dropped} out-of-scope (takeover pass still "
              f"covered those)")
        if not kept:
            print("[nuclei] no in-scope URLs for the full template pass — "
                  "skipping full pass (takeover pass already ran on the pool)")
            return None
        out = self.outdir / "web_urls_in_scope.txt"
        out.write_text("\n".join(kept) + "\n")
        return out

    def _follow_same_host(self) -> bool:
        """Follow same-host redirects (/ -> /login/)? Interview stash wins; else
        config; else False. Cross-host redirects are never followed regardless."""
        try:
            from .runmode import answer, has_answer
            if has_answer("follow_same_host_redirects"):
                return bool(answer("follow_same_host_redirects", False))
        except Exception:  # noqa: BLE001
            pass
        return getattr(self.cfg, "follow_same_host_redirects", False)

    def _run_stacked_scans(self, targets, state) -> None:
        """Run the extra TCP scan types (ACK/FIN/NULL/Xmas), each behind a gate,
        and merge any open/unfiltered ports they find into the host results."""
        from .tools import _confirm
        cfg = self.cfg
        stack = [
            ("ack", cfg.stack_ack, self.runner.ack_sweep,
             "ACK scan (-sA: map firewall filtering)"),
            ("fin", cfg.stack_fin, self.runner.fin_sweep,
             "FIN scan (-sF: sneak past stateless SYN filters)"),
            ("null", cfg.stack_null, self.runner.null_sweep,
             "NULL scan (-sN: no-flag probe past filters)"),
            ("xmas", cfg.stack_xmas, self.runner.xmas_sweep,
             "Xmas scan (-sX: FIN/PSH/URG probe past filters)"),
        ]
        for tag, enabled, fn, label in stack:
            if not enabled:
                continue
            if not _confirm(f"Run stacked {label}?", self.assume_yes):
                print(f"[stack] {tag} skipped by operator")
                continue
            self.metrics.start(f"nmap-{tag}")
            print(f"[stack] running {label} over {len(targets)} host(s)")
            try:
                xml = fn(targets)
                found = nmap_parser.parse(xml)
                merged = 0
                for h in found:
                    # ACK reports unfiltered (not open); FIN/NULL/Xmas report
                    # open|filtered. Treat any non-closed port as a lead to merge.
                    new_ports = [str(p.portid) for p in h.ports
                                 if p.state in ("open", "open|filtered", "unfiltered")]
                    if not new_ports:
                        continue
                    info = state["results"].setdefault(h.address, {
                        "address": h.address, "hostnames": [],
                        "open_ports": "", "filtered_count": 0})
                    existing = set(filter(None, info.get("open_ports", "").split(",")))
                    before = len(existing)
                    existing.update(new_ports)
                    if len(existing) > before:
                        info["open_ports"] = ",".join(sorted(existing, key=int))
                        merged += len(existing) - before
                        self.metrics.set_status(h.address, "nmap", "ok",
                                                f"{tag} found ports SYN missed")
                if merged:
                    print(f"[stack] {tag}: merged {merged} port(s) SYN missed")
                else:
                    print(f"[stack] {tag}: no new ports beyond SYN")
            except Exception as e:  # noqa: BLE001
                print(f"[stack] {tag} error: {e}")
            self.metrics.stop(f"nmap-{tag}")
        self._save_state(state)

    def _save_state(self, state: dict) -> None:
        self.state_file.write_text(json.dumps(state, indent=2, default=str))

    def _load_state(self) -> dict:
        if self.state_file.exists():
            return json.loads(self.state_file.read_text())
        return {"phase1_done": False, "deep_done": [], "results": {}, "completed": False}

    def _fresh_start_if_completed(self) -> None:
        """If the previous run in this output dir COMPLETED (no resume point),
        archive it with a timestamp and start clean — so a new run never
        replays old results. A previous run that did NOT complete is left in
        place so it can resume."""
        if not self.state_file.exists():
            return
        try:
            prev = json.loads(self.state_file.read_text())
        except (json.JSONDecodeError, OSError):
            return
        if prev.get("completed"):
            import datetime
            stamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            archived = self.outdir.parent / f"{self.outdir.name}_archived_{stamp}"
            self.outdir.rename(archived)
            self.outdir.mkdir(parents=True, exist_ok=True)
            self.runner.outdir = self.outdir
            print(f"[i] previous run was complete — archived to {archived.name}, "
                  f"starting fresh")

    def _reconcile_and_augment_web_pool(self, paths: dict, groups: dict) -> None:
        """Honeypot skip + Nessus port reconciliation + evidence-driven web pool.

        1. Flag hosts with > threshold Nessus '?' ports as likely honeypots and
           record them (they're excluded from the Nessus web-evidence + noted).
        2. Reconcile: for non-honeypot hosts, find Nessus-open ports nmap missed
           and directed-rescan them (-sT -Pn -sV -vi7, twice). Never drop a
           Nessus port — keep it flagged if unconfirmed.
        3. Augment the web pool ADD-ONLY: append in-scope web ports reported by
           Nessus + the scope onto WebGet's urls.txt (never rewriting or dropping
           WebGet's validated URLs). Gated on _web_pool_ok — if WebGet produced no
           pool, this returns without touching anything (no back-door fallback).
        """
        from . import reconcile as R
        # Nessus data lives in _nessus_rich ({ip: host_dict}); that's what the
        # reconciliation, honeypot detection, and web-evidence read.
        nessus_hosts = getattr(self, "_nessus_rich", None) or {}

        # 1. honeypots
        honeypots = R.honeypot_report(nessus_hosts)
        if honeypots:
            self._honeypot_ips = set(honeypots)
            for ip, n in honeypots.items():
                # Item 7: DETECT + RECORD but do NOT exclude — the host gets the
                # full battery; it's tagged likely-filtered in the report so the
                # analyst can strike it from the deliverable.
                print(f"[honeypot] {ip}: {n} uncertain (?) ports — likely "
                      f"honeypot/tarpit. Full scan proceeds; tagged in report.")
            # persist for the report
            (self.outdir / "honeypots.txt").write_text(
                "\n".join(f"{ip}\t{n} uncertain ports" for ip, n in honeypots.items()) + "\n")
        else:
            self._honeypot_ips = set()

        # 2. reconciliation — directed re-probe of Nessus ports nmap missed
        if getattr(self.cfg, "reconcile_nessus_ports", True) and not self.dry_run:
            self._reconcile_missed_ports(nessus_hosts, groups)

        # 3. evidence-driven web pool augmentation (ADD-ONLY, onto WebGet's pool).
        # Only ever ENRICHES a pool WebGet actually produced. If WebGet produced
        # nothing (web_pool_ok is False, [STOP] already printed), do NOT let Nessus/
        # scope evidence silently repopulate urls.txt — that would be a back-door
        # fallback and contradict the one-source rule. Honeypot detection + Nessus
        # port reconciliation above still ran; only the pool write is gated.
        if not getattr(self, "_web_pool_ok", False):
            return
        web_file = paths.get("web_urls") if isinstance(paths, dict) else None
        if not web_file:
            return
        wf = Path(web_file)
        existing = []
        if wf.is_file():
            existing = [l.strip() for l in wf.read_text(errors="replace").splitlines()
                        if l.strip()]
        sources = {"nmap": [], "nessus": [], "scope": []}
        # nmap's already-built URLs pass through as-is
        sources["nmap"] = existing
        # Nessus web ports — Item 7: honeypots are NO LONGER excluded (full scan);
        # _honeypot_ips is retained only for the report's likely-filtered tag.
        sources["nessus"] = R.web_entries_from_nessus(nessus_hosts, set())
        # scope: in-scope correlate domains as bare hosts (http+https only if a
        # source elsewhere reports them; here we add them so a live check keeps
        # the real ones — but ONLY standard web ports, evidence still required via
        # the httpx liveness filter downstream)
        # (We do NOT invent ports; Nessus/nmap evidence drives inclusion.)
        pool = R.build_web_pool(sources)
        # scope-filter the union so we never add an out-of-scope host
        kept = []
        for u in pool:
            from urllib.parse import urlparse as _up
            host = _up(u).hostname or ""
            if not host:
                continue
            try:
                self.guard.check(host)
                kept.append(u)
            except Exception:  # noqa: BLE001
                continue
        added = [u for u in kept if u not in set(existing)]
        # urls.txt is WebGet's validated output — the SINGLE web pool. This
        # augmentation is STRICTLY ADD-ONLY: WebGet already scope-confirmed every
        # URL in `existing`, and re-running guard.check() here would drop IP-based /
        # FQDN hosts the guard doesn't recognize and OVERWRITE urls.txt with a tiny
        # subset (observed: 9 validated URLs collapsing to 1). So we preserve every
        # existing line and only append the net-new Nessus/scope evidence URLs.
        if added:
            merged = existing + [u for u in added if u not in set(existing)]
            wf.write_text("\n".join(merged) + "\n")
            print(f"[web-pool] evidence-driven augmentation (add-only): "
                  f"+{len(added)} URL(s) from Nessus/scope "
                  f"(total {len(merged)}, WebGet's {len(existing)} preserved)")
        else:
            print(f"[web-pool] no net-new evidence URLs; WebGet's "
                  f"{len(existing)} validated URL(s) unchanged")

    def _reconcile_missed_ports(self, nessus_hosts: dict, groups: dict) -> None:
        """Directed re-probe of Nessus-known ports nmap missed, for non-honeypot
        hosts. Tries twice; never drops a Nessus port."""
        from . import reconcile as R
        import subprocess
        from . import resources
        # what nmap confirmed per IP (from scan results / groups)
        nmap_ports_by_ip = self._nmap_confirmed_ports_by_ip()
        for ip, host in (nessus_hosts or {}).items():
            if ip in getattr(self, "_honeypot_ips", set()):
                continue
            nports = R.nessus_open_ports(host)
            if not nports:
                continue
            missed = R.ports_nmap_missed(nports, nmap_ports_by_ip.get(ip, set()))
            if not missed:
                continue
            print(f"[reconcile] {ip}: Nessus reported {len(missed)} port(s) nmap "
                  f"missed {missed} — directed re-probe (2 tries)")
            confirmed = set()
            for attempt in (1, 2):
                cmd = R.build_directed_scan_cmd(
                    ip, missed, self.outdir,
                    version_intensity=getattr(self.cfg, "reconcile_version_intensity", 7))
                with open(self.runner.command_log, "a") as log:
                    log.write(" ".join(cmd) + f"   # reconcile attempt {attempt}\n")
                try:
                    proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL,
                                            stderr=subprocess.DEVNULL,
                                            **resources.popen_kwargs())
                    try:
                        proc.wait(timeout=getattr(self.cfg, "reconcile_timeout", 700))
                    finally:
                        if proc.poll() is None:
                            resources.kill_tree(proc)
                    confirmed = self._parse_reconcile_confirmed(ip)
                    if confirmed.issuperset(set(missed)):
                        break   # all confirmed, no need for a 2nd try
                except Exception as e:  # noqa: BLE001
                    print(f"[reconcile] {ip} attempt {attempt} error: {e}")
            still_unconfirmed = [p for p in missed if p not in confirmed]
            # NEVER DROP: record every Nessus port, flagged by confirmation status
            self._nessus_reconciled.setdefault(ip, {})
            for p in missed:
                self._nessus_reconciled[ip][p] = (
                    "nmap-confirmed" if p in confirmed
                    else "Nessus-confirmed, nmap-unverified")
            if still_unconfirmed:
                print(f"[reconcile] {ip}: {len(still_unconfirmed)} port(s) still "
                      f"unconfirmed after 2 tries {still_unconfirmed} — kept, "
                      f"flagged 'Nessus-confirmed, nmap-unverified'")
                # Note: these Nessus-found-but-nmap-unconfirmed web ports still reach
                # the scanners via the add-only augmentation in
                # _reconcile_and_augment_web_pool (which merges Nessus web ports into
                # WebGet's urls.txt), so no separate routing list is needed here.

    def _nmap_confirmed_ports_by_ip(self) -> dict:
        """Map ip -> set(open ports) that nmap confirmed. Results store open ports
        as a CSV string in 'open_ports' (e.g. '80,443'); some entries may also
        carry a 'ports' list. Handle both."""
        out = {}
        try:
            results = getattr(self, "_last_results", None) or {}
            for addr, data in results.items():
                ports = set()
                # CSV string form: open_ports = "80,443,8080"
                csv = (data.get("open_ports") or "") if isinstance(data, dict) else ""
                for tok in str(csv).split(","):
                    tok = tok.strip()
                    if tok.isdigit():
                        ports.add(int(tok))
                # list form: ports = [{"port": 80}, ...]
                for p in (data.get("ports") or []) if isinstance(data, dict) else []:
                    try:
                        ports.add(int(p.get("port")))
                    except (TypeError, ValueError, AttributeError):
                        continue
                if ports:
                    out[addr] = ports
        except Exception:  # noqa: BLE001
            pass
        return out

    def _parse_reconcile_confirmed(self, ip: str) -> set:
        """Parse the reconcile_<ip>.xml to see which ports nmap confirmed open."""
        import defusedxml.ElementTree as ET
        safe = ip.replace(":", "_").replace("/", "_")
        xml = self.outdir / f"reconcile_{safe}.xml"
        confirmed = set()
        if not xml.is_file():
            return confirmed
        try:
            root = ET.parse(xml).getroot()
            for port in root.iter("port"):
                state = port.find("state")
                if state is not None and state.get("state") == "open":
                    try:
                        confirmed.add(int(port.get("portid")))
                    except (TypeError, ValueError):
                        continue
        except Exception:  # noqa: BLE001
            pass
        return confirmed

    def _run_full_discovery(self) -> None:
        """Full subdomain discovery in phase 0, BEFORE the web tools, so the
        scanners see discovered subdomains. Runs enum -> takeover -> mutations ->
        FQDN resolution for each correlate domain. Writes audit completion markers
        so the recon engine skips the duplicate. Scope-safe: discovery never
        expands the scan target set (targets.txt is untouched)."""
        from . import audit
        cfg = self.cfg
        cl = self.runner.command_log
        resolvers = getattr(cfg, "resolvers_file", "") or "resolvers.txt"
        for domain in self.correlate_domains:
            try:
                if getattr(cfg, "run_subdomains", True):
                    from . import subdomains
                    print(f"[discovery] subdomain enum: {domain}")
                    audit.log_action(cl, "subdomains", f"subfinder|shuffledns|dnsx -d {domain}")
                    subdomains.process_domain(domain, self.outdir, cl,
                                              resolvers=resolvers, dry_run=False)
                    audit.mark_complete(self.outdir, "subdomains", domain)

                if getattr(cfg, "run_takeover", True):
                    from . import takeover
                    print(f"[discovery] subdomain takeover: {domain}")
                    audit.log_action(cl, "takeover", f"nuclei -tags takeover (master list) {domain}")
                    takeover.run_takeover(self.outdir, cl,
                                          rate_limit=getattr(cfg, "nuclei_rate_limit", 3),
                                          proxy="", dry_run=False)
                    audit.mark_complete(self.outdir, "takeover", domain)

                if getattr(cfg, "run_submutate", True):
                    from . import submutate
                    print(f"[discovery] subdomain mutations: {domain}")
                    audit.log_action(cl, "submutate", f"mutation resolve {domain}")
                    submutate.process_domain(
                        domain, self.outdir, cl, resolvers=resolvers,
                        max_words=getattr(cfg, "submutate_max_words", 40),
                        max_candidates=getattr(cfg, "submutate_max_candidates", 5000),
                        proxy="", dry_run=False)
                    audit.mark_complete(self.outdir, "submutate", domain)

                # D1: fqdn_resolve on the SCAN path is off by default now — WebGet
                # owns FQDN<->IP for scanning + the report. The recon engine still
                # runs its own fqdn_resolve. Both the legacy run_fqdn_resolve flag
                # AND the new scan-path gate must be on to run it here.
                if (getattr(cfg, "fqdn_resolve_on_scan_path", False)
                        and getattr(cfg, "run_fqdn_resolve", True)):
                    try:
                        from . import fqdn_resolve as fr
                        print(f"[discovery] FQDN<->IP resolution: {domain}")
                        audit.log_action(cl, "fqdn_resolve", f"2-of-3 confirm pairs {domain}")
                        dnsx_pairs = fr.gather_dnsx_pairs(self.outdir)
                        if dnsx_pairs:
                            nessus_hosts = getattr(self, "_nessus_hosts", None)
                            nessus_pairs = fr.gather_nessus_pairs(nessus_hosts) if nessus_hosts else {}
                            fwd = lambda f: _dig_ipv4(f, cl)
                            rev = lambda ip: _dig_reverse(ip, cl)
                            result = fr.resolve_pairs(dnsx_pairs, nessus_pairs, fwd, rev)
                            outp = fr.write_pairs_json(result, self.outdir)
                            print(f"[fqdn] {domain}: {len(result.confirmed_1to1)} confirmed 1:1, "
                                  f"{len(result.confirmed_multi)} multi, "
                                  f"{len(result.unconfirmed)} unconfirmed -> {outp.name}")
                        audit.mark_complete(self.outdir, "fqdn_resolve", domain)
                    except Exception as e:  # noqa: BLE001
                        print(f"[discovery] fqdn resolution skipped: {e}")
            except Exception as e:  # noqa: BLE001
                print(f"[discovery] {domain}: step failed — {e}")

    def _run_host_validation(self) -> None:
        """Bridge step (webget/reconx): correlate targets.txt + discovered
        subdomains into urls.txt (the webapp-scanner pool) and 403.txt (the
        nomore403 seed). Runs AFTER subdomain discovery, BEFORE the web fuzzers.

        Scope-safe: the tool's own IP spine is targets.txt, so it can never widen
        scope past it. Graceful + resumable: a missing/empty subdomain list warns
        and degrades to IP-only; an existing completion marker skips the re-run.
        On success the emitted urls.txt/403.txt paths are stashed on self for the
        fuzzer + nomore403 wiring to pick up. urls.txt is the SINGLE web pool: if it
        stays None/empty, there is no fallback — run() prints a [STOP] notice and the
        web-fuzz phase is skipped.
        """
        cfg = self.cfg
        if not getattr(cfg, "hostval_enabled", True):
            return
        if self.dry_run:
            return
        from . import audit
        urls = self.outdir / getattr(cfg, "hostval_urls_file", "urls.txt")
        forb = self.outdir / getattr(cfg, "hostval_403_file", "403.txt")
        # Reuse a prior run's output ONLY if urls.txt actually holds targets. A
        # completion marker with an empty/missing urls.txt (e.g. a pre-pass that
        # produced nothing, or output that got archived) must NOT be trusted —
        # urls.txt is the sole web pool, so we re-run to rebuild it rather than
        # sail on with an empty pool.
        if audit.is_complete(self.outdir, "host_validation") and _has_real_targets(urls):
            self._hostval_urls = urls
            if forb.exists():
                self._hostval_403 = forb
            n = sum(1 for l in urls.read_text(errors="replace").splitlines() if l.strip())
            print(f"[host_validation] already complete — reusing {n} URL(s) from "
                  f"{urls.name}")
            return

        # Gather subfinder's raw per-domain name lists (bare hostnames, exactly
        # what `subfinder -silent` prints — parse_subs handles these natively).
        sf_files = sorted(self.outdir.glob("subdomains_*.subfinder.txt"))
        combined_subs = None
        if sf_files:
            combined_subs = self.outdir / "hostval_subdomains.txt"
            seen, lines = set(), []
            for p in sf_files:
                try:
                    for ln in p.read_text(errors="replace").splitlines():
                        s = ln.strip()
                        if s and s not in seen:
                            seen.add(s)
                            lines.append(s)
                except OSError:
                    continue
            combined_subs.write_text("\n".join(lines) + ("\n" if lines else ""))
            print(f"[host_validation] {len(lines)} discovered name(s) from "
                  f"{len(sf_files)} subfinder file(s)")
        else:
            print("[host_validation] no subfinder output found; "
                  "correlating targets.txt by IP only (scope unchanged)")

        try:
            from .host_validation import run_host_validation
            audit.log_action(self.runner.command_log, "host_validation",
                             "correlate targets+subdomains -> urls.txt/403.txt")
            result = run_host_validation(
                cfg.targets_file, combined_subs, self.outdir,
                resolve=True,
                no_probe=getattr(cfg, "hostval_no_probe", False),
                httpx_bin=getattr(cfg, "httpx_bin", None),
                jobs=getattr(cfg, "hostval_jobs", 5),
                ports=(getattr(cfg, "hostval_ports", "") or None),
                timeout=getattr(cfg, "hostval_timeout", 10),
            )
        except Exception as e:  # noqa: BLE001
            print(f"[host_validation] skipped ({e}); no web pool produced — the "
                  f"web-fuzz phase will be skipped (no fallback pool)")
            return

        if result.get("ok"):
            urls_p = Path(result["urls"])
            forb_p = Path(result["forbidden"])
            self._hostval_urls = urls_p if urls_p.exists() else None
            self._hostval_403 = forb_p if forb_p.exists() else None
            audit.mark_complete(self.outdir, "host_validation")
            nu = (len(urls_p.read_text(errors="replace").splitlines())
                  if self._hostval_urls else 0)
            print(f"[host_validation] complete — urls.txt has {nu} URL(s) "
                  f"for the webapp scanners")
        else:
            print("[host_validation] produced no scan-worthy output; no web pool — "
                  "the web-fuzz phase will be skipped (no fallback pool)")

    def _load_nessus_enrichment(self) -> None:
        """Parse the seeded Nessus file(s) into self._nessus_rich + self._force_validate
        and write the exploitability summary. Runs on EVERY invocation (fresh AND
        resume) so the web-pool reconciliation, testssl force-validate, Nessus-SSH feed,
        and report always have Nessus data — a resumed run (phase 1 already complete)
        must not silently lose it. No-op when no .nessus was seeded or on a dry run."""
        self._nessus_rich = {}
        self._force_validate = {}   # ip -> {(proto,port): {validators}}
        if not (self.nessus_files and not self.dry_run):
            return
        from . import nessus_import
        self._nessus_rich = nessus_import.load_multi(self.nessus_files)
        from .validation_map import validators_for_host
        for ip, h in self._nessus_rich.items():
            vmap = validators_for_host(h)
            if vmap:
                self._force_validate[ip] = vmap
        if self._force_validate:
            n = sum(len(v) for v in self._force_validate.values())
            print(f"[validate] {n} Nessus finding-port(s) flagged for "
                  f"independent validation (testssl/ssh-audit/nuclei)")
        # EXPLOITABILITY SUMMARY — surface Nessus findings that have a public exploit
        # (exploit_available / Metasploit): high-signal for prioritization and a direct
        # feed for the Cache PoC lookup. Written to a file the workbook picks up. Uses
        # the expanded parser fields (all optional), so it's empty if Nessus didn't emit.
        try:
            exploitable = []
            for ip, h in self._nessus_rich.items():
                for (proto, port), pd in (h.get("ports") or {}).items():
                    if pd.get("exploit_available") or pd.get("metasploit"):
                        ms = "; ".join(pd.get("metasploit") or []) or "-"
                        fw = "; ".join(pd.get("exploit_frameworks") or []) or "-"
                        cves = "; ".join(pd.get("cves") or []) or "-"
                        ease = pd.get("exploit_ease") or "-"
                        cred = "credentialed" if pd.get("credentialed") else "remote"
                        exploitable.append(
                            f"{ip}\t{proto.upper()}/{port}\t{ease}\t"
                            f"frameworks={fw}\tmetasploit={ms}\tCVEs={cves}\t{cred}")
            if exploitable:
                outp = self.outdir / "nessus_exploitable.txt"
                header = ("# Nessus findings with a PUBLIC EXPLOIT available\n"
                          "# IP\tPROTO/PORT\tEASE\tFRAMEWORKS\tMETASPLOIT\tCVEs\tDETECTION\n")
                outp.write_text(header + "\n".join(exploitable) + "\n")
                print(f"[nessus] {len(exploitable)} finding(s) with a public "
                      f"exploit -> {outp.name} (prioritize these)")
        except Exception as e:  # noqa: BLE001
            print(f"[nessus] exploitability summary skipped: {e}")

    def _isolate(self, label: str, fn, *args, **kwargs):
        """Run ONE phase-0 tool so its failure can NEVER abort the rest of the pipe.
        The phase-0 web tools run in sequence; without this, one tool raising an
        exception skipped EVERY tool after it (the "pipe only runs half the tools"
        bug) — and forced a full, API-credit-burning re-run to recover. This mirrors
        the recon engine's per-tool containment (_dispatch): log the failure loudly,
        then continue with the next tool. KeyboardInterrupt still propagates so the
        interrupt/skip menu keeps working. Returns fn's result, or None on error."""
        try:
            return fn(*args, **kwargs)
        except KeyboardInterrupt:
            raise
        except Exception as e:  # noqa: BLE001
            import os as _os
            import traceback as _tb
            print(f"[{label}] ERROR — {type(e).__name__}: {e}. Skipping ONLY this "
                  f"tool and CONTINUING with the rest of the scan (no other tool is "
                  f"affected).")
            if _os.environ.get("NIGREDO_DEBUG"):
                _tb.print_exc()
            return None

    def run(self) -> dict:
        targets = _load_lines(self.cfg.targets_file)

        # If targets.txt is empty, fall back to scanning everything authorized
        # in scope.txt (the common case where scope == targets). This expands
        # single IPs and CIDR ranges into concrete hosts.
        if not targets:
            try:
                targets = self.guard.scannable_targets()
            except ValueError as e:
                raise ScopeViolation(str(e))
            if targets:
                print(f"[scope] targets.txt empty -> scanning {len(targets)} "
                      f"host(s) expanded from scope.txt")

        # Hard stop: never launch nmap with no target. If we still have nothing,
        # tell the operator exactly what to fix instead of silently scanning air.
        if not targets:
            raise ScopeViolation(
                "No targets to scan. targets.txt is empty (or all comments) and "
                "scope.txt has no expandable hosts (only wildcards, or empty). "
                "Add an IP/CIDR/hostname to targets.txt, or a concrete IP/CIDR to scope.txt.")

        # --- Root check: -sS and the stealth scans (-sA/-sF/-sN/-sX) plus -O
        # all REQUIRE root. Without it nmap silently falls back to -sT (connect
        # scan) and the stealth scans fail entirely — a silent cause of missed
        # ports. Warn loudly so it's never the hidden reason for thin results.
        import os as _os
        if not self.dry_run and hasattr(_os, "geteuid") and _os.geteuid() != 0:
            print("\n" + "!" * 60)
            print("  WARNING: not running as root.")
            print("  -sS (SYN) and the stealth scans (-sA/-sF/-sN/-sX) and -O")
            print("  need root. Without it nmap falls back to a connect scan and")
            print("  the stealth scans WON'T WORK — you'll miss ports.")
            print("  Re-run with:  sudo python run.py engagement")
            print("!" * 60 + "\n")

        # --- Scope enforcement: validate everything before any scan ---
        # Raises ScopeViolation and halts if any target is unauthorized.
        self.guard.filter_targets(targets)
        print(f"[scope] {len(targets)} targets validated against allowlist")

        # run metrics: track timing + per-host-per-tool status through the run.
        # outdir is passed so start/stop write a live phase0_state.json the campaign
        # dashboard reads (phase-0 progress bar).
        from .metrics import RunMetrics
        metrics = RunMetrics(self.outdir)
        self.metrics = metrics
        for t in targets:
            metrics.ensure_host(t)

        # If the previous run in this folder finished cleanly, archive it and
        # start fresh so we don't replay stale output. THIS MUST RUN BEFORE the
        # correlation/discovery block below — otherwise the discovery output we're
        # about to write gets archived away with the old folder, and the web tools
        # see an empty folder (the "detected less than before" bug).
        self._fresh_start_if_completed()

        # --- Early subdomain correlation (scope-safe, never expands scope) ---
        # NOTE: correlate_domains is intentionally EMPTY on the normal run path
        # (see __main__: preflight recon domains are firewalled off the scan engine),
        # so this block does not run for typed recon domains — it only resolves/
        # correlates when the caller explicitly hands the scan engine domains, which
        # the preflight flow never does. This prevents a recon domain from being
        # resolved to an IP and pulled into the scan/fuzz pool.
        if self.correlate_domains and not self.dry_run:
            try:
                from . import subdomains as _sub
                # target IPs are the concrete IPs in the scan list
                target_ips = {t for t in targets if _looks_like_ip(t)}
                print(f"[subdomains] correlating {len(self.correlate_domains)} "
                      f"domain(s) against {len(target_ips)} target IP(s) "
                      f"(scope-safe, no expansion)")
                enrichment, _inv = _sub.run_phase0_correlation(
                    self.correlate_domains, target_ips, self.outdir,
                    self.runner.command_log,
                    resolvers_file=getattr(self.cfg, "resolvers_file", ""),
                    dry_run=self.dry_run)
                self._subdomain_enrichment = enrichment
            except Exception as e:  # noqa: BLE001
                print(f"[subdomains] correlation skipped: {e}")

            # DISCOVERY-BEFORE-SCAN (reorder): run the FULL discovery chain now —
            # subdomain enum, takeover, mutations, FQDN<->IP resolution — so the
            # web tools below (httpx/katana/nuclei/ffuf/feroxbuster) scan the
            # DISCOVERED subdomains, not just targets.txt. Phase 0 already has the
            # subdomains module + resolvers_file, so this is an expansion of the
            # correlation call above, not a new subsystem. The recon engine detects
            # these ran (completion markers / output) and skips the duplicate.
            if getattr(self.cfg, "discovery_before_scan", True):
                self._run_full_discovery()

        # HOST VALIDATION (webget) — the SINGLE source of the web-tool pool.
        # Runs on EVERY scan (NOT gated behind correlate_domains), so urls.txt is
        # (re)built in-process from targets.txt + any discovered subdomains on disk,
        # rather than depending on a separate pre-pass that may not have run (or
        # whose output _fresh_start_if_completed archived out from under it — the
        # old "first run, every client, web tools skip" bug). Scope-safe: targets.txt
        # is the spine and host_validation.read_ips() expands CIDR to individual IPs.
        # There is NO fallback pool — if this yields nothing, the web-fuzz phase is
        # skipped with a loud, explicit reason (see the override guard below).
        if not self.dry_run:
            self._run_host_validation()

        state = self._load_state()

        # Nessus enrichment loads on EVERY invocation (fresh AND resume). Previously
        # it lived inside the phase-1 block, so a resumed run (phase1_done already set)
        # silently lost _nessus_rich/_force_validate — and with them the web-pool
        # reconciliation, testssl force-validate, Nessus-SSH feed, and report data.
        self._load_nessus_enrichment()

        # --- Phase 1: sweep (or seed from a Nessus export, skipping nmap) ---
        if not state["phase1_done"]:
            # nmap ALWAYS runs (baseline discovery + validation). Nessus enrichment
            # was already parsed by _load_nessus_enrichment() above (into
            # self._nessus_rich / self._force_validate); here we UNION-merge those
            # Nessus ports/hosts into the nmap results — the discovery layer is the
            # two tools together.
            from . import nessus_import   # for the Nessus union-merge below
            print(f"[scan:sweep] nmap SYN sweep over {len(targets)} hosts")
            self.metrics.start("nmap")
            xml = self.runner.sweep(targets)
            if not self.dry_run:
                hosts = nmap_parser.parse(xml)
                for h in hosts:
                    state["results"][h.address] = {
                        "address": h.address,
                        "hostnames": h.hostnames,
                        "open_ports": h.open_port_spec(),
                        "filtered_count": len(h.filtered_ports),
                    }
                # union-merge Nessus ports/hosts into the results
                if self._nessus_rich:
                    merged_hosts = merged_ports = 0
                    ness_targets = nessus_import.to_target_dict(self._nessus_rich)
                    for ip, ninfo in ness_targets.items():
                        if ip not in state["results"]:
                            state["results"][ip] = {
                                "address": ip, "hostnames": ninfo["hostnames"],
                                "open_ports": "", "filtered_count": 0}
                            merged_hosts += 1
                        existing = set(filter(None,
                            state["results"][ip]["open_ports"].split(",")))
                        before = len(existing)
                        existing.update(ninfo["open_ports"].split(","))
                        if len(existing) > before:
                            merged_ports += len(existing) - before
                        state["results"][ip]["open_ports"] = ",".join(
                            sorted(existing, key=lambda x: int(x) if x.isdigit() else 0))
                        # keep FQDNs from Nessus even on shared IPs
                        for fq in ninfo["hostnames"]:
                            if fq and fq not in state["results"][ip]["hostnames"]:
                                state["results"][ip]["hostnames"].append(fq)
                    print(f"[nessus] merged {merged_hosts} new host(s) and "
                          f"{merged_ports} new port(s) into the target list")
                for t in targets:
                    if not _looks_like_ip(t) and "/" in t:
                        continue
                    info = state["results"].get(t)
                    if info is None or not info.get("open_ports"):
                        self.metrics.mark_dead_on_arrival(t)
                    else:
                        self.metrics.set_status(t, "nmap", "ok",
                                                f"{info.get('open_ports','')}")
            self.metrics.stop("nmap")
            state["phase1_done"] = True
            self._save_state(state)

            if not self.dry_run:
                self._run_stacked_scans(targets, state)

        # --- Shodan passive enrichment (InternetDB free + optional host lookup)
        # Runs after nmap so we can cross-reference passive vs active. Scope-safe:
        # only the validated target IPs. Passive: no packets to the target.
        if getattr(self.cfg, "run_shodan", True):
            try:
                from . import shodan_tool
                self.metrics.start("shodan")
                ip_targets = [t for t in targets if shodan_tool._looks_like_ip(t)]
                self._shodan_hosts = shodan_tool.enrich(
                    ip_targets, self.outdir, self.runner.command_log,
                    use_host_lookup=getattr(self.cfg, "shodan_use_host_lookup", False),
                    api_key=getattr(self.cfg, "shodan_api_key", ""),
                    host_lookup_cap=getattr(self.cfg, "shodan_host_lookup_cap", 50),
                    ledger=self.ledger, dry_run=self.dry_run)
                self.metrics.stop("shodan")
                # --- on-demand ACTIVE scan (opt-in): submit now, collect at end ---
                # Submit the nmap/Nessus-discovered in-scope IPs for a fresh Shodan
                # scan. Async — results collected in the final stage. Only if the
                # user opted in during setup AND a key is present. Never blocks.
                if getattr(self.cfg, "shodan_ondemand_scan", False):
                    api_key = getattr(self.cfg, "shodan_api_key", "")
                    if api_key and ip_targets:
                        try:
                            shodan_tool.submit_ondemand_scan(
                                ip_targets, api_key, self.outdir,
                                self.runner.command_log)
                        except Exception as e:  # noqa: BLE001
                            print(f"[shodan] on-demand scan submit skipped: {e}")
            except Exception as e:  # noqa: BLE001
                print(f"[shodan] enrichment skipped: {e}")

        # --- Phase 2: deep scan on discovered open ports ---
        for addr, info in state["results"].items():
            if addr in state["deep_done"]:
                continue
            port_spec = info.get("open_ports", "")
            if not port_spec:
                if self.cfg.treat_no_open_as_dead:
                    print(f"[scan:deep] {addr}: no open ports, skipping")
                    state["deep_done"].append(addr)
                    self._save_state(state)
                    continue
            else:
                print(f"[scan:deep] {addr}: deep scan on {port_spec}")
                xml = self.runner.deep(addr, port_spec)
                if not self.dry_run:
                    deep_hosts = nmap_parser.parse(xml)
                    if deep_hosts:
                        info["services"] = [
                            {
                                "port": p.portid,
                                "protocol": p.protocol,
                                "service": p.service,
                                "product": p.product,
                                "version": p.version,
                                "extrainfo": p.extrainfo,
                                "ostype": p.ostype,
                                "cpe": p.cpe,
                                "tunnel": p.tunnel,
                                "method": p.method,
                                "conf": p.conf,
                                "hostname": p.hostname,
                                "devicetype": p.devicetype,
                                "scripts": p.scripts,
                            }
                            for p in deep_hosts[0].open_ports
                        ]
                        info["os_matches"] = deep_hosts[0].os_matches
                        info["os_accuracy"] = deep_hosts[0].os_accuracy
                        info["os_classes"] = [
                            {
                                "vendor": oc.vendor,
                                "osfamily": oc.osfamily,
                                "osgen": oc.osgen,
                                "type": oc.type,
                                "accuracy": oc.accuracy,
                            }
                            for oc in deep_hosts[0].os_classes
                        ]
                        info["distance"] = deep_hosts[0].distance
                        info["uptime_seconds"] = deep_hosts[0].uptime_seconds

            # --- Optional ACK phase ---
            if (self.cfg.ack_phase_enabled
                    and info.get("filtered_count", 0) >= self.cfg.ack_filtered_threshold
                    and port_spec):
                print(f"[scan:ack] {addr}: ACK firewall fingerprint")
                self.runner.ack(addr, port_spec)

            state["deep_done"].append(addr)
            self._save_state(state)

        # --- Classification ---
        endpoints = classifier.classify_results(state["results"])
        groups = classifier.group_by_class(endpoints)
        # stash results so the Nessus reconciliation can see what nmap confirmed
        self._last_results = state["results"]
        print(f"[classify] web={len(groups['web'])} tls={len(groups['tls'])} "
              f"auth_surface={len(groups['auth_surface'])} other={len(groups['other'])}")

        # --- Web probe: protocol confirmation + curl status pass ---
        web_probes = []
        seen = set()
        for ep in groups["web"]:
            key = (ep.host, ep.port)
            if key in seen:
                continue
            seen.add(key)
            pr = probe_endpoint(ep.host, ep.port,
                                timeout=self.cfg.probe_connect_timeout,
                                max_time=self.cfg.probe_max_time,
                                command_log=self.runner.command_log,
                                dry_run=self.dry_run,
                                proxy=self._fwd_proxy(),
                                follow_same_host=self._follow_same_host())
            web_probes.append(pr)
            if not self.dry_run:
                if pr.is_redirect:
                    dest = pr.redirect_location or "(no Location header)"
                    # http->https same-host upgrade is the only skipped origin
                    loc = dest.strip().lower()
                    upgrade = (pr.scheme == "http" and loc.startswith("https")
                               and pr.host.lower() in loc)
                    note = ("origin skipped, https form scanned" if upgrade
                            else "origin scanned, destination NOT followed")
                    print(f"[probe] {ep.host}:{ep.port} -> {pr.scheme} {pr.status} "
                          f"REDIRECT -> {dest}  ({note})")
                else:
                    tag = pr.status if pr.status is not None else pr.error
                    print(f"[probe] {ep.host}:{ep.port} -> {pr.scheme or '-'} {tag}")

        # --- Dual-target: also probe the FQDN form of each in-scope host ---
        # For every hostname that enrichment matched to a target IP, re-verify
        # via dig that the FQDN STILL resolves to an in-scope target IP (scope
        # safety at scan time), then probe the FQDN form on the same open ports
        # and add live ones so tools scan BOTH the IP and the FQDN. Vulns often
        # live on the IP; vhost/SNI-dependent apps answer only on the FQDN.
        if self._subdomain_enrichment and not self.dry_run:
            target_ip_set = {t for t in targets if _looks_like_ip(t)}
            # ports that were probed per IP (host -> [ports])
            ip_ports: dict[str, list[int]] = {}
            for pr in list(web_probes):
                ip_ports.setdefault(pr.host, []).append(pr.port)
            added = 0
            # anti-overload: never scan the same (FQDN, IP, port) combination
            # twice. Distinct pairs (same FQDN diff IP, or same IP diff FQDN)
            # each still get scanned — only exact (FQDN,IP,port) dupes collapse.
            scanned_tuples: set = set()
            for ip, hostnames in self._subdomain_enrichment.items():
                ports = ip_ports.get(ip, [])
                if not ports:
                    continue
                for fqdn in hostnames:
                    # SCOPE GATE: dig the FQDN; only proceed if it resolves to an
                    # in-scope target IP. Otherwise record-only, never scan.
                    resolved = _dig_ipv4(fqdn, self.runner.command_log)
                    if not any(rip in target_ip_set for rip in resolved):
                        print(f"[dual] {fqdn} -> {resolved or 'no A'} not in target "
                              f"scope, NOT scanned (recorded only)")
                        continue
                    for port in ports:
                        # the exact pair that would be scanned: (fqdn, ip, port)
                        tup = (fqdn.lower(), ip, port)
                        if tup in scanned_tuples:
                            print(f"[dual] = {fqdn}:{port} on {ip} already queued, "
                                  f"skipping duplicate (anti-overload)")
                            continue
                        scanned_tuples.add(tup)
                        pr = probe_endpoint(fqdn, port,
                                            timeout=self.cfg.probe_connect_timeout,
                                            max_time=self.cfg.probe_max_time,
                                            command_log=self.runner.command_log,
                                            dry_run=self.dry_run,
                                            proxy=self._fwd_proxy(),
                                            follow_same_host=self._follow_same_host())
                        # liveness poke: keep forms that answered and are not
                        # redirects — EXCEPT same-host redirects we followed (those
                        # were promoted to their in-scope landing page, so keep).
                        if pr.scheme and pr.status is not None and (
                                not pr.is_redirect or pr.same_host_redirect):
                            web_probes.append(pr)
                            added += 1
                            print(f"[dual] + {fqdn}:{port} -> {pr.scheme} "
                                  f"{pr.status} (in-scope FQDN, added)")
            if added:
                print(f"[dual] added {added} in-scope FQDN endpoint(s) alongside "
                      f"their IP forms")

        # --- Emit per-tool target files ---
        tool_dir = self.outdir / "targets"
        paths = emit_target_files(tool_dir, web_probes, groups,
                                  recon_domains=self.recon_domains_ref)
        # WebGet's urls.txt IS the web-tool pool — the SINGLE source, no fallback.
        # Host validation (run above) built it from targets.txt (+ any discovered
        # subdomains), expanding CIDR and scope-confirming every host. If it holds
        # real targets it becomes web_urls and every web tool consumes it directly.
        # If not, there is NO substitute pool — the web-fuzz phase is skipped with a
        # loud, explicit reason (never silently). web_urls is kept as a Path (the type
        # emit_target_files returns) so downstream tools that call .read_text() on it
        # work unchanged.
        if self.dry_run:
            # Dry-run preview: host validation didn't run, so keep the emit-derived
            # web_urls for a command preview and don't fire the [STOP] banner.
            self._web_pool_ok = _has_real_targets(paths.get("web_urls"))
        else:
            hv_urls = getattr(self, "_hostval_urls", None)
            if not (hv_urls and Path(hv_urls).is_file()):
                _cand = self.outdir / getattr(self.cfg, "hostval_urls_file", "urls.txt")
                hv_urls = _cand if _cand.is_file() else None
            self._web_pool_ok = bool(hv_urls and _has_real_targets(hv_urls))
            if self._web_pool_ok:
                paths["web_urls"] = Path(hv_urls)
                n_hv = len([u for u in Path(hv_urls).read_text(errors="replace").splitlines()
                            if u.strip()])
                print(f"[host_validation] web pool = {Path(hv_urls).name} "
                      f"({n_hv} validated URL(s))")
            else:
                where = Path(hv_urls) if hv_urls else (
                    self.outdir / getattr(self.cfg, "hostval_urls_file", "urls.txt"))
                # Point the pool at urls.txt (empty/missing) so every web tool skips on
                # its own empty-target guard — never at the probe-derived pool. No
                # fallback, by design.
                paths["web_urls"] = where
                print("\n" + "!" * 64)
                print("  [STOP] WebGet produced no web targets — urls.txt is empty/missing.")
                print(f"         looked for: {where}")
                print("         The web-fuzz tools (nuclei / ffuf / feroxbuster / testssl /")
                print("         sns / nomore403 / burp list) have NO pool and are SKIPPED.")
                print("         This is NOT a silent skip: host validation found nothing to")
                print("         hand them, and there is no fallback pool by design.")
                print("         Check: does targets.txt have live web hosts? did host")
                print("         validation (httpx/dnsx) run and emit urls.txt? Run it solo")
                print("         to confirm, then re-run.")
                print("!" * 64 + "\n")
        print(f"[emit] target files written to {tool_dir}")

        # --- Honeypot detection + Nessus reconciliation + evidence-driven pool ---
        # This makes the web tools resilient to nmap discovery degradation: even
        # if nmap dropped packets and missed web ports, we seed the pool from
        # Nessus + scope too, and we skip likely-honeypot hosts.
        try:
            self._reconcile_and_augment_web_pool(paths, groups)
        except Exception as e:  # noqa: BLE001
            print(f"[reconcile] skipped (non-fatal): {e}")

        # --- Live URL list for manual review (Burp/ZAP via a proxy browser) ---
        # Same single pool: the burp list IS urls.txt (WebGet's validated, deduped,
        # in-scope URLs). No probe-derived fallback list. Empty when the pool is not
        # ok (the [STOP] banner above already explained why).
        self._web_probes = web_probes
        if getattr(self, "_web_pool_ok", False):
            _u = Path(paths["web_urls"])
            self._live_urls = [ln.strip() for ln in
                               _u.read_text(errors="replace").splitlines()
                               if ln.strip()] if _u.is_file() else []
        else:
            self._live_urls = []
        if self._live_urls:
            client = (self.correlate_domains[0] if self.correlate_domains
                      else self.cfg.engagement_name or "engagement")
            safe = client.replace("/", "_")
            live_file = self.outdir / f"{safe}_live_urls.txt"
            live_file.write_text("\n".join(self._live_urls) + "\n")
            print(f"[burp] {len(self._live_urls)} live URL(s) -> {live_file} "
                  f"(paste into a proxy-enabled browser for Burp)")

        # --- Verify TLS before committing endpoints to the testssl list ---
        # Build the testssl list from VERIFIED TLS, from three sources:
        #   1. probe-confirmed https endpoints (already completed a TLS handshake)
        #   2. classifier tls candidates that pass a raw TLS handshake check
        #   3. ANY other nmap-confirmed open port that passes a raw TLS handshake
        #      check — catches TLS on non-standard ports the classifier didn't
        #      flag (SMTPS/IMAPS/POP3S/LDAPS and anything on an oddball port).
        # The raw check is a lightweight presence test (one handshake); the full
        # scan is still testssl's job and only runs on what passes here.
        verified_tls: set[str] = set()
        if not self.dry_run:
            from .probe import verify_tls
            # source 1: probe confirmed https. Include redirecting origins too —
            # an in-scope 443 host that bounces to SSO still has a TLS cert we
            # want testssl to scan (we just never scan the redirect destination).
            for pr in web_probes:
                if pr.scheme == "https":
                    verified_tls.add(f"{pr.host}:{pr.port}")

            already = {(p.host, p.port) for p in web_probes if p.scheme == "https"}
            checked: set[tuple] = set(already)

            # source 2: classifier tls candidates not already confirmed
            for ep in groups.get("tls", []):
                if (ep.host, ep.port) in checked:
                    continue
                checked.add((ep.host, ep.port))
                if verify_tls(ep.host, ep.port,
                              timeout=self.cfg.probe_connect_timeout):
                    verified_tls.add(f"{ep.host}:{ep.port}")
                else:
                    print(f"[tls-verify] {ep.host}:{ep.port} -> no TLS handshake, "
                          f"excluded from testssl")

            # source 3: every remaining nmap-confirmed open port — catch TLS on
            # ports the classifier never flagged.
            for addr, info in state["results"].items():
                for svc in info.get("services", []):
                    try:
                        port = int(svc.get("port", 0))
                    except (TypeError, ValueError):
                        continue
                    if not port or (addr, port) in checked:
                        continue
                    checked.add((addr, port))
                    if verify_tls(addr, port,
                                  timeout=self.cfg.probe_connect_timeout):
                        verified_tls.add(f"{addr}:{port}")
                        print(f"[tls-verify] {addr}:{port} -> TLS found on "
                              f"unflagged port, added to testssl")

            # source 4: Nessus flagged a TLS/SSL finding on this host:port ->
            # FORCE testssl to run there so an independent tool validates it,
            # even if our own handshake probe was inconclusive. This is the
            # finding-validation half of the two-tool principle.
            forced = 0
            for ip, vmap in self._force_validate.items():
                for (proto, port), tools in vmap.items():
                    if "testssl" in tools and f"{ip}:{port}" not in verified_tls:
                        verified_tls.add(f"{ip}:{port}")
                        forced += 1
                        print(f"[validate] {ip}:{port} forced into testssl "
                              f"(Nessus TLS finding to validate)")
            if forced:
                print(f"[validate] {forced} Nessus-flagged TLS port(s) forced "
                      f"into testssl for cross-validation")

            # overwrite the tls target file with the verified set
            tls_file = paths["tls_endpoints"]
            verified_sorted = sorted(verified_tls)
            Path(tls_file).write_text("\n".join(verified_sorted)
                                      + ("\n" if verified_sorted else ""))
            print(f"[tls-verify] {len(verified_sorted)} verified TLS endpoint(s) "
                  f"-> testssl")

        # --- Redirect summary: surface before any tool runs ---
        # New behavior: the redirect DESTINATION is never scanned, but an
        # in-scope origin that redirects IS scanned at itself. http->https
        # same-host upgrades are the only origins we drop (the https form is
        # already scanned). Reflect that split clearly.
        redirecting = [p for p in web_probes if p.is_redirect]
        if redirecting:
            def _same_host_upgrade(p):
                loc = (p.redirect_location or "").strip().lower()
                return (p.scheme == "http" and loc.startswith("https")
                        and (p.host.lower() in loc))
            scanned_origins = [p for p in redirecting if not _same_host_upgrade(p)]
            skipped_upgrades = [p for p in redirecting if _same_host_upgrade(p)]

            print("\n[!] Redirect handling (destinations are NEVER scanned):")
            if scanned_origins:
                print("    In-scope origins that redirect off-site (e.g. SSO) — the")
                print("    ORIGIN host is still scanned; the destination is not:")
                for p in scanned_origins:
                    dest = p.redirect_location or "(no Location header)"
                    print(f"      SCAN {p.url}  [{p.status}]  -x->  {dest}")
            if skipped_upgrades:
                print("    Same-host http->https upgrades — http origin skipped")
                print("    (the https form is already scanned):")
                for p in skipped_upgrades:
                    dest = p.redirect_location or "(no Location header)"
                    print(f"      skip {p.url}  [{p.status}]  ->  {dest}")
            print(f"\n    Full redirect log: {paths['redirects']}\n")

        # --- Persist probe results (resolved URLs per host:port) so the scan
        #     summary sheet can show the resolved URL next to its port. ---
        for pr in web_probes:
            host_info = state["results"].get(pr.host)
            if not host_info:
                continue
            for svc in host_info.get("services", []):
                if int(svc.get("port", -1)) == int(pr.port):
                    if pr.scheme and not pr.is_redirect:
                        svc["resolved_url"] = pr.url
                    svc["http_status"] = pr.status
                    if pr.is_redirect:
                        svc["redirect_to"] = pr.redirect_location

        # --- Final results artifact (before tools, so it's saved regardless) ---
        results_path = self.outdir / "results.json"
        # attach subdomain enrichment (hostnames -> their target IP) to results
        if self._subdomain_enrichment:
            for addr, hostnames in self._subdomain_enrichment.items():
                if addr in state["results"]:
                    state["results"][addr]["hostnames"] = hostnames

        results_path.write_text(json.dumps(state["results"], indent=2, default=str))
        print(f"[done] recon results written to {results_path}")

        # --- Tool routing, each behind a yes/no gate (timed for metrics) ---
        tc = self.tool_config

        def _hosts_in(target_file):
            """host-forms referenced in a target file (host or host:port or URL)."""
            from urllib.parse import urlparse
            out = set()
            try:
                for ln in Path(target_file).read_text(errors="replace").splitlines():
                    ln = ln.strip()
                    if not ln:
                        continue
                    if "://" in ln:
                        h = urlparse(ln).hostname or ln
                    else:
                        h = ln.split(":")[0]
                    out.add(h)
            except OSError:
                pass
            return out

        def _mark(step, hosts, status="scanned"):
            for h in hosts:
                self.metrics.ensure_host(h)
                self.metrics.set_status(h, step, status)

        # --- Web discovery expansion: httpx (fingerprint) + katana (crawl) +
        # gau (passive historical) -> merged, deduped URL pool that nuclei and
        # the 403 collection consume. Brute-forcers (ffuf/feroxbuster) stay on
        # their seeds. FunnelWeb (deep JS crawl) runs LAST, later in this method.
        # NOTE ON PROXY: the forwarding proxy exists for tools that HAMMER the
        # client (ffuf, feroxbuster, FunnelWeb, probe) — that's the traffic you
        # want routed through your proxy. The web-discovery tools here are
        # passive/light: gau queries PUBLIC ARCHIVES (never touches the client),
        # and httpx/katana do light fingerprinting/crawl. Routing them through
        # the forwarding proxy is unnecessary and, for gau, actively breaks it
        # (gau rejects https:// proxies). So discovery tools do NOT get the
        # forwarding proxy. Their own optional proxies (if ever needed) are
        # separate config, not the client-forwarding one.
        from . import web_discovery as _wd

        if getattr(tc, "httpx_enabled", True):
            self.metrics.start("httpx")
            self._httpx_out = self._isolate(
                "httpx", _wd.run_httpx, paths["web_urls"], self.outdir,
                self.runner.command_log, proxy="", dry_run=self.dry_run)
            self.metrics.stop("httpx")

        katana_out = None
        if getattr(tc, "katana_enabled", True):
            self.metrics.start("katana")
            katana_out = self._isolate(
                "katana", _wd.run_katana, paths["web_urls"], self.outdir,
                self.runner.command_log, proxy="",
                depth=getattr(tc, "katana_depth", 2), dry_run=self.dry_run)
            self.metrics.stop("katana")

        gau_out = None
        if getattr(tc, "gau_enabled", True):
            self.metrics.start("gau")
            # gau mines PUBLIC ARCHIVES by registrable/apex domain, so it runs ONLY
            # against the RECON DOMAIN(S) the operator entered at startup
            # (recon_domains_ref). It NEVER reads targets.txt: that is the scan scope
            # (IPs/CIDRs/subdomains), and an IP or bare subdomain gives gau little or
            # nothing to mine. No recon domain -> gau simply skips (no fallback).
            gau_domains = sorted(self.recon_domains_ref)
            if gau_domains:
                print(f"[gau] mining archives for {len(gau_domains)} recon "
                      f"domain(s): {', '.join(gau_domains)}")
                gau_out = self._isolate(
                    "gau", _wd.run_gau, gau_domains, self.outdir,
                    self.runner.command_log, proxy="",
                    extra=getattr(tc, "gau_extra", None), dry_run=self.dry_run)
            else:
                print("[gau] no recon domain to mine — skipping "
                      "(gau runs against the client domain entered at startup, "
                      "never targets.txt)")
            self.metrics.stop("gau")

        # Merge everything into the expanded, deduped pool nuclei consumes.
        # Seeds are already probe-verified; katana/gau are unverified, so we
        # liveness-filter THOSE through httpx (retries guard transient drops)
        # before they reach nuclei. Seeds never get re-filtered (no regression).
        nuclei_full_pool = paths["web_urls"]
        if not self.dry_run and (katana_out or gau_out):
            try:
                live_set = None
                if getattr(tc, "httpx_enabled", True):
                    # collect the raw katana+gau URLs, write them, liveness-check
                    disc = []
                    for f in (katana_out, gau_out):
                        if f and Path(f).is_file():
                            disc += [l.strip() for l in
                                     Path(f).read_text(errors="replace").splitlines()
                                     if l.strip()]
                    if disc:
                        disc_file = self.outdir / "discovered_urls_raw.txt"
                        disc_file.write_text("\n".join(disc) + "\n")
                        live_set = _wd.run_httpx_liveness(
                            disc_file, self.outdir, self.runner.command_log,
                            proxy="", retries=getattr(tc, "httpx_retries", 3),
                            dry_run=self.dry_run)
                nuclei_full_pool = _wd.build_url_pool(
                    paths["web_urls"], katana_out=katana_out, gau_out=gau_out,
                    live_urls=live_set)
            except Exception as e:  # noqa: BLE001
                print(f"[web-pool] discovered-URL merge failed ({e}); nuclei's "
                      f"takeover fallback uses urls.txt. Continuing.")
                nuclei_full_pool = paths["web_urls"]

        # TWO nuclei passes with TWO lists:
        #   1. TAKEOVER pass  -> subfinder's discovered subdomain names (fallback:
        #      the katana/gau-enriched pool). Only the takeover templates run — safe
        #      to reach broadly because it just fingerprints dangling/unclaimed DNS.
        #   2. FULL pass      -> WebGet's urls.txt ONLY. Those URLs were authored by
        #      WebGet's own httpx liveness check, so they are already confirmed live
        #      and in-scope WITHOUT katana — katana is never a liveness gatekeeper
        #      here and cannot create a blindspot that drops a host. The full template
        #      set runs against every urls.txt host.
        self.metrics.start("nuclei")

        # pass 1: takeover-only against the full pool (incl. out-of-scope subs).
        # Output uses the takeover_ prefix so the existing parse_takeover() +
        # 'Subdomain Takeovers' report sheet ingest it alongside the dedicated
        # subdomain takeover pass.
        # pass 1: takeover-only. Runs against SUBFINDER's discovered subdomains
        # (its own unique list — dangling CNAMEs AND NXDOMAIN-enumerated names),
        # NOT the fuzzer pool. This is a different vuln class with a different
        # target set: nuclei's takeover templates fingerprint unclaimed services,
        # so they want the enumerated names regardless of whether they resolve.
        # Falls back to the old pool only if no subdomains were discovered.
        takeover_pool = self._takeover_targets()
        if takeover_pool is None:
            # no subfinder output (e.g. IP-only engagement, no domains): fall back
            # to the resolution-filtered web pool so the pass still does something.
            takeover_pool = _wd.resolution_filter(nuclei_full_pool,
                                                  self.runner.command_log)
        _mark("nuclei-takeover", _hosts_in(takeover_pool))
        self._isolate("nuclei-takeover", run_nuclei, tc, takeover_pool, self.outdir,
                      self.runner.command_log, assume_yes=self.assume_yes,
                      dry_run=self.dry_run, takeover_only=True,
                      out_prefix="takeover_urlpool")

        # pass 2: full templates against the single web pool (WebGet's urls.txt).
        # WebGet already scope-confirmed and CIDR-expanded every host, so there is
        # no separate in-scope filtering here.
        in_scope_pool = self._scan_pool(paths["web_urls"])
        if in_scope_pool is not None:
            _mark("nuclei", _hosts_in(in_scope_pool))
            self._isolate("nuclei", run_nuclei, tc, in_scope_pool, self.outdir,
                          self.runner.command_log, assume_yes=self.assume_yes,
                          dry_run=self.dry_run, takeover_only=False,
                          out_prefix="nuclei")
        else:
            print(f"[skip] nuclei (full pass): web pool is empty "
                  f"(seed={Path(paths['web_urls']).name}) — WebGet produced no "
                  f"targets; see the [STOP] banner above")
        self.metrics.stop("nuclei")

        # ffuf (brains) first: calibrated discovery -> targeted hit list.
        # INTRUSIVE (aggressive fuzzing) -> the single web pool (urls.txt).
        # Coerce to Path: run_ffuf/run_feroxbuster call .read_text() on this arg, so
        # it must be a Path even though every producer already hands us one.
        from .ffuf_tool import run_ffuf
        web_pool = Path(paths["web_urls"])
        self.metrics.start("ffuf")
        _mark("ffuf", _hosts_in(web_pool))
        ffuf_hits = self._isolate("ffuf", run_ffuf, tc, web_pool, self.outdir,
                                  self.runner.command_log,
                                  assume_yes=self.assume_yes, dry_run=self.dry_run)
        self.metrics.stop("ffuf")
        # feroxbuster (workhorse): recurse into ffuf's confirmed hits if we have
        # them and the feed is enabled; otherwise use the full web list.
        # feroxbuster gets the original ROOTS *plus* ffuf's discovered
        # directories — so it recurses into ffuf's confirmed dirs AND still
        # catches root-level files ffuf (directories-only) didn't look for.
        # INTRUSIVE -> the roots come from the single web pool (urls.txt).
        ferox_input = web_pool
        if (getattr(tc, "ffuf_feed_feroxbuster", True) and ffuf_hits
                and Path(ffuf_hits).exists() and Path(ffuf_hits).stat().st_size > 0):
            roots = [u.strip() for u in
                     Path(web_pool).read_text(errors="replace").splitlines() if u.strip()]
            dirs = [u.strip() for u in
                    Path(ffuf_hits).read_text(errors="replace").splitlines() if u.strip()]
            # merge, de-dupe, preserve order (roots first, then ffuf dirs)
            seen, merged = set(), []
            for u in roots + dirs:
                if u not in seen:
                    seen.add(u)
                    merged.append(u)
            combined = self.outdir / "feroxbuster_targets.txt"
            combined.write_text("\n".join(merged) + "\n")
            ferox_input = combined
            print(f"[feroxbuster] scanning {len(roots)} root(s) + "
                  f"{len(dirs)} ffuf directory hit(s) = {len(merged)} target(s)")
        self.metrics.start("feroxbuster")
        _mark("feroxbuster", _hosts_in(ferox_input))
        self._isolate("feroxbuster", run_feroxbuster, tc, ferox_input, self.outdir,
                      self.runner.command_log, assume_yes=self.assume_yes,
                      dry_run=self.dry_run)
        self.metrics.stop("feroxbuster")

        # nomore403: take the 403s feroxbuster found and try access-control
        # bypasses on them (403->200 = likely real bypass). Runs right after
        # feroxbuster since it consumes feroxbuster's 403 responses.
        if getattr(tc, "nomore403_enabled", True):
            self.metrics.start("nomore403")
            from .nomore403_tool import run_nomore403
            # Union the host-validation 403 seed list (403.txt) with the 403s the
            # fuzzers discovered, so nomore403 tests both sources.
            hv_403 = getattr(self, "_hostval_403", None)
            hv_403 = str(hv_403) if (hv_403 and Path(hv_403).is_file()) else None
            self._isolate(
                "nomore403", run_nomore403,
                self.outdir, self.runner.command_log,
                script=getattr(tc, "nomore403_script", "nomore403"),
                proxy=getattr(tc, "forward_proxy", "") or "",
                payloads_dir=getattr(tc, "nomore403_payloads_dir", ""),
                safe_mode=getattr(tc, "nomore403_safe_mode", True),
                dry_run=self.dry_run,
                extra_403_file=hv_403)
            self.metrics.stop("nomore403")

        # testssl: INTRUSIVE (active TLS probing). Endpoint list is (https from
        # WebGet's urls.txt) UNION (non-web TLS ports from the nmap classifier group
        # — imaps/pop3s/smtps/ldaps/ftps that WebGet, being webapp-only, can't know
        # about), deduped + scope-anchored. This is NOT a fallback pool: the nmap TLS
        # ports are a legitimate, distinct TLS source, not a substitute web pool.
        tls_input = self._testssl_input(paths["tls_endpoints"],
                                        paths.get("web_urls")) or paths["tls_endpoints"]
        self.metrics.start("testssl")
        _mark("testssl", _hosts_in(tls_input))
        self._isolate("testssl", run_testssl, tc, tls_input, self.outdir,
                      self.runner.command_log, assume_yes=self.assume_yes,
                      dry_run=self.dry_run)
        self.metrics.stop("testssl")

        # SNS: IIS short-name check. Fed by the SAME single web pool (WebGet's
        # urls.txt) as the other web tools — no probe-derived fallback. If the pool
        # is missing/empty, sns simply gets an empty list and skips (the [STOP]
        # banner above already explained why).
        try:
            sns_urls = [u for u in Path(paths["web_urls"]).read_text(errors="replace").splitlines()
                        if u.strip()]
        except OSError:
            sns_urls = []
        self.metrics.start("sns")
        from urllib.parse import urlparse as _up
        _mark("sns", {(_up(u).hostname or u) for u in sns_urls})
        self._isolate("sns", run_sns, tc, sns_urls, self.outdir,
                      self.runner.command_log, assume_yes=self.assume_yes,
                      dry_run=self.dry_run)
        self.metrics.stop("sns")

        # ssh-audit: against detected SSH endpoints (service == ssh).
        ssh_endpoints = []
        for addr, info in state["results"].items():
            for svc in info.get("services", []):
                if (svc.get("service", "").lower() == "ssh"
                        or int(svc.get("port", 0)) == 22):
                    ssh_endpoints.append((addr, int(svc.get("port", 22))))
        # Item 7: also feed Nessus-detected SSH (port 22 or 'ssh' service) into
        # ssh-audit even if nmap missed it — Nessus is the authority when seeded.
        # In-scope only (guard-anchored); no-op when no .nessus was seeded.
        for _ip, _h in (getattr(self, "_nessus_rich", None) or {}).items():
            for (_proto, _port), _pd in (_h.get("ports", {}) or {}).items():
                _svc = str(_pd.get("service", "")).lower()
                if int(_port) == 22 or "ssh" in _svc:
                    try:
                        self.guard.check(_ip)
                    except Exception:  # noqa: BLE001
                        continue
                    _ep = (_ip, int(_port))
                    if _ep not in ssh_endpoints:
                        ssh_endpoints.append(_ep)
        self.metrics.start("sshaudit")
        _mark("sshaudit", {h for h, _ in ssh_endpoints})
        self._isolate("sshaudit", run_sshaudit, tc, ssh_endpoints, self.outdir,
                      self.runner.command_log, assume_yes=self.assume_yes,
                      dry_run=self.dry_run)
        self.metrics.stop("sshaudit")

        # Phase-0 tools are done — flip the dashboard from the phase-0 bar to the
        # recon-engine bar (the recon orchestrator runs next and writes recon_state.json).
        self.metrics.mark_phase0_complete()

        # --- Scan summary sheet: triage worktop of host:port + nuclei/testssl
        #     tallies, written after the scans so the data is present. ---
        if not self.dry_run:
            try:
                from openpyxl import Workbook
                from .scan_summary import (add_scan_summary_sheet,
                                           add_hosts_by_port_sheet,
                                           add_feroxbuster_sheet, add_sshaudit_sheet,
                                           add_feroxbuster_403_hotspots_sheet,
                                           add_nomore403_sheet,
                                           add_httpx_sheet, add_katana_sheet,
                                           add_gau_sheet, add_web_hosts_glance_sheet,
                                           add_takeover_sheet, add_shodan_sheet,
                                           add_subdomain_inventory_sheet,
                                           add_live_urls_sheet,
                                           add_nessus_vs_nmap_sheet,
                                           add_severity_matrix_sheet)
                from .metrics import add_metrics_sheet
                wb = Workbook()
                wb.remove(wb.active)
                add_scan_summary_sheet(wb, self.outdir)
                add_hosts_by_port_sheet(wb, self.outdir)
                add_nessus_vs_nmap_sheet(wb, state.get("results", {}),
                                         getattr(self, "_nessus_rich", {}),
                                         nessus_used=bool(self.nessus_files))
                add_severity_matrix_sheet(wb, getattr(self, "_nessus_rich", {}))
                add_live_urls_sheet(wb, self._live_urls)
                add_feroxbuster_sheet(wb, self.outdir)
                add_feroxbuster_403_hotspots_sheet(wb, self.outdir)
                add_nomore403_sheet(wb, self.outdir)
                add_web_hosts_glance_sheet(wb, getattr(self, "_web_probes", None), self.outdir)
                add_takeover_sheet(wb, self.outdir)
                add_shodan_sheet(wb, self.outdir)
                add_httpx_sheet(wb, self.outdir)
                add_katana_sheet(wb, self.outdir)
                add_gau_sheet(wb, self.outdir)
                add_sshaudit_sheet(wb, self.outdir)
                add_subdomain_inventory_sheet(wb, self.outdir)
                add_metrics_sheet(wb, self.metrics)
                summary_path = self.outdir / "scan_summary.xlsx"
                wb.save(summary_path)
                print(f"[done] scan summary written to {summary_path}")
            except Exception as e:
                print(f"[!] scan summary build failed: {e}")

        # Mark this run complete so a future run starts fresh rather than
        # replaying these results (only when not a dry run).
        if not self.dry_run:
            state["completed"] = True
            self._save_state(state)

        return state["results"]
