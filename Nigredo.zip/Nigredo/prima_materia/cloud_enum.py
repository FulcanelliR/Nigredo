#!/usr/bin/env python3
"""cloud_enum (initstring) runner — active multi-cloud bucket enumeration (phase 1).

cloud_enum brute-forces predicted storage names across AWS S3, Azure Blob, and
Google Cloud from keywords, reporting which exist / are open. Unlike the GHW
tool (which queries a passive index), cloud_enum ACTIVELY probes the cloud
providers' endpoints with guessed names — it does not touch the target's own
infrastructure, but it does generate real requests to AWS/Azure/GCP.

This runner saves RAW output only — the tool's native logfile plus captured
stdout — to the engagement folder. No parsing, cleaning, or report integration
yet (that comes later once the output shape is understood). Skips safely if the
cloud_enum binary/script isn't on PATH.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path


def _resolve_script(script: str) -> str | None:
    """Return a runnable path/command for cloud_enum, or None if not found.

    Resolution order (explicit path wins, to avoid the name-collision trap):
      1. If `script` is an explicit FILE PATH that exists -> use that exact file.
         This is the safe, unambiguous case: we run precisely what you point at,
         regardless of what a bare 'cloud_enum' on PATH might resolve to.
      2. If `script` is a bare name found on PATH -> use it.
      3. Fall back to the canonical command name 'cloud_enum' (UNDERSCORE) on
         PATH. NOTE: the apt package is 'cloud-enum' (hyphen) but it installs a
         command named 'cloud_enum' (underscore) — we always invoke the
         underscore form / the file, never the hyphen (which is the package).
    """
    # 1. explicit configured file path wins — run exactly this file
    if script and Path(script).is_file():
        return str(Path(script).resolve())
    # 2. configured name happens to be on PATH
    if script and shutil.which(script):
        return script
    # 3. canonical command name (underscore) as a last resort
    if shutil.which("cloud_enum"):
        return "cloud_enum"
    return None


def parse_findings(outdir: Path) -> list:
    """Parse cloud_enum's raw output into findings for the workbook.

    cloud_enum prints positive hits as lines containing markers like OPEN /
    PUBLIC / a cloud URL, usually prefixed '[+]'. We extract those lines (the
    actual discoveries) and skip the progress/checking noise. Returns a list of
    [provider, status, url_or_detail] rows. Reads both the .log and .stdout.txt
    for every domain in the engagement folder."""
    import re as _re
    rows = []
    seen = set()
    files = sorted(list(Path(outdir).glob("cloud_enum_*.log"))
                   + list(Path(outdir).glob("cloud_enum_*.stdout.txt")))
    # a finding line usually has a cloud URL and/or an OPEN/PUBLIC status
    url_re = _re.compile(r"https?://[^\s'\"]+", _re.I)
    for f in files:
        try:
            text = f.read_text(errors="replace")
        except OSError:
            continue
        # strip ANSI colour codes cloud_enum emits
        text = _re.sub(r"\x1b\[[0-9;]*m", "", text)
        for line in text.splitlines():
            low = line.lower()
            # keep only genuine hits: an OPEN/PUBLIC/protected resource or a URL
            # on a '[+]' hit line. Skip "checking", "brute", progress noise.
            is_hit = (("open" in low or "public" in low or "protected" in low)
                      and ("bucket" in low or "blob" in low or "container" in low
                           or "storage" in low or url_re.search(line)))
            if not is_hit:
                continue
            url_m = url_re.search(line)
            url = url_m.group(0) if url_m else line.strip()
            # provider guess
            provider = ("AWS" if "s3" in low or "amazonaws" in low else
                        "Azure" if "azure" in low or "blob" in low or "windows.net" in low else
                        "GCP" if "google" in low or "gcp" in low or "storage.googleapis" in low else
                        "?")
            status = ("OPEN" if "open" in low else
                      "PUBLIC" if "public" in low else
                      "PROTECTED" if "protected" in low else "?")
            key = (provider, url)
            if key in seen:
                continue
            seen.add(key)
            rows.append([provider, status, url])
    return rows


# Valid cloud_enum depth modes (see recon_config.cloud_enum_depth).
CLOUD_ENUM_DEPTHS = ("quick", "normal", "full")
CLOUD_ENUM_DEPTH_DEFAULT = "normal"

# cloud_enum flags that, if the operator already supplied any in `extra`, mean
# we should NOT inject our own depth flags (explicit operator extra always wins).
_DEPTH_OVERRIDE_FLAGS = frozenset({"-m", "--mutations", "-b", "--brute",
                                   "-qs", "--quickscan"})


def _basic_mutations_file() -> Path:
    """Path to the bundled curated ~149-name mutations list (best-first). Ships
    next to this module, so it resolves whether run from source or installed."""
    return Path(__file__).with_name("cloud_enum_mutations_basic.txt")


def normalize_depth(depth: "str | None") -> str:
    """Normalise a cloud_enum_depth value: lowercased/trimmed if valid, else the
    default. Callers that want to warn on invalid values should check membership
    in CLOUD_ENUM_DEPTHS themselves before calling (this never raises)."""
    d = (depth or "").strip().lower()
    return d if d in CLOUD_ENUM_DEPTHS else CLOUD_ENUM_DEPTH_DEFAULT


def build_command(resolved: str, keywords: list[str], logfile: Path,
                  extra: list[str], depth: str = CLOUD_ENUM_DEPTH_DEFAULT) -> list[str]:
    # cloud_enum takes repeated -k KEYWORD and -l LOGFILE. If it's a .py script,
    # run it through the current Python interpreter.
    if resolved.endswith(".py"):
        cmd = [sys.executable, resolved]
    else:
        cmd = [resolved]
    for kw in keywords:
        cmd += ["-k", kw]
    cmd += ["-l", str(logfile)]

    # Depth flags — injected only if the operator hasn't already supplied their
    # own mutations/brute/quickscan flag in `extra` (their explicit choice wins).
    depth = normalize_depth(depth)
    if not (_DEPTH_OVERRIDE_FLAGS & set(extra)):
        if depth == "quick":
            cmd += ["-qs"]
        elif depth == "normal":
            mut = str(_basic_mutations_file())
            cmd += ["-m", mut, "-b", mut]
        # "full" -> inject nothing; cloud_enum uses its stock fuzz.txt default.

    cmd += list(extra)
    return cmd


def process(domain: str, outdir, command_log,
            company: str = "", script: str = "cloud_enum.py",
            extra: list[str] | None = None, dry_run: bool = False,
            depth: str = CLOUD_ENUM_DEPTH_DEFAULT) -> Path | None:
    """Run cloud_enum for a domain, saving raw logfile + stdout. Returns the
    logfile path (or None if skipped). Runs to completion — no timeout — for
    full coverage (no paid API, so no credit-burn risk)."""
    outdir = Path(outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    extra = extra or []
    # Validate depth: an unrecognised value warns and falls back to the default
    # rather than silently doing the wrong thing (or hanging on a prompt).
    if (depth or "").strip().lower() not in CLOUD_ENUM_DEPTHS:
        print(f"[cloud_enum] cloud_enum_depth {depth!r} not recognised "
              f"(valid: {', '.join(CLOUD_ENUM_DEPTHS)}) — using "
              f"'{CLOUD_ENUM_DEPTH_DEFAULT}'.")
    depth = normalize_depth(depth)
    safe = domain.replace("/", "_")

    # keywords: domain, its base label, and the company name if provided
    keywords: list[str] = [domain]
    base = domain.split(".")[0]
    if base and base != domain:
        keywords.append(base)
    if company:
        keywords.append(company)
    # dedupe preserve order
    seen, kw = set(), []
    for k in keywords:
        kl = k.strip()
        if kl and kl.lower() not in seen:
            seen.add(kl.lower())
            kw.append(kl)

    logfile = outdir / f"cloud_enum_{safe}.log"
    stdout_file = outdir / f"cloud_enum_{safe}.stdout.txt"

    resolved = _resolve_script(script)
    if resolved is None and not dry_run:
        print(f"[cloud_enum] '{script}' not found on PATH — skipping "
              f"(install initstring/cloud_enum)")
        return None

    cmd = build_command(resolved or script, kw, logfile, extra, depth=depth)
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + f"  > {stdout_file}\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd), ">", stdout_file)
        return None

    print(f"[cloud_enum] brute-forcing cloud storage for keywords: {', '.join(kw)}")
    print(f"[cloud_enum] depth={depth} "
          f"({'quickscan, no mutations' if depth == 'quick' else 'curated ~149 names' if depth == 'normal' else 'stock ~306 fuzz.txt'})")
    print(f"[cloud_enum] (active discovery — probes AWS/Azure/GCP endpoints; "
          f"this is slow by nature — heartbeat every 13 min so you know it's alive)")
    import threading, time as _time
    try:
        # No timeout: cloud_enum runs to completion for full coverage (no paid
        # API, so no credit-burn risk). Because it's a long, silent subprocess, we
        # run it non-blocking and print a heartbeat so it's never mistaken for a
        # hang. A heartbeat that STOPS advancing while the process is alive is the
        # signal that it's genuinely wedged (vs. just slow).
        start = _time.time()
        from . import resources
        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, errors="replace",
                                **resources.popen_kwargs())
        captured = []

        def _pump():
            # drain output so the pipe never blocks; keep it for the logfile
            for line in proc.stdout:
                captured.append(line)

        pump = threading.Thread(target=_pump, daemon=True); pump.start()

        beat = 0
        last_lines = 0
        try:
            while proc.poll() is None:
                _time.sleep(5)
                beat += 5
                if beat % 780 == 0:     # heartbeat every 13 minutes
                    mins = beat // 60
                    now_lines = len(captured)
                    rate = now_lines - last_lines      # lines in the last minute
                    last_lines = now_lines
                    moving = f"+{rate}/min" if rate else "no new output this min"
                    print(f"[cloud_enum] still running… {mins}m elapsed | "
                          f"{now_lines} output lines ({moving}) | no timeout — "
                          f"runs to completion (Ctrl+C to pause/skip)", flush=True)
        except KeyboardInterrupt:
            resources.kill_tree(proc)
            raise
        finally:
            if proc.poll() is None:
                resources.kill_tree(proc)
            pump.join(timeout=5)
        elapsed = int(_time.time() - start)

        text = "".join(captured)
        stdout_file.write_text(text)
        print(f"[\u2713] cloud_enum done in {elapsed}s:")
        print(f"    logfile -> {logfile}")
        print(f"    stdout  -> {stdout_file}")

        # END-OF-RUN HEALTH SUMMARY (one line, low-noise). Per design: DON'T watch
        # for 429s (most checks are DNS-based and don't 429). Instead surface the
        # signals that actually indicate DEGRADED COVERAGE: DNS/resolution errors
        # and timeouts. If these are high, results may be incomplete.
        low = text.lower()
        dns_errs = sum(low.count(s) for s in
                       ("could not resolve", "name resolution", "temporary failure",
                        "timed out", "timeout", "connection error", "max retries"))
        found = sum(low.count(s) for s in
                    ("open", "public", "found", "protected"))  # rough positive signal
        if dns_errs:
            print(f"[cloud_enum] health: {dns_errs} resolution/timeout indicator(s) "
                  f"seen — coverage MAY be incomplete (check network/resolvers).")
        else:
            print(f"[cloud_enum] health: no resolution-error indicators "
                  f"(~{found} positive-hit lines).")
    except Exception as e:  # noqa: BLE001
        stdout_file.write_text(f"cloud_enum error: {e}\n")
        print(f"[cloud_enum] error: {e}")
    return logfile if logfile.exists() else stdout_file
