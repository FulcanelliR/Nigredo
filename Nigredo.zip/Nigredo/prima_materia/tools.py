"""Tool routing: emit per-tool target files, then optionally run each tool behind
a per-tool yes/no confirmation gate.

Rate-limiting is a baked-in default, not an afterthought. nuclei in particular
sends a large volume of requests; it is capped at -rl 3 by default here and the
cap is enforced unless the operator explicitly raises nuclei_max_rate_limit in config.

This module routes for SCANNING / FINGERPRINTING only. It does not construct
credential lists or auth-attempt payloads for the auth_surface group.
"""
from __future__ import annotations

import subprocess
import shutil
import json
from dataclasses import dataclass, field
from pathlib import Path

from .classifier import ClassifiedEndpoint
from .probe import ProbeResult, strip_default_port as _strip_default_port


def _file_has_real_targets(path) -> bool:
    """True if `path` exists and contains at least one non-blank line.

    Replaces the old `not exists or st_size == 0` entry guards: a target file
    with only newlines/whitespace has a non-zero size but zero real targets, so
    the size check passed and the tool 'ran' over an empty list — writing no
    output while looking like it worked. Decode-safe so a stray non-UTF-8 byte
    in a scraped target list can't crash the guard.
    """
    try:
        p = Path(path)
        if not p.is_file():
            return False
        for raw in p.read_text(errors="replace").splitlines():
            if raw.strip():
                return True
        return False
    except OSError:
        return False


# SecLists lands in different places depending on install method (apt, kali,
# manual git clone, pipx, etc.). ffuf/feroxbuster hardcoded /usr/share/seclists
# and SILENTLY SKIPPED when it wasn't there — which is why fuzzing produced no
# output on boxes where SecLists sits elsewhere. Resolve the real base once and
# rewrite wordlist paths against it so the tools find the rafts wherever they are.
_SECLISTS_BASES = (
    "/usr/share/seclists",
    "/usr/share/wordlists/seclists",
    "/usr/share/wordlists/SecLists",
    "/opt/seclists",
    "/opt/SecLists",
    str(Path.home() / ".local/share/seclists"),
    str(Path.home() / "seclists"),
    str(Path.home() / "SecLists"),
)


def find_seclists_base() -> str | None:
    """Return the SecLists install root if found, else None."""
    for base in _SECLISTS_BASES:
        # a cheap, reliable marker file that exists in every SecLists checkout
        if (Path(base) / "Discovery" / "Web-Content").is_dir():
            return base
    return None


def resolve_wordlist(path: str) -> str:
    """If `path` points into SecLists but doesn't exist (wrong base), relocate it
    to wherever SecLists actually is. Returns the resolved path if found, else the
    original (callers still check is_file and warn)."""
    if not path:
        return path
    if Path(path).is_file():
        return path
    p = Path(path)
    # find the '.../seclists/<rest>' tail and re-root it on the real base
    parts = [x.lower() for x in p.parts]
    for marker in ("seclists",):
        if marker in parts:
            idx = parts.index(marker)
            tail = Path(*p.parts[idx + 1:])
            base = find_seclists_base()
            if base:
                candidate = Path(base) / tail
                if candidate.is_file():
                    return str(candidate)
    return path


@dataclass
class ToolConfig:
    nuclei_enabled: bool = True
    nuclei_rate_limit: int = 3            # -rl ; HARD default, see clamp below
    nuclei_max_rate_limit: int = 3       # operator must consciously raise this
    nuclei_stats: bool = True             # show periodic progress line
    nuclei_stats_interval: int = 60       # seconds between progress lines (default
                                          # 60 instead of nuclei's spammy 5)
    nuclei_single_line: bool = False      # CURRENTLY INERT. The quiet one-line
                                          # display (which piped nuclei stdout to
                                          # DEVNULL) has been REMOVED — we do not
                                          # hide the tool's output while the pipeline
                                          # is still being proven. nuclei always runs
                                          # in visible streaming mode now. Flag kept
                                          # only so configs referencing it don't break.
    # Scan strategy (-ss). Default "" = use nuclei's NATIVE default (template-spray),
    # which is exactly what a plain `nuclei -l ... -rl 3` manual run uses and is
    # confirmed working. "host-spray" was previously hardcoded on every full pass;
    # combined with -rl it starved/stalled the run on some nuclei versions, sending
    # a small first batch then grinding to ~0 completed requests / 0 findings. Left
    # configurable for operators who explicitly want it, but OFF by default so the
    # wrapper's command matches the known-good manual invocation.
    nuclei_scan_strategy: str = ""        # "" | "host-spray" | "template-spray" | "auto"
    nuclei_extra: list[str] = field(default_factory=list)

    feroxbuster_enabled: bool = True
    feroxbuster_words_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-words-lowercase.txt"
    feroxbuster_files_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-files-lowercase.txt"
    feroxbuster_threads: int = 10        # -t concurrency
    feroxbuster_depth: int = 3           # -d recursion depth
    feroxbuster_rate_limit: int = 20     # --rate-limit (req/s, PER DIRECTORY).
                                         # Lowered 50->20 (see Config for why:
                                         # rate x scan_limit saturation closes
                                         # connections on fragile targets).
    feroxbuster_rate_mode: str = "auto_tune_capped"  # see Config.feroxbuster_rate_mode:
                                         # auto_tune_capped | fixed |
                                         # auto_tune_uncapped | off
    feroxbuster_scan_limit: int = 2      # --scan-limit : how many directory
                                         # scans run concurrently per host. Lowered
                                         # 3->2. NOTE the rate multiplies —
                                         # --rate-limit is PER directory, so
                                         # 20/dir x 2 = ~40 req/s
                                         # on a host. (1 = sequential/lightest.)
    # per-client feroxbuster intensity, carried from the phase-0 Config via
    # build_tool_config so an unattended run reads the configured value instead
    # of a hardcoded default. ferox_mode: w/f/b/c; ferox_wordlist_size: s/m/l.
    ferox_mode: str = "w"
    ferox_wordlist_size: str = "m"
    ferox_custom_wordlist: str = ""   # used only when ferox_mode == "c"
    # ffuf directory-wordlist size (s/m/l), same source/flow as the ferox knobs.
    # ffuf_tool reads getattr(tc, "ffuf_wordlist_size", ...); without this field
    # it always fell back to the literal default regardless of the config.
    ffuf_wordlist_size: str = "m"
    feroxbuster_progress_interval: int = 30  # seconds between progress-meter prints
    feroxbuster_stuck_timeout: int = 600     # kill+skip a host if no progress for N sec (10 min)
    feroxbuster_status_codes: str = "200,204,301,302,307,308,401,403,405,500"
    # ^ status codes worth keeping (allow-list, via -s). Matches ffuf's curated
    #   list — deliberately EXCLUDES 404 (not-found = noise, nothing to recurse
    #   into). These codes indicate real resources/dirs, so recursion still works.
    # nomore403: 403-bypass testing over feroxbuster's forbidden URLs
    nomore403_enabled: bool = True
    nomore403_script: str = "nomore403"
    nomore403_payloads_dir: str = ""         # point at payloads/ if installed via `go install`
    # Safe mode (DEFAULT): exclude techniques that can change server state
    # (verbs/method-override send PUT/DELETE/PATCH) or smuggle requests
    # (raw-desync/duplicates/authority affect shared infra + other users).
    # Set nomore403_safe_mode=False to run the FULL technique set (only on
    # targets you know can take method tampering + desync — e.g. a lab).
    nomore403_safe_mode: bool = True
    # web discovery expansion
    httpx_enabled: bool = True
    httpx_retries: int = 3                    # retries on the liveness-filter pass
    katana_enabled: bool = True
    katana_depth: int = 2                    # shallow crawl (FunnelWeb does deep)
    gau_enabled: bool = True
    gau_extra: list[str] = field(default_factory=list)  # e.g. provider/key flags later
                                         # the per-dir rate-limit can't multiply
                                         # unbounded during recursion
    feroxbuster_parallel: int = 10       # value used if operator opts into --parallel
    feroxbuster_extensions: str = "php,html,txt,asp,aspx,jsp,json"
    # ffuf: the "brains" discovery pass that feeds feroxbuster a targeted list
    ffuf_enabled: bool = True
    ffuf_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-directories.txt"
    ffuf_words_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-directories.txt"
    ffuf_files_wordlist: str = "/usr/share/seclists/Discovery/Web-Content/raft-large-files-lowercase.txt"
    ffuf_extensions: str = "php,html,txt,asp,aspx,jsp,json"
    ffuf_dirs_only: bool = True
    ffuf_progress_interval: int = 30
    forward_proxy: str = ""
    ffuf_match_codes: str = "200,204,301,302,307,308,401,403,405,500"
    ffuf_threads: int = 3                 # tight leash (see config.py note)
    ffuf_grace_secs: int = 90        # no health checks during initial ramp-up
    ffuf_error_ratio: float = 0.70   # errors this % of requests => CHECK if target's up (not auto-bail)
    ffuf_error_min_reqs: int = 100   # ...only after this many requests sent
    ffuf_stall_secs: int = 120       # stalled rate this long => CHECK if target's up
    ffuf_stall_rate: int = 1         # req/sec at/below this counts as "stalled"
    ffuf_health_recheck_secs: int = 120  # min gap between target health checks
    ffuf_rate: int = 0                    # 0 = no ffuf-side limit
    ffuf_extra: list[str] = field(default_factory=list)
    ffuf_feed_feroxbuster: bool = True    # hand ffuf's hits to feroxbuster  # -x (words pass only)
    feroxbuster_extra: list[str] = field(default_factory=list)

    testssl_enabled: bool = True
    testssl_jsonfile: bool = True        # also emit --jsonfile-pretty per endpoint
    testssl_phone_out: bool = False      # --phone-out (CRL/OCSP revocation): OFF by
                                         # default — it sends traffic to external
                                         # third-party responders, off-scope on an
                                         # external engagement. Flip on only when
                                         # revocation status specifically matters.
    testssl_add_ca: str = ""             # --add-ca <PEM>: client internal CA for
                                         # trust-chain validation; empty = unused
    testssl_extra: list[str] = field(default_factory=list)

    # SNS — IIS short-name (8.3 tilde) scanner (sw33tLie/sns). Check-only mode,
    # threads capped at 5. Produces a yes/no flag per resolved web URL.
    sns_enabled: bool = True
    sns_threads: int = 5
    sns_extra: list[str] = field(default_factory=list)

    # ssh-audit (jtesta) — SSH server algorithm/security audit. Runs against
    # detected SSH ports; its recommendations get their own report page.
    sshaudit_enabled: bool = True
    sshaudit_extra: list[str] = field(default_factory=list)


def _forward_proxy_from_runmode() -> str:
    """The startup interview stashes the forwarding proxy; prefer it if set."""
    try:
        from .runmode import answer, has_answer
        if has_answer("forward_proxy"):
            return answer("forward_proxy", "") or ""
    except Exception:  # noqa: BLE001
        pass
    return ""


def build_tool_config(cfg) -> "ToolConfig":
    """Build a ToolConfig from a phase-0 Config. Shared by the pipeline and the
    standalone single-tool runner so the two never drift apart. Fields not on
    Config (sns/sshaudit/nuclei_stats) fall back to ToolConfig defaults."""
    return ToolConfig(
        nuclei_enabled=cfg.nuclei_enabled,
        nuclei_rate_limit=cfg.nuclei_rate_limit,
        nuclei_max_rate_limit=cfg.nuclei_max_rate_limit,
        nuclei_extra=cfg.nuclei_extra,
        nuclei_scan_strategy=getattr(cfg, "nuclei_scan_strategy", ""),
        feroxbuster_enabled=cfg.feroxbuster_enabled,
        feroxbuster_words_wordlist=resolve_wordlist(cfg.feroxbuster_words_wordlist),
        feroxbuster_files_wordlist=resolve_wordlist(cfg.feroxbuster_files_wordlist),
        feroxbuster_threads=cfg.feroxbuster_threads,
        feroxbuster_depth=cfg.feroxbuster_depth,
        feroxbuster_rate_limit=cfg.feroxbuster_rate_limit,
        feroxbuster_rate_mode=getattr(cfg, "feroxbuster_rate_mode", "auto_tune_capped"),
        feroxbuster_scan_limit=cfg.feroxbuster_scan_limit,
        ferox_mode=getattr(cfg, "ferox_mode", "w"),
        ferox_wordlist_size=getattr(cfg, "ferox_wordlist_size", "m"),
        ferox_custom_wordlist=getattr(cfg, "ferox_custom_wordlist", ""),
        ffuf_wordlist_size=getattr(cfg, "ffuf_wordlist_size", "m"),
        feroxbuster_progress_interval=getattr(cfg, "feroxbuster_progress_interval", 30),
        feroxbuster_stuck_timeout=getattr(cfg, "feroxbuster_stuck_timeout", 600),
        nomore403_enabled=getattr(cfg, "nomore403_enabled", True),
        nomore403_script=getattr(cfg, "nomore403_script", "nomore403"),
        nomore403_payloads_dir=getattr(cfg, "nomore403_payloads_dir", ""),
        nomore403_safe_mode=getattr(cfg, "nomore403_safe_mode", True),
        httpx_enabled=getattr(cfg, "httpx_enabled", True),
        httpx_retries=getattr(cfg, "httpx_retries", 3),
        katana_enabled=getattr(cfg, "katana_enabled", True),
        katana_depth=getattr(cfg, "katana_depth", 2),
        gau_enabled=getattr(cfg, "gau_enabled", True),
        gau_extra=getattr(cfg, "gau_extra", []),
        feroxbuster_parallel=cfg.feroxbuster_parallel,
        feroxbuster_extensions=cfg.feroxbuster_extensions,
        feroxbuster_status_codes=getattr(cfg, "feroxbuster_status_codes",
                                         "200,204,301,302,307,308,401,403,405,500"),
        feroxbuster_extra=cfg.feroxbuster_extra,
        ffuf_enabled=getattr(cfg, "ffuf_enabled", True),
        ffuf_wordlist=resolve_wordlist(getattr(cfg, "ffuf_wordlist",
                              "/usr/share/seclists/Discovery/Web-Content/raft-large-directories.txt")),
        ffuf_words_wordlist=resolve_wordlist(getattr(cfg, "ffuf_words_wordlist",
                              "/usr/share/seclists/Discovery/Web-Content/raft-large-directories.txt")),
        ffuf_files_wordlist=resolve_wordlist(getattr(cfg, "ffuf_files_wordlist",
                              "/usr/share/seclists/Discovery/Web-Content/raft-large-files-lowercase.txt")),
        ffuf_extensions=getattr(cfg, "ffuf_extensions", "php,html,txt,asp,aspx,jsp,json"),
        ffuf_dirs_only=getattr(cfg, "ffuf_dirs_only", True),
        ffuf_progress_interval=getattr(cfg, "ffuf_progress_interval", 30),
        forward_proxy=(_forward_proxy_from_runmode()
                       or getattr(cfg, "forward_proxy", "")),
        ffuf_match_codes=getattr(cfg, "ffuf_match_codes",
                                 "200,204,301,302,307,308,401,403,405,500"),
        ffuf_threads=getattr(cfg, "ffuf_threads", 3),
        ffuf_rate=getattr(cfg, "ffuf_rate", 0),
        ffuf_extra=getattr(cfg, "ffuf_extra", []),
        ffuf_feed_feroxbuster=getattr(cfg, "ffuf_feed_feroxbuster", True),
        testssl_enabled=cfg.testssl_enabled,
        testssl_jsonfile=cfg.testssl_jsonfile,
        testssl_phone_out=cfg.testssl_phone_out,
        testssl_add_ca=cfg.testssl_add_ca,
        testssl_extra=cfg.testssl_extra,
    )


def _confirm(prompt: str, assume_yes: bool = False) -> bool:
    from .runmode import is_unattended
    if assume_yes or is_unattended():
        return True
    try:
        ans = input(f"{prompt} [y/N] ").strip().lower()
    except EOFError:
        return False
    return ans in ("y", "yes")


def _choose(prompt: str, options: dict[str, str], default: str,
            assume_yes: bool = False) -> str:
    """Single-choice prompt. options maps an input key -> description.
    Returns the chosen key, or `default` when non-interactive/unattended."""
    from .runmode import is_unattended
    if assume_yes or is_unattended():
        return default
    opt_str = "  ".join(f"[{k}] {v}" for k, v in options.items())
    try:
        ans = input(f"{prompt}\n  {opt_str}\n  choice (default {default}): ").strip().lower()
    except EOFError:
        return default
    return ans if ans in options else default


def _ask_text(prompt: str, default: str = "") -> str:
    """Free-text prompt. Returns the entered string, or `default` on empty/EOF
    or when running unattended."""
    from .runmode import is_unattended
    if is_unattended():
        return default
    try:
        ans = input(f"{prompt} ").strip()
    except EOFError:
        return default
    return ans or default


def emit_target_files(outdir: Path,
                      web_probes: list[ProbeResult],
                      groups: dict[str, list[ClassifiedEndpoint]],
                      recon_domains=None) -> dict[str, Path]:
    """Write the input files each tool consumes. Returns a map of name->path.

    recon_domains: read-only set of operator-entered recon domains, used ONLY as a
    confirmation key for one case (below). It is never scanned wholesale.
    """
    outdir.mkdir(parents=True, exist_ok=True)
    paths: dict[str, Path] = {}
    _recon = {str(d).strip().lower().rstrip(".") for d in (recon_domains or []) if d}

    def _norm_apex(h: str) -> str:
        h = (h or "").lower().rstrip(".")
        return h[4:] if h.startswith("www.") else h

    def _redirect_dest_if_recon(p):
        """If this redirect's destination host is one of the operator-entered recon
        domains (exact match, modulo a leading www.), return (dest_url, dest_host).
        This is a deterministic membership test against domains the operator
        declared — a target IP that 301s to *its own declared front door* is the
        same engagement, so we scan that FQDN too. No DNS guesswork. Anything else
        (SSO/IdP/CDN) is not a recon domain, so it's excluded as before."""
        if not _recon:
            return None
        loc = (p.redirect_location or "").strip()
        if not loc:
            return None
        from urllib.parse import urlparse
        try:
            dst = urlparse(loc if "://" in loc else f"//{loc}")
        except ValueError:
            return None
        host = (dst.hostname or "").lower().rstrip(".")
        if not host:
            return None
        if _norm_apex(host) not in {_norm_apex(d) for d in _recon}:
            return None
        scheme = dst.scheme or ("https" if loc.lower().startswith("https") else "https")
        port = f":{dst.port}" if dst.port else ""
        return (f"{scheme}://{host}{port}/", host)

    # Web URLs to scan -> nuclei + feroxbuster + ffuf.
    #
    # Redirect handling is nuanced:
    #  - We NEVER follow a redirect or scan its DESTINATION (frequently off-scope:
    #    MSO/Okta/SSO). That rule is absolute...
    #  - ...EXCEPT when the destination is one of the operator-entered recon
    #    domains: a target IP that 301s to its own declared FQDN front door is the
    #    same in-scope box, just named. That destination FQDN is recorded in the
    #    probe-derived web_urls list. Everything else stays excluded.
    #  - An in-scope host on 443 that redirects (e.g. to a Microsoft SSO login) is
    #    STILL scanned at the ORIGIN — the origin may be misconfigured even though
    #    it bounces to an IdP.
    #  - EXCEPTION: an http->https upgrade to the SAME host is redundant (we already
    #    scan the https form) and is dropped.
    def _is_http_to_https_self(p) -> bool:
        loc = (p.redirect_location or "").strip()
        if not loc or p.scheme != "http":
            return False
        # normalize the destination host (strip scheme, path, port)
        from urllib.parse import urlparse
        try:
            dst = urlparse(loc if "://" in loc else f"//{loc}")
            dst_host = (dst.hostname or "").lower()
        except ValueError:
            return False
        # same host and the destination is https -> pure scheme upgrade
        return (loc.lower().startswith("https") and dst_host == p.host.lower())

    live_urls = []
    confirmed_redirect_hosts: list[str] = []
    for p in web_probes:
        if not (p.scheme and p.status is not None):
            continue
        if not p.is_redirect:
            live_urls.append(p.url)                # normal live endpoint
        elif not _is_http_to_https_self(p):
            # in-scope origin that redirects off somewhere (e.g. SSO) — scan the
            # ORIGIN directly; we still never follow/scan the destination...
            live_urls.append(p.url)
            # ...UNLESS the destination is an operator-entered recon domain: that's
            # the confirmed real front door of this same target, so scan it too.
            dest = _redirect_dest_if_recon(p)
            if dest:
                live_urls.append(dest[0])
                confirmed_redirect_hosts.append(dest[1])
        # else: http->https self-upgrade — skip (https form already scanned)
    # de-dupe while preserving order
    _seen = set()
    _deduped = []
    for u in live_urls:
        if u not in _seen:
            _seen.add(u)
            _deduped.append(u)
    live_urls = _deduped
    web_file = outdir / "web_urls.txt"
    web_file.write_text("\n".join(live_urls) + ("\n" if live_urls else ""))
    paths["web_urls"] = web_file

    # Confirmed recon-domain redirect destinations: a target that 301s to its own
    # declared recon domain. Recorded here for operator awareness/reporting. (The
    # scan pool the fuzzers use is WebGet's urls.txt; such a FQDN is scanned only if
    # WebGet independently validated it.)
    if confirmed_redirect_hosts:
        crh = sorted(set(confirmed_redirect_hosts))
        rc_file = outdir / "confirmed_redirect_hosts.txt"
        rc_file.write_text("\n".join(crh) + "\n")
        paths["redirect_confirmed"] = rc_file
        print(f"[redirect] {len(crh)} target(s) redirect to a declared recon "
              f"domain: {', '.join(crh)}")

    # Redirect log: records where each redirect started and where it went. The
    # DESTINATION is never scanned; in-scope origins that redirect off-site are
    # still scanned at themselves (except http->https same-host upgrades).
    redirects = [p for p in web_probes if p.is_redirect]
    redir_lines = [
        f"{p.url}\t{p.status}\t{p.redirect_location or '(no Location header)'}"
        for p in redirects
    ]
    redir_file = outdir / "redirects.tsv"
    redir_file.write_text(
        ("# origin\tstatus\tredirected_to (destination NOT scanned)\n"
         + "\n".join(redir_lines) + ("\n" if redir_lines else ""))
    )
    paths["redirects"] = redir_file

    # TLS endpoints host:port -> testssl.sh
    tls_eps = sorted({f"{e.host}:{e.port}" for e in groups.get("tls", [])})
    tls_file = outdir / "tls_endpoints.txt"
    tls_file.write_text("\n".join(tls_eps) + ("\n" if tls_eps else ""))
    paths["tls_endpoints"] = tls_file

    # auth_surface + other -> banner dump for manual review (NOT auto-attacked)
    review_lines = []
    for cls in ("auth_surface", "other"):
        for e in groups.get(cls, []):
            review_lines.append(f"{cls}\t{e.host}:{e.port}\t{e.service}\t{e.banner}")
    review_file = outdir / "manual_review.tsv"
    review_file.write_text("\n".join(review_lines) + ("\n" if review_lines else ""))
    paths["manual_review"] = review_file

    return paths


def _log_and_run(cmd: list[str], command_log: Path, dry_run: bool,
                 log_path=None) -> int:
    """Run an external tool, recording the command AND streaming its full
    stdout+stderr to a per-tool log on disk.

    Why streaming (Popen + merged streams + line buffering) instead of
    capture_output: a scanner can run for an hour, so we must write output to
    disk AS IT HAPPENS — you can `tail -f` the log during the run, nothing
    buffers in memory, the log survives a hang/crash, and merging stderr into
    stdout avoids the classic two-pipe read deadlock. Without this the tools'
    own errors (timeouts, calibration failures, TLS rejections) scrolled past
    the terminal and were lost, making every failure a guessing game.

    log_path: where to write the tool's output. Defaults to a file next to the
    command_log named for the binary (e.g. <dir>/<tool>.log). Returns the exit
    code (or 0 on dry-run).
    """
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + "\n")
    if dry_run:
        print("[dry-run]", " ".join(cmd))
        return 0
    if log_path is None:
        tool = Path(cmd[0]).name or "tool"
        log_path = Path(command_log).parent / f"{tool}.log"
    try:
        # Binary mode ('ab'): tool output goes straight to disk as bytes, so
        # non-UTF-8 output (scanners emit raw bytes sometimes) can never crash a
        # decode step. stderr merged into stdout -> single stream, no read
        # deadlock.
        with open(log_path, "ab") as lf:
            lf.write(b"\n$ " + " ".join(cmd).encode("utf-8", "replace") + b"\n")
            lf.flush()
            proc = subprocess.Popen(cmd, stdout=lf, stderr=subprocess.STDOUT)
            return proc.wait()
    except OSError as e:
        # Never let a logging problem kill the run; fall back to an uncaptured
        # run so the tool still executes.
        print(f"[run] could not open log {log_path}: {e} — running uncaptured")
        return subprocess.run(cmd, check=False).returncode


def run_nuclei(tc: ToolConfig, web_file: Path, outdir: Path,
               command_log: Path, assume_yes: bool = False, dry_run: bool = False,
               takeover_only: bool = False, out_prefix: str = "nuclei") -> None:
    if not tc.nuclei_enabled:
        return
    if not _file_has_real_targets(web_file):
        label = "takeover" if takeover_only else "web"
        print(f"[nuclei] no {label} targets, skipping "
              f"(target file empty or blank-only: {web_file})")
        return
    if shutil.which("nuclei") is None and not dry_run:
        print("[nuclei] 'nuclei' not found on PATH — skipping")
        return
    # Phase-1 Scribe: always save the exact target list this tool ran against.
    try:
        from . import audit as _audit
        _audit.save_targets(outdir, out_prefix,
                            web_file.read_text(errors="replace").splitlines())
    except Exception:  # noqa: BLE001
        pass
    # Enforce the rate-limit cap. nuclei is loud; never let it exceed the cap
    # without the operator having consciously raised nuclei_max_rate_limit.
    rl = min(tc.nuclei_rate_limit, tc.nuclei_max_rate_limit)
    n = len(web_file.read_text(errors="replace").splitlines())
    if takeover_only:
        # takeover pass: runs ONLY the subdomain-takeover templates. Safe to run
        # against the broader pool (incl. not-in-scope gau/subdomain URLs) because
        # it only fingerprints dangling-DNS/unclaimed-resource responses — it does
        # NOT run the full vuln battery against off-scope hosts.
        print(f"[nuclei] TAKEOVER pass: {n} target(s) (incl. out-of-scope subs), "
              f"takeover templates only, -rl {rl}")
        prompt = "Run nuclei TAKEOVER-only pass against the full subdomain pool?"
    else:
        print(f"[nuclei] FULL pass: {n} in-scope web target(s), full template set, "
              f"-rl {rl}")
        prompt = "Run nuclei FULL template pass against the in-scope web list?"
    if not _confirm(prompt, assume_yes):
        print("[nuclei] skipped by operator")
        return
    # Output: human-readable txt findings plus a JSONL file for the reporting
    # module to parse (severity, template, matched URL) without scraping text.
    # -stats prints periodic progress to stderr so a slow run doesn't look hung.
    out_txt = outdir / f"{out_prefix}.txt"
    out_jsonl = outdir / f"{out_prefix}.jsonl"

    # NOTE: the "single-line" mode (which piped nuclei stdout to DEVNULL and showed
    # one \r status line) is intentionally NOT used right now — we do not hide the
    # tool's output while the pipeline is still being proven out. Everything runs
    # through the classic STREAMING path below, where nuclei's normal output and
    # live findings are visible. (nuclei_single_line is retained for later but no
    # longer routes here.)

    # --- classic streaming mode (findings print live) ---
    cmd = ["nuclei", "-l", str(web_file), "-rl", str(rl),
           "-o", str(out_txt), "-jsonl-export", str(out_jsonl)]
    if takeover_only:
        cmd += ["-tags", "takeover"]      # ONLY subdomain-takeover templates
    elif getattr(tc, "nuclei_scan_strategy", ""):
        # opt-in only; default "" leaves nuclei on its native (template-spray)
        # strategy, matching the known-good manual run
        cmd += ["-ss", tc.nuclei_scan_strategy]
    if tc.nuclei_stats:
        cmd += ["-stats", "-stats-interval", str(tc.nuclei_stats_interval)]
    # Same forwarding-proxy routing as the single-line path / ffuf / feroxbuster.
    if getattr(tc, "forward_proxy", ""):
        cmd += ["-proxy", tc.forward_proxy]
    cmd += [*tc.nuclei_extra]
    _log_and_run(cmd, command_log, dry_run)
    if not dry_run:
        print(f"[nuclei] findings: {out_txt}  |  structured: {out_jsonl}")
        _nuclei_detect_outcome(outdir, out_prefix, out_jsonl, takeover_only)


def _nuclei_detect_outcome(outdir, prefix, out_jsonl, takeover_only=False,
                           requests_sent=None, errors_seen=None):
    """Nuclei success/failure verdict.

    Operator rule: on a FULL pass against live webapps, 0 findings is ALWAYS a
    failure — nuclei's full template set includes many info-severity checks, so a
    real scan of live hosts never legitimately returns zero. When nuclei's stats
    are available (single-line path), the error rate NAMES the cause: a high error
    ratio => unreachable targets (proxy/DNS/TLS); a low error ratio with 0 findings
    => templates not loaded, WAF blackhole, or proxy swallowing responses. Non-zero
    findings with a high error ratio are flagged DEGRADED (partial results).
    Takeover passes are exempt (they legitimately match nothing)."""
    if takeover_only:
        return
    from pathlib import Path
    n = 0
    try:
        p = Path(out_jsonl)
        if p.exists():
            n = sum(1 for ln in p.read_text(errors="replace").splitlines() if ln.strip())
    except OSError:
        n = 0
    try:
        from . import audit as _audit

        have_stats = (requests_sent is not None and errors_seen is not None)
        err_ratio = (errors_seen / max(1, requests_sent)) if have_stats and requests_sent else None

        # --- 0 findings on a FULL pass against live webapps is ALWAYS a failure. ---
        # nuclei's full template set includes a large body of info-severity checks
        # (ssl-issuer, missing-security-headers, tech-detect, waf-detect, dns-*,
        # etc.), so a real scan of live hosts never legitimately returns zero. If
        # it did, the scan did not actually reach the targets. Report it as a
        # failure and, when stats are available, NAME the likely cause.
        if n == 0:
            if err_ratio is not None and err_ratio >= 0.5:
                msg = (f"TOTAL FAILURE: nuclei errored on {errors_seen} of "
                       f"{requests_sent} requests ({err_ratio*100:.0f}%) and "
                       f"returned 0 findings — targets unreachable as invoked. "
                       f"Check the forwarding proxy is passed (-proxy), DNS/"
                       f"resolvers under the run's user, and TLS/host reachability.")
            elif err_ratio is not None:
                msg = (f"TOTAL FAILURE: nuclei returned 0 findings despite "
                       f"{requests_sent} requests at a low error rate "
                       f"({err_ratio*100:.0f}%) — a full pass on live webapps "
                       f"should surface info-level findings. Suspect templates not "
                       f"loaded/updated, a WAF blackholing responses, or a proxy "
                       f"swallowing them. Verify nuclei -update-templates and the "
                       f"target set by hand.")
            else:
                msg = ("TOTAL FAILURE: nuclei returned 0 findings on a live webapp "
                       "target set — a full pass should never be empty. Check "
                       "connectivity / proxy / templates / rate-limiting.")
            _audit.append_error(outdir, prefix, msg, completed=False)
            return

        # --- non-zero findings: healthy, but warn on degraded runs ---
        if err_ratio is not None and err_ratio >= 0.5:
            _audit.append_error(
                outdir, prefix,
                f"DEGRADED: nuclei returned {n} finding(s) but errored on "
                f"{errors_seen}/{requests_sent} requests ({err_ratio*100:.0f}%) — "
                f"results are partial; fix reachability (proxy/DNS/rate) and re-run.",
                completed=True)
            return
        if n < 5:
            _audit.append_error(
                outdir, prefix,
                f"RATE-LIMIT ADJUSTMENT NEEDED: nuclei returned only {n} match(es) "
                f"(<5) — likely throttled; slow it down and re-run",
                completed=True)
    except Exception:  # noqa: BLE001
        pass


_NUCLEI_SEV_ORDER = ["critical", "high", "medium", "low", "info", "unknown"]


def _print_nuclei_summary(out_jsonl: Path) -> None:
    """Read nuclei.jsonl and print all findings grouped by host, severity-first."""
    import json as _json
    if not out_jsonl.exists() or out_jsonl.stat().st_size == 0:
        print("[nuclei] no findings.")
        return
    by_host: dict[str, list[dict]] = {}
    for ln in out_jsonl.read_text(errors="replace").splitlines():
        ln = ln.strip()
        if not ln:
            continue
        try:
            f = _json.loads(ln)
        except ValueError:
            continue
        host = (f.get("host") or f.get("matched-at") or f.get("url") or "unknown")
        by_host.setdefault(host, []).append(f)

    total = sum(len(v) for v in by_host.values())
    if not total:
        print("[nuclei] no findings.")
        return

    print(f"\n===== nuclei findings ({total} across {len(by_host)} host(s)) =====")
    for host in sorted(by_host):
        findings = by_host[host]
        findings.sort(key=lambda x: _NUCLEI_SEV_ORDER.index(
            (x.get("info", {}).get("severity", "unknown") or "unknown").lower())
            if (x.get("info", {}).get("severity", "unknown") or "unknown").lower()
            in _NUCLEI_SEV_ORDER else len(_NUCLEI_SEV_ORDER))
        print(f"\n  {host}  ({len(findings)})")
        for f in findings:
            info = f.get("info", {})
            sev = (info.get("severity", "unknown") or "unknown").upper()
            name = info.get("name", f.get("template-id", "?"))
            matched = f.get("matched-at", "")
            print(f"    [{sev:>8}] {name}"
                  + (f"  -> {matched}" if matched and matched != host else ""))
    print("\n=====================================================")


def _feroxbuster_rate_flags(tc: "ToolConfig") -> list[str]:
    """Build the request-rate CLI flags for feroxbuster from the configured mode.

    feroxbuster throttles adaptively in-process (back off on errors, recover when
    clean), so we SELECT one of its native modes rather than wrapping it:

      auto_tune_capped   -> ["--auto-tune", "--rate-limit", N]
                            Adaptive, capped at N: starts at N, drops on errors,
                            climbs back, never exceeds N. Needs feroxbuster>=2.13.1
                            (older builds reject --auto-tune with --rate-limit).
      fixed              -> ["--rate-limit", N]              (hard cap, any version)
      auto_tune_uncapped -> ["--auto-tune"]                 (adaptive, no ceiling)
      off                -> []                               (feroxbuster default)

    An unknown mode falls back to "fixed" (the safe, version-agnostic choice).
    """
    mode = (getattr(tc, "feroxbuster_rate_mode", "auto_tune_capped") or "").strip()
    rate = str(tc.feroxbuster_rate_limit)
    if mode == "off":
        return []
    if mode == "auto_tune_uncapped":
        return ["--auto-tune"]
    if mode == "auto_tune_capped":
        return ["--auto-tune", "--rate-limit", rate]
    # "fixed" and any unrecognized value: plain hard cap.
    return ["--rate-limit", rate]


def run_feroxbuster(tc: ToolConfig, web_file: Path, outdir: Path,
                    command_log: Path, assume_yes: bool = False, dry_run: bool = False) -> None:
    if not tc.feroxbuster_enabled:
        return
    if not _file_has_real_targets(web_file):
        print(f"[feroxbuster] no web targets, skipping "
              f"(target file empty or blank-only: {web_file})")
        return
    if shutil.which("feroxbuster") is None and not dry_run:
        print("[feroxbuster] 'feroxbuster' not found on PATH — skipping")
        return
    # Phase-1 Scribe: save the target list feroxbuster ran against.
    try:
        from . import audit as _audit
        _audit.save_targets(outdir, "feroxbuster", web_file.read_text(errors="replace").splitlines())
    except Exception:  # noqa: BLE001
        pass

    n = len(web_file.read_text(errors="replace").splitlines())
    print(f"[feroxbuster] {n} web targets | -t {tc.feroxbuster_threads} "
          f"-d {tc.feroxbuster_depth} --rate-limit {tc.feroxbuster_rate_limit} "
          f"--scan-limit {tc.feroxbuster_scan_limit}")
    if not _confirm("Run feroxbuster against the web target list?", assume_yes):
        print("[feroxbuster] skipped by operator")
        return

    # Wordlist mode. Extensions ride with the WORDS pass only (they manufacture
    # filenames from path names: admin -> admin.php). The FILES list already
    # contains real filenames, so it runs bare (appending -x would give
    # index.php.php). "both" = words+ext pass, then files-bare pass.
    from .runmode import is_unattended, answer as _rm_answer
    if is_unattended():
        # stash wins if the interview ran this session; otherwise fall back to
        # THIS client's configured value (set in the preflight), not a literal.
        choice = _rm_answer("ferox_mode", getattr(tc, "ferox_mode", "w"))
    else:
        choice = _choose(
            "Wordlist mode?",
            {"w": "words + extensions",
             "f": "files only (no extensions)",
             "b": "both (words+ext, then files-bare)",
             "c": "custom wordlist (you provide the path)"},
            default="w", assume_yes=assume_yes,
        )
    passes: list[tuple[str, str, bool]] = []  # (label, wordlist, use_extensions)
    if choice == "c":
        # Custom path for maximum flexibility, with its own extension choice.
        if is_unattended():
            # stash wins if the interview ran this session; else fall back to
            # THIS client's configured value (persisted in the preflight), not
            # a literal — so the campaign child honors a per-client custom path.
            path = str(_rm_answer("ferox_custom_wordlist",
                                  getattr(tc, "ferox_custom_wordlist", "")) or "").strip()
        else:
            path = _ask_text("Path to custom wordlist:", default="").strip()
        if not path:
            print("[feroxbuster] no custom wordlist path given, skipping")
            return
        if not Path(path).is_file() and not dry_run:
            print(f"[feroxbuster] custom wordlist not found: {path} — skipping")
            return
        use_ext = _confirm("Apply file extensions to the custom wordlist?",
                           assume_yes=False if not assume_yes else True)
        passes.append(("custom", path, use_ext))
    else:
        from .ffuf_tool import _prompt_wordlist
        from . import wordlist_select
        # feroxbuster uses TWO wordlists (words/directories, and files) — prompt
        # for each independently with a small/medium/large chooser (large flagged
        # EXTREME). This is why feroxbuster asks twice: directory discovery and
        # file discovery genuinely use different lists. Unattended uses defaults.
        default_size = _rm_answer("ferox_wordlist_size",
                                  getattr(tc, "ferox_wordlist_size", "m")) \
            if is_unattended() else "m"

        if choice in ("w", "b"):
            wl = wordlist_select.prompt_size("words", "feroxbuster",
                                             default_size=default_size, dry_run=dry_run)
            if not wl:
                wl = tc.feroxbuster_words_wordlist
            if not dry_run and not Path(wl).is_file():
                print(f"[feroxbuster] words wordlist not found: {wl}")
                wl = _prompt_wordlist(wl, "feroxbuster words", dry_run)
            if wl:
                passes.append(("words", wl, True))
        if choice in ("f", "b"):
            wl = wordlist_select.prompt_size("files", "feroxbuster",
                                             default_size=default_size, dry_run=dry_run)
            if not wl:
                wl = tc.feroxbuster_files_wordlist
            if not dry_run and not Path(wl).is_file():
                print(f"[feroxbuster] files wordlist not found: {wl}")
                wl = _prompt_wordlist(wl, "feroxbuster files", dry_run)
            if wl:
                passes.append(("files", wl, False))
    if not passes and not dry_run:
        print("[feroxbuster] no valid wordlist — skipping")
        return

    # C0: run feroxbuster PER HOST, not as one --stdin batch. A single batch
    # means one bad target can bail the whole run and the shared -o JSON is never
    # flushed (the "config-only file" symptom). Per-host runs each write their own
    # feroxbuster_<host>_<port>_<label>.json, so one host failing never loses the
    # others; the report globs feroxbuster_*.json and picks them all up at the end.
    # No --parallel (the per-host loop replaces it; feroxbuster is still
    # multi-threaded per host via -t).
    import threading, time as _time
    from urllib.parse import urlsplit
    from . import resources

    targets = [t.strip() for t in web_file.read_text(errors="replace").splitlines() if t.strip()]
    stuck_timeout = getattr(tc, "feroxbuster_stuck_timeout", 600)  # 10 min

    def _host_port_label(target: str) -> str:
        parts = urlsplit(target if "://" in target else "http://" + target)
        host = parts.hostname or "host"
        try:
            port = parts.port
        except ValueError:
            port = None
        if not port:
            port = 443 if parts.scheme == "https" else 80
        token = f"{host}_{port}"
        return "".join(c if (c.isalnum() or c in "-._") else "_" for c in token)

    def _run_one(target: str, out_json: Path, cmd: list) -> None:
        """Run feroxbuster against ONE target with its own progress meter + stuck
        detector; writes out_json independently. Exceptions are contained so the
        loop moves to the next host rather than aborting the whole pass."""
        stop_flag = {"done": False}
        proc_holder = {"proc": None}

        def _progress_meter(json_path: Path):
            last_line = ""
            last_done = -1
            last_advance = _time.time()
            for _ in range(30):
                if json_path.exists():
                    break
                _time.sleep(1)
            while not stop_flag["done"]:
                try:
                    stats = _read_ferox_stats(json_path)
                    if stats:
                        done = stats.get("requests_made", 0)
                        total = stats.get("total_expected", 0)
                        dirs = stats.get("dirs_scanned", 0)
                        if total:
                            left = max(total - done, 0)
                            pct = (done / total * 100) if total else 0
                            line = (f"[ferox-progress] {target}: {left:,} reqs left · "
                                    f"{pct:.0f}% · {dirs} dir(s)")
                        else:
                            line = f"[ferox-progress] {target}: {done:,} reqs · {dirs} dir(s)"
                        if line != last_line:
                            print(line, flush=True)
                            last_line = line
                        if done > last_done:
                            last_done = done
                            last_advance = _time.time()
                        elif _time.time() - last_advance >= stuck_timeout:
                            mins = int(stuck_timeout // 60)
                            print(f"[feroxbuster] {target}: no progress for {mins} min "
                                  f"(stuck on runaway recursion?) — killing this host "
                                  f"and moving on.", flush=True)
                            p = proc_holder.get("proc")
                            if p and p.poll() is None:
                                p.terminate()
                                try:
                                    p.wait(timeout=10)
                                except Exception:  # noqa: BLE001
                                    p.kill()
                            return
                except Exception:  # noqa: BLE001
                    pass
                _time.sleep(tc.feroxbuster_progress_interval)

        meter = threading.Thread(target=_progress_meter, args=(out_json,), daemon=True)
        meter.start()
        proc = None
        try:
            proc = subprocess.Popen(cmd, **resources.popen_kwargs())
            proc_holder["proc"] = proc
            proc.wait()
        except KeyboardInterrupt:
            resources.kill_tree(proc)
            raise
        except Exception as e:  # noqa: BLE001
            resources.kill_tree(proc)
            print(f"[feroxbuster] {target}: error: {e} — moving to next host.")
        finally:
            if proc is not None and proc.poll() is None:
                resources.kill_tree(proc)
            stop_flag["done"] = True
            meter.join(timeout=2)

    for label, wordlist, use_ext in passes:
        # --json makes -o emit JSON-lines (structured, parseable for the findings
        # sheet). We do NOT pass -r/--redirects, so feroxbuster records redirect
        # responses (301/302/307/308) with their Location but does not follow them.
        for target in targets:
            hp = _host_port_label(target)
            out_json = outdir / f"feroxbuster_{hp}_{label}.json"
            debug_log = outdir / f"feroxbuster_{hp}_{label}.debug.log"
            cmd = [
                "feroxbuster", "-u", target,
                "-w", wordlist,
                "-t", str(tc.feroxbuster_threads),
                "-d", str(tc.feroxbuster_depth),
                # feroxbuster's native per-request log. This is where the real
                # reason a request failed shows up (connection closed, timeout,
                # TLS, etc.) — the thing that was previously invisible and made
                # 'Could not connect' impossible to diagnose. One file per target.
                "--debug-log", str(debug_log),
            ]
            cmd += _feroxbuster_rate_flags(tc)
            cmd += [
                "--scan-limit", str(tc.feroxbuster_scan_limit),
                "--insecure",   # target certs are frequently self-signed / IP-based
                "--json",
                "-o", str(out_json),
            ]
            sc = getattr(tc, "feroxbuster_status_codes", "").strip()
            if sc:
                cmd += ["-s", sc]
            # feroxbuster rejects --auto-tune and --auto-bail TOGETHER (they're
            # mutually exclusive: tune slows a struggling scan down and keeps it,
            # bail abandons a runaway directory). auto-tune wins here — when an
            # NOTE: no --auto-bail. feroxbuster erroring against a live target does
            # not mean the scan should quit — same reasoning as ffuf's health check
            # and nuclei running uncapped. Let it error; do not abandon the target.
            if getattr(tc, "forward_proxy", ""):
                cmd += ["--proxy", tc.forward_proxy]
            if use_ext:
                cmd += ["-x", tc.feroxbuster_extensions]
            cmd += tc.feroxbuster_extra

            with open(command_log, "a") as log:
                log.write(" ".join(cmd) + "\n")
            if dry_run:
                print(f"[dry-run] ({label}) " + " ".join(cmd))
                continue
            print(f"[feroxbuster] {label} pass · {target} -> {out_json}")
            _run_one(target, out_json, cmd)


def _read_ferox_stats(json_path: Path) -> dict | None:
    """Read the latest statistics event from feroxbuster's --json output.
    feroxbuster writes newline-delimited JSON; statistics lines have
    type == 'statistics'. Returns a normalized dict or None."""
    try:
        lines = json_path.read_text(errors="ignore").splitlines()
    except OSError:
        return None
    latest = None
    for ln in reversed(lines):          # newest stats last; scan from the end
        ln = ln.strip()
        if not ln or '"statistics"' not in ln and '"type"' not in ln:
            continue
        try:
            obj = json.loads(ln)
        except ValueError:
            continue
        if obj.get("type") == "statistics" or "requests" in obj:
            latest = obj
            break
    if latest is None:
        return None
    # feroxbuster stats keys vary by version; pull what we can
    return {
        "requests_made": latest.get("requests", latest.get("requests_made", 0)),
        "total_expected": latest.get("expected_per_scan", 0) * max(latest.get("total_scans", 1), 1)
                          if latest.get("expected_per_scan") else latest.get("total_expected", 0),
        "dirs_scanned": latest.get("dirs_scanned", latest.get("total_scans", 0)),
    }


def _save_tool_targets(outdir, tool, path):
    try:
        from . import audit as _a
        from pathlib import Path as _P
        f=_P(path)
        if f.exists(): _a.save_targets(outdir, tool, f.read_text(errors="replace").splitlines())
    except Exception: pass


def run_testssl(tc: ToolConfig, tls_file: Path, outdir: Path,
                command_log: Path, assume_yes: bool = False, dry_run: bool = False) -> None:
    if not tc.testssl_enabled:
        return
    if not tls_file.exists() or tls_file.stat().st_size == 0:
        print("[testssl] no tls endpoints, skipping")
        return
    eps = tls_file.read_text(errors="replace").splitlines()
    if shutil.which("testssl.sh") is None and not dry_run:
        print("[testssl] 'testssl.sh' not found on PATH — skipping "
              "(symlink it into /usr/local/bin)")
        return
    print(f"[testssl] {len(eps)} TLS endpoints (full run: cert chain, expiry, "
          f"self-signed, SAN/private-info, protocols)")
    if not _confirm("Run testssl.sh against the TLS endpoints?", assume_yes):
        print("[testssl] skipped by operator")
        return
    # testssl.sh tests one target at a time; iterate, one output file set each.
    # Full run (no --vulnerable narrowing) so the certificate section — chain of
    # trust, expiry, self-signed, and SANs that may leak internal IPs/hostnames —
    # is fully captured. Dual output: human-readable .log + structured .json
    # (--jsonfile-pretty) for the reporting module, which carries per-check
    # severity, host, port, and finding.
    for ep in eps:
        safe = ep.replace(":", "_")
        # --warnings batch: on a client/server problem (e.g. "no protocol
        # detected" on a dead host) testssl TERMINATES that scan instead of
        # blocking on the interactive 'say YES to proceed' prompt. Keeps the
        # unattended run moving; testssl is reliable on the no-protocol call.
        cmd = ["testssl.sh", "--quiet", "--warnings", "batch",
               "--logfile", str(outdir / f"testssl_{safe}.log")]
        if tc.testssl_jsonfile:
            cmd += ["--jsonfile-pretty", str(outdir / f"testssl_{safe}.json")]
        if tc.testssl_phone_out:
            cmd += ["--phone-out"]
        if tc.testssl_add_ca:
            cmd += ["--add-ca", tc.testssl_add_ca]
        cmd += [*tc.testssl_extra, ep]
        _log_and_run(cmd, command_log, dry_run)
        if not dry_run:
            print(f"[testssl] {ep} -> testssl_{safe}.log"
                  + (f" + testssl_{safe}.json" if tc.testssl_jsonfile else ""))


def run_sns(tc: ToolConfig, web_urls: "list[str]", outdir: Path,
            command_log: Path, assume_yes: bool = False, dry_run: bool = False) -> None:
    """SNS IIS short-name scanner, check-only mode, per resolved web URL.

    sw33tLie/sns. We run the vulnerability *check* only (not the full short-name
    enumeration), threads capped at 5. Each URL's stdout is captured to
    sns_<host>_<port>.txt; the scan summary keys a Y/N flag off whether the
    output reports the target as vulnerable.
    """
    if not tc.sns_enabled:
        return
    if not web_urls:
        print("[sns] no resolved web URLs, skipping")
        return
    if shutil.which("sns") is None and not dry_run:
        print("[sns] 'sns' binary not found on PATH — skipping (install sw33tLie/sns)")
        return
    print(f"[sns] {len(web_urls)} web URL(s), check-only, threads {tc.sns_threads}")
    if not _confirm("Run SNS (IIS short-name check) against the resolved web URLs?", assume_yes):
        print("[sns] skipped by operator")
        return
    for raw_url in web_urls:
        # Strip the redundant default port: https://host:443 -> https://host and
        # http://host:80 -> http://host (some tools mishandle the explicit default
        # port). Non-default ports (:8443, :8080) are kept. Same normalisation as
        # probe.build_web_url, applied here as a safety net regardless of how the
        # web_urls list was built.
        url = _strip_default_port(raw_url)
        # Derive host + explicit port for the FILENAME even when the URL dropped a
        # default port. sns_flags parses sns_<host>_<port>.txt and skips any name
        # without an underscore, so a bare sns_<host>.txt (80/443) would never show
        # a verdict — keep the port in the filename regardless of default-port
        # stripping in the URL itself.
        hostport_url = url.split("://", 1)[-1].split("/")[0]
        _host = hostport_url.split(":")[0]
        if ":" in hostport_url:
            _port = hostport_url.split(":")[1]
        else:
            _port = "443" if url.startswith("https") else "80"
        safe = f"{_host}_{_port}"
        out_txt = outdir / f"sns_{safe}.txt"
        # check-only: -c (check), -u <url>, -t threads. Flags follow the CLI; if
        # the installed build differs, sns_extra can adjust without code changes.
        cmd = ["sns", "--check", "-u", url, "-t", str(tc.sns_threads), *tc.sns_extra]
        with open(command_log, "a") as log:
            log.write(" ".join(cmd) + f"  > {out_txt}\n")
        if dry_run:
            print("[dry-run]", " ".join(cmd), ">", out_txt)
            continue
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=600)
            out_txt.write_text((res.stdout or "") + (res.stderr or ""))
            verdict = "VULNERABLE" if "VULNERABLE" in (res.stdout or "").upper() else "not vulnerable"
            print(f"[sns] {url} -> {verdict}")
            tilde_vuln = "VULNERABLE" in (res.stdout or "").upper()
            # IIS recon enrichment: when the host is IIS, run the recon suite
            # (internal-IP disclosure, shortscan if tilde-vulnerable, high-value
            # paths). Records manual exploit follow-ups without automating them.
            try:
                from . import iis_recon
                iis_out = outdir / f"iis_{safe}.txt"
                finding = iis_recon.process(
                    url, outdir, command_log, tilde_vulnerable=tilde_vuln,
                    server_header="Microsoft-IIS", tech="", dry_run=dry_run)
                if finding is not None:
                    lines = []
                    for row in finding.rows():
                        lines.append(" | ".join(row))
                    if lines:
                        iis_out.write_text("\n".join(lines) + "\n")
            except Exception as e:  # noqa: BLE001
                print(f"[iis] enrichment skipped: {e}")
        except subprocess.TimeoutExpired:
            out_txt.write_text("sns timeout\n")
            print(f"[sns] {url} -> timeout")
        except Exception as e:  # noqa: BLE001
            out_txt.write_text(f"sns error: {e}\n")
            print(f"[sns] {url} -> error: {e}")


def run_sshaudit(tc: ToolConfig, ssh_endpoints: "list[tuple[str, int]]", outdir: Path,
                 command_log: Path, assume_yes: bool = False, dry_run: bool = False) -> None:
    """ssh-audit (jtesta) against detected SSH endpoints, JSON output.

    Each endpoint is host:port from the deep scan where the service is ssh. The
    JSON carries the recommendations and CVE data, which the report's SSH-Audit
    page surfaces. Output saved to sshaudit_<host>_<port>.json.
    """
    if not tc.sshaudit_enabled:
        return
    if not ssh_endpoints:
        print("[ssh-audit] no SSH endpoints, skipping")
        return
    if shutil.which("ssh-audit") is None and not dry_run:
        print("[ssh-audit] 'ssh-audit' not found on PATH — skipping (pip install ssh-audit)")
        return
    print(f"[ssh-audit] {len(ssh_endpoints)} SSH endpoint(s)")
    if not _confirm("Run ssh-audit against the detected SSH endpoints?", assume_yes):
        print("[ssh-audit] skipped by operator")
        return
    for host, port in ssh_endpoints:
        safe = f"{host}_{port}".replace(":", "_").replace("/", "_")
        out_json = outdir / f"sshaudit_{safe}.json"
        # -j JSON, -p port. Target host as positional. No color (implicit in JSON).
        cmd = ["ssh-audit", "-j", "-p", str(port), *tc.sshaudit_extra, host]
        with open(command_log, "a") as log:
            log.write(" ".join(cmd) + f"  > {out_json}\n")
        if dry_run:
            print("[dry-run]", " ".join(cmd), ">", out_json)
            continue
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=120)
            # ssh-audit writes JSON to stdout
            out_json.write_text(res.stdout or "{}")
            print(f"[ssh-audit] {host}:{port} -> {out_json.name}")
        except subprocess.TimeoutExpired:
            out_json.write_text('{"error": "timeout"}')
            print(f"[ssh-audit] {host}:{port} -> timeout")
        except Exception as e:  # noqa: BLE001
            out_json.write_text(f'{{"error": "{e}"}}')
            print(f"[ssh-audit] {host}:{port} -> error: {e}")
