"""Reusable sensitive-file pattern library.

A shared list of high-value / sensitive file indicators, usable by any tool that
hunts exposed files. Currently used by buckets.py (GrayHatWarfare cloud-bucket
search — keyword hints, regex patterns, and local triage flagging).

NOTE: file-enum (fileenum.py) is intentionally NOT wired to this — it hunts
metadata-rich DOCUMENTS (PDF/DOCX/etc. -> exiftool OSINT), a different purpose.
This library is available if we ever add a sensitive-file dimension there, but
file-enum's metadata-document hunting stays as-is.
"""
from __future__ import annotations

# High-value file categories -> the substrings that flag them. Grouped so the
# report/triage can say WHY a file was flagged, and so tools can pick subsets.
SENSITIVE_CATEGORIES = {
    "credentials": ["credential", "creds", "password", "passwd", ".htpasswd",
                    "secret", "token", ".aws/credentials", "id_rsa", "id_dsa",
                    "authorized_keys", ".ssh"],
    "keys_certs": [".pem", ".ppk", ".key", ".pfx", ".p12", ".kdbx", ".keystore",
                   ".jks", "privatekey", "private_key", ".asc", ".gpg"],
    "env_config": [".env", "env.", ".envrc", "config", "conf", "settings",
                   "web.config", "wp-config", "application.properties",
                   ".npmrc", ".dockercfg", ".docker/config", "appsettings"],
    "database": ["backup", ".bak", "dump", ".sql", "database", ".db",
                 ".sqlite", ".mdb", ".dbf", "mysqldump", "pg_dump"],
    "vcs": [".git/config", ".git-credentials", ".svn", ".gitignore-like"],
    "archives": [".zip", ".tar", ".gz", ".7z", ".rar", ".tgz", "export",
                 "archive"],
    "cloud": ["aws", "azure", "gcp", "terraform", ".tfstate", ".tfvars",
              "serviceaccount", "service-account"],
    "business": ["confidential", "internal", "payroll", "invoice", "ssn",
                 "salary", "financial", "contract", "nda"],
}

# flat list for simple substring triage (kept for backward compatibility)
SENSITIVE_HINTS = sorted({h for hints in SENSITIVE_CATEGORIES.values() for h in hints})

# Regex patterns targeting sensitive files directly, for server-side regex
# search (GrayHatWarfare Premium+). These match the WHOLE filename/path, per
# GrayHat's regex rules (they wrap as .*{regex}.* internally, but explicit is
# safer). Ordered best-shot-first: creds/keys/env before archives.
SENSITIVE_REGEXES = [
    r".*\.(env|envrc)$",
    r".*\.(pem|ppk|key|pfx|p12|kdbx|keystore|jks)$",
    r".*(id_rsa|id_dsa|authorized_keys).*",
    r".*\.(sql|bak|dump|sqlite|db|mdb|dbf)$",
    r".*(wp-config|web\.config|appsettings|application\.properties).*",
    r".*(\.git/config|\.git-credentials|\.aws/credentials|\.htpasswd).*",
    r".*\.(tfstate|tfvars)$",
    r".*(credential|password|secret|token).*",
]


def categorize(filename: str, fullpath: str = "") -> str:
    """Return the sensitive category a file matches (or '' if none).
    Best-shot-first: checks the highest-value categories before lower ones."""
    hay = (filename + " " + fullpath).lower()
    for cat in ("credentials", "keys_certs", "env_config", "database", "vcs",
                "cloud", "business", "archives"):
        for hint in SENSITIVE_CATEGORIES[cat]:
            if hint in hay:
                return cat
    return ""


def is_sensitive(filename: str, fullpath: str = "") -> str:
    """Y/'' triage flag — True if the file matches any sensitive indicator."""
    return "Y" if categorize(filename, fullpath) else ""
