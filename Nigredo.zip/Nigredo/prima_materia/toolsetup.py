#!/usr/bin/env python3
"""
toolsetup.py — install-command map + the --install-missing installer.

Single source of truth for how every external tool Nigredo can use gets
installed, plus the interactive installer that --install-missing drives and
setup.sh can reuse.

Design (agreed):
  - Full toolset: Go tools, apt/system tools, pip libs, and git-clone scripts.
  - `install_command()` returns the exact shell command to install each tool.
    Running an already-installed tool's command is a harmless no-op (go install
    updates, apt says newest, pip says satisfied), so the installer can just run
    the command without complex pre-checks.
  - Numbered interactive selection: list all MISSING tools numbered; the user
    picks 'all' or lists numbers to SKIP (comma-separated). Strong nudge to
    install everything.
  - Remembered skips: choices persist to .nigredo_skip_tools next to run.py so
    re-runs don't re-nag about deliberately-skipped tools.
  - Go PATH: after installing Go tools, ensure GOPATH/bin is on PATH and OFFER
    (strongly recommend) to append it to the shell profile — since Nigredo is
    typically run in a container/VM, being heavy-handed here is fine.
  - cloud_enum: apt package is 'cloud-enum' (hyphen); the command it installs is
    'cloud_enum' (underscore). We install the hyphen, verify the underscore.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from pathlib import Path

# each tool -> how to detect it, and how to install it.
#   check: ("bin", name) present on PATH | ("py", module) importable
#          ("file", path) exists
#   install: shell command string (run as-is)
#   kind: go|apt|pip|git|special (for grouping + PATH handling)
#   note: optional extra guidance shown to the user
TOOLS: dict[str, dict] = {
    # ---- Go tools (land in $GOPATH/bin, need PATH) ----
    "subfinder": {"check": ("bin", "subfinder"), "kind": "go",
                  "install": "go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest"},
    "shuffledns": {"check": ("bin", "shuffledns"), "kind": "go",
                   "install": "go install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest"},
    "dnsx": {"check": ("bin", "dnsx"), "kind": "go",
             "install": "go install github.com/projectdiscovery/dnsx/cmd/dnsx@latest"},
    "nuclei": {"check": ("bin", "nuclei"), "kind": "go",
               "install": "go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest"},
    "cvemap": {"check": ("bin", "cvemap"), "kind": "go",
               "install": "go install github.com/projectdiscovery/cvemap/cmd/cvemap@latest",
               "note": "CVE lookup on discovered tech; may need a free PDCP key "
                       "(run 'cvemap -auth') for full API access"},
    "ffuf": {"check": ("bin", "ffuf"), "kind": "go",
             "install": "go install github.com/ffuf/ffuf/v2@latest"},
    "feroxbuster": {"check": ("bin", "feroxbuster"), "kind": "go",
                    "install": "go install github.com/epi052/feroxbuster@latest",
                    "note": "or: apt install feroxbuster (Kali)"},
    "gitleaks": {"check": ("bin", "gitleaks"), "kind": "go",
                 "install": "go install github.com/zricethezav/gitleaks/v8@latest",
                 "note": "module path is zricethezav/gitleaks even though the repo "
                         "moved to gitleaks/gitleaks"},
    "trufflehog": {"check": ("bin", "trufflehog"), "kind": "script",
                   "install": "curl -sSfL https://raw.githubusercontent.com/"
                              "trufflesecurity/trufflehog/main/scripts/install.sh "
                              "| sudo sh -s -- -b /usr/local/bin",
                   "note": "go install fails (replace directives); use the "
                           "official install script instead"},
    "sns": {"check": ("bin", "sns"), "kind": "go",
            "install": "go install github.com/sw33tLie/sns@latest"},
    "shortscan": {"check": ("bin", "shortscan"), "kind": "go",
                  "install": "go install github.com/bitquark/shortscan/cmd/shortscan@latest",
                  "note": "IIS 8.3 shortname enumeration (richer than the sns Y/N "
                          "check); used by iis_recon when a host is tilde-vulnerable"},
    "jsluice": {"check": ("bin", "jsluice"), "kind": "go",
                "install": "go install github.com/BishopFox/jsluice/cmd/jsluice@latest",
                "note": "used by FunnelWeb Phase B (JS URL/secret extraction)"},
    "nomore403": {"check": ("bin", "nomore403"), "kind": "git",
                  "install":
                      "( [ -d ~/tools/nomore403/.git ] "
                      "  || git clone https://github.com/devploit/nomore403 ~/tools/nomore403 ) "
                      "&& ( cd ~/tools/nomore403 "
                      "     && git fetch --tags --force "
                      "     && git checkout -f \"$(git describe --tags \"$(git rev-list --tags --max-count=1)\")\" "
                      "     && go build ) "
                      "&& sudo ln -sf ~/tools/nomore403/nomore403 /usr/local/bin/nomore403",
                  "note": "403-bypass tester. Clones/updates ~/tools/nomore403 and "
                          "checks out the LATEST release tag each run (the old plain "
                          "'git clone' failed silently if the folder existed, leaving "
                          "a stale build). No sudo for clone/build; only the final "
                          "symlink needs sudo. KEEP the folder — it needs its "
                          "payloads/ dir at runtime. Needs curl on PATH for a few "
                          "techniques."},
    "httpx": {"check": ("bin", "httpx"), "kind": "go",
              "install": "go install github.com/projectdiscovery/httpx/cmd/httpx@latest",
              "note": "fast HTTP prober + tech/CDN fingerprinting (ProjectDiscovery). "
                      "NOTE: this is the PD httpx, not the python httpx lib."},
    "katana": {"check": ("bin", "katana"), "kind": "go",
               "install": "go install github.com/projectdiscovery/katana/cmd/katana@latest",
               "note": "fast crawler; discovers URLs to feed nuclei/403 pool"},
    "gau": {"check": ("bin", "gau"), "kind": "go",
            "install": "go install github.com/lc/gau/v2/cmd/gau@latest",
            "note": "passive historical URL mining (Wayback/CommonCrawl/OTX/URLScan); "
                    "key-free by default"},
    # ---- apt / system tools ----
    "nmap": {"check": ("bin", "nmap"), "kind": "apt",
             "install": "sudo apt install -y nmap"},
    "cloud-enum": {"check": ("bin", "cloud_enum"), "kind": "apt",
                   "install": "sudo apt install -y cloud-enum",
                   "note": "package is 'cloud-enum' (hyphen); command is "
                           "'cloud_enum' (underscore). Or git clone "
                           "github.com/initstring/cloud_enum"},
    "dnsrecon": {"check": ("bin", "dnsrecon"), "kind": "apt",
                 "install": "sudo apt install -y dnsrecon"},
    "dnstwist": {"check": ("bin", "dnstwist"), "kind": "apt",
                 "install": "sudo apt install -y dnstwist"},
    "ssh-audit": {"check": ("bin", "ssh-audit"), "kind": "apt",
                  "install": "sudo apt install -y ssh-audit"},
    "exiftool": {"check": ("bin", "exiftool"), "kind": "apt",
                 "install": "sudo apt install -y libimage-exiftool-perl"},
    "retire": {"check": ("bin", "retire"), "kind": "npm",
               "install": "sudo npm install -g retire",
               "note": "retire.js (FunnelWeb) — needs Node/npm; sudo for the global install"},
    "semgrep": {"check": ("bin", "semgrep"), "kind": "pip", "pip_pkg": "semgrep"},
    "testssl.sh": {"check": ("bin", "testssl.sh"), "kind": "git",
                   "install": "git clone --depth 1 https://github.com/drwetter/testssl.sh /opt/testssl.sh "
                              "&& sudo ln -sf /opt/testssl.sh/testssl.sh /usr/local/bin/testssl.sh",
                   "note": "git clone + symlink into PATH"},
    # ---- pip libs (into the SAME interpreter running nigredo) ----
    # 'pip_pkg' is the package name; the actual command is built at runtime from
    # sys.executable so it installs into the exact Python that imports it (avoids
    # the uv-venv-vs-system-python mismatch where uv installs somewhere the
    # running python can't see).
    "serpapi": {"check": ("py", "serpapi"), "kind": "pip",
                "pip_pkg": "serpapi",
                "note": "the code does `from serpapi import search` (the newer "
                        "'serpapi' package), NOT the legacy 'google-search-results' "
                        "(which exposes GoogleSearch). Both import as 'serpapi' and "
                        "shadow each other, so install 'serpapi'. Needed by "
                        "fileenum + emailenum."},
    "patchright": {"check": ("py", "patchright"), "kind": "pip",
                   "pip_pkg": "patchright", "post": "patchright_browser",
                   "note": "needed by FunnelWeb; the chromium browser is "
                           "installed as a follow-up step"},
    "jsbeautifier": {"check": ("py", "jsbeautifier"), "kind": "pip",
                     "pip_pkg": "jsbeautifier",
                     "note": "FunnelWeb Phase B: beautifies minified JS before scanning"},
    "defusedxml": {"check": ("py", "defusedxml"), "kind": "pip",
                   "pip_pkg": "defusedxml",
                   "note": "hard import in nmap_parser / nessus_import / pipeline "
                           "(XXE-safe XML parsing). Also pinned in requirements.txt; "
                           "listed here so install-missing can repair a broken venv."},
    # --- lib-only deps the PREFLIGHT gates tools on (PYLIB_REQUIREMENTS). All are
    #     pinned in requirements.txt; listed here so `install-missing` can repair a
    #     venv where the bulk install partially failed. Import-name != pip-name for
    #     several, which is why a plain `pip install <import-name>` doesn't fix them.
    "dnspython": {"check": ("py", "dns"), "kind": "pip",
                  "pip_pkg": "dnspython",
                  "note": "REQUIRED by dkim (DKIM selector brute-force) and the "
                          "dnstwist NS backfill. Imports as 'dns' but the pip "
                          "package is 'dnspython' — this mismatch is why a missing "
                          "'dns' lib keeps dkim at [SKIP]."},
    "requests": {"check": ("py", "requests"), "kind": "pip",
                 "pip_pkg": "requests",
                 "note": "core HTTP lib; gates fileenum/buckets/snov/trufflehog/"
                         "gitleaks readiness in preflight."},
    "aiohttp": {"check": ("py", "aiohttp"), "kind": "pip",
                "pip_pkg": "aiohttp",
                "note": "REQUIRED by FunnelWeb's async JS/PHP download phase."},
    "aiofiles": {"check": ("py", "aiofiles"), "kind": "pip",
                 "pip_pkg": "aiofiles",
                 "note": "REQUIRED by FunnelWeb's async file writes."},
    "python-magic": {"check": ("py", "magic"), "kind": "pip",
                     "pip_pkg": "python-magic",
                     "note": "FunnelWeb content-type sniffing. Imports as 'magic' "
                             "but the pip package is 'python-magic'; also needs the "
                             "system libmagic (Debian/Kali: apt install libmagic1)."},
}


def _installed(tool: str) -> bool:
    spec = TOOLS.get(tool, {})
    check = spec.get("check")
    if not check:
        return False
    kind, val = check
    if kind == "bin":
        return shutil.which(val) is not None
    if kind == "py":
        import importlib.util
        return importlib.util.find_spec(val) is not None
    if kind == "file":
        return Path(val).is_file()
    return False


def missing_tools() -> list[str]:
    """Names of every mapped tool NOT currently present."""
    return [t for t in TOOLS if not _installed(t)]


def _uv_bin() -> str:
    """Locate uv even under sudo (sudo often strips the user's cargo/bin from
    PATH). Falls back to common install locations, then bare 'uv'."""
    import shutil as _sh
    found = _sh.which("uv")
    if found:
        return found
    for cand in (Path.home() / ".cargo/bin/uv",
                 Path.home() / ".local/bin/uv",
                 Path("/usr/local/bin/uv")):
        if cand.is_file():
            return str(cand)
    # sudo case: check the invoking user's home too
    sudo_user = os.environ.get("SUDO_USER")
    if sudo_user:
        try:
            import pwd
            home = Path(pwd.getpwnam(sudo_user).pw_dir)
            for cand in (home / ".cargo/bin/uv", home / ".local/bin/uv"):
                if cand.is_file():
                    return str(cand)
        except (KeyError, ImportError):
            pass
    return "uv"   # last resort — assume it's on PATH


def install_command(tool: str) -> str:
    spec = TOOLS.get(tool, {})
    # pip tools: install with uv into the ACTIVE venv (the one nigredo runs in,
    # since you launch via `uv run python run.py`). uv installs into the venv it
    # detects, so deps land exactly where nigredo imports them.
    if spec.get("kind") == "pip" and spec.get("pip_pkg"):
        return f"{_uv_bin()} pip install {spec['pip_pkg']}"
    return spec.get("install", "")


def tool_note(tool: str) -> str:
    return TOOLS.get(tool, {}).get("note", "")


# ---- remembered skips ----

def _skip_file() -> Path:
    # next to run.py (the top folder) — cwd is typically that folder
    return Path("./.nigredo_skip_tools")


def load_skips() -> set:
    f = _skip_file()
    if f.is_file():
        return {ln.strip() for ln in f.read_text().splitlines() if ln.strip()}
    return set()


def save_skips(skips: set) -> None:
    try:
        _skip_file().write_text("\n".join(sorted(skips)) + "\n")
    except OSError:
        pass


# ---- Go PATH handling ----

def _gobin() -> str:
    try:
        out = subprocess.run(["go", "env", "GOPATH"], capture_output=True,
                             text=True, errors="replace", timeout=10)
        gopath = out.stdout.strip()
        if gopath:
            return str(Path(gopath) / "bin")
    except Exception:  # noqa: BLE001
        pass
    # fallback to the conventional location
    home = os.environ.get("HOME", "/root")
    return str(Path(home) / "go" / "bin")


def ensure_go_path_offer() -> None:
    """If GOPATH/bin isn't on PATH, strongly recommend adding it to the shell
    profile so Go tools resolve both for Nigredo and in a manual shell."""
    gobin = _gobin()
    if gobin in os.environ.get("PATH", "").split(os.pathsep):
        return
    print(f"\n[!] Go tools install to {gobin}, which is NOT on your PATH.")
    print("    Without this, installed Go tools won't be found when you run "
          "them by hand.")
    print("    STRONGLY RECOMMENDED (especially in a container/VM):")
    profile = Path(os.environ.get("HOME", "/root")) / ".bashrc"
    line = f'export PATH="$PATH:{gobin}"'
    try:
        ans = input(f"    Append '{line}' to {profile}? [Y/n]: ").strip().lower()
    except EOFError:
        ans = "n"
    if ans in ("", "y", "yes"):
        try:
            with open(profile, "a") as f:
                f.write(f"\n# added by nigredo --install-missing\n{line}\n")
            print(f"    added to {profile}. Run 'source {profile}' or open a new "
                  f"shell to pick it up.")
        except OSError as e:
            print(f"    could not write {profile}: {e}")
            print(f"    add this line manually: {line}")
    else:
        print(f"    skipped. Add this yourself if Go tools go missing: {line}")


# ---- the interactive installer ----

def run_installer(only: list[str] | None = None) -> int:
    """Interactive numbered installer for missing tools.
    only: restrict to this subset (e.g. tools this run needs); default = all."""
    remembered = load_skips()
    miss = [t for t in missing_tools() if (only is None or t in only)]
    # don't re-nag about deliberately-skipped tools
    miss = [t for t in miss if t not in remembered]

    if not miss:
        print("[install] all mapped tools are present (or previously skipped). "
              "Nothing to do.")
        return 0

    print("\n" + "=" * 64)
    print(" MISSING TOOLS — you should install everything for full coverage")
    print("=" * 64)
    import sys as _sys
    print(f" pip tools install via uv into the active venv")
    print(f" (running python: {_sys.executable})")
    print(" launch nigredo with `uv run python run.py` so deps + runtime match")
    for i, t in enumerate(miss, 1):
        note = tool_note(t)
        print(f"  {i:2}. {t:14} {install_command(t)}")
        if note:
            print(f"      ({note})")
    print("\n  Enter 'all' to install everything, or list the NUMBERS to SKIP")
    print("  (comma-separated), e.g. '2,5' to skip #2 and #5.")
    try:
        choice = input("  choice [all]: ").strip().lower()
    except EOFError:
        choice = "all"

    skip_idx = set()
    if choice and choice != "all":
        for part in choice.replace(" ", "").split(","):
            if part.isdigit():
                skip_idx.add(int(part))

    to_install = [t for i, t in enumerate(miss, 1) if i not in skip_idx]
    skipped = [t for i, t in enumerate(miss, 1) if i in skip_idx]

    if skipped:
        remembered.update(skipped)
        save_skips(remembered)
        print(f"\n[install] remembering skipped: {', '.join(skipped)} "
              f"(won't re-nag; edit .nigredo_skip_tools to reset)")

    installed_go = False
    for t in to_install:
        cmd = install_command(t)
        print(f"\n[install] {t}: {cmd}")
        try:
            # nosec B602 — cmd built from install_command(t); t is a key from the
            # static TOOLS dict, no user input reaches this shell.
            subprocess.run(cmd, shell=True, check=False)  # nosec B602
        except Exception as e:  # noqa: BLE001
            print(f"[install] {t} FAILED: {e}")
            note = tool_note(t)
            if note:
                print(f"[install] try: {note}")
            continue
        if TOOLS.get(t, {}).get("kind") == "go":
            installed_go = True
        # post-install steps (e.g. patchright needs its browser downloaded)
        post = TOOLS.get(t, {}).get("post")
        if post == "patchright_browser":
            pw_cmd = f"{_uv_bin()} run patchright install chromium"
            print(f"[install] {t}: fetching chromium ({pw_cmd})")
            try:
                # nosec B602 — pw_cmd is a fully static string (_uv_bin() returns a
                # resolved binary path); no user input reaches this shell.
                subprocess.run(pw_cmd, shell=True, check=False)  # nosec B602
            except Exception as e:  # noqa: BLE001
                print(f"[install] chromium fetch failed: {e} — run manually: {pw_cmd}")
            # Browser SYSTEM libraries — without these the downloaded chromium won't
            # LAUNCH on Debian/Kali (setup.sh does the same via `install-deps`). Needs
            # root, so best-effort under sudo; harmless / no-op on non-Debian.
            deps_cmd = f"sudo {_uv_bin()} run patchright install-deps chromium"
            print(f"[install] {t}: installing browser system deps ({deps_cmd})")
            try:
                # nosec B602 — deps_cmd is a fully static string (_uv_bin() returns a
                # resolved binary path); no user input reaches this shell.
                subprocess.run(deps_cmd, shell=True, check=False)  # nosec B602
            except Exception as e:  # noqa: BLE001
                print(f"[install] browser deps failed: {e} — run manually: {deps_cmd}")
        # verify
        if _installed(t):
            print(f"[install] {t} OK")
        else:
            print(f"[install] {t} still not detected — may need PATH/shell reload")

    if installed_go:
        ensure_go_path_offer()

    print("\n[install] done.")
    return 0
