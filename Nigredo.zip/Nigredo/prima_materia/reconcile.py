"""Nessus<->nmap reconciliation, honeypot detection, and the evidence-driven
web-URL pool.

Three related jobs, all about making sure IN-SCOPE targets get properly scanned
even when nmap's own discovery degrades (dropped packets under load, etc.):

1. HONEYPOT DETECTION — a host with many Nessus '?' ports (uncertain service
   detection) is a classic honeypot/tarpit signature. If a host has more than
   HONEYPOT_QMARK_THRESHOLD '?' ports, flag it and EXCLUDE it from deep
   scanning entirely (don't waste time / don't feed the trap).

2. NESSUS PORT RECONCILIATION — Nessus often finds ports nmap missed. For each
   NON-honeypot host, take the Nessus-reported open ports that nmap didn't
   confirm and re-probe ONLY those with a reliable directed scan (-sT -Pn, full
   connect + retries, version-intensity 7). Try twice. Never DROP a Nessus port:
   if still unconfirmed, keep it flagged 'Nessus-confirmed, nmap-unverified'.

3. EVIDENCE-DRIVEN WEB POOL — build the web-URL pool for nuclei/katana/ffuf/
   feroxbuster from EVERY source that reported a web port open (nmap results,
   Nessus, the scope's own targets, katana) — unioned + deduped. A URL is only
   included if SOME source reported that web port open; nothing is guessed.
"""
from __future__ import annotations

import re
from pathlib import Path

HONEYPOT_QMARK_THRESHOLD = 7   # > this many '?' ports on a host => likely honeypot

# ports (and service names) that count as "web" for the evidence-driven pool
_WEB_PORTS = {80: "http", 443: "https", 8080: "http", 8443: "https",
              8000: "http", 8888: "http", 8008: "http", 4443: "https"}
_WEB_SVC_RE = re.compile(r"\b(https?|www|http-proxy|http-alt|ssl/http)\b", re.I)


# --------------------------- honeypot detection ---------------------------

def qmark_ports(host: dict) -> list:
    """Return the list of (proto, port) on a Nessus host whose service detection
    is uncertain — Nessus appends '?' to the service name when it's guessing."""
    out = []
    for key, pd in (host.get("ports") or {}).items():
        svc = (pd.get("service") or "")
        if svc.strip().endswith("?"):
            out.append(key)
    return out


def uncertain_remote_ports(host: dict) -> list:
    """'?' ports that were seen ONLY by remote detection (not credentialed).

    A '?' from a credentialed scan is more likely a genuinely-odd real host; a
    pile of '?' ports seen only remotely is the stronger honeypot/tarpit signal
    (something answering every probe ambiguously). Uses the expanded parser's
    per-port 'credentialed' flag when available; falls back to plain '?' count."""
    out = []
    for key, pd in (host.get("ports") or {}).items():
        svc = (pd.get("service") or "")
        if not svc.strip().endswith("?"):
            continue
        if not pd.get("credentialed", False):
            out.append(key)
    return out


def is_honeypot(host: dict, threshold: int = HONEYPOT_QMARK_THRESHOLD) -> bool:
    """True if the host has more than `threshold` uncertain REMOTE-ONLY ('?')
    ports — the honeypot/tarpit signature. Credentialed '?' ports don't count
    (a credentialed scan wouldn't be fooled the same way). Falls back to the
    plain '?' count ONLY when the host has no provenance data at all."""
    q = qmark_ports(host)
    if not q:
        return False
    have_provenance = any("credentialed" in (pd or {})
                          for pd in (host.get("ports") or {}).values())
    if have_provenance:
        # provenance available -> only remote-only '?' ports count toward the trap
        return len(uncertain_remote_ports(host)) > threshold
    # no provenance at all -> fall back to the plain '?' count
    return len(q) > threshold


def honeypot_report(nessus_hosts: dict,
                    threshold: int = HONEYPOT_QMARK_THRESHOLD) -> dict:
    """Return {ip: qmark_count} for every host flagged as a likely honeypot.
    Callers exclude these IPs from deep discovery and note them in the report."""
    flagged = {}
    for ip, host in (nessus_hosts or {}).items():
        if is_honeypot(host, threshold):
            flagged[ip] = len(uncertain_remote_ports(host)) or len(qmark_ports(host))
    return flagged


# --------------------------- port reconciliation ---------------------------

def nessus_open_ports(host: dict) -> dict:
    """Return {port:int -> {'service':str, 'uncertain':bool}} for a Nessus host's
    TCP ports. 'uncertain' marks the '?' (guessed) ones."""
    out = {}
    for (proto, port), pd in (host.get("ports") or {}).items():
        if proto != "tcp":
            continue
        svc = (pd.get("service") or "").strip()
        out[port] = {"service": svc.rstrip("?").strip() or "unknown",
                     "uncertain": svc.endswith("?")}
    return out


def ports_nmap_missed(nessus_ports: dict, nmap_confirmed: set) -> list:
    """Ports Nessus reported open that nmap did NOT confirm — the reconciliation
    targets. Returns a sorted list of port ints."""
    return sorted(p for p in nessus_ports if p not in (nmap_confirmed or set()))


def build_directed_scan_cmd(ip: str, ports: list, outdir: Path,
                            version_intensity: int = 7) -> list:
    """nmap command to reliably confirm a specific set of known-open ports.
    Full TCP connect (-sT, resilient to dropped SYNs), assume-up (-Pn), aggressive
    retries, careful timing, targeted version detection. Fast because it only
    touches the handful of Nessus-known ports, not a range."""
    plist = ",".join(str(p) for p in ports)
    safe = ip.replace(":", "_").replace("/", "_")
    return [
        "nmap", "-sT", "-Pn", "-sV",
        f"--version-intensity", str(version_intensity),
        "--max-retries", "5", "-T3",
        "--host-timeout", "10m",
        "-p", plist,
        "-oX", str(Path(outdir) / f"reconcile_{safe}.xml"),
        ip,
    ]


def build_banner_scan_cmd(ip: str, ports: list, outdir: Path) -> list:
    """Stage-2 mop-up: --script banner on the ports that were confirmed open but
    that -sV/-sC couldn't identify. Only runs on the still-fuzzy ports so it
    doesn't overlap the deep scan's -sV -sC."""
    plist = ",".join(str(p) for p in ports)
    safe = ip.replace(":", "_").replace("/", "_")
    return [
        "nmap", "-sT", "-Pn", "--script", "banner",
        "--max-retries", "3", "-T3",
        "-p", plist,
        "-oX", str(Path(outdir) / f"banner_{safe}.xml"),
        ip,
    ]


# --------------------------- evidence-driven web pool ---------------------------

def _is_web(port: int, service: str = "") -> bool:
    """A port counts as web if it's a known web port OR a source labelled its
    service http/https/www (web service on a nonstandard port)."""
    if port in _WEB_PORTS:
        return True
    if service and _WEB_SVC_RE.search(service):
        return True
    return False


def _scheme_for(port: int, service: str = "") -> str:
    """Pick http vs https for a web port. 443/8443/4443 -> https; a service
    string mentioning https/ssl -> https; else http."""
    if port in (443, 8443, 4443):
        return "https"
    if service and re.search(r"https|ssl", service, re.I):
        return "https"
    return _WEB_PORTS.get(port, "http")


def _url(scheme: str, host: str, port: int) -> str:
    """Build a URL, dropping the default port for the scheme."""
    default = (scheme == "https" and port == 443) or (scheme == "http" and port == 80)
    return f"{scheme}://{host}" if default else f"{scheme}://{host}:{port}"


def build_web_pool(sources: dict) -> list:
    """Union web URLs from every evidence source. A URL is included ONLY if some
    source reported that web port open — nothing is guessed.

    `sources` is a dict of source_name -> list of (host, port, service) tuples,
    e.g. {'nmap': [...], 'nessus': [...], 'katana': [...], 'scope': [...]}.
    (katana entries can pass port 0 + a full-URL host if already a URL; those are
    passed through as-is.)

    Returns a deduped, sorted list of URLs.
    """
    seen = set()
    urls = []
    for src, entries in (sources or {}).items():
        for entry in entries or []:
            # katana / pre-built URLs: a single string that already looks like a URL
            if isinstance(entry, str) and "://" in entry:
                u = entry.strip()
                if u and u not in seen:
                    seen.add(u)
                    urls.append(u)
                continue
            try:
                host, port, service = entry
            except (ValueError, TypeError):
                continue
            if not host:
                continue
            port = int(port) if port else 0
            if port and _is_web(port, service):
                u = _url(_scheme_for(port, service), host, port)
                if u not in seen:
                    seen.add(u)
                    urls.append(u)
    return sorted(urls)


def web_entries_from_nessus(nessus_hosts: dict, honeypot_ips: set = None) -> list:
    """Extract (host, port, service) web entries from Nessus, skipping honeypots."""
    honeypot_ips = honeypot_ips or set()
    out = []
    for ip, host in (nessus_hosts or {}).items():
        if ip in honeypot_ips:
            continue
        # prefer a resolvable hostname if present, else the IP
        names = host.get("hostnames") or []
        target = names[0] if names else ip
        for (proto, port), pd in (host.get("ports") or {}).items():
            if proto != "tcp":
                continue
            svc = (pd.get("service") or "").rstrip("?").strip()
            if _is_web(port, svc):
                out.append((target, port, svc))
    return out
