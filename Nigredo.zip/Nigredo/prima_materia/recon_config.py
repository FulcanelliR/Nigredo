"""Configuration for Phase 1 (passive recon) and Phase 2 (email/breach) runs.

Centralizes the shared keys/paths multiple tools need, so they aren't prompted
per-tool or hardcoded. Loads from a JSON file; anything omitted falls back to
env vars or sane defaults. Secrets prefer env vars over the file.

AUDIT NOTES:
  - BACKWARD-COMPAT: fields are read at call sites with getattr(cfg, "x", default),
    so an OLD config.json missing newer fields still loads and runs — the new
    fields just take their defaults. Don't assume every field exists on every
    loaded config; that's why callers use getattr, not cfg.x directly.
  - CREDIT CAPS: the *_credit_cap fields default to None = UNCAPPED (full
    coverage). They're an opt-in ceiling, not a default limit. The APIs cap their
    own spend server-side; these only add a local stop if the operator sets one.
  - DEFAULTS ARE SAFE-BY-DEFAULT: loud/aggressive behavior is off or conservative
    unless consciously raised (e.g. shodan host-lookup off, nuclei rate low).
"""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path


@dataclass
class ReconConfig:
    # single domain input for both phases (one list, per the agreed design)
    domains_file: str = "domains.txt"
    output_dir: str = "recon_results"
    engagement_name: str = "engagement"

    # shared credentials (env vars take precedence; file is fallback)
    serpapi_key: str = ""
    snov_client_id: str = ""
    snov_client_secret: str = ""
    grayhat_api_key: str = ""
    grayhat_tier: str = "low"    # low/medium/high/max — GHW subscription tier
    grayhat_file_prompt_threshold: int = 500  # prompt if a run would pull > N files
    # Shodan passive enrichment (InternetDB free by default)
    run_shodan: bool = True
    shodan_api_key: str = ""              # only needed for the optional host lookup
    cvemap_api_key: str = ""              # ProjectDiscovery PDCP key: authenticates
                                          # cvemap so the CVE lookup isn't throttled on
                                          # the anonymous tier. Blank = free/anonymous.
    shodan_use_host_lookup: bool = False  # opt-in richer lookup (spends credits)
    shodan_ondemand_scan: bool = False    # opt-in ACTIVE scan of discovered IPs (spends scan credits)
    shodan_host_lookup_cap: int = 50      # budget guard on host lookups per run
    github_token: str = ""
    # The client's GitHub org/handle for trufflehog + gitleaks. This is the REAL
    # org name (e.g. 'AcmeCorp'), which is frequently NOT the domain's first label
    # ('acme.com' -> 'acme'). Set in the interview and persisted here so the
    # unattended campaign child uses it — otherwise it fell back to the domain-
    # derived guess and scanned a nonexistent/wrong org, finding nothing.
    github_org: str = ""
    # The client's real company/org name for bucket + cloud_enum keyword search
    # (e.g. 'AcmeCorp'), frequently NOT the domain's first label. Set in the
    # interview and persisted here so the unattended campaign child uses it
    # instead of falling back to the domain-derived base (which searched the
    # wrong org in batch runs).
    company: str = ""

    # helper script / resource paths
    # PartyOn replaces the old dehashed tool (phase 2 breach/credential lookup)
    partyon_script: str = "PartyOn.py"
    dehashed_api_key: str = ""
    partyon_seconds_min: int = 3
    # PartyOn (breach/credential) settings, set in the interview and persisted
    # here so the unattended campaign child honors them. partyon_spray is
    # SECURITY-SENSITIVE: it FIRES credential stuffing at the client, so it
    # defaults to False (results-only) and is only ever True when the operator
    # explicitly opted in. proxy/seconds apply only to the spray engine.
    partyon_spray: bool = False
    partyon_proxy: str = ""
    partyon_seconds: int = 3
    resolvers_file: str = "resolvers.txt"   # subdomains; bundled 8-resolver file
                                            # ships with nigredo (Google/Cloudflare/
                                            # Quad9/OpenDNS). Prompted only if this
                                            # is cleared AND no file is found.
    dkim_wordlist: str = ""           # DKIM selector list; required for DKIM

    # tool toggles
    run_dnsrecon: bool = True
    run_dnstwist: bool = True
    dnstwist_whois: bool = False           # WHOIS registrar lookups: OFF by default
                                           # (serial, slow, and the hang-prone part;
                                           # DNS/permutation results don't need it)
    dnstwist_backfill: bool = True         # re-query failed NS/registrar lookups
    dnstwist_whois_delay: float = 2.0      # seconds between WHOIS backfills (rate-limit safety)
    dnstwist_whois_backfill_cap: int = 100  # max WHOIS backfills per run (ban guard)
    run_subdomains: bool = True
    run_takeover: bool = True    # dedicated nuclei subdomain-takeover pass
    run_submutate: bool = True   # target-specific subdomain mutation (in-scope)
    submutate_max_words: int = 40      # top-N learned words to recombine
    submutate_max_candidates: int = 5000  # cap on mutation candidates per domain
    follow_same_host_redirects: bool = False  # follow / -> /login/ (same host only)
    # Forwarding proxy for target-hitting HTTP tools (web probe, ffuf, feroxbuster).
    # Set in the interview and persisted here so the unattended campaign child
    # routes through it; blank = connect direct. (Phase-0 Config has its own
    # forward_proxy; this mirrors it for the recon child, which loads ReconConfig.)
    forward_proxy: str = ""
    run_cvemap: bool = True      # CVE lookup against discovered technologies
    run_cache: bool = True       # Cache (Stockpiler Exp): online PoC lookup for CVEs
    run_fqdn_resolve: bool = True  # build confirmed FQDN<->IP pairs (2-of-3)
    dnsrecon_lifetime: float = 10.0  # dnsrecon --lifetime (per-query DNS timeout,
                                     # raise for slow/filtered target DNS servers)
    run_dkim: bool = True
    run_fileenum: bool = True
    run_emailenum: bool = True
    run_partyon: bool = True
    run_snov: bool = True

    # email-enum (linkedin) settings
    email_format: str = "{f}{last}"   # appends @<domain> if no @
    # LinkedIn business name for email enumeration (LinkThief). Set in the
    # interview; persisted here so the unattended campaign child uses the REAL
    # business name instead of an empty stash (which made emailenum run with no
    # company, falling back to a domain-guess that targeted the wrong org).
    email_business: str = ""
    # fileenum settings
    file_types: list[str] = field(default_factory=lambda: [
        # documents
        "pdf", "docx", "doc", "xlsx", "xls", "pptx", "ppt", "csv", "txt", "rtf", "odt",
        # backups & archives (user does occasionally find .bak)
        "bak", "old", "backup", "swp", "tar", "zip", "rar", "7z", "gz", "tgz",
        # config & secrets (high value)
        "env", "config", "conf", "cfg", "ini", "yaml", "yml", "json", "xml",
        # database files
        "sql", "db", "sqlite", "mdb", "accdb",
        # logs + credentials/certs
        "log", "key", "pem", "p12", "pfx", "crt", "cer", "asc",
        # misc
        "properties", "htpasswd", "git",
    ])
    file_use_crawler: bool = True
    # fileenum search scope: "basic" (metadata-bearing office/PDF types only, no
    # sensitive dorks, ~8 SerpAPI credits) vs "full" (all configured types +
    # sensitive dorks, ~60 credits). Set in the interview and persisted here so
    # the unattended campaign child honors the operator's choice instead of
    # defaulting to basic.
    fileenum_mode: str = "basic"

    # FunnelWeb crawler (REQUIRED — core crawl/discovery work; runs unless the
    # operator explicitly sets run_funnelweb=false. Missing deps are auto-installed
    # at run time rather than causing a skip.)
    run_buckets: bool = True
    buckets_file_cap: int = 1000        # max files listed per bucket in report
    # cloud_enum (initstring) — active brute-force; raw output only for now
    run_cloud_enum: bool = True
    cloud_enum_script: str = "cloud_enum.py"
    # cloud_enum runs to completion (no timeout) for full coverage — it doesn't
    # spend API credits, so there's no credit-burn risk in letting it run long.

    # --- OPTIONAL API credit caps (OFF by default = no ceiling, full coverage) ---
    # Set any of these to a number to make that tool STOP once it has spent that
    # many credits this run. Left as None, the tool runs uncapped (the API caps
    # its own spend server-side; cost is billed to the client). Credit spend is
    # always TRACKED and reported regardless of these caps.
    snov_credit_cap: "int | None" = None
    grayhat_credit_cap: "int | None" = None
    shodan_credit_cap: "int | None" = None
    serpapi_credit_cap: "int | None" = None
    dehashed_credit_cap: "int | None" = None
    cloud_enum_extra: list[str] = field(default_factory=list)
    # cloud_enum brute-force depth:
    #   "quick"  -> -qs (cloud_enum's --quickscan: no mutations, no 2nd-level scans)
    #   "normal" -> curated ~149 common-name mutations via -m and -b (default; ~half runtime)
    #   "full"   -> cloud_enum's stock fuzz.txt (~306 entries; original behavior)
    # An invalid value warns and falls back to "normal". Operators can still
    # override via cloud_enum_extra (an explicit -m/-b/-qs there wins).
    cloud_enum_depth: str = "normal"
    # feroxbuster per-client intensity, set in the preflight interview and saved
    # to this client's config so the parallel run honors it (was stash-only, so
    # it never survived into the run subprocess).
    #   ferox_mode: w=words+ext, f=files-only, b=both, c=custom path
    #   ferox_wordlist_size: s/m/l wordlist size (l is EXTREME/slow)
    ferox_mode: str = "w"
    ferox_wordlist_size: str = "m"
    # Custom feroxbuster wordlist path, used only when ferox_mode == "c". Set in
    # the interview and persisted here so a per-client custom path survives into
    # the unattended campaign child (was stash-only, so the child ignored it).
    ferox_custom_wordlist: str = ""
    # ffuf directory-wordlist size (s/m/l). Already read at run time with a
    # config fallback; the interview now persists the per-client choice here.
    ffuf_wordlist_size: str = "m"
    # GitHub enumeration + secret scanning (public repos only)
    run_trufflehog: bool = True
    run_gitleaks: bool = True
    trufflehog_results: str = "verified,unknown,unverified"
    trufflehog_include_members: bool = False
    trufflehog_include_comments: bool = False
    gitleaks_clone_depth: int = 0      # 0 = full history; >0 = shallow
    gitleaks_max_repos: int = 0        # 0 = no cap
    run_funnelweb: bool = True   # REQUIRED core web-crawl phase. Runs unless set
                                 # false here. No prompt, no ready-gate skip; missing
                                 # deps are auto-installed at run time.
    funnelweb_script: str = "FunnelWeb.py"
    funnelweb_workers: int = 0            # 0 = script default
    funnelweb_rate_limit: float = 0.0     # 0 = script default
    funnelweb_stealth: bool = False       # --stealth: real Chrome, headed (needs xvfb on headless box)

    def resolve_secrets(self) -> None:
        """Let env vars override file values for secrets."""
        self.serpapi_key = os.getenv("SERPAPI_KEY", self.serpapi_key)
        self.snov_client_id = os.getenv("SNOV_CLIENT_ID", self.snov_client_id)
        self.snov_client_secret = os.getenv("SNOV_CLIENT_SECRET", self.snov_client_secret)
        self.grayhat_api_key = os.getenv("GRAYHAT_API_KEY", self.grayhat_api_key)
        self.shodan_api_key = os.getenv("SHODAN_API_KEY", self.shodan_api_key)
        self.cvemap_api_key = os.getenv("PDCP_API_KEY", self.cvemap_api_key)
        self.github_token = os.getenv("GITHUB_TOKEN", self.github_token)
        self.dehashed_api_key = os.getenv("DEHASHED_API_KEY", self.dehashed_api_key)

    @classmethod
    def load(cls, path: str | Path) -> "ReconConfig":
        data = json.loads(Path(path).read_text())
        # Only pass keys that are actual dataclass fields. Unknown keys (from an
        # older config, a rename, or a typo) are dropped with a warning instead
        # of crashing the whole tool with an unexpected-keyword TypeError.
        import dataclasses
        valid = {f.name for f in dataclasses.fields(cls)}
        # graceful migration for renamed fields
        if "run_dehashed" in data and "run_partyon" not in data:
            data["run_partyon"] = data.pop("run_dehashed")
            print("[config] migrated 'run_dehashed' -> 'run_partyon'")
        # One file serves both the scan (Config) and recon (ReconConfig) phases, so
        # ReconConfig legitimately sees scan-only keys. Only warn about keys that
        # belong to NEITHER schema (genuine typos/removed options), not the sibling's.
        cross = set()
        try:
            from .config import Config as _C
            cross = {f.name for f in dataclasses.fields(_C)}
        except Exception:  # noqa: BLE001
            pass
        unknown = [k for k in data if k not in valid and k not in cross]
        if unknown:
            print(f"[config] ignoring {len(unknown)} unrecognized key(s) in "
                  f"{Path(path).name}: {', '.join(unknown)}")
        clean = {k: v for k, v in data.items() if k in valid}
        cfg = cls(**clean)
        cfg.resolve_secrets()
        return cfg

    def dump(self, path: str | Path) -> None:
        Path(path).write_text(json.dumps(asdict(self), indent=2))

    def config_keys(self) -> dict:
        """Map of credential env-var names -> values, for the preflight check.
        Also carries the funnelweb script path so preflight can locate it."""
        return {
            "SERPAPI_KEY": self.serpapi_key,
            "SNOV_CLIENT_ID": self.snov_client_id,
            "SNOV_CLIENT_SECRET": self.snov_client_secret,
            "GRAYHAT_API_KEY": self.grayhat_api_key,
            "GITHUB_TOKEN": self.github_token,
            "funnelweb_script": self.funnelweb_script,
            "funnelweb_stealth": self.funnelweb_stealth,
            "cloud_enum_script": self.cloud_enum_script,
            "partyon_script": self.partyon_script,
            "DEHASHED_API_KEY": self.dehashed_api_key,
        }


def load_domains(path: str | Path) -> list[str]:
    """Read domains.txt: one apex domain per line, '#' comments allowed.
    Tolerates multiple domains on a single line separated by commas and/or spaces
    (e.g. a hand-entered 'domain1.com, domain2.com') — each is split out so it runs
    and is saved separately, instead of the whole line becoming one bad 'domain'
    that breaks subfinder (subfinder -d "domain1.com, domain2.com")."""
    out: list[str] = []
    for raw in Path(path).read_text().splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        for tok in line.replace(",", " ").split():
            tok = tok.strip().rstrip(".").lower()
            if tok:
                out.append(tok)
    # dedupe, preserve order
    seen, uniq = set(), []
    for d in out:
        if d not in seen:
            seen.add(d)
            uniq.append(d)
    return uniq
