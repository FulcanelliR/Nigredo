"""Wordlist size selection — a small/medium/large chooser presented at preflight
for the content-discovery tools (ffuf, feroxbuster).

Maps a size choice to the matching SecLists 'raft' wordlist for the requested
list TYPE (directories / files / words). The LARGE option is flagged inline as
extending duration and requests to the client by extreme amounts, so the operator
makes an informed choice. Default is medium. In unattended / dry-run, no prompt is
shown and the configured default is used.
"""
from __future__ import annotations

from pathlib import Path

# SecLists raft variants. These are the standard install paths on Kali.
_RAFT_BASE = "/usr/share/seclists/Discovery/Web-Content"

# type -> {size -> filename}. 'words' and 'directories' use the lowercase raft
# variants (matches the tool defaults we ship); 'files' likewise.
_RAFT = {
    "directories": {
        "s": "raft-small-directories-lowercase.txt",
        "m": "raft-medium-directories-lowercase.txt",
        "l": "raft-large-directories-lowercase.txt",
    },
    "words": {
        "s": "raft-small-words-lowercase.txt",
        "m": "raft-medium-words-lowercase.txt",
        "l": "raft-large-words-lowercase.txt",
    },
    "files": {
        "s": "raft-small-files-lowercase.txt",
        "m": "raft-medium-files-lowercase.txt",
        "l": "raft-large-files-lowercase.txt",
    },
}

# approximate line counts, shown so the operator understands the cost
_APPROX = {
    "directories": {"s": "~18k", "m": "~30k", "l": "~62k"},
    "words":       {"s": "~18k", "m": "~40k", "l": "~92k"},
    "files":       {"s": "~11k", "m": "~17k", "l": "~37k"},
}


def raft_path(list_type: str, size: str) -> str:
    """Return the absolute raft wordlist path for a type + size (s/m/l).

    Resolves the SecLists base dynamically (it isn't always at /usr/share/seclists
    — apt, manual clone, /opt, ~/.local all differ), so ffuf/feroxbuster find the
    rafts wherever SecLists actually lives instead of silently skipping.
    """
    fn = _RAFT.get(list_type, {}).get(size)
    if not fn:
        return ""
    # Try the real SecLists base first; fall back to the hardcoded default.
    try:
        from .tools import find_seclists_base
        base = find_seclists_base()
    except Exception:  # noqa: BLE001
        base = None
    if base:
        wc = Path(base) / "Discovery" / "Web-Content"
        # try the exact (lowercase) filename, then the non-lowercase variant —
        # some SecLists versions ship one but not the other.
        for candidate_fn in (fn, fn.replace("-lowercase", "")):
            cand = wc / candidate_fn
            if cand.is_file():
                return str(cand)
    return str(Path(_RAFT_BASE) / fn)


def prompt_size(list_type: str, tool: str, default_size: str = "m",
                dry_run: bool = False) -> str:
    """Prompt for small/medium/large for a given list type, return the raft path.

    The LARGE option is flagged as extreme (duration + requests). Falls back to
    the configured default_size in unattended/dry-run without prompting. If the
    chosen raft file doesn't exist on disk, returns "" so the caller can fall back
    to its own configured wordlist path.
    """
    default_size = (default_size or "m").lower()[:1]
    if default_size not in ("s", "m", "l"):
        default_size = "m"

    chosen = default_size
    if not dry_run:
        from .runmode import is_unattended
        if not is_unattended():
            approx = _APPROX.get(list_type, {})
            print(f"\n  {tool}: choose {list_type} wordlist size")
            print(f"    [s] small   (raft-small-{list_type}, {approx.get('s','')})")
            print(f"    [m] medium  (raft-medium-{list_type}, {approx.get('m','')})")
            print(f"    [l] large   (raft-large-{list_type}, {approx.get('l','')})"
                  f"   \u26a0 EXTREME: greatly increases scan duration and the number "
                  f"of requests sent to the client")
            try:
                ans = input(f"  choice [{default_size}]: ").strip().lower()[:1]
            except EOFError:
                ans = ""
            if ans in ("s", "m", "l"):
                chosen = ans

    path = raft_path(list_type, chosen)
    if path and Path(path).is_file():
        label = {"s": "small", "m": "medium", "l": "large"}[chosen]
        print(f"  {tool} {list_type}: {label} -> {path}")
        return path
    # The chosen raft file isn't at the default SecLists path. We STILL made the
    # size choice with the operator above; return "" so the caller prompts for
    # the actual wordlist path (rather than silently using a config default the
    # operator never saw).
    from .runmode import is_unattended as _iu
    if path and not _iu() and not dry_run:
        print(f"  {tool} {list_type}: '{chosen}' size chosen, but the raft file "
              f"isn't at {path} — you'll be asked for the wordlist path next.")
    elif path:
        print(f"  {tool} {list_type}: chosen raft file not found ({path}); "
              f"falling back to configured default")
    return ""
