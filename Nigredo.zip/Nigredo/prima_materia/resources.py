"""Resource telemetry + subprocess-tree cleanup.

Two jobs, both backed by psutil (with graceful degrade if it's absent):

1. TELEMETRY — sample CPU / RAM at phase boundaries so a run that hogs the box
   leaves DATA behind (written to resource_log.txt in the engagement folder).
   This is how we diagnose "why did Kali lag / why did CPU stay pegged".

2. CLEANUP — kill a spawned tool AND its whole descendant tree. The high-CPU-
   after-a-crash problem is orphaned children: a Popen'd tool (nuclei / ffuf /
   feroxbuster / cloud_enum) that keeps running after nigredo errored. Killing
   just the direct child leaves grandchildren alive; psutil lets us walk the
   tree and terminate all of it. If psutil is missing we fall back to killing
   the process GROUP (works when the child was started with start_new_session).
"""
from __future__ import annotations

import os
import signal
import time
from pathlib import Path

try:
    import psutil  # type: ignore
    _HAVE_PSUTIL = True
except ImportError:  # graceful degrade
    psutil = None  # type: ignore
    _HAVE_PSUTIL = False


# ----------------------------- telemetry -----------------------------

def snapshot() -> dict:
    """Return a small dict of current resource stats. Coarse if psutil absent."""
    data = {"ts": time.strftime("%Y-%m-%dT%H:%M:%S")}
    if _HAVE_PSUTIL:
        try:
            vm = psutil.virtual_memory()
            data["cpu_pct"] = psutil.cpu_percent(interval=0.2)
            data["ram_used_gb"] = round(vm.used / 1e9, 2)
            data["ram_pct"] = vm.percent
            # this process tree's own footprint
            me = psutil.Process()
            kids = me.children(recursive=True)
            data["child_procs"] = len(kids)
            rss = me.memory_info().rss + sum(_safe_rss(c) for c in kids)
            data["tree_rss_gb"] = round(rss / 1e9, 2)
        except Exception:  # noqa: BLE001
            pass
    else:
        # stdlib-only fallback: load average + this process' RSS (best effort)
        try:
            data["loadavg"] = os.getloadavg()[0]
        except (OSError, AttributeError):
            pass
        try:
            import resource as _r
            data["self_maxrss_gb"] = round(
                _r.getrusage(_r.RUSAGE_SELF).ru_maxrss / 1e6, 2)  # KB->GB-ish
        except Exception:  # noqa: BLE001
            pass
        data["psutil"] = "absent (limited stats)"
    return data


def log_snapshot(outdir: Path, label: str) -> None:
    """Append a labelled resource snapshot to resource_log.txt. Never raises."""
    try:
        snap = snapshot()
        line = f"[{snap.get('ts','')}] [{label}] " + " ".join(
            f"{k}={v}" for k, v in snap.items() if k != "ts")
        p = Path(outdir) / "resource_log.txt"
        with open(p, "a") as f:
            f.write(line + "\n")
    except Exception:  # noqa: BLE001
        pass


def _safe_rss(proc) -> int:
    try:
        return proc.memory_info().rss
    except Exception:  # noqa: BLE001
        return 0


# ----------------------------- cleanup -----------------------------

def kill_tree(proc, timeout: float = 5.0) -> None:
    """Terminate a subprocess.Popen AND all its descendants.

    Order: SIGTERM the tree, wait briefly, then SIGKILL whatever's left. This is
    what stops orphaned nuclei/feroxbuster processes from pegging the CPU after
    nigredo moves on or crashes. Safe to call on an already-dead process.
    """
    if proc is None:
        return
    pid = getattr(proc, "pid", None)
    if pid is None:
        return

    if _HAVE_PSUTIL:
        try:
            parent = psutil.Process(pid)
        except Exception:  # noqa: BLE001 (already gone)
            return
        try:
            procs = parent.children(recursive=True)
        except Exception:  # noqa: BLE001
            procs = []
        procs.append(parent)
        # SIGTERM the whole tree
        for p in procs:
            try:
                p.terminate()
            except Exception:  # noqa: BLE001
                pass
        gone, alive = _wait_procs(procs, timeout)
        # SIGKILL survivors
        for p in alive:
            try:
                p.kill()
            except Exception:  # noqa: BLE001
                pass
        return

    # ---- stdlib fallback: kill the process group ----
    try:
        pgid = os.getpgid(pid)
        os.killpg(pgid, signal.SIGTERM)
        time.sleep(min(timeout, 3.0))
        try:
            os.killpg(pgid, signal.SIGKILL)
        except ProcessLookupError:
            pass
    except (ProcessLookupError, PermissionError, OSError):
        # last resort: direct terminate/kill on the child
        try:
            proc.terminate()
            time.sleep(1.0)
            proc.kill()
        except Exception:  # noqa: BLE001
            pass


def _wait_procs(procs, timeout):
    if _HAVE_PSUTIL:
        try:
            return psutil.wait_procs(procs, timeout=timeout)
        except Exception:  # noqa: BLE001
            return [], procs
    return [], procs


def popen_kwargs() -> dict:
    """kwargs to give subprocess.Popen so the child leads its OWN session/group.
    That makes the process-group fallback in kill_tree work, and isolates the
    child so a stray signal to nigredo doesn't half-kill it. POSIX only."""
    if os.name == "posix":
        return {"start_new_session": True}
    return {}
