"""iis_recon.py — IIS-focused recon enrichment (runs alongside the sns tilde check).

When a web host fingerprints as Microsoft-IIS, IIS has a wide, consistently
under-tested attack surface. This module automates the *recon/enumeration*
pieces of that surface (the safe, information-gathering steps) and records
high-value MANUAL follow-ups for the operator. It does NOT automate exploitation
(web.config RCE, ViewState deserialization, NTFS auth bypass, file-upload tricks,
HPP/WAF bypass) — those are hands-on-keyboard actions, out of scope for automated
recon, and some could damage the target.

Automated here (all low-impact recon):
  1. Internal IP disclosure  — an HTTP/1.0 request often makes IIS/Exchange leak
     an internal IP + hostname in the Location / X-FEServer headers. One request.
  2. Shortname enumeration   — if a host is tilde-vulnerable, run shortscan
     (bitquark) to actually extract 8.3 short names (richer than a Y/N check).
  3. IIS high-value paths     — probe a small, curated list of IIS/.NET debug &
     config endpoints (trace.axd, elmah.axd, web.config.bak, ...) — high signal.
  4. IIS nuclei tags          — recorded as a recommended targeted nuclei run.

Reference methodology: mll.sh "humiliating iis servers for fun and jail time".
"""
from __future__ import annotations

import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path

# curated high-value IIS/.NET endpoints (small + high-signal; article's list).
# trace.axd / elmah.axd are debug viewers that leak requests/creds when left on;
# web.config[.bak/.old/...] and appsettings*.json carry secrets/machine keys.
IIS_HIGH_VALUE_PATHS = [
    "/web.config", "/web.config.bak", "/web.config.old", "/web.config.txt",
    "/global.asax", "/trace.axd", "/elmah.axd", "/connectionstrings.config",
    "/appsettings.json", "/appsettings.Development.json",
    "/appsettings.Staging.json", "/appsettings.Production.json",
    "/appsettings.Local.json", "/secrets.json", "/WS_FTP.LOG",
    "/_vti_pvt/service.cnf", "/aspnet_client/",
]

# high-value manual follow-ups recorded (NOT automated) when IIS is confirmed
IIS_MANUAL_FOLLOWUPS = [
    "web.config read (path traversal / backup / shortname) -> machine keys -> "
    "ViewState RCE via ysoserial.net",
    "bin/ DLL exposure via cookieless session tokens: /(S(X))/b/(S(X))in/<App>.dll "
    "-> decompile (dnSpy/dotPeek) for secrets",
    "reverse-proxy path confusion: /anything/..%2fadmin/ to bypass 403",
    "NTFS auth bypass: /admin::$INDEX_ALLOCATION/admin.php",
    "file-upload: .cer/.htm (HTML XSS), trailing-dot bypass (shell.aspx.)",
    "HTTPAPI 2.0 404 = vhost-bound; brute Host header (ffuf -H 'Host: FUZZ')",
]

# IIS-specific nuclei tag set from the article
IIS_NUCLEI_TAGS = "microsoft,windows,asp,aspx,iis,azure,config,exposure"


def is_iis(server_header: str = "", tech: str = "") -> bool:
    """Does this host look like IIS from its Server header / detected tech?"""
    blob = f"{server_header} {tech}".lower()
    return ("microsoft-iis" in blob or "iis/" in blob
            or "asp.net" in blob or "x-powered-by: asp.net" in blob)


@dataclass
class IISFinding:
    url: str = ""
    internal_ip: str = ""            # leaked internal IP (HTTP/1.0 disclosure)
    fe_server: str = ""              # X-FEServer internal hostname
    shortnames: list = field(default_factory=list)   # 8.3 names from shortscan
    exposed_paths: list = field(default_factory=list)  # high-value paths that responded
    tilde_vulnerable: bool = False

    def rows(self) -> list:
        out = []
        if self.internal_ip or self.fe_server:
            out.append(["IIS Internal Disclosure", self.url,
                        f"internal IP: {self.internal_ip} FEServer: {self.fe_server}"])
        for sn in self.shortnames:
            out.append(["IIS Shortname", self.url, sn])
        for p in self.exposed_paths:
            out.append(["IIS Exposed Path", self.url, p])
        return out


def check_internal_ip_disclosure(url: str, command_log: Path, proxy: str = "",
                                 timeout: int = 10, dry_run: bool = False) -> tuple[str, str]:
    """HTTP/1.0 request → IIS/Exchange sometimes leaks an internal IP in the
    Location header + internal hostname in X-FEServer. Returns (internal_ip,
    fe_server). One request, low-impact."""
    cmd = ["curl", "-s", "-k", "-I", "--http1.0", "--max-time", str(timeout)]
    if proxy:
        cmd += ["-x", proxy]
    cmd.append(url)
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + "   # IIS internal-IP disclosure\n")
    if dry_run:
        return ("", "")
    internal_ip, fe_server = "", ""
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=timeout + 5)
        for line in (res.stdout or "").splitlines():
            low = line.lower()
            if low.startswith("location:"):
                loc = line.split(":", 1)[1].strip()
                import re
                # private-range IP in the redirect target
                m = re.search(r"(?:10\.\d+|172\.(?:1[6-9]|2\d|3[01])|192\.168)\."
                              r"\d+\.\d+", loc)
                if m:
                    internal_ip = m.group(0)
            elif low.startswith("x-feserver:"):
                fe_server = line.split(":", 1)[1].strip()
    except (subprocess.TimeoutExpired, OSError):
        pass
    return (internal_ip, fe_server)


def run_shortscan(url: str, outdir: Path, command_log: Path, proxy: str = "",
                  dry_run: bool = False) -> list[str]:
    """If shortscan (bitquark) is present, extract 8.3 short names — richer than
    a Y/N tilde check. `-F` full-url fuzz, `-p 1` patience. Returns shortnames."""
    if shutil.which("shortscan") is None:
        return []
    safe = url.split("://", 1)[-1].split("/")[0].replace(":", "_")
    out_txt = outdir / f"shortscan_{safe}.txt"
    cmd = ["shortscan", url, "-F", "-p", "1"]
    if proxy:
        cmd += ["-x", proxy]
    with open(command_log, "a") as log:
        log.write(" ".join(cmd) + f"  > {out_txt}\n")
    if dry_run:
        return []
    names = []
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=600)
        out_txt.write_text((res.stdout or "") + (res.stderr or ""))
        for line in (res.stdout or "").splitlines():
            s = line.strip()
            # shortscan prints "File: WEB~1.CON" / "Dir:  ADMIN~1"
            if s.startswith("File:") or s.startswith("Dir:"):
                names.append(s.split(":", 1)[1].strip())
    except (subprocess.TimeoutExpired, OSError):
        pass
    return names


def check_high_value_paths(url: str, command_log: Path, proxy: str = "",
                          timeout: int = 8, dry_run: bool = False) -> list[str]:
    """Probe the curated IIS/.NET high-value endpoints. Records paths that return
    a non-404 (200/301/302/403 — 403 still means 'exists but blocked'). Uses HEAD
    to stay light. Returns 'PATH [status]' strings."""
    base = url.rstrip("/")
    exposed = []
    for path in IIS_HIGH_VALUE_PATHS:
        full = base + path
        cmd = ["curl", "-s", "-k", "-o", "/dev/null", "-w", "%{http_code}",
               "-I", "--max-time", str(timeout)]
        if proxy:
            cmd += ["-x", proxy]
        cmd.append(full)
        if dry_run:
            continue
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, errors="replace", timeout=timeout + 3)
            code = (res.stdout or "").strip()
            if code and code not in ("404", "000"):
                exposed.append(f"{path} [{code}]")
        except (subprocess.TimeoutExpired, OSError):
            continue
    if not dry_run:
        with open(command_log, "a") as log:
            log.write(f"# IIS high-value path check on {url} "
                      f"({len(exposed)} responded)\n")
    return exposed


def process(url: str, outdir: Path, command_log: Path, tilde_vulnerable: bool = False,
            server_header: str = "", tech: str = "", proxy: str = "",
            dry_run: bool = False) -> IISFinding | None:
    """Run the IIS recon suite against one confirmed-IIS URL. Returns an
    IISFinding (or None if not IIS). Records manual follow-ups to the notes."""
    if not is_iis(server_header, tech):
        return None
    print(f"[iis] {url}: IIS detected — running recon suite")
    finding = IISFinding(url=url, tilde_vulnerable=tilde_vulnerable)

    ip, fe = check_internal_ip_disclosure(url, command_log, proxy=proxy, dry_run=dry_run)
    finding.internal_ip, finding.fe_server = ip, fe
    if ip or fe:
        print(f"[iis] {url}: internal disclosure — IP:{ip or '-'} FEServer:{fe or '-'}")

    # shortname extraction if tilde-vulnerable (else skip the heavier scan)
    if tilde_vulnerable:
        finding.shortnames = run_shortscan(url, outdir, command_log, proxy=proxy,
                                          dry_run=dry_run)
        if finding.shortnames:
            print(f"[iis] {url}: {len(finding.shortnames)} shortname(s) via shortscan")

    finding.exposed_paths = check_high_value_paths(url, command_log, proxy=proxy,
                                                  dry_run=dry_run)
    if finding.exposed_paths:
        print(f"[iis] {url}: {len(finding.exposed_paths)} high-value path(s) responded")

    return finding
