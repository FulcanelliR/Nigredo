"""Burp Suite export: emit a project-scope JSON (importable via Burp UI) and a
consolidated list of every discovered URL (for a seeded scan or a sitemap
extension). Also feeds the 'Burp Target URLs' workbook tab.

Nothing here talks to Burp directly — Burp's Montoya API is a Java extension API,
not a network endpoint. We produce two files:
  - burp_scope.json  : project options w/ advanced scope include-rules; import via
                       Burp UI (Project options -> load).
  - burp_urls.txt    : deduped discovered URLs (live URLs + ffuf/ferox hits +
                       katana/gau + FunnelWeb endpoints + JS paths).
"""
from __future__ import annotations
import json
import re
from pathlib import Path
from urllib.parse import urlsplit

_URL_RE = re.compile(r'https?://[^\s"\'<>]+')

# files we harvest discovered URLs from (globs)
_URL_SOURCES = [
    "*_live_urls.txt", "web_urls*.txt", "discovered_urls*.txt",
    "katana_output.txt", "gau_output.txt", "ffuf_hits.txt", "ffuf_*.json",
    "feroxbuster_*.txt", "feroxbuster_*.json", "tls_endpoints.txt",
    "*/report.csv",           # FunnelWeb rows (Source URL column)
    "*/js/*.txt",
]


def collect_urls(outdir) -> list[str]:
    outdir = Path(outdir)
    seen, out = set(), []
    for patt in _URL_SOURCES:
        for p in outdir.glob(patt):
            try:
                text = p.read_text(errors="replace")
            except OSError:
                continue
            for m in _URL_RE.findall(text):
                m = m.rstrip('.,;")\'')
                if m not in seen:
                    seen.add(m)
                    out.append(m)
    return sorted(out)


def build_scope_json(outdir, primary_domains: list[str]) -> Path:
    """Write burp_scope.json — project options w/ advanced scope include rules for
    the primary domain(s) and every discovered in-scope host."""
    outdir = Path(outdir)
    hosts = set()
    for d in (primary_domains or []):
        d = (d or "").strip()
        if d:
            hosts.add(d)
            hosts.add(rf".*\.{re.escape(d)}")   # subdomains
    # add discovered URL hosts that fall under a primary domain
    urls = collect_urls(outdir)
    for u in urls:
        try:
            host = urlsplit(u).hostname or ""
        except ValueError:
            continue
        if host and any(host == d or host.endswith("." + d)
                        for d in (primary_domains or [])):
            hosts.add(re.escape(host))
    scope = {
        "target": {
            "scope": {
                "advanced_mode": True,
                "include": [{"enabled": True, "protocol": "any",
                             "host": h, "file": "^/.*"} for h in sorted(hosts)],
                "exclude": [],
            }
        }
    }
    out = outdir / "burp_scope.json"
    out.write_text(json.dumps(scope, indent=2))
    return out


def build_url_feed(outdir) -> tuple[Path, list[str]]:
    """Write burp_urls.txt. Burp1: the feed IS nuclei's resolved target list
    (nuclei_targets.txt) — the same pages nuclei scans — so Burp and nuclei check
    the same surface and Burp crawls out from there, instead of stuffing every
    discovered sub-path into the seed list. Falls back to discovered URLs if
    nuclei did not run."""
    outdir = Path(outdir)
    nt = outdir / "nuclei_targets.txt"
    if nt.is_file() and nt.stat().st_size > 0:
        urls = [u.strip() for u in nt.read_text(errors="replace").splitlines() if u.strip()]
    else:
        urls = collect_urls(outdir)
    urls = list(dict.fromkeys(urls))
    out = outdir / "burp_urls.txt"
    out.write_text("\n".join(urls) + ("\n" if urls else ""))
    return out, urls
