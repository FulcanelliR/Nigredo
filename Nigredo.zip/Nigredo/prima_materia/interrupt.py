"""interrupt.py — shared Ctrl+C pause menu for the whole run (both engines).

WHY
  Ctrl+C alone is ambiguous (skip? quit?). So instead of guessing, an interrupt
  PAUSES the run and asks. This gives the operator intentional mid-run control:
  a wedged tool (e.g. a hung cloud_enum) can be dropped without killing the whole
  engagement, or the run can be stopped gracefully.

CONTRACT
  run_tool_with_interrupt(label, fn, *args, retryable=True, resumable=False, **kw)
    Runs fn(*args, **kw). If the operator hits Ctrl+C, the current tool's
    subprocess is left to raise KeyboardInterrupt up to here; we then show:
        [s] skip this tool, continue the run
        [t] retry this tool from the beginning
        [r] resume this tool (only offered when resumable=True — most external
            tools can't checkpoint, so this is usually hidden)
        [q] quit nigredo (progress saved by the caller; resume later)
    Returns one of: "done" (tool finished), "skip", "quit". On "retry" it re-runs
    fn and loops. A SECOND Ctrl+C AT THE MENU is the escape hatch -> "quit".

NOTE ON RESUME
  "resume" = continue the CURRENT tool from where it paused. Most CLI tools
  (nuclei, ffuf, cloud_enum) don't checkpoint, so once interrupted they can only
  RESTART — which is what "retry" does. So resume is only offered when the caller
  passes resumable=True (a tool that genuinely supports it). Otherwise it's hidden
  to avoid promising something that would silently just restart.

USAGE (both engines call this the same way)
  result = run_tool_with_interrupt("nuclei", run_nuclei, tc, web_file, outdir, ...)
  if result == "quit":  # caller saves state and returns
  # "skip"/"done" -> caller continues to the next tool
"""
from __future__ import annotations

import sys


def _prompt_multitarget_menu(tool_label: str, target_label: str) -> str:
    """Sub-menu shown when Ctrl+C hits a MULTI-target tool (funnelweb crawls many
    targets in one run). 'skip' is ambiguous there — this target, or the whole
    tool — so ask. Returns one of: 'this' | 'tool' | 'retry' | 'quit'.
    A second Ctrl+C here = quit (escape hatch)."""
    print(f"\n[paused] interrupted during '{tool_label}' on target "
          f"'{target_label}'. What now?")
    print("    [c] skip THIS target, continue to the next")
    print("    [w] skip the WHOLE tool, move on to the next tool")
    print("    [t] retry this target from the start")
    print("    [q] quit nigredo (progress saved)")
    mapping = {"c": "this", "w": "tool", "t": "retry", "q": "quit"}
    while True:
        try:
            choice = input("choice: ").strip().lower()
        except KeyboardInterrupt:
            print("\n[i] quitting.")
            return "quit"
        except EOFError:
            # stdin closed (backgrounded) — safest is to skip this target, not hang
            print("[i] no input available — skipping this target.")
            return "this"
        if choice in mapping:
            return mapping[choice]
        print("    please choose one of: c, w, t, q")


def _prompt_menu(label: str, resumable: bool) -> str:
    """Show the pause menu, return the chosen action. A second Ctrl+C here quits."""
    opts = ["[s] skip this tool, continue", "[t] retry this tool from the start"]
    if resumable:
        opts.append("[r] resume this tool where it paused")
    opts.append("[q] quit nigredo (progress saved)")
    print(f"\n[paused] interrupted during '{label}'. What now?")
    for o in opts:
        print(f"    {o}")
    valid = {"s", "t", "q"} | ({"r"} if resumable else set())
    while True:
        try:
            choice = input("choice: ").strip().lower()
        except KeyboardInterrupt:
            # second Ctrl+C at the menu = escape hatch
            print("\n[i] quitting.")
            return "q"
        except EOFError:
            # stdin closed (e.g. backgrounded) — safest is to skip, not hang
            print("[i] no input available — skipping this tool.")
            return "s"
        if choice in valid:
            return choice
        print(f"    please choose one of: {', '.join(sorted(valid))}")


def run_tool_with_interrupt(label, fn, *args, retryable=True, resumable=False,
                            **kwargs) -> str:
    """Run fn with a Ctrl+C pause menu. Returns 'done' | 'skip' | 'quit'.

    The tool's own subprocess should die on the interrupt (Python propagates the
    KeyboardInterrupt into the child on Ctrl+C for foreground subprocesses); the
    tool runners already use subprocess in the foreground, so the child stops when
    we catch the interrupt here. On 'retry' we simply call fn again."""
    while True:
        try:
            fn(*args, **kwargs)
            return "done"
        except KeyboardInterrupt:
            action = _prompt_menu(label, resumable)
            if action == "s":
                print(f"[i] skipped '{label}' — continuing.")
                return "skip"
            if action == "q":
                return "quit"
            if action == "r":
                # resume requested; only reachable when resumable=True. We can't
                # truly resume an external tool, so honor it as "run again" but
                # tell the truth about what's happening.
                print(f"[i] resuming '{label}' (note: external tools restart)…")
                continue
            if action == "t":
                print(f"[i] retrying '{label}' from the beginning…")
                continue
            # any fall-through -> skip (safe default)
            return "skip"
