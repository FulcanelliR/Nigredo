#!/usr/bin/env python3
"""
secret_scan.py — Regex-based secret detection for harvested JavaScript.

Phase B (Wave 1) of the FunnelWeb upgrade. Runs against the .js files saved by
js_harvest.py and finds API keys, tokens, and credentials using patterns
borrowed from Gitleaks' default ruleset and SecretFinder, with the false-positive
controls that make Gitleaks accurate:

  - keywords : cheap pre-filter — skip the expensive regex unless a keyword is
               present in the file (Gitleaks' performance pattern)
  - entropy  : reject matches that aren't random enough (kills FPs on matches
               that fit the shape but are obviously not secrets)
  - allowlist/stopwords : reject known-benign values (example keys, common words)
  - confidence tier : specific-prefix rules (AKIA, ghp_, sk-ant-) are HIGH;
               the generic catch-all is LOW -> drives whether we later attempt
               safe validation vs. just report as informational

Each finding captures the SOURCE LOCATION: which JS file, and a context snippet
around the match (SecretFinder's getContext idea) so it can be found again.

This is the tool's OWN detection pass; it runs independently of jsluice. Both
feed the report (two-tool cross-check). Values are reported UNMASKED — this is
the internal scan report, not the client deliverable.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from pathlib import Path

try:
    import jsbeautifier
    _HAS_BEAUTIFY = True
except ImportError:
    _HAS_BEAUTIFY = False


# ---- confidence tiers ----
HIGH = "high"      # specific, low-FP format -> eligible for safe validation
MEDIUM = "medium"
LOW = "low"        # generic/loose -> informational only


@dataclass
class SecretRule:
    id: str
    regex: str
    keywords: tuple = ()
    entropy: float = 0.0
    confidence: str = MEDIUM
    secret_group: int = 0          # which capture group holds the secret (0=whole)
    description: str = ""
    _compiled: "re.Pattern" = field(default=None, repr=False)

    def compile(self):
        if self._compiled is None:
            self._compiled = re.compile(self.regex)
        return self._compiled


# ---- the rule set: high-value subset of Gitleaks defaults + SecretFinder ----
# Confidence HIGH = distinctive prefix/shape, very low FP. MEDIUM = contextual.
# LOW = generic catch-all (informational). Extend freely from the full toml.
RULES: list[SecretRule] = [
    # ---- cloud / infra (HIGH) ----
    SecretRule("aws-access-key", r"\b((?:A3T[A-Z0-9]|AKIA|ASIA|ABIA|ACCA)[A-Z2-7]{16})\b",
               ("akia", "asia", "abia", "acca", "a3t"), 3.0, HIGH,
               description="AWS Access Key ID"),
    SecretRule("gcp-api-key", r"\b(AIza[0-9A-Za-z_\-]{35})\b",
               ("aiza",), 4.0, HIGH, description="Google/GCP API Key"),
    SecretRule("anthropic-api-key", r"\b(sk-ant-api03-[a-zA-Z0-9_\-]{93}AA)\b",
               ("sk-ant-api03",), 0, HIGH, description="Anthropic API Key"),
    SecretRule("openai-api-key",
               r"\b(sk-(?:proj|svcacct|admin)?-?[A-Za-z0-9_-]{20,}T3BlbkFJ[A-Za-z0-9_-]{20,})\b",
               ("t3blbkfj",), 3.0, HIGH, description="OpenAI API Key"),
    SecretRule("azure-ad-secret",
               r"(?:^|[\\'\"\s>=:(,)])([a-zA-Z0-9_~.]{3}\dQ~[a-zA-Z0-9_~.-]{31,34})(?:$|[\\'\"\s<),])",
               ("q~",), 3.0, HIGH, secret_group=1, description="Azure AD Client Secret"),
    # ---- source / CI (HIGH) ----
    SecretRule("github-pat", r"\b(ghp_[0-9a-zA-Z]{36})\b",
               ("ghp_",), 3.0, HIGH, description="GitHub Personal Access Token"),
    SecretRule("github-oauth", r"\b(gho_[0-9a-zA-Z]{36})\b",
               ("gho_",), 3.0, HIGH, description="GitHub OAuth Token"),
    SecretRule("github-app-token", r"\b((?:ghu|ghs)_[0-9a-zA-Z]{36})\b",
               ("ghu_", "ghs_"), 3.0, HIGH, description="GitHub App Token"),
    SecretRule("github-fine-pat", r"\b(github_pat_\w{82})\b",
               ("github_pat_",), 3.0, HIGH, description="GitHub Fine-Grained PAT"),
    SecretRule("gitlab-pat", r"\b(glpat-[\w-]{20})\b",
               ("glpat-",), 3.0, HIGH, description="GitLab PAT"),
    SecretRule("npm-token", r"\b(npm_[a-z0-9]{36})\b",
               ("npm_",), 2.0, HIGH, description="npm Access Token"),
    # ---- payments (HIGH) ----
    SecretRule("stripe-key", r"\b((?:sk|rk)_(?:test|live|prod)_[a-zA-Z0-9]{10,99})\b",
               ("sk_test", "sk_live", "sk_prod", "rk_test", "rk_live", "rk_prod"),
               2.0, HIGH, description="Stripe Access Token"),
    SecretRule("square-token", r"\b((?:EAAA|sq0atp-)[\w-]{22,60})\b",
               ("sq0atp-", "eaaa"), 2.0, HIGH, description="Square Access Token"),
    # ---- comms / services (HIGH) ----
    SecretRule("slack-bot-token", r"\b(xoxb-[0-9]{10,13}-[0-9]{10,13}[a-zA-Z0-9-]*)\b",
               ("xoxb",), 3.0, HIGH, description="Slack Bot Token"),
    SecretRule("slack-user-token", r"(xox[pe](?:-[0-9]{10,13}){3}-[a-zA-Z0-9-]{28,34})",
               ("xoxp-", "xoxe-"), 2.0, HIGH, description="Slack User Token"),
    SecretRule("slack-webhook",
               r"(https?://hooks\.slack\.com/(?:services|workflows|triggers)/[A-Za-z0-9+/]{43,56})",
               ("hooks.slack.com",), 0, HIGH, description="Slack Webhook URL"),
    SecretRule("sendgrid-key", r"\b(SG\.[a-zA-Z0-9=_\-\.]{66})\b",
               ("sg.",), 2.0, HIGH, description="SendGrid API Token"),
    SecretRule("twilio-key", r"\b(SK[0-9a-fA-F]{32})\b",
               ("sk",), 3.0, MEDIUM, description="Twilio API Key"),
    SecretRule("mailgun-key", r"(key-[0-9a-zA-Z]{32})",
               ("mailgun", "key-"), 2.0, MEDIUM, description="Mailgun API Key"),
    SecretRule("shopify-token", r"\b(shp(?:at|ca|pa|ss)_[a-fA-F0-9]{32})\b",
               ("shpat_", "shpca_", "shppa_", "shpss_"), 2.0, HIGH,
               description="Shopify Access Token"),
    SecretRule("heroku-key-v2", r"\b(HRKU-AA[0-9a-zA-Z_-]{58})\b",
               ("hrku-aa",), 4.0, HIGH, description="Heroku API Key"),
    # ---- tokens / generic-but-distinctive (HIGH/MEDIUM) ----
    SecretRule("jwt", r"\b(ey[a-zA-Z0-9]{17,}\.ey[a-zA-Z0-9\/\\_-]{17,}\.(?:[a-zA-Z0-9\/\\_-]{10,}={0,2})?)",
               ("ey",), 3.0, MEDIUM, description="JSON Web Token"),
    SecretRule("google-oauth", r"(ya29\.[0-9A-Za-z\-_]+)",
               ("ya29.",), 3.0, HIGH, description="Google OAuth Access Token"),
    SecretRule("facebook-token", r"\b(EAA[MC][a-zA-Z0-9]{100,})\b",
               ("eaam", "eaac"), 4.0, HIGH, description="Facebook Access Token"),
    # ---- private keys (HIGH) ----
    SecretRule("private-key",
               r"(-----BEGIN[ A-Z0-9_-]{0,100}PRIVATE KEY(?: BLOCK)?-----)",
               ("-----begin",), 0, HIGH, description="Private Key block"),
    # ---- generic catch-all (LOW — informational, high FP without entropy) ----
    SecretRule("generic-api-key",
               r"""(?i)(?:access|auth|api[_.-]?key|secret|token|password|passwd|credential)(?:[ \t\w.-]{0,20})['"\s:=]{1,4}['"]?([\w.=\-]{16,80})['"]?""",
               ("access", "auth", "api", "key", "secret", "token", "password",
                "passwd", "credential"),
               3.5, LOW, secret_group=1, description="Generic API Key / credential"),
]

# ---- allowlist: known-benign values to never report ----
ALLOWLIST_EXACT = {
    "AKIAIOSFODNN7EXAMPLE",                       # AWS docs example
    "AIzaSyabcdefghijklmnopqrstuvwxyz1234567",    # gitleaks example
}
ALLOWLIST_SUBSTRINGS = ("example", "test", "sample", "dummy", "placeholder",
                        "xxxxxx", "000000", "your_", "changeme")
# generic-rule stopwords (subset of Gitleaks' list — common words that ride the
# generic pattern). Lowercased compare.
STOPWORDS = {
    "true", "false", "null", "undefined", "function", "return", "object",
    "string", "number", "boolean", "default", "content", "property", "element",
    "className", "constructor", "prototype", "background", "position",
    "transition", "translate", "container", "identifier", "development",
    "production", "application", "environment", "configuration",
}


def _shannon_entropy(s: str) -> float:
    if not s:
        return 0.0
    counts = {}
    for c in s:
        counts[c] = counts.get(c, 0) + 1
    n = len(s)
    return -sum((c / n) * math.log2(c / n) for c in counts.values())


def _is_allowlisted(value: str) -> bool:
    if value in ALLOWLIST_EXACT:
        return True
    low = value.lower()
    if any(sub in low for sub in ALLOWLIST_SUBSTRINGS):
        return True
    if low in STOPWORDS:
        return True
    return False


@dataclass
class SecretFinding:
    rule_id: str
    description: str
    secret: str
    confidence: str
    filename: str
    context: str = ""
    entropy: float = 0.0

    def as_row(self) -> list:
        """CSV row for the internal report (Category, Detail, Source URL,
        Local Path, Notes). Secret shown in full (internal doc)."""
        note = (f"[{self.confidence.upper()}] {self.description} "
                f"(entropy={self.entropy:.1f}) | context: {self.context}")
        return ["Secret", self.secret, "", self.filename, note]


def _context(text: str, start: int, end: int, width: int = 60) -> str:
    a = max(0, start - width)
    b = min(len(text), end + width)
    snippet = text[a:b].replace("\n", " ").replace("\r", " ")
    return snippet.strip()


def scan_text(text: str, filename: str = "") -> list[SecretFinding]:
    """Scan a blob of JS/text for secrets. Returns findings (deduped by value)."""
    if not text:
        return []
    # beautify minified JS so matches and context are readable (size-guarded)
    scan_src = text
    if _HAS_BEAUTIFY and len(text) < 2_000_000:
        try:
            scan_src = jsbeautifier.beautify(text)
        except Exception:  # noqa: BLE001
            scan_src = text
    low = scan_src.lower()

    findings: list[SecretFinding] = []
    seen: set[str] = set()
    for rule in RULES:
        # keyword pre-filter (skip expensive regex if no keyword present)
        if rule.keywords and not any(k in low for k in rule.keywords):
            continue
        pat = rule.compile()
        for m in pat.finditer(scan_src):
            value = m.group(rule.secret_group) if rule.secret_group else m.group(0)
            if not value or value in seen:
                continue
            if _is_allowlisted(value):
                continue
            ent = _shannon_entropy(value)
            if rule.entropy and ent < rule.entropy:
                continue          # not random enough — likely FP
            seen.add(value)
            findings.append(SecretFinding(
                rule_id=rule.id, description=rule.description, secret=value,
                confidence=rule.confidence, filename=filename,
                context=_context(scan_src, m.start(), m.end()), entropy=ent,
            ))
    return findings


def scan_file(path) -> list[SecretFinding]:
    p = Path(path)
    try:
        text = p.read_text(errors="replace")
    except OSError:
        return []
    return scan_text(text, filename=str(p))


def scan_folder(js_dir) -> list[SecretFinding]:
    """Scan every .js file in a folder. Returns all findings."""
    js_dir = Path(js_dir)
    out: list[SecretFinding] = []
    for p in sorted(js_dir.glob("*.js")):
        out.extend(scan_file(p))
    return out
