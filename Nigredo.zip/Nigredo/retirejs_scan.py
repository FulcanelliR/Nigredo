#!/usr/bin/env python3
"""
retirejs_scan.py — retire.js integration for FunnelWeb (Phase B).

Scans the JavaScript that FunnelWeb already downloaded into <domain>/js/ for
known-vulnerable library versions, using RetireJS (https://github.com/retirejs/retire.js/).

Because FunnelWeb saves the JS locally, retire.js runs against that folder — no
extra requests to the target. For each vulnerable component it records:
  - component name + version
  - severity
  - CVE(s) if present
  - when NO CVE is assigned: the GHSA/githubID + advisory URL, so the component
    can be looked up on Snyk (https://security.snyk.io) or GitHub Advisories by
    hand. (retire.js gives the advisory identifiers even when NVD hasn't issued
    a CVE yet.)

  retire --path <js_dir> --outputformat json --outputpath <file>

Requires the `retire` CLI (npm install -g retire). Graceful skip if absent.
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass, field
from pathlib import Path


def retirejs_available() -> bool:
    return shutil.which("retire") is not None


@dataclass
class RetireFinding:
    component: str = ""
    version: str = ""
    severity: str = ""
    cves: list = field(default_factory=list)
    ghsa: str = ""              # GHSA / githubID when no CVE
    advisory_url: str = ""      # where to look it up (Snyk/GitHub advisory)
    summary: str = ""
    file: str = ""

    def as_row(self) -> list:
        """Row aligned with FunnelWeb summary CSV: Category, Detail, Source, Local, Notes."""
        cve_str = ", ".join(self.cves) if self.cves else ""
        # when no CVE, surface the GHSA + lookup URL so it can be checked manually
        if cve_str:
            ident = cve_str
        elif self.ghsa:
            ident = f"{self.ghsa} (no CVE — look up on Snyk/GitHub)"
        else:
            ident = "no CVE/advisory id"
        detail = f"{self.component} {self.version}"
        note = f"[{self.severity}] {ident}"
        if self.advisory_url:
            note += f" — {self.advisory_url}"
        elif self.summary:
            note += f" — {self.summary[:120]}"
        return ["Retire.js Finding", detail, self.file, self.advisory_url, note]


def _best_advisory_url(vuln: dict, cves: list, ghsa: str) -> str:
    """Pick the most useful lookup URL. Prefer a Snyk or GitHub advisory link
    from the info[] list; else construct a GitHub advisory URL from the GHSA;
    else the first info URL."""
    info = vuln.get("info") or []
    for u in info:
        lu = u.lower()
        if "snyk.io" in lu or "github.com/advisories" in lu or "ghsa" in lu:
            return u
    if ghsa and ghsa.upper().startswith("GHSA"):
        return f"https://github.com/advisories/{ghsa}"
    return info[0] if info else ""


def run(js_dir: Path, out_json: Path, timeout: int = 300) -> list[RetireFinding]:
    """Run retire.js over js_dir, parse results. Empty list if retire missing or
    no JS/vulns."""
    js_dir = Path(js_dir)
    if not retirejs_available():
        print("[retire.js] not installed — skipping JS vuln scan "
              "(npm install -g retire)")
        return []
    if not js_dir.is_dir() or not any(js_dir.rglob("*.js")):
        print("[retire.js] no downloaded JS to scan")
        return []

    cmd = ["retire", "--path", str(js_dir), "--outputformat", "json",
           "--outputpath", str(out_json)]
    print(f"[retire.js] scanning {js_dir} for vulnerable JS libraries")
    try:
        # retire exits 13 when it finds vulns — that's success, not an error
        subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        print("[retire.js] timed out")
        return []
    except OSError as e:
        print(f"[retire.js] failed to run: {e}")
        return []

    if not Path(out_json).is_file():
        return []
    try:
        data = json.loads(Path(out_json).read_text(errors="replace"))
    except ValueError:
        print("[retire.js] could not parse JSON output")
        return []

    findings: list[RetireFinding] = []
    # retire json: {"data": [{"file":..., "results":[{"component","version",
    #   "vulnerabilities":[{"severity","identifiers":{"CVE":[],"summary","githubID"},"info":[]}]}]}]}
    entries = data.get("data") if isinstance(data, dict) else data
    for entry in entries or []:
        fpath = entry.get("file", "")
        for result in entry.get("results", []) or []:
            comp = result.get("component", "")
            ver = result.get("version", "")
            vulns = result.get("vulnerabilities", []) or []
            if vulns:
                for vuln in vulns:
                    sev = (vuln.get("severity", "") or "").upper()
                    idents = vuln.get("identifiers", {}) or {}
                    cves = idents.get("CVE", []) or []
                    ghsa = idents.get("githubID", "") or ""
                    summary = idents.get("summary", "") or ""
                    advisory = _best_advisory_url(vuln, cves, ghsa)
                    findings.append(RetireFinding(
                        component=comp, version=ver, severity=sev, cves=cves,
                        ghsa=ghsa, advisory_url=advisory, summary=summary,
                        file=fpath))
            else:
                # Component identified but NO known vuln. Record it anyway — the
                # JS component/version inventory is useful recon on its own
                # (knowing the exact library versions in use), and flags nothing
                # is being silently dropped. Marked severity NONE so it sorts to
                # the bottom and is visually distinct from real vulns.
                if comp or ver:
                    findings.append(RetireFinding(
                        component=comp, version=ver, severity="NONE", cves=[],
                        ghsa="", advisory_url="", summary="(no known vulnerability "
                        "— inventory only)", file=fpath))

    # sort by severity
    sev_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "NONE": 5}
    findings.sort(key=lambda f: sev_rank.get(f.severity, 4))
    no_cve = sum(1 for f in findings if not f.cves)
    print(f"[retire.js] {len(findings)} finding(s)"
          f"{f', {no_cve} without a CVE (GHSA/advisory recorded)' if no_cve else ''}")
    return findings


def summary_rows(findings: list[RetireFinding]) -> list[list]:
    return [f.as_row() for f in findings]


def high_count(findings: list[RetireFinding]) -> int:
    return sum(1 for f in findings if f.severity in ("HIGH", "CRITICAL"))
